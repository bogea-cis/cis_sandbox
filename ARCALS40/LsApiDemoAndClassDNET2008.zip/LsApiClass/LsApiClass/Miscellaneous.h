// Funzioni di supporto
#include <windows.h>

#include "LsApi_Define.h"

#pragma once

using namespace System;
using namespace System::IO;
using namespace System::Runtime::InteropServices;
using namespace System::Runtime::Serialization;
using namespace System::Reflection;
#using <System.Drawing.dll>

namespace Miscellaneous {

	public ref class Func
	{
		// Classe che exporta le define della classe
	public :
		static bool ConvertClassBitmapToDIB(System::Drawing::Bitmap ^hImage, char **pBitmap);

		static void SetResolution(HANDLE hImage, System::Drawing::Bitmap ^bImage);

		static void CreateBitmapFileHeader(HANDLE pImage, Byte *bfh, int *DimImage);

		static void ConvertBitmapTo32Bit(Byte *pImage, Byte **pImage32, int *DimImage);
	};
}

