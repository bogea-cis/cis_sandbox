
#include "stdafx.h"

#include "Miscellaneous.h"


#define R100_PELSMETER					3937L	/* 100dpi/25.4(mmxinch)*1000 */
#define R200_PELSMETER					7874L	/* 200dpi/25.4(mmxinch)*1000 */
#define R300_PELSMETER					11811L	/* 300dpi/25.4(mmxinch)*1000 */
#define	IMAGE_099_DPI					99
#define	IMAGE_100_DPI					100
#define	IMAGE_199_DPI					199
#define	IMAGE_200_DPI					200
#define	IMAGE_299_DPI					299
#define	IMAGE_300_DPI					300


void Miscellaneous::Func::SetResolution(HANDLE hImage, System::Drawing::Bitmap ^bImage)
{
	float ResolutionMode;

	switch( ((BITMAPINFOHEADER *)hImage)->biXPelsPerMeter )
	{
	case R100_PELSMETER:
		ResolutionMode = IMAGE_100_DPI;
		break;
	case R200_PELSMETER:
		ResolutionMode = IMAGE_200_DPI;
		break;
	case R300_PELSMETER:
		ResolutionMode = IMAGE_300_DPI;
		break;
	default:	// Per 240 dpi !
		ResolutionMode = IMAGE_200_DPI;
		break;
	}

	bImage->SetResolution(ResolutionMode, ResolutionMode);

} // SetResolution


// -------------------------------------------------------------------------
//  FUNCTION : NSetInfoBmap_BW
// 
//  Compile bitmap header and RGBQUAD structures for bitmap bw.
// -------------------------------------------------------------------------
void NSetInfoBmap_BW(char	*lpImgBmp,
					 long	ImageWidth,
					 long	ImageHeight)
{
	BITMAPINFO  *pbmi;
	long	CondDib;


	// Compile bitmap header
	pbmi = (BITMAPINFO *) lpImgBmp;

	pbmi->bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
	pbmi->bmiHeader.biWidth         = ImageWidth;
	pbmi->bmiHeader.biHeight        = ImageHeight;
	pbmi->bmiHeader.biPlanes        = 1;
	pbmi->bmiHeader.biBitCount      = 1;
	pbmi->bmiHeader.biCompression   = 0;

	// Arrotondo il numero di colonne ad un multiplo di 4 byte
	if( CondDib = (ImageWidth % 32) )
		ImageWidth = (ImageWidth + 32 - CondDib);

	pbmi->bmiHeader.biSizeImage     = ImageWidth * ImageHeight / 8;
	pbmi->bmiHeader.biXPelsPerMeter = R200_PELSMETER;
	pbmi->bmiHeader.biYPelsPerMeter = R200_PELSMETER;
	pbmi->bmiHeader.biClrUsed       = 0;
	pbmi->bmiHeader.biClrImportant  = 0;

	// Compile the two RGBQUAD structures.
	pbmi->bmiColors[0].rgbBlue      = 0x00;
	pbmi->bmiColors[0].rgbGreen     = 0x00;
	pbmi->bmiColors[0].rgbRed       = 0x00;
	pbmi->bmiColors[0].rgbReserved  = 0x00;

	pbmi->bmiColors[1].rgbBlue      = 0xFF;
	pbmi->bmiColors[1].rgbGreen     = 0xFF;
	pbmi->bmiColors[1].rgbRed       = 0xFF;
	pbmi->bmiColors[1].rgbReserved  = 0x00;

} // End NSetInfoBmap_BW

// -------------------------------------------------------------------------
//  FUNCTION : NSetInfoBmap_GR16                                                                           :
//                                                                             
//  Compile bitmap header and RGBQUAD structures for bitmap gr16, 100 and
//  200 dpi, brutto netto e alternato.
// -------------------------------------------------------------------------
void NSetInfoBmap_GR16(char	*lpImgBmp,
					   long	ImageWidth,
					   long	ImageHeight,
					   short	ResolutionMode)
{
	int		ii;
	unsigned char Val;
    BITMAPINFO  *pbmi;
	long	CondDib;


    // Compile bitmap header.
    pbmi = (BITMAPINFO *) lpImgBmp;

    pbmi->bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
    pbmi->bmiHeader.biWidth         = ImageWidth;
    pbmi->bmiHeader.biHeight        = ImageHeight;
    pbmi->bmiHeader.biPlanes        = 1;
    pbmi->bmiHeader.biBitCount      = 4;
    pbmi->bmiHeader.biCompression   = 0;

	if( ImageWidth % 2 )				// Se dispari aggiungo una colonna
		ImageWidth ++;
	ImageWidth /= 2;					// Ci sono 2 pixel in un byte
	if( CondDib = (ImageWidth % 4) )
		ImageWidth += (4 - CondDib);
    pbmi->bmiHeader.biSizeImage     = ImageHeight * ImageWidth;

	switch( ResolutionMode )
    {
	case IMAGE_099_DPI:
	case IMAGE_100_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R100_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R100_PELSMETER;
		break;

	case IMAGE_199_DPI:
	case IMAGE_200_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R200_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R200_PELSMETER;
		break;

	case IMAGE_299_DPI:
	case IMAGE_300_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R300_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R300_PELSMETER;
		break;
    }

    // Compile the 16 RGB QUAD STRUCTURES.
    pbmi->bmiHeader.biClrUsed       = 0;
    pbmi->bmiHeader.biClrImportant  = 0;

	for( ii = 0, Val = 0x00; ii < 16; ii ++, Val += 0x11)
	{
		pbmi->bmiColors[ii].rgbBlue      = Val;
		pbmi->bmiColors[ii].rgbGreen     = Val;
		pbmi->bmiColors[ii].rgbRed       = Val;
		pbmi->bmiColors[ii].rgbReserved  = 0x00;
	}

} // End NSetInfoBmap_GR16

// -------------------------------------------------------------------------
//  FUNCTION : NSetInfoBmap_GR256                                                                           :
//                                                                             
//  Compile bitmap header and RGBQUAD structures for bitmap gr256, 100 and
//  200 dpi.
// -------------------------------------------------------------------------
void NSetInfoBmap_GR256(char	*lpImgBmp,
						long	ImageWidth,
						long	ImageHeight,
						short	ResolutionMode)
{
	BITMAPINFO *pbmi;
	int        i;
	long	CondDib;


    // Compile bitmap header.
    pbmi = (BITMAPINFO *) lpImgBmp;

    pbmi->bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
    pbmi->bmiHeader.biWidth         = ImageWidth;
    pbmi->bmiHeader.biHeight        = ImageHeight;
    pbmi->bmiHeader.biPlanes        = 1;
    pbmi->bmiHeader.biBitCount      = 8;
    pbmi->bmiHeader.biCompression   = 0;

	if( CondDib = (ImageWidth % 4) )
		ImageWidth += (4 - CondDib);
    pbmi->bmiHeader.biSizeImage     = ImageHeight * ImageWidth;

    switch (ResolutionMode )
	{
	case IMAGE_099_DPI:
	case IMAGE_100_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R100_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R100_PELSMETER;
		break;

	case IMAGE_199_DPI:
	case IMAGE_200_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R200_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R200_PELSMETER;
		break;

	case IMAGE_299_DPI:
	case IMAGE_300_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R300_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R300_PELSMETER;
		break;
    }

    // Compile the 256 RGB QUAD STRUCTURES.
    pbmi->bmiHeader.biClrUsed       = 0;
    pbmi->bmiHeader.biClrImportant  = 0;

	for (i=0; i<256; i++)
	{
		pbmi->bmiColors[i].rgbBlue      = i;
		pbmi->bmiColors[i].rgbGreen     = i;
		pbmi->bmiColors[i].rgbRed       = i;
		pbmi->bmiColors[i].rgbReserved  = 0x00;
	}

} // End NSetInfoBmap_GR256

// -------------------------------------------------------------------------
//  FUNCTION : NSetInfoBmap_Color
//                                                                             
//  Compile bitmap header and RGBQUAD structures for color bitmap 
// -------------------------------------------------------------------------
void NSetInfoBmap_Color(char	*lpImgBmp,
						 long	ImageWidth,
						 long	ImageHeight,
						 short	ResolutionMode)
{
	BITMAPINFO *pbmi;
	long	CondDib;


    // Compile bitmap header.
    pbmi = (BITMAPINFO *) lpImgBmp;

    pbmi->bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
    pbmi->bmiHeader.biWidth         = ImageWidth;
    pbmi->bmiHeader.biHeight        = ImageHeight;
    pbmi->bmiHeader.biPlanes        = 1;
    pbmi->bmiHeader.biBitCount      = 24;
    pbmi->bmiHeader.biCompression   = BI_RGB;

	ImageWidth *= 3;					// Ha 3 pixel per colonna
	if( CondDib = (ImageWidth % 4) )
		ImageWidth += (4 - CondDib);
    pbmi->bmiHeader.biSizeImage     = ImageHeight * ImageWidth;


    switch (ResolutionMode )
	{
	case IMAGE_099_DPI:
	case IMAGE_100_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R100_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R100_PELSMETER;
		break;

	case IMAGE_199_DPI:
	case IMAGE_200_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R200_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R200_PELSMETER;
		break;

	case IMAGE_299_DPI:
	case IMAGE_300_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R300_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R300_PELSMETER;
		break;
    }

    pbmi->bmiHeader.biClrUsed       = 0;
    pbmi->bmiHeader.biClrImportant  = 0;

}  // End NSetInfoBmap_Color


// -------------------------------------------------------------------------
//  FUNCTION : ConvertClassBitmapToDIB
//
#define BITMAP_A_COLORI					0
#define BITMAP_BW						1
#define BITMAP_16_GRAY					4
#define BITMAP_256_GRAY					8
//
//  Coonverte una class bitmap in una bitmap DIB
// -------------------------------------------------------------------------
bool Miscellaneous::Func::ConvertClassBitmapToDIB(System::Drawing::Bitmap ^hImage, char **pBitmap)
{
	bool rc = true;
	// Non riesco ad avere l'handle dell'immagine dalla classe bitmap !
	// Allora la ricostruisco !!!
	//----------------------------
	int xx, yy, xxt;
	char *pData;
	int height;
	int width, bytes_width;
	int CondDib;
//	int BitCount;
	float ResolutionMode;
	System::Drawing::Color pixColor;
	unsigned char ByteBitmap;
	System::Drawing::Imaging::PixelFormat g_color;


	// Leggo l'altezza e la larghezza
	height = hImage->Height;
	width = hImage->Width;

	g_color = hImage->PixelFormat;
/*
	// Per sapere di che tipo ERA la bitmap ...
	BitCount = BITMAP_BW;
	// ... Faccio una passata sulla riga centrale ...
	yy = height / 2;
	for( xx = 0; ((xx < width) && (BitCount != BITMAP_A_COLORI)); xx ++)
	{
		pixColor = hImage->GetPixel(xx, yy);
		if( BitCount == BITMAP_BW )
		{
			if( (pixColor.R % 0xff) || (pixColor.G % 0xff) || (pixColor.B % 0xff) )
				BitCount = BITMAP_16_GRAY;
		}
		if( BitCount == BITMAP_16_GRAY )
		{
			if( (pixColor.R % 0x11) || (pixColor.G % 0x11) || (pixColor.B % 0x11))
				BitCount = BITMAP_256_GRAY;
		}
		if( BitCount == BITMAP_256_GRAY )
		{
			if( (pixColor.R != pixColor.G) || (pixColor.R != pixColor.B) || (pixColor.G != pixColor.B))
				BitCount = BITMAP_A_COLORI;
		}
	}

	// ... ed una passata sulla colonna centrale
	xx = width / 2;
	for( yy = 0; ((yy < height) && (BitCount != BITMAP_A_COLORI)); yy ++)
	{
		pixColor = hImage->GetPixel(xx, yy);
		if( BitCount == BITMAP_BW )
		{
			if( (pixColor.R % 0xff) || (pixColor.G % 0xff) || (pixColor.B % 0xff) )
				BitCount = BITMAP_16_GRAY;
		}
		if( BitCount == BITMAP_16_GRAY )
		{
			if( (pixColor.R % 0x11) || (pixColor.G % 0x11) || (pixColor.B % 0x11))
				BitCount = BITMAP_256_GRAY;
		}
		if( BitCount == BITMAP_256_GRAY )
		{
			if( (pixColor.R != pixColor.G) || (pixColor.R != pixColor.B) || (pixColor.G != pixColor.B))
				BitCount = BITMAP_A_COLORI;
		}
	}
*/

	// The Bitmap class, contain a BW image !
//	if( BitCount == BITMAP_BW )
	if( g_color == System::Drawing::Imaging::PixelFormat::Format1bppIndexed )
	{
		bytes_width = width;
		if( CondDib = (bytes_width % 32) )
			bytes_width = bytes_width + (32 - CondDib);
		bytes_width /= 8;

		ResolutionMode = hImage->HorizontalResolution;
		// Alloco l'area per la bitmap + header
		*pBitmap = (char *)GlobalAlloc(GPTR, ((bytes_width * height) + 1000));

		if( *pBitmap )
		{
			pData = *pBitmap + sizeof(BITMAPINFOHEADER) + (2 * sizeof(RGBQUAD));

			// Build a B/W image !
			NSetInfoBmap_BW(*pBitmap, width, height);
			for( xx = (height - 1), xxt = 0; xx >= 0; xx --, xxt ++)
			{
				ByteBitmap = 0;
				for( yy = 0; yy < width; yy++ )
				{
					// Leggo il valore del pixel e lo salvo in byte,
					// poi comporr� 2 pixel in un byte
					pixColor = hImage->GetPixel(yy, xx);

					if( pixColor.G == 0xff )
					{
						// Compilo e Copio il byte
						switch( yy % 8 )
						{
						case 0:
							ByteBitmap |= 0x80;
							break;
						case 1:
							ByteBitmap |= 0x40;
							break;
						case 2:
							ByteBitmap |= 0x20;
							break;
						case 3:
							ByteBitmap |= 0x10;
							break;
						case 4:
							ByteBitmap |= 0x08;
							break;
						case 5:
							ByteBitmap |= 0x04;
							break;
						case 6:
							ByteBitmap |= 0x02;
							break;
						case 7:
							ByteBitmap |= 0x01;
							break;
						}
					}
					// Copio il byte nella bitmap
					if( (yy % 8) == 7 )
					{
						*(pData + (xxt * bytes_width) + (yy / 8)) = ByteBitmap;
						ByteBitmap = 0;
					}
				}
				// Copio il rimanente, in caso di nr colonne != da 8
				*(pData + (xxt * bytes_width) + (yy / 8)) = ByteBitmap;
			}
		}
		else
			rc = false;
	}

	// The Bitmap class, contain a 16 gray image !
//	else if( BitCount == BITMAP_16_GRAY )
	else if( g_color == System::Drawing::Imaging::PixelFormat::Format4bppIndexed )
	{
		bytes_width = width;
		if( CondDib = (bytes_width % 8) )
			bytes_width = bytes_width + (8 - CondDib);
		bytes_width /= 2;

		ResolutionMode = hImage->HorizontalResolution;
		// Alloco l'area per la bitmap + header
		*pBitmap = (char *)GlobalAlloc(GPTR, ((bytes_width * height) + 1000));

		if( *pBitmap )
		{
			pData = *pBitmap + sizeof(BITMAPINFOHEADER) + (16 * sizeof(RGBQUAD));

			// Build a image 16 gray !
			NSetInfoBmap_GR16(*pBitmap, width, height, (short)ResolutionMode);
			for( xx = (height - 1), xxt = 0; xx >= 0; xx --, xxt ++)
			{
				for( yy = 0; yy < width; yy++ )
				{
					// Leggo il valore del pixel e lo salvo in byte,
					// poi comporr� 2 pixel in un byte
					pixColor = hImage->GetPixel(yy, xx);

					// Compilo e Copio il byte
					if( yy % 2 )
					{
						ByteBitmap += (pixColor.G & 0x0f);
						*(pData + (xxt * bytes_width) + (yy / 2)) = ByteBitmap;
					}
					else
					{
						ByteBitmap = pixColor.G << 4;
					}
				}
				// Copio il mezzo byte in caso di colonne dispari
				*(pData + (xxt * bytes_width) + (yy / 2)) = ByteBitmap;
			}
		}
		else
			rc = false;
	}

	// The Bitmap class, contain a 256 gray image !
//	else if( BitCount == BITMAP_256_GRAY )
	else if( g_color == System::Drawing::Imaging::PixelFormat::Format8bppIndexed )
	{
		bytes_width = width;
		if( CondDib = (bytes_width % 4) )
			bytes_width = bytes_width + (4 - CondDib);

		ResolutionMode = hImage->HorizontalResolution;
		// Alloco l'area per la bitmap + header
		*pBitmap = (char *)GlobalAlloc(GPTR, ((bytes_width * height) + 2000));

		if( *pBitmap )
		{
			pData = *pBitmap + sizeof(BITMAPINFOHEADER) + (256 * sizeof(RGBQUAD));

			// Build a image 256 gray !
			NSetInfoBmap_GR256(*pBitmap, width, height, (short)ResolutionMode);
			for( xx = (height - 1), xxt = 0; xx >= 0; xx --, xxt ++)
				for( yy = 0; yy < width; yy++ )
				{
					// Ne copio uno xch� i 3 valori sono uguali
					pixColor = hImage->GetPixel(yy, xx);
					*(pData + (xxt * bytes_width) + yy) = pixColor.G;
				}
		}
		else
			rc = false;

		//{
		//	array<Byte>^dataArray;
		//	long lenData = ((bytes_width * height) + 2000);
		//	BITMAPFILEHEADER bh;
		//	DWORD	DimFile;
		//	long	nColorData = 256;

		//	//FileStream^ fWrite = gcnew FileStream(".\\Gray_256.bmp",
		//	//	FileMode::Create, FileSystemRights::Modify,
		//	//	FileShare::None, 8, FileOptions::None, fs);
		//	FileStream^ fWrite = gcnew FileStream(".\\Gray_256.bmp", FileMode::Create);

		//	//Calcolo dimensione della bitmap
		//	DimFile = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD)) + ((BITMAPINFOHEADER *)(*pBitmap))->biSizeImage;

		//	// Compilo l'header file e lo scrivo
		//	bh.bfType		= 0x4d42;		// Setto BF
		//	bh.bfSize		= DimFile;
		//	bh.bfReserved1	= 0;
		//	bh.bfReserved2	= 0;
		//	bh.bfOffBits	= sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD));	// struttura BITMAPINFOHEADER + tabella paletta

		//	// Converto char * in data array
		//	dataArray = gcnew array<Byte>( lenData );
		//	Marshal::Copy((IntPtr)(char *)(&bh), dataArray, 0, sizeof(BITMAPFILEHEADER));

		//	// Write the bytes to the file.
		//	fWrite->Write(dataArray, 0, sizeof(BITMAPFILEHEADER));


		//	// Converto BITMAPFILEHEADER in data array
		//	//dataArray = gcnew array<Byte>( lenData );
		//	Marshal::Copy((IntPtr)(char *)(*pBitmap), dataArray, 0, lenData);

		//	// Write the bytes to the file.
		//	fWrite->Write(dataArray, 0, lenData);

		//	// Close the stream.
		//	fWrite->Close();
		//}
	}

	// The Bitmap class, contain a color image !
//	else if( BitCount == BITMAP_A_COLORI )
	else if( g_color == System::Drawing::Imaging::PixelFormat::Format24bppRgb )
	{
		bytes_width = width * 3;
		if( CondDib = (bytes_width % 4) )
			bytes_width = bytes_width + (4 - CondDib);

		ResolutionMode = hImage->HorizontalResolution;
		// Alloco l'area per la bitmap + header
		*pBitmap = (char *)GlobalAlloc(GPTR, ((bytes_width * height) + 1000));

		if( *pBitmap )
		{
			pData = *pBitmap + sizeof(BITMAPINFOHEADER);

			// Build a color image !
			NSetInfoBmap_Color(*pBitmap, width, height, (short)ResolutionMode);
			for( xx = (height - 1), xxt = 0; xx >= 0; xx --, xxt ++)
				for( yy = 0; yy < width; yy++ )
				{
					pixColor = hImage->GetPixel(yy, xx);
					*(pData + (xxt * bytes_width) + (yy * 3)) = pixColor.B;
					*(pData + (xxt * bytes_width) + (yy * 3) + 1) = pixColor.G;
					*(pData + (xxt * bytes_width) + (yy * 3) + 2) = pixColor.R;
				}
		}
		else
			rc = false;
	}

	return rc;
} // ConvertClassBitmapToDIB


void Miscellaneous::Func::CreateBitmapFileHeader(HANDLE pImage, Byte *bfh, int *DimImage)
{
	BITMAPFILEHEADER *pBfh = (BITMAPFILEHEADER *)bfh;
	BITMAPINFOHEADER *pBih = (BITMAPINFOHEADER *)pImage;
	int		Height;
	int		Width, Width_bytes;
	int		CondDib;
	int		nColorData;
	int		BitCount;

	// Calcolo la dimensione della bitmap
	BitCount = pBih->biBitCount;
	Height = pBih->biHeight;
	Width = Width_bytes = pBih->biWidth;

	// Calcolo la dimensione della bitmap
	if( BitCount == BITMAP_BW )
	{
		if( CondDib = Width_bytes % 32 )
			Width_bytes += (32 - CondDib);
		Width_bytes /= 8;
	}
	else if( BitCount == BITMAP_16_GRAY )
	{
		if( CondDib = Width_bytes % 8 )
			Width_bytes += (8 - CondDib);
		Width_bytes /= 2;
	}
	else if( BitCount == BITMAP_256_GRAY )
	{
		if( CondDib = Width_bytes % 4 )
			Width_bytes += (4 - CondDib);
	}
	else if( BitCount == BITMAP_A_COLORI )
	{
		if( CondDib = Width_bytes % 4 )
			Width_bytes += (4 - CondDib);
	}

	// Calcolo nr elementi paletta
	if( BitCount <= 8 )
		nColorData = 1 << pBih->biBitCount;
	else
		nColorData = 0;

	//Calcolo e ritorno la dimensione della bitmap
	*DimImage = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD)) + pBih->biSizeImage;

	pBfh->bfType		= 0x4d42;		// Setto BF
	pBfh->bfSize		= *DimImage;
	pBfh->bfReserved1	= 0;
	pBfh->bfReserved2	= 0;
	pBfh->bfOffBits	= sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD));	// struttura BITMAPINFOHEADER + tabella paletta

} // CreateBitmapFileHeader


void Miscellaneous::Func::ConvertBitmapTo32Bit(Byte *pImage, Byte **pImage32, int *DimImage)
{
	int		xx, yy;
	BITMAPINFOHEADER *hImage = (BITMAPINFOHEADER *)pImage;
	BITMAPFILEHEADER *pBfh32;
	BITMAPINFOHEADER *pBih32;
	unsigned char	*pDati, *pDati32;
	int		Height;
	int		Width, Width_bytes, Width32_bytes;
	int		CondDib;
	int		nColorData;
	int		BitCount;
	unsigned char	pixel, ByteBitmap;


	BitCount = hImage->biBitCount;
	Height = hImage->biHeight;
	Width = Width_bytes = hImage->biWidth;

	// Calcolo la dimensione della bitmap
	if( BitCount == BITMAP_BW )
	{
		if( CondDib = Width_bytes % 32 )
			Width_bytes += (32 - CondDib);
		Width_bytes /= 8;
	}
	else if( BitCount == BITMAP_16_GRAY )
	{
		if( CondDib = Width_bytes % 8 )
			Width_bytes += (8 - CondDib);
		Width_bytes /= 2;
	}
	else if( BitCount == BITMAP_256_GRAY )
	{
		if( CondDib = Width_bytes % 4 )
			Width_bytes += (4 - CondDib);
	}
	else if( BitCount == BITMAP_A_COLORI )
	{
		if( CondDib = Width_bytes % 4 )
			Width_bytes += (4 - CondDib);
	}

	// Calcolo nr elementi paletta
	if( hImage->biBitCount <= 8 )
		nColorData = 1 << hImage->biBitCount;
	else
		nColorData = 0;


	// Calcolo la dimensione della bitmap a 32 bit
	Width32_bytes = Width * 4;
//	if( CondDib = Width32_bytes % 4 )
//		Width32_bytes += (4 - CondDib);

	*DimImage = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (Height * Width32_bytes);
	*pImage32 = (Byte *)::GlobalAlloc(GPTR, *DimImage);


	// Compilo il file header
	pBfh32 = (BITMAPFILEHEADER *)(*pImage32);
	pBfh32->bfType		= 0x4d42;		// Setto BF
	pBfh32->bfSize		= *DimImage;
	pBfh32->bfReserved1	= 0;
	pBfh32->bfReserved2	= 0;
	pBfh32->bfOffBits	= sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER); // + (nColorData * sizeof(RGBQUAD));	// tabella paletta nulla


	// Copio l'info header a cambio il valore di biBitCount
	pBih32 = (BITMAPINFOHEADER *)((*pImage32) + sizeof(BITMAPFILEHEADER));
	*pBih32 = *hImage;
	pBih32->biBitCount = 32;
	pBih32->biSizeImage = Height * Width32_bytes;


	// Compilo i pixel della bitmap a 32 bit
	pDati = pImage + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD));
	pDati32 = *pImage32 + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER); // + (nColorData * sizeof(RGBQUAD));	// tabella paletta nulla

	if( BitCount == BITMAP_BW )
	{
		for( yy = 0; yy < Height; yy ++)
		{
			for( xx = 0; xx < Width; xx ++ )
			{
				// Leggo il valore del pixel e lo salvo in byte
				if( xx % 8 )
					pixel = *(pDati + (Width_bytes * yy) + (xx / 8));

				// Compilo il byte da copiare
				switch( yy % 8 )
				{
				case 0:
					if( pixel & 0x80 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 1:
					if( pixel & 0x40 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 2:
					if( pixel & 0x20 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 3:
					if( pixel & 0x10 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 4:
					if( pixel & 0x08 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 5:
					if( pixel & 0x04 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 6:
					if( pixel & 0x02 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				case 7:
					if( pixel & 0x01 )
						ByteBitmap = 0xff;	// Bianco
					else
						ByteBitmap = 0x00;	// Nero
					break;
				}

				// Copio il byte nella bitmap
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4)) = ByteBitmap;
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 1) = ByteBitmap;
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 2) = ByteBitmap;
				*(pDati32 ++) = 0x00; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 3) = ByteBitmap;
			}
		}
	}

	// The Bitmap class, contain a 16 gray image !
	else if( BitCount == BITMAP_16_GRAY )
	{
		for( yy = 0; yy < Height; yy ++)
		{
			for( xx = 0; xx < Width; xx ++ )
			{
				// Leggo il valore del pixel e lo salvo in byte
				if( xx % 2 )
					pixel = *(pDati + (Width_bytes * yy) + (xx / 2));

				// Compilo il byte da copiare
				if( xx % 2 )
					ByteBitmap = ((pixel & 0xf0) >> 4) * 0x11;
				else
					ByteBitmap = (pixel & 0x0f) * 0x11;

				// Copio il byte nella bitmap
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4)) = ByteBitmap;
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 1) = ByteBitmap;
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 2) = ByteBitmap;
				*(pDati32 ++) = 0x00; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 3) = ByteBitmap;
			}
		}
	}

	// The Bitmap class, contain a 256 gray image !
	else if( BitCount == BITMAP_256_GRAY )
	{
		for( yy = 0; yy < Height; yy ++)
		{
			for( xx = 0; xx < Width; xx ++ )
			{
				// Leggo il valore del pixel e lo salvo in byte
				ByteBitmap = *(pDati + (Width_bytes * yy) + xx);

				// Copio il byte nella bitmap
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4)) = ByteBitmap;
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 1) = ByteBitmap;
				*(pDati32 ++) = ByteBitmap; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 2) = ByteBitmap;
				*(pDati32 ++) = 0x00; // *(pDati32 + (Width32_bytes * yy) + (xx * 4) + 3) = ByteBitmap;
			}
		}
	}

	// The Bitmap class, contain a color image !
	else if( BitCount == BITMAP_A_COLORI )
	{
		for( yy = 0; yy < Height; yy ++)
		{
			for( xx = 0; xx < Width; xx ++ )
			{
				// Leggo il valore del pixel e lo salvo in byte
				ByteBitmap = *(pDati + (Width_bytes * yy) + xx);

				// Copio il byte nella bitmap
				*(pDati32 ++) = *(pDati + (Width_bytes * yy) + xx);
				*(pDati32 ++) = *(pDati + (Width_bytes * yy) + xx + 1);
				*(pDati32 ++) = *(pDati + (Width_bytes * yy) + xx + 2);
				*(pDati32 ++) = 0x00;
			}
		}
	}

} // ConvertBitmapTo32Bit
