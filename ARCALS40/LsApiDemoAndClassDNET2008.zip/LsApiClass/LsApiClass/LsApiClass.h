// LsApiClass.h
#include <windows.h>

#include "LsApi.h"
#include "CtsIQA.h"
#include "LsApi_Define.h"

#pragma once

using namespace System;
using namespace System::IO;
using namespace System::Runtime::InteropServices;
using namespace System::Runtime::Serialization;
using namespace System::Reflection;
#using <System.Drawing.dll>
using namespace System::ComponentModel;


namespace LsFamily {

	public ref class LsHistory
	{
		public:

		short			Size;					// Size of the struct
		unsigned long	num_doc_handled;		// Nr. documents handled
		unsigned long	bourrage_feeder;		// Nr. jam in the feeder
		unsigned long	doc_retain_micr;		// Nr. documents retained after MICR header
		unsigned long	doc_retain_scan;		// Nr. documents retained after front scanning
		unsigned long	bourrage_stamp;			// Nr. jam at stamp document
		unsigned long	bourrage_film;			// Nr. jam during scan document
		unsigned long	bourrage_micr;			// Nr. jam during read MICR document
		unsigned long	bourrage_exit ;			//Ls100
		unsigned long	doc_cmc7_err;			// Nr. of document CMC7, read with error
		unsigned long	doc_e13b_err;			// Nr. of document E13B, read with error
		unsigned long	doc_barcode_err;		// Nr. of document Barcode, read with error
		unsigned long	doc_optic_err;			// Nr. of document OCR, read with error
		unsigned long	time_peripheral_on;		// Seconds peripheral time life
		unsigned long	nr_power_on;			// Nr. of time power ON
		unsigned long	doc_sorted;				// Nr. of document sortered
		unsigned long	doc_retain;				// Nr. of document retained
		unsigned long	jams_card;				// Jam in the card entry
		unsigned long	jams_micr;				// Jam during the MICR reading
		unsigned long	jams_scanner;			// Jam in the feeder
		unsigned long	num_turn_on;			// Nr. of power on
		unsigned long	doc_ink_jet;			// Nr. of document printed
		unsigned long	doc_stamp;				// Nr. of document stamped
		unsigned long	jam_feeder;				// Nr. jam in the feeder
		unsigned long	jam_front_scanner;		// Jam in scanner front
		unsigned long	jam_track_left;			// Jam in the left track
		unsigned long	jam_track_right;		// Jam in the right track
		unsigned long	jam_back_scanner;		// Jam in scanner back
		unsigned long	jam_in_the_sorters;		// Jam in sorters track
		unsigned long	doc_printed;			// Nr. of documents printed
		unsigned long	nr_double_leafing;		// Nr. double leafing occurs
		
		char  ^stTime;	
	};

	public ref class LsDefines
	{
		// Classe che exporta le define della classe
	public :
		enum class LsUnitType
		{
			LS_40_LSCONNECT	= 39,		// Define for LsConnect
			LS_40_USB = 40,				// Define for connect LS40
			LS_100_USB = 100,			// Define for connect LS100
			LS_100_LSCONNECT = 109,     // Define for LsConnect
			LS_100_ETH = 110,			// Dfines for connect LS100 IP
			LS_150_LSCONNECT = 149,     // Define for LsConnect
			LS_150_USB = 150,			// Define for connect LS150
			LS_150_ETH = 151,			// Define for connect LS150 IP
			LS_515_LSCONNECT = 501,     // Define for LsConnect
			LS_515_USB = 502,			// Define for connect LS515
			LS_520_USB = 503,			// Define for connect LS520
			LS_800_USB = 801,			// Define for connect LS800
		};

		enum class Stamp
		{
			STAMP_NO = 0,				// No stamp is done
			STAMP_FRONT = 1,			// Stamp on front document
			STAMP_BACK = 2,				// Stamp on rear document
			STAMP_FRONT_AND_BACK = 3,	// Stamp front and rear document
		};

		enum class PrintValidate
		{
			PRINT_VALIDATE_NO = 0,			// No print is done
			PRINT_VALIDATE_YES = 1,			// Print done
			PRINT_VALIDATE_WITH_LOGO = 5,	// Print logo and lines
		};

		enum class Feeder
		{
			FEED_AUTO = 0,				// Start Document from Feeder
			FEED_FROM_PATH = 1,			// Start Document from Unit Path
		};

		enum class Sorter
		{
			SORTER_DOC_HOLDED = 0,
			SORTER_POCKET_1 = 1,
			SORTER_POCKET_2 = 2,
			SORTER_AUTOMATIC = 3,
			SORTER_SWICTH_1_TO_2 = 4,
			SORTER_DOC_EJECTED = 5,
			SORTER_ON_CODELINE_CALLBACK = 6,

			// For Ls800 unit
			SORTER_CIRCULAR = 48,
			SORTER_SEQUENTIAL = 49,
			SORTER_POCKET_0_SELECTED = 50,
			SORTER_POCKET_1_SELECTED = 51,
			SORTER_POCKET_2_SELECTED = 52,
			SORTER_POCKET_3_SELECTED = 53,
			SORTER_POCKET_4_SELECTED = 54,
			SORTER_POCKET_5_SELECTED = 55,
			SORTER_POCKET_6_SELECTED = 56,
			SORTER_POCKET_7_SELECTED = 57,
			SORTER_POCKET_8_SELECTED = 58,
			SORTER_POCKET_9_SELECTED = 59,
			SORTER_POCKET_10_SELECTED = 60,
			SORTER_POCKET_11_SELECTED = 61,
			SORTER_POCKET_12_SELECTED = 62,
			SORTER_POCKET_13_SELECTED = 63,
			SORTER_POCKET_14_SELECTED = 64,
			SORTER_POCKET_15_SELECTED = 65,
			SORTER_POCKET_16_SELECTED = 66,
			SORTER_POCKET_17_SELECTED = 67,
			SORTER_POCKET_18_SELECTED = 68,
			SORTER_POCKET_19_SELECTED = 69,
			SORTER_POCKET_20_SELECTED = 70,
			SORTER_POCKET_21_SELECTED = 71,
		};

		enum class CodelineToRead
		{
			READ_CODELINE_HW_NO = 0,
			READ_CODELINE_HW_MICR = 1,
			READ_CODELINE_E13B_MICR_WITH_OCR = 15 , 

			READ_CODELINE_SW_OCRA = 'A',
			READ_CODELINE_SW_OCRB_NUM = 'B',
			READ_CODELINE_SW_OCRB_ALFANUM = 'C',
			READ_CODELINE_SW_OCRB_ITALY = 'F',
			READ_CODELINE_SW_E13B = 'E',
			READ_CODELINE_SW_E13B_X_OCRB = 'X',

			READ_BARCODE_2_OF_5 = 50,
			READ_BARCODE_CODE39 = 51,
			READ_BARCODE_CODE128 = 52,
			READ_BARCODE_EAN13 = 53,
		};

		enum class Unit
		{
			UNIT_MM = 0,
			UNIT_INCH = 1,
		};

//		enum class OcrHeight
//		{
		static const double OCR_MAX_HEIGHT_IN_MM = 10.5;
		static const double OCR_MAX_HEIGHT_IN_INCH = 0.41;
//		};

		enum class BlankInCodeline
		{
			BLANK_IN_CODELINE_NO = 0,
			BLANK_IN_CODELINE_YES = 1,
		};

		enum class OriginOCR
		{
			ORIGIN_BOTTOM_RIGHT_MM = 10,
			ORIGIN_BOTTOM_RIGHT_INCH = 20,
		};

		enum class ScanMode
		{
			SCAN_MODE_BW = 1,
			SCAN_MODE_16_GRAY_100 = 2,
			SCAN_MODE_16_GRAY_200 = 3,
			SCAN_MODE_256_GRAY_100 = 4,
			SCAN_MODE_256_GRAY_200 = 5,
			SCAN_MODE_COLOR_100 = 10,
			SCAN_MODE_COLOR_200 = 11,
			SCAN_MODE_16_GRAY_300 = 20,
			SCAN_MODE_256_GRAY_300 = 21,
			SCAN_MODE_COLOR_300	= 22,
			SCAN_MODE_256GR100_AND_UV = 40,
			SCAN_MODE_256GR200_AND_UV = 41,
			SCAN_MODE_256GR300_AND_UV = 42,
			SCAN_MODE_A4_BW_200 = 100,
			SCAN_MODE_A4_BW_300 = 101,
			SCAN_MODE_A4_GRAY_200 = 102,
			SCAN_MODE_A4_GRAY_300 = 103,
			SCAN_MODE_A4_COLOR_200 = 104,
			SCAN_MODE_A4_COLOR_300 = 105,
			

		};

		enum class ScanDocType
		{
			SCAN_PAPER_DOCUMENT = 0 ,
			SCAN_CARD = 1 , 
		};

		enum class Side
		{
			SIDE_NONE_IMAGE = 'N',
			SIDE_FRONT_IMAGE = 'F',
			SIDE_BACK_IMAGE = 'B',
			SIDE_ALL_IMAGE = 'X',
			SIDE_FRONT_UV ='U' ,
			SIDE_FRONT_MERGED = 'M' ,
			
		};

		enum class Wait
		{
			WAIT_NO = 'G',
			WAIT_YES = 'W',
		};

		enum class Beep
		{
			BEEP_NO = 0,
			BEEP_YES = 1,
		};

		enum class ClearBlack
		{
			CLEAR_BLACK_NO = 0,
			CLEAR_BLACK_YES = 1,
			CLEAR_AND_ALIGN_IMAGE = 2 , 
		};

		enum class PrintFont
		{
			PRINT_FORMAT_NORMAL = 'N',
			PRINT_FORMAT_BOLD = 'B',
			PRINT_FORMAT_NORMAL_15 = 'A',
			PRINT_FORMAT_DOUBLE_HIGH = 'D',

			PRINT_UP_FORMAT_NORMAL = 'n',
			PRINT_UP_FORMAT_BOLD = 'b',
			PRINT_UP_FORMAT_NORMAL_15_CHAR = 'a',
		};

		enum class DoubleLeafing
		{

			DOUBLE_LEAFING_WARNING = 0 ,
			DOUBLE_LEAFING_ERROR = 1 ,
			//DOUBLE_LEAFING_LEVEL1 = 1,non lo uso piu'
			DOUBLE_LEAFING_LEVEL2 = 2,
			DOUBLE_LEAFING_LEVEL3 = 3,
			DOUBLE_LEAFING_DEFAULT = 4,
			DOUBLE_LEAFING_LEVEL4 = 5,
			DOUBLE_LEAFING_LEVEL5 = 6,
			DOUBLE_LEAFING_DISABLE = 7,
		};

		

		enum class Reset
		{
			RESET_ERROR = '0',
			RESET_PATH = '1',
			RESET_BELT_CLEANING	= '2',
		};

		enum class ImageSave
		{
			IMAGE_SAVE_ON_FILE = 4,
			IMAGE_SAVE_HANDLE = 5,
			IMAGE_SAVE_BOTH = 6,
			IMAGE_SAVE_NONE = 7,
		};

		enum class FileType
		{
			FILE_JPEG = 10,
			FILE_BMP = 11,
			FILE_TIF = 3,
			FILE_CCITT = 25,
			FILE_CCITT_GROUP3_1DIM = 27,
			FILE_CCITT_GROUP3_2DIM = 28,
			FILE_CCITT_GROUP4 = 29,
		};

		enum class FileAttribute
		{
			SAVE_OVERWRITE = 0,
			SAVE_APPEND = 1,
			SAVE_REPLACE = 2,
			SAVE_INSERT = 3,
		};

		enum class Badge
		{
			BADGE_READ_TRACK_1 = 0x20,
			BADGE_READ_TRACK_2 = 0x40,
			BADGE_READ_TRACK_3 = 0x80,
			BADGE_READ_TRACKS_1_2 = 0x60,
			BADGE_READ_TRACKS_2_3 = 0xc0,
			BADGE_READ_TRACKS_1_2_3 = 0xe0,
		};

		
	};


	public ref class LsReply
	{
	public :
		// ------------------------------------------------------------------------
		//                          REPLY-CODE
		// ------------------------------------------------------------------------

		static const int LS_OKAY							= 0;

		// ------------------------------------------------------------------------
		//                  ERRORS
		// ------------------------------------------------------------------------
		static const int LS_SYSTEM_ERROR					= -1;
		static const int LS_USB_ERROR						= -2;
		static const int LS_PERIPHERAL_NOT_FOUND			= -3;
		static const int LS_HARDWARE_ERROR					= -4;
		static const int LS_PERIPHERAL_OFF_ON				= -5;
		static const int LS_RESERVED_ERROR					= -6;
		static const int LS_PAPER_JAM						= -7;
		static const int LS_TARGET_BUSY						= -8;
		static const int LS_INVALID_COMMAND					= -9;
		static const int LS_DATA_LOST						= -10;
		static const int LS_COMMAND_IN_EXECUTION_YET		= -11;
		static const int LS_JPEG_ERROR						= -12;
		static const int LS_COMMAND_SEQUENCE_ERROR			= -13;
		static const int LS_PC_HW_ERROR						= -14;
		static const int LS_IMAGE_OVERWRITE					= -15;
		static const int LS_INVALID_HANDLE					= -16;
		static const int LS_NO_LIBRARY_LOAD					= -17;
		static const int LS_BMP_ERROR						= -18;
		static const int LS_TIFF_ERROR						= -19;
		static const int LS_IMAGE_NO_MORE_AVAILABLE			= -20;
		static const int LS_IMAGE_NO_FILMED					= -21;
		static const int LS_IMAGE_NOT_PRESENT				= -22;
		static const int LS_FUNCTION_NOT_AVAILABLE			= -23;
		static const int LS_DOCUMENT_NOT_SUPPORTED			= -24;
		static const int LS_BARCODE_ERROR					= -25;
		static const int LS_INVALID_LIBRARY					= -26;
		static const int LS_INVALID_IMAGE					= -27;
		static const int LS_INVALID_IMAGE_FORMAT			= -28;
		static const int LS_INVALID_BARCODE_TYPE			= -29;
		static const int LS_OPEN_NOT_DONE					= -30;
		static const int LS_INVALID_TYPE_COMMAND			= -31;
		static const int LS_INVALID_CLEARBLACK				= -32;
		static const int LS_INVALID_SIDE					= -33;
		static const int LS_MISSING_IMAGE					= -34;
		static const int LS_INVALID_TYPE					= -35;
		static const int LS_INVALID_SAVEMODE				= -36;
		static const int LS_INVALID_PAGE_NUMBER				= -37;
		static const int LS_INVALID_NRIMAGE					= -38;
		static const int LS_INVALID_STAMP					= -39;
		static const int LS_INVALID_WAITTIMEOUT				= -40;
		static const int LS_INVALID_VALIDATE				= -41;
		static const int LS_INVALID_CODELINE_TYPE			= -42;
		static const int LS_MISSING_NRIMAGE					= -43;
		static const int LS_INVALID_SCANMODE				= -44;
		static const int LS_INVALID_BEEP					= -45;
		static const int LS_INVALID_FEEDER					= -46;
		static const int LS_INVALID_SORTER					= -47;
		static const int LS_INVALID_BADGE_TRACK				= -48;
		static const int LS_MISSING_FILENAME				= -49;
		static const int LS_INVALID_QUALITY					= -50;
		static const int LS_INVALID_FILEFORMAT				= -51;
		static const int LS_INVALID_COORDINATE				= -52;
		static const int LS_MISSING_HANDLE_VARIABLE			= -53;
		static const int LS_INVALID_POLO_FILTER				= -54;
		static const int LS_INVALID_ORIGIN_MEASURES			= -55;
		static const int LS_INVALID_SIZEH_VALUE				= -56;
		static const int LS_INVALID_FORMAT					= -57;
		static const int LS_STRINGS_TOO_LONGS				= -58;
		static const int LS_READ_IMAGE_FAILED				= -59;
		static const int LS_INVALID_CMD_HISTORY				= -60;
		static const int LS_MISSING_BUFFER_HISTORY			= -61;
		static const int LS_INVALID_ANSWER					= -62;
		static const int LS_OPEN_FILE_ERROR_OR_NOT_FOUND	= -63;
		static const int LS_READ_TIMEOUT_EXPIRED			= -64;
		static const int LS_INVALID_METHOD					= -65;
		static const int LS_CALIBRATION_FAILED				= -66;
		static const int LS_INVALID_SAVEIMAGE				= -67;
		static const int LS_INVALID_UNIT					= -68;
		static const int LS_INVALID_NRWINDOWS				= -71;
		static const int LS_INVALID_VALUE					= -72;
		static const int LS_ILLEGAL_REQUEST					= -73;
		static const int LS_INVALID_NR_CRITERIA				= -74;
		static const int LS_MISSING_CRITERIA_STRUCTURE		= -75;
		static const int LS_INVALID_MOVEMENT				= -76;
		static const int LS_INVALID_DEGREE					= -77;
		static const int LS_R0TATE_ERROR					= -78;
		static const int LS_MICR_VALUE_OUT_OF_RANGE			= -79;
		static const int LS_PERIPHERAL_RESERVED				= -80;
		static const int LS_INVALID_NCHANGE					= -81;
		static const int LS_BRIGHTNESS_ERROR				= -82;
		static const int LS_CONTRAST_ERROR					= -83;
		static const int LS_INVALID_SIDETOPRINT				= -84;
		static const int LS_DOUBLE_LEAFING_ERROR			= -85;
		static const int LS_INVALID_BADGE_TIMEOUT			= -86;
		static const int LS_INVALID_RESET_TYPE				= -87;
		static const int LS_MISSING_SET_CALLBACK			= -88;
		static const int LS_IMAGE_NOT_200_DPI				= -89;
		static const int LS_DOWNLOAD_ERROR					= -90;
		static const int LS_INVALID_SORT_ON_CHOICE			= -91;
	
		static const int LS_JAM_AT_MICR_PHOTO				=-201;
		static const int LS_JAM_DOC_TOO_LONG				=-202;
		static const int LS_JAM_AT_SCANNER_PHOTO			=-203;
						
		static const int LS_SCAN_NETTO_IMAGE_NOT_SUPPORTED	= -521;
		static const int LS_256_GRAY_NOT_SUPPORTED			= -522;
		static const int LS_INVALID_PATH					= -523;
		static const int LS_MISSING_CALLBACK_FUNCTION		= -526;
		static const int LS_INVALID_OCR_IMAGE_SIDE			= -558;
		static const int LS_PERIPHERAL_NOT_ANSWER			= -599;

		static const int LS_INVALID_CONNECTION_HANDLE		= -1000;
		static const int LS_INVALID_CONNECT_PERIPHERAL		= -1001;
		static const int LS_PERIPHERAL_NOT_YET_INTEGRATE	= -1002;
		static const int LS_UNKNOW_PERIPHERAL_REPLY			= -1003;
		static const int LS_CODELINE_ALREADY_DEFINED		= -1004;
		static const int LS_INVALID_NUMBER_OF_DOC			= -1005;

		static const int LS_DECODE_FONT_NOT_PRESENT			= -1101;
		static const int LS_DECODE_INVALID_COORDINATE		= -1102;
		static const int LS_DECODE_INVALID_OPTION			= -1103;
		static const int LS_DECODE_INVALID_CODELINE_TYPE	= -1104;
		static const int LS_DECODE_SYSTEM_ERROR				= -1105;
		static const int LS_DECODE_DATA_TRUNC				= -1106;
		static const int LS_DECODE_INVALID_BITMAP			= -1107;
		static const int LS_DECODE_ILLEGAL_USE				= -1108;

		static const int LS_BARCODE_GENERIC_ERROR		    = -1201;
		static const int LS_BARCODE_NOT_DECODABLE			= -1202;
		static const int LS_BARCODE_OPENFILE_ERROR			= -1203;
		static const int LS_BARCODE_READBMP_ERROR		    = -1204;
		static const int LS_BARCODE_MEMORY_ERROR			= -1205;
		static const int LS_BARCODE_START_NOTFOUND			= -1206;
		static const int LS_BARCODE_STOP_NOTFOUND			= -1207;

		static const int LS_PDF_NOT_DECODABLE				= -1301;
		static const int LS_PDF_READBMP_ERROR				= -1302;
		static const int LS_PDF_BITMAP_FORMAT_ERROR			= -1303;
		static const int LS_PDF_MEMORY_ERROR				= -1304;
		static const int LS_PDF_START_NOTFOUND				= -1305;
		static const int LS_PDF_STOP_NOTFOUND				= -1306;
		static const int LS_PDF_LEFTIND_ERROR				= -1307;
		static const int LS_PDF_RIGHTIND_ERROR				= -1308;
		static const int LS_PDF_OPENFILE_ERROR				= -1309;

// ------------------------------------------------------------------------
//                  WARNINGS
// ------------------------------------------------------------------------
		static const int LS_FEEDER_EMPTY					= 1;
		static const int LS_DATA_TRUNCATED					= 2;
		static const int LS_DOC_PRESENT						= 3;
		static const int LS_BADGE_TIMEOUT					= 4;
		static const int LS_ALREADY_OPEN					= 5;
		static const int LS_PERIPHERAL_BUSY					= 6;
		static const int LS_DOUBLE_LEAFING_WARNING			= 7;
		static const int LS_COMMAND_NOT_ENDED				= 8;
		static const int LS_RETRY							= 9;
		static const int LS_NO_OTHER_DOCUMENT				= 10;
		static const int LS_QUEUE_FULL						= 11;
		static const int LS_NO_SENSE						= 12;
		static const int LS_TRY_TO_RESET					= 14;
		static const int LS_STRING_TRUNCATED				= 15;
		static const int LS_COMMAND_NOT_SUPPORTED			= 19;
		static const int LS_SORTER1_FULL					= 35;
		static const int LS_SORTER2_FULL					= 36;
		static const int LS_SORTERS_BOTH_FULL				= 37;
		static const int LS_KEEP_DOC_ON_CODELINE_ERROR		= 39;
		static const int LS_LOOP_INTERRUPTED				= 40;

		static const int LS_SORTER_1_POCKET_1_FULL			= 51;
		static const int LS_SORTER_1_POCKET_2_FULL			= 52;
		static const int LS_SORTER_1_POCKET_3_FULL			= 53;
		static const int LS_SORTER_2_POCKET_1_FULL			= 54;
		static const int LS_SORTER_2_POCKET_2_FULL			= 55;
		static const int LS_SORTER_2_POCKET_3_FULL			= 56;
		static const int LS_SORTER_3_POCKET_1_FULL			= 57;
		static const int LS_SORTER_3_POCKET_2_FULL			= 58;
		static const int LS_SORTER_3_POCKET_3_FULL			= 59;
		static const int LS_SORTER_4_POCKET_1_FULL			= 60;
		static const int LS_SORTER_4_POCKET_2_FULL			= 61;
		static const int LS_SORTER_4_POCKET_3_FULL			= 62;
		static const int LS_SORTER_5_POCKET_1_FULL			= 63;
		static const int LS_SORTER_5_POCKET_2_FULL			= 64;
		static const int LS_SORTER_5_POCKET_3_FULL			= 65;
		static const int LS_SORTER_6_POCKET_1_FULL			= 66;
		static const int LS_SORTER_6_POCKET_2_FULL			= 67;
		static const int LS_SORTER_6_POCKET_3_FULL			= 68;
		static const int LS_SORTER_7_POCKET_1_FULL			= 69;
		static const int LS_SORTER_7_POCKET_2_FULL			= 70;
		static const int LS_SORTER_7_POCKET_3_FULL			= 71;
	};


	public ref class LsConfiguration
	{
	public:
		static const int Release = 1;		// Release struttura
	
		bool	MICR_Reader;			//		 Ls100 Ls150 Ls520 Ls800
		bool	CMC7_Reader_only;		//		 Ls100 Ls150 Ls520 Ls800
		bool	E13B_Reader_only;		//		 Ls100 Ls150 Ls520 Ls800
		bool	Scanner_Front;			//		 Ls100 Ls150 Ls520 Ls800
		bool	Scanner_Rear;			//		 Ls100 Ls150 Ls520 Ls800
		bool	InkJet_Printer;			//		 Ls100 Ls150 Ls520 Ls800
		bool	InkJet_Printer_4_lines;	//					 Ls520 Ls800
		bool	Feeder;					//		 Ls100
		bool	Double_Leafing_sensor;	//					 Ls520
		bool	Stamp_Front;			//		 Ls100       Ls520
		bool	Stamp_Rear;				//					 Ls520
		bool	Badge_Track123;			//		 Ls100 Ls150
		bool	Badge_Track12;			//		 Ls100 Ls150 Ls520
		bool	Badge_Track23;			//		 Ls100 Ls150 Ls520
		bool	OCR_Reader;				//		 Ls100
		long	Sorters_Nr;				//						    Ls800
		bool	Module_Encoder;			//							Ls800
		bool    ProcessCard;			//	Ls40
		bool	ScannerUltraViolet;		//				Ls150
		bool    ColorVersion ;			//				Ls150
		bool    HightSpeed ;			//				Ls150
		bool	FeederMotorized;		//				Ls150
		//bool    E13BMicrOcr ;			//					  Ls520
	};


	public ref class LsUnitStatus
	{
	public:
		static const int Release = 1;		// Release struttura

		short	UnitStatus;					// Ls100 Ls150 Ls520 Ls800

		bool	Photo_Feeder;				// Ls100 Ls150 Ls520 Ls800
		bool	Photo_Sorter;				// Ls100
		bool	Photo_MICR;					// Ls100 Ls150
		bool	Photo_Path_Ls100;			// Ls100
		bool	Photo_Scanners;				// Ls100
		bool	Unit_Just_ON;				// Ls100 Ls150
		bool	Photo_Double_Leafing_Down;	// Ls100 Ls150
		bool	Photo_Double_Leafing_Middle;//       Ls150
		bool	Photo_Double_Leafing_Up;	// Ls100 Ls150
		bool	Photo_Card;					//       Ls150
		bool	Bins_All_Full;				//       Ls150 Ls520
		bool	Photo_Stamp;				//             Ls520
		bool	Photo_Exit;					//             Ls520
		bool	Bin_1_Full;					//             Ls520
		bool	Bin_2_Full;					//             Ls520

		bool	Photo_Path_Feeder;			//                   Ls800
		bool	Photo_Path_Module_Begin;	//                   Ls800
		bool	Photo_Path_Binary_Rigth;	//                   Ls800
		bool	Photo_Path_Binary_Left;		//                   Ls800
		bool	Photo_Path_Module_End;		//                   Ls800
		bool	Sorter_1_input_pocket_1;	//                   Ls800
		bool	Sorter_1_pocket_1_full;		//                   Ls800
		bool	Sorter_1_input_pocket_2;	//                   Ls800
		bool	Sorter_1_pocket_2_full;		//                   Ls800
		bool	Sorter_1_input_pocket_3;	//                   Ls800
		bool	Sorter_1_pocket_3_full;		//                   Ls800
		bool	Sorter_2_input_pocket_1;	//                   Ls800
		bool	Sorter_2_pocket_1_full;		//                   Ls800
		bool	Sorter_2_input_pocket_2;	//                   Ls800
		bool	Sorter_2_pocket_2_full;		//                   Ls800
		bool	Sorter_2_input_pocket_3;	//                   Ls800
		bool	Sorter_2_pocket_3_full;		//                   Ls800
		bool	Sorter_3_input_pocket_1;	//                   Ls800
		bool	Sorter_3_pocket_1_full;		//                   Ls800
		bool	Sorter_3_input_pocket_2;	//                   Ls800
		bool	Sorter_3_pocket_2_full;		//                   Ls800
		bool	Sorter_3_input_pocket_3;	//                   Ls800
		bool	Sorter_3_pocket_3_full;		//                   Ls800
		bool	Sorter_4_input_pocket_1;	//                   Ls800
		bool	Sorter_4_pocket_1_full;		//                   Ls800
		bool	Sorter_4_input_pocket_2;	//                   Ls800
		bool	Sorter_4_pocket_2_full;		//                   Ls800
		bool	Sorter_4_input_pocket_3;	//                   Ls800
		bool	Sorter_4_pocket_3_full;		//                   Ls800
		bool	Sorter_5_input_pocket_1;	//                   Ls800
		bool	Sorter_5_pocket_1_full;		//                   Ls800
		bool	Sorter_5_input_pocket_2;	//                   Ls800
		bool	Sorter_5_pocket_2_full;		//                   Ls800
		bool	Sorter_5_input_pocket_3;	//                   Ls800
		bool	Sorter_5_pocket_3_full;		//                   Ls800
		bool	Sorter_6_input_pocket_1;	//                   Ls800
		bool	Sorter_6_pocket_1_full;		//                   Ls800
		bool	Sorter_6_input_pocket_2;	//                   Ls800
		bool	Sorter_6_pocket_2_full;		//                   Ls800
		bool	Sorter_6_input_pocket_3;	//                   Ls800
		bool	Sorter_6_pocket_3_full;		//                   Ls800
		bool	Sorter_7_input_pocket_1;	//                   Ls800
		bool	Sorter_7_pocket_1_full;		//                   Ls800
		bool	Sorter_7_input_pocket_2;	//                   Ls800
		bool	Sorter_7_pocket_2_full;		//                   Ls800
		bool	Sorter_7_input_pocket_3;	//                   Ls800
		bool	Sorter_7_pocket_3_full;		//                   Ls800
	};


	// Class that contains the data for 
	// the alarm event. Derives from System.EventArgs.
	//
	public ref class LsApiEventArgs : EventArgs
	{
	public:
		int		NrDoc;					// Progessive document number
		String	^CodelineRead;			// Codeline returned

		// Parameter compiled from Application
		short	Sorter;					// Sorter where put the document
		char	FormatString;			// Set from application NORMAL or BOLD
		String	^StringToPrint;			// String to print rear of the document
	};

	// Delegate declaration.
	//
//	public delegate void LS515CodelineEventHandler(Object ^sender, LsApiEventArgs ^e);
	public delegate bool LS515OnCodelineCallBack(String ^Codeline, Int32 NrDoc, Int32 %Pocket, LsFamily::LsDefines::PrintFont %Font, String ^%StringToPrint);
	public delegate bool LS800OnCodelineCallBack(String ^Codeline, Int32 NrDoc, Int32 %Pocket, LsFamily::LsDefines::PrintFont %Font, String ^%StringToPrint);
	public delegate bool LS800OnImageCallBack(System::Drawing::Bitmap ^FrontImage, String ^Codeline, Int32 NrDoc, Int32 %Pocket, LsFamily::LsDefines::PrintFont %Font, String ^%StringToPrint);


//	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType::AutoDispatch)]
	public ref class LsApi
	{
	public :
		static LsFamily::LS515OnCodelineCallBack	^Ls515CallBack;
		static LsFamily::LS800OnCodelineCallBack	^Ls800cCallBack;
		static LsFamily::LS800OnImageCallBack		^Ls800iCallBack;
//	public:
		// Event Exported.
//		static event LS515CodelineEventHandler^ OnLS515CodelineRead;   // declare the event OnClick

//	protected:
//		void FireEvents()
//		{
////			void OnLs515CodelineRead(Object sender, LsApiEventArgs e)
//			OnLS515CodelineRead( gcnew Object(), gcnew LsApiEventArgs());
//		}


	public:
//		int __clrcall OnCodelineRead(S_CODELINE_INFO *CodelineInfo);

		// Method exported.
		int LSConnect(Int32 hWnd, LsDefines::LsUnitType UnitType, Int32 %hConnect,bool fReset);

		int LSSetIPAddress(Int16 UnitType, String ^IPaddress, Int16 Net_Port);

		int LSDisconnect(Int32 hConnect, Int32 hWnd);

		int LSIdentify(Int32 hConnect, Int32 hWnd, LsConfiguration ^lpCfg, String ^%Model, String ^%FwVersion, String ^%FwDate, String ^%UnitID);

		int LSLoadString(Int32 hConnect, Int32 hWnd, LsDefines::PrintFont Format, String ^sPrint, UInt32 StartNumber, Int16 Step);

		int LSLoadMultiStrings(Int32 hConnect, Int32 hWnd, LsDefines::PrintFont Font1, String ^sPrint1, LsDefines::PrintFont Font2, String ^sPrint2, LsDefines::PrintFont Font3, String ^sPrint3, LsDefines::PrintFont Font4, String ^sPrint4);

		int LSDoubleLeafingSensibility(Int32 hConnect, Int32 hWnd, LsDefines::DoubleLeafing Value);

		int LSDisableWaitDocument(Int32 hConnect, Int32 hWnd, BOOL fDo);

		int LSDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::Stamp Stamp, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanMode, LsDefines::Feeder Feeder, LsDefines::Sorter Sorter, LsDefines::Wait WaitTimeout, LsDefines::Beep Beep, UInt32 %NrDoc,LsDefines::ScanDocType ScanDocType);

		int LSReadCodeline(Int32 hConnect, Int32 hWnd, String ^%Codeline);

		int LSReadImage(Int32 hConnect, Int32 hWnd, LsDefines::ClearBlack ClearBlack, LsDefines::Side Side, UInt32 NrDoc, System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage,System::Drawing::Bitmap ^%FrontImage2, System::Drawing::Bitmap ^%RearImage2);

		int LsFamily::LsApi::LSReadImage(Int32 hConnect, Int32 hWnd, LsDefines::ClearBlack ClearBlack, LsDefines::Side Side, UInt32 NrDoc, System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage ,System::Drawing::Bitmap ^%FrontImage2,System::Drawing::Bitmap ^%RearImage2,System::Drawing::Bitmap ^%ImageMerged,bool fShowImageUV);
		
		int LSSaveImage(Int32 hConnect, Int32 hWnd, System::Drawing::Bitmap ^hImage, String ^FileName, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber,LsDefines::Side Side);
	
		int LSFreeImage(Int32 hWnd, System::Drawing::Bitmap ^hImage);

		int LSReset(Int32 hConnect, Int32 hWnd, LsDefines::Reset ResetType);

		int LSUnitStatus(Int32 hConnect, Int32 hWnd, LsUnitStatus ^lpStatus);

		int LSAutoDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::Stamp Stamp, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanMode, LsDefines::Sorter Sorter, Int16 NumDocument, LsDefines::ClearBlack ClearBlack, LsDefines::ImageSave SaveImage, String ^DirectoryFile, String ^BaseFilename, LsDefines::Unit UnitMeasure, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber, LsDefines::Wait WaitTimeout, LsDefines::Beep Beep, LsFamily::LS515OnCodelineCallBack ^pCallBack);

		int LS800AutoDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanModeFront, LsDefines::ScanMode ScanModeRear, LsDefines::ClearBlack ClearBlack, Int16 NumDocument, LsDefines::ImageSave SaveImage, String ^DirectoryFile, String ^BaseFilename, LsDefines::Unit Unit, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber, LsDefines::Beep Beep, LsFamily::LS800OnCodelineCallBack ^pcCallBack, LsFamily::LS800OnImageCallBack ^piCallBack);

		int LSGetDocData(Int32 hConnect, Int32 hWnd, UInt32 %NrDoc, String ^%FilenameFront, String ^%FilenameRear, String ^%FilenameFront2 , String ^%FilenameRear2 ,System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage ,System::Drawing::Bitmap ^%FrontImage2 , System::Drawing::Bitmap ^%RearImage2 , String ^%CodelineSW, String ^%CodelineHW);

		int LsFamily::LsApi::LSGetDocData(Int32 hConnect, Int32 hWnd, UInt32 %NrDoc, String ^%FilenameFront, String ^%FilenameRear, String ^%FilenameFront2, String ^%FilenameRear2,System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage , System::Drawing::Bitmap ^%FrontImage2, System::Drawing::Bitmap ^%RearImage2, System::Drawing::Bitmap ^%ImageMerged , String ^%CodelineSW, String ^%CodelineHW,bool fShowUVImage,bool fSaveImage,LsDefines::FileType FileFormat);

		int LSStopAutoDocHandle(Int32 hConnect, Int32 hWnd);

		int LSReadBadgeWithTimeout(Int32 hConnect, Int32 hWnd, LsDefines::Badge Tracks, UInt32 Timeout, String ^%BadgeTracks);

		int LSReadBadge(Int32 hConnect, Int32 hWnd, LsDefines::Badge Tracks, String ^%BadgeTracks);

		int LSCodelineReadFromBitmap(Int32 hWnd, System::Drawing::Bitmap ^hImage, String ^codelineType, LsDefines::Unit UnitMeasure, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::BlankInCodeline PutBlanks, String ^%Codeline);

		int LSReadBarcodeFromBitmap(Int32 hWnd, System::Drawing::Bitmap ^hImage, LsDefines::CodelineToRead TypeBarcode, Int32 pos_x, Int32 pos_y, Int32 sizeW, Int32 sizeH, String ^%Codeline);

		int LSModifyPWMUltraViolet(Int32 hConnect, Int32 hWnd,Int16 Value,bool fHighContrast,Int16 Reserved);

		int LSMergeImageGrayAndUV(Int32	hWnd,System::Drawing::Bitmap ^hImageGray,System::Drawing::Bitmap ^hImageUV,float Reserved1,float Reserved2,System::Drawing::Bitmap ^%pImage);

		int LsFamily::LsApi::LSHistory(Int32 hConnect, Int32 hWnd, LsHistory ^lpCfg,String ^%stTime);

		int LsFamily::LsApi::LSConfigDoubleLeafingAndDocLength(Int32 hConnect, Int32 hWnd, LsDefines::DoubleLeafing  Type , Int32 Value ,Int32 DocMin , Int32 DocMax);

		int LsFamily::LsApi::LSSetNetworkName(Int16 UnitType, String ^New_Network_Node_Name, Int16 New_Net_Port);

		int LsFamily::LsApi::LSReadPdfFromBitmap(Int32 hWnd, System::Drawing::Bitmap ^hImage, String ^%Codeline);
		
		void LSDebug(String ^ss);


	};



	public ref class CtsIQA
	{
	public:

		ref class IqaTestError
		{
		public:
			long	Size ;
			long	Function_Paramiter_Error ; 
			long	UndersizeImage_flag;
			long	UndersizeImage_error;
			long	UndersizeImage_Width ; 
			long	UndersizeImage_Height ; 
			long	Document_Corners_flag ; 
			long	Document_Corners_error ;
			long	Document_Corners_width ; 
			long	Document_Corners_height ;
			long	Document_Edges_flag;
			long	Document_Edges_error ; 
			long	Document_Edges_width ; 
			long	Document_Edges_height ;
			long	Document_Framing_flag ;
			long	Document_Framing_error ; 
			long	Document_Framing_left ; 
			long	Document_Framing_right;
			long	Document_Framing_top;
			long	Document_Framing_bottom ;
			long	Document_Skew_flag ;
			long	Document_Skew_error ; 
			long	Document_Skew_value ; 
			long	OversizeImage_flag ; 
			long	OversizeImage_error ; 
			long	OversizeImage_Width ; 
			long	OversizeImage_Height ; 
			long	Image_too_Light_flag ;
			long	Image_too_Ligth_error ; 
			long	Image_too_Light_AvgBrightness ; 
			long	Image_too_Light_AvgContrast ; 
			long	Image_too_Light_PercentBlackPixel ; 
			long	Image_too_Dark_flag  ; 
			long	Image_too_Dark_error ; 
			long	Image_too_Dark_AvgBrightness;
			long	Image_too_Dark_PercentBlackPixel ; 
			long	Horizontal_Streaks_flag ; 
			long	Horizontal_Streaks_error ; 
			long	Horizontal_Streaks_value ; 
			long	Below_Compressed_Size_flag ; 
			long	Below_Compressed_Size_error ; 
			long	Below_Compressed_Size_value ; 
			long	Above_Compressed_Size_flag ;
			long	Above_Compressed_Size_error ; 
			long	Above_Compressed_Size_value ; 
			long	Spot_Noise_flag ;
			long	Sport_Noise_error ; 
			long	Sport_Noise_value ; 
			long	Front_Rear_Dimension_Mismatch_flag;
			long	Front_Rear_Dimension_Mismatch_error ; 
			long	Front_Rear_Dimension_Mismatch_widthdiff ; 
			long	Front_Rear_Dimension_Mismatch_heightdiff ; 
			long	Carbon_Strip_flag ;
			long	Carbon_Strip_error ; 
			long	Out_of_Focus_flag ; 
			long	Out_of_Focus_error ; 
			long	Out_of_Focus_value ; 
		};


	public:
		// Method exported.
		int CheckImage(Int32 DocType, System::Drawing::Bitmap ^fImage, System::Drawing::Bitmap ^rImage, String ^pFnameFrontCompressed, String ^pFnameRearCompressed);

		int GetLoadIniError(String ^%DetailError);

		int GetTestsErrors(IqaTestError ^stTestErrorsFront, IqaTestError ^stTestErrorsRear);
	};
}
