// File DLL principale.

// Assembly marked as compliant.
//[assembly: CLSCompliantAttribute(true)]

#include "stdafx.h"
#include "LsApiClass.h"
#include "Miscellaneous.h"
#include "eztwain.h"
#include "twain.h"
#include "dr_twain.h"

#include <stdio.h>
#include <math.h>

#define HISTORY_TIME_UNIT				300			// secondi

#define R100_PELSMETER					3937L	// 100dpi/25.4(mmxinch)*1000
#define R120_PELSMETER					4724L	// 120dpi/25.4(mmxinch)*1000
#define R200_PELSMETER					7874L	// 200dpi/25.4(mmxinch)*1000
#define R240_PELSMETER					9449L	// 240dpi/25.4(mmxinch)*1000
#define R300_PELSMETER					11811L	// 300dpi/25.4(mmxinch)*1000

#define	IMAGE_100_DPI					100
#define	IMAGE_120_DPI					120
#define	IMAGE_200_DPI					200
#define	IMAGE_240_DPI					240
#define	IMAGE_300_DPI					300


#define BW_BMPHEADER					48		// sizeof(BITMAPINFOHEADER)+  2*sizeof(RGBQUAD)
#define GR16_BMPHEADER					104		// sizeof(BITMAPINFOHEADER)+ 16*sizeof(RGBQUAD)
#define GR256_BMPHEADER					1064	// sizeof(BITMAPINFOHEADER)+256*sizeof(RGBQUAD)
#define	COLOR_BMPHEADER					40		// sizeof(BITMAPINFOHEADER)

#define MASK_OCR_HW						0x20


//ffbImage immagine grigio fronte
//rrbImage immagine grigio retro
//ffnImage immagine UV
//rrnImage immagine Merge_Gray_Uv

HANDLE ffbImage=NULL, rrbImage=NULL, ffnImage=NULL, rrnImage=NULL;
short fScaMode_A4;

#if 0 
struct BMP{
	BITMAPINFOHEADER bInfoheader;
	RGBQUAD bColors[256];
	char bBits[1024];
};

BOOL SalvaDIB_Bitmap(BITMAPINFOHEADER *Bitmap, char *nFile)
{
	BOOL	ret;
	DWORD	DimFile;
	long	nColorData;
	FILE	*fh;
	BITMAPFILEHEADER bh;
	unsigned long NrBytesWrite;


	ret = TRUE;

	// Setto header file DIB (struttura BITMAPFILEHEADER)
	if(Bitmap->biBitCount <= 8)
		nColorData = 1 << Bitmap->biBitCount;
	else
		nColorData = 0;

	//Calcolo dimensione della bitmap
	DimFile = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD)) + Bitmap->biSizeImage;

	bh.bfType		= 0x4d42;		// Setto BF
	bh.bfSize		= DimFile;
	bh.bfReserved1	= 0;
	bh.bfReserved2	= 0;
	bh.bfOffBits	= sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + (nColorData * sizeof(RGBQUAD));	// struttura BITMAPINFOHEADER + tabella paletta

	if( (fh = fopen(nFile, "wb")) != NULL )
	{
		//Scrivo header
		NrBytesWrite = fwrite(&bh, sizeof(BITMAPFILEHEADER), 1, fh);

		if( NrBytesWrite == 1 )
		{
			//Scrivo bitmap
			//NrBytesWrite = fwrite(Bitmap, sizeof(unsigned char), (1100 *1024), fh);
			//NrBytesWrite = fwrite(Bitmap, sizeof(unsigned char), (1800 *1024), fh);
			//NrBytesWrite = fwrite(Bitmap, sizeof(unsigned char), DimFile, fh);
			//1136640
			NrBytesWrite = fwrite(Bitmap, sizeof(unsigned char), (DimFile - sizeof(BITMAPFILEHEADER)), fh);
			if( NrBytesWrite != (DimFile - sizeof(BITMAPFILEHEADER)) )
				ret = FALSE;
		}
		else
			ret = FALSE;

		fclose( fh );
	}
	else
		ret = FALSE;

	return ret;
} // SalvaDIBBitmap

#endif 



// -------------------------------------------------------------------------
//  FUNCTION : NSetInfoBmap_GR256                                                                           :
//                                                                             
//  Compile bitmap header and RGBQUAD structures for bitmap gr256, 100 and
//  200 dpi.
// -------------------------------------------------------------------------
void NSetInfoBmap_GR256(DWORD	*lpImgBmp,
						long	ImageWidth,
						long	ImageHeight,
						short	ResolutionMode)
{
	BITMAPINFO *pbmi;
	int        i;
	long	CondDib;


    // Compile bitmap header.
    pbmi = (BITMAPINFO *) lpImgBmp;

    pbmi->bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
    pbmi->bmiHeader.biWidth         = ImageWidth;
    pbmi->bmiHeader.biHeight        = ImageHeight;
    pbmi->bmiHeader.biPlanes        = 1;
    pbmi->bmiHeader.biBitCount      = 8;
    pbmi->bmiHeader.biCompression   = 0;

	if( CondDib = (ImageWidth % 4) )
		ImageWidth += (4 - CondDib);
    pbmi->bmiHeader.biSizeImage     = ImageHeight * ImageWidth;

    switch (ResolutionMode )
	{
	case IMAGE_100_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R100_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R100_PELSMETER;
		break;

	case IMAGE_120_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R120_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R120_PELSMETER;
		break;

	case IMAGE_200_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R200_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R200_PELSMETER;
		break;

	case IMAGE_300_DPI:
        pbmi->bmiHeader.biXPelsPerMeter = R300_PELSMETER;
        pbmi->bmiHeader.biYPelsPerMeter = R300_PELSMETER;
		break;
    }

    // Compile the 256 RGB QUAD STRUCTURES.
    pbmi->bmiHeader.biClrUsed       = 0;
    pbmi->bmiHeader.biClrImportant  = 0;

	for (i=0; i<256; i++)
	{
		pbmi->bmiColors[i].rgbBlue      = i;
		pbmi->bmiColors[i].rgbGreen     = i;
		pbmi->bmiColors[i].rgbRed       = i;
		pbmi->bmiColors[i].rgbReserved  = 0x00;
	}

} // End NSetInfoBmap_GR256



short ScanModeSelezionato ; //variabile globale che uso nella ReadImage e nella GetDocData  per sapere se e' stata chiesta anche l'immagine UV

short GlobalQuality ;
int   GloabalFileType ;

int LsFamily::LsApi::LSConnect(Int32 hWnd, LsDefines::LsUnitType UnitType, Int32 %hConnect,bool fReset)
//int LsFamily::LsApi::LSConnect(Int32 %hConnect, String ^%ss )
{
#if 1
	int rc;
	short hLS;
	HINSTANCE hInst = 0;
	short TypeLS;

	// TypeLS = Marshal::ReadInt32(UnitType, 0);
	TypeLS = (short)UnitType;
	// In the LsApi_dnet modifies defines for 520 so the application
	// handle 2 separates peripheral !
	if( TypeLS == (short)LsFamily::LsDefines::LsUnitType::LS_520_USB )
		TypeLS = (short)LsFamily::LsDefines::LsUnitType::LS_515_USB;
	//if( TypeLS == LsFamily::LS_520_USB )
	//	TypeLS = LsFamily::LS_515_USB;

	rc = ::LSConnectDiagnostica((HWND)hWnd, hInst, TypeLS, &hLS);

	if( rc == LSAPI_OKAY || rc == LSAPI_ALREADY_OPEN /*|| rc == LSAPI_COMMAND_SEQUENCE_ERROR*/)
	{
		hConnect = (int)hLS;
		if (fReset)
		// Do a reset for check the unit
		::LSReset(hLS, (HWND)hWnd, (char)LsDefines::Reset::RESET_ERROR);
		
		
	}

	return rc;
#else
	int aa = 5;
	char str[8] = {'C', 'i', 'a', 'o', '\0', 0, 0, 0};

	hConnect = aa;
	//Marshal::WriteInt32(hConnect, 0, aa);
//	ss = Marshal::PtrToStringAnsi(static_cast<IntPtr>(str));
//	Marshal::Copy(str, 0, ss, strlen(str));

	return 0;
#endif
} // LsFamily::LSConnect

int LsFamily::LsApi::LSDisconnect(Int32 hConnect, Int32 hWnd)
{
	int rc;

	rc = ::LSDisconnect(hConnect, (HWND)hWnd);

	return rc;
} // LsFamily::LSDisconnect

int LsFamily::LsApi::LSSetIPAddress(Int16 UnitType, String ^IPaddress, Int16 Net_Port)
{
	int rc;
	IntPtr ipString;
	char *pString;

	// Convert from String to char
	ipString = Marshal::StringToHGlobalAnsi(IPaddress);
//	pString = static_cast<char*>(static_cast<void*>(ipString));
	pString = (char*)(void*)(ipString);

    rc = ::LSSetIPAddress(UnitType, pString, Net_Port);

	Marshal::FreeHGlobal(ipString);

	return rc;
} // LsFamily::LSSetIPAddress

int LsFamily::LsApi::LSSetNetworkName(Int16 UnitType, String ^New_Network_Node_Name, Int16 New_Net_Port)
{
	int rc;
	IntPtr ipNetworkName;
	char *pString;

	// Convert from String to char
	ipNetworkName = Marshal::StringToHGlobalAnsi(New_Network_Node_Name);
//	pString = static_cast<char*>(static_cast<void*>(ipString));
	pString = (char*)(void*)(ipNetworkName);

    rc = ::LSSetNetworkName(UnitType, pString, New_Net_Port);

	Marshal::FreeHGlobal(ipNetworkName);

	return rc;

}// LsFamily::LSSetNetworkName

int LsFamily::LsApi::LSIdentify(Int32 hConnect, Int32 hWnd, LsConfiguration ^lpCfg, String ^%Model, String ^%FwVersion, String ^%Date, String ^%UnitID)
{
	int rc;
	char pCfg[16];
	char cModel[20], cVersion[20], cDate[20], cUnitID[20], cExpVersion[20], cInkJet[20], cFeeder[20], cSorter[20], cMotor[20];
	char cReserved1[8], cReserved2[8];

	memset(pCfg, 0, sizeof(pCfg));
	rc = LSUnitIdentify(hConnect, (HWND)hWnd, pCfg, cModel, cVersion, cDate, cUnitID, NULL, cExpVersion, cInkJet, cFeeder, cSorter, cMotor, cReserved1, cReserved2);

	if( rc == LSAPI_OKAY )
	{
		if( lpCfg )
		{
//			::Buffer::SetByte(lpCfg, 0, pCfg[0]);
//			::Buffer::SetByte(lpCfg, 1, pCfg[1]);
//			::Buffer::SetByte(lpCfg, 2, pCfg[2]);
//			::Buffer::SetByte(lpCfg, 3, pCfg[3]);
//			::Buffer::SetByte(lpCfg, 4, pCfg[4]);

			// Clear the configuration structure
			if( lpCfg->Release <= 1 )
			{
				lpCfg->MICR_Reader = FALSE;
				lpCfg->OCR_Reader = FALSE;
				lpCfg->Scanner_Front = FALSE;
				lpCfg->Scanner_Rear = FALSE;
				lpCfg->InkJet_Printer = FALSE;
				lpCfg->Stamp_Front = FALSE;
				lpCfg->Stamp_Rear = FALSE;
				lpCfg->Feeder = FALSE;
				lpCfg->Badge_Track123 = FALSE;
				lpCfg->Badge_Track12 = FALSE;
				lpCfg->Badge_Track23 = FALSE;
				lpCfg->Sorters_Nr = 0;
				lpCfg->CMC7_Reader_only = FALSE;
				lpCfg->E13B_Reader_only = FALSE;
				lpCfg->InkJet_Printer_4_lines = FALSE;
				lpCfg->Double_Leafing_sensor = FALSE;
				lpCfg->Module_Encoder = FALSE;
				lpCfg->ProcessCard = FALSE ; 
				lpCfg->ScannerUltraViolet = FALSE ; 
				lpCfg->ColorVersion = FALSE ;
				lpCfg->HightSpeed = FALSE ; 
				lpCfg->FeederMotorized = FALSE ;
				//lpCfg->E13BMicrOcr = FALSE ;

				if (! strncmp(cModel, MODEL_LS40, strlen(MODEL_LS40)))
				{
					// Build the Fw version from the Model string
					//strcpy_s(cVersion, sizeof(cVersion), &cModel[4]);
			
					//byte 0 
					if( pCfg[0] & 0x01 )
						lpCfg->MICR_Reader = TRUE;
					if (pCfg[0] & 0x02 )
						lpCfg->ProcessCard = TRUE ; 
					if( pCfg[0] & 0x08 )
						lpCfg->InkJet_Printer = TRUE;
					if( pCfg[0] & 0x20 )
						lpCfg->Stamp_Front = TRUE;

					//byte 1
					if( pCfg[1] & 0x01 )
						lpCfg->Scanner_Front = TRUE;
					if( pCfg[1] & 0x02 )
						lpCfg->Scanner_Rear = TRUE;
					if( pCfg[1] & 0x04 )
						lpCfg->Badge_Track12 = TRUE;
					if( pCfg[1] & 0x08 )
						lpCfg->Badge_Track23  = TRUE;
					if( pCfg[1] & 0x10)
						lpCfg->Badge_Track123   = TRUE;

					//if( pCfg[1] & 0x10 )
					//	lpCfg->Feeder = TRUE;
		
					
				}

				if( ! strncmp(cModel, MODEL_LS100, strlen(MODEL_LS100)) ) 
					
				{
					// Build the Fw version from the Model string
					strcpy_s(cVersion, sizeof(cVersion), &cModel[4]);

					if( pCfg[1] & 0x01 )
						lpCfg->MICR_Reader = TRUE;
					if( pCfg[1] & 0x02 )
						lpCfg->OCR_Reader = TRUE;
					if( pCfg[1] & 0x08 )
						lpCfg->InkJet_Printer = TRUE;
					if( pCfg[1] & 0x10 )
						lpCfg->Feeder = TRUE;
					if( pCfg[1] & 0x20 )
						lpCfg->Stamp_Front = TRUE;
					if( pCfg[2] & 0x01 )
						lpCfg->Scanner_Front = TRUE;
					if( pCfg[2] & 0x02 )
						lpCfg->Scanner_Rear = TRUE;
					if( pCfg[2] & 0x04 )
					{
						if( pCfg[2] & 0x10 )
							lpCfg->Badge_Track123 = TRUE;
						else if( pCfg[2] & 0x08 )
							lpCfg->Badge_Track12 = TRUE;
						else
							lpCfg->Badge_Track23 = TRUE;
					}
				}

				if( ! strncmp(cModel, MODEL_LS150, strlen(MODEL_LS150)) )
				{
					//card 
					lpCfg->ProcessCard = TRUE ;

					if( pCfg[0] & 0x01 )
						lpCfg->MICR_Reader = TRUE;
					if( pCfg[0] & 0x02 )	
						lpCfg->HightSpeed =TRUE ;
					if( pCfg[0] & 0x04 )
						lpCfg->FeederMotorized = TRUE ;
					if( pCfg[0] & 0x08 )
						lpCfg->InkJet_Printer = TRUE;
					
					if( pCfg[0] & 0x20 )
						lpCfg->Stamp_Front = TRUE;
					if( pCfg[1] & 0x01 )
						lpCfg->Scanner_Front = TRUE;
					if( pCfg[1] & 0x02 )
						lpCfg->Scanner_Rear = TRUE;
					if( pCfg[1] & 0x04 )						
						lpCfg->ScannerUltraViolet = TRUE  ;
					if( pCfg[1] & 0x08 )
					{
						if( pCfg[1] & 0x10 )
							lpCfg->Badge_Track123 = TRUE;
						else
							lpCfg->Badge_Track23 = TRUE;
					}
					else
					{
						if( pCfg[1] & 0x10 )
							lpCfg->Badge_Track12 = TRUE;
					}

					if( pCfg[1] & 0x20 )						
						lpCfg->ColorVersion  = TRUE;

					if (pCfg[2] & 0x01  )
						lpCfg->InkJet_Printer_4_lines = TRUE;
				}

				if( ! strncmp(cModel, MODEL_LS520, strlen(MODEL_LS520)) ||
					! strncmp(cModel, MODEL_LS515, strlen(MODEL_LS515)) )
				{
					if( (pCfg[1] & 0x01) && (pCfg[1] & 0x02) )
						lpCfg->MICR_Reader = TRUE;
					else
					{
						if( pCfg[1] & 0x01 )
							lpCfg->CMC7_Reader_only = TRUE;
						if( pCfg[1] & 0x02 )
							lpCfg->E13B_Reader_only = TRUE;
					}
					if( pCfg[1] & 0x08 )
						lpCfg->InkJet_Printer = TRUE;
					// Test for printer to 4 lines
					if( ! strncmp(cModel, MODEL_LS520, strlen(MODEL_LS520)) && (pCfg[2] & 0x08) )
						lpCfg->InkJet_Printer_4_lines = TRUE;
					if( pCfg[1] & 0x10 )
						lpCfg->Stamp_Rear = TRUE;
					if( pCfg[1] & 0x20 )
						lpCfg->Stamp_Front = TRUE;
					if( pCfg[2] & 0x01 )
						lpCfg->Scanner_Front = TRUE;
					if( pCfg[2] & 0x02 )
						lpCfg->Scanner_Rear = TRUE;
					if( pCfg[2] & 0x10 )
						lpCfg->Badge_Track23 = TRUE;
					if( pCfg[2] & 0x20 )
						lpCfg->Double_Leafing_sensor = TRUE;

					if( pCfg[2] & 0x08 )
						lpCfg->ColorVersion  = TRUE;

				}

				if( ! strncmp(cModel, MODEL_LS800, strlen(MODEL_LS800)) ||
					! strncmp(cModel, MODEL_LS800_NCR, strlen(MODEL_LS800_NCR)) )
				{
					// Build the Fw version from the Model string
					strcpy_s(cVersion, sizeof(cVersion), &cModel[6]);
					// Ls800 don't have the Fw date
					memset(cDate, 0, sizeof(cDate));

					if( (pCfg[0] & 0x01) && (pCfg[0] & 0x02) )
						lpCfg->MICR_Reader = TRUE;
					else
					{
						if( pCfg[0] & 0x01 )
							lpCfg->CMC7_Reader_only = TRUE;
						if( pCfg[0] & 0x02 )
							lpCfg->E13B_Reader_only = TRUE;
					}
					if( pCfg[0] & 0x04 )
						lpCfg->Module_Encoder = TRUE;
					if( pCfg[0] & 0x08 )
						lpCfg->InkJet_Printer = TRUE;
					if( pCfg[0] & 0x10 )
						lpCfg->InkJet_Printer_4_lines = TRUE;
					if( pCfg[1] & 0x01 )
						lpCfg->Scanner_Front = TRUE;
					if( pCfg[1] & 0x02 )
						lpCfg->Scanner_Rear = TRUE;
					if( (pCfg[2] & MASK_7_SORTERS) == MASK_7_SORTERS )		// 00000111
						lpCfg->Sorters_Nr = 7;
					else if( (pCfg[2] & MASK_6_SORTERS) == MASK_6_SORTERS )	// 00000110
						lpCfg->Sorters_Nr = 6;
					else if( (pCfg[2] & MASK_5_SORTERS) == MASK_5_SORTERS )	// 00000101
						lpCfg->Sorters_Nr = 5;
					else if( pCfg[2] & MASK_4_SORTERS )			// 00000100
						lpCfg->Sorters_Nr = 4;
					else if( (pCfg[2] & MASK_3_SORTERS) == MASK_3_SORTERS )	// 00000011
						lpCfg->Sorters_Nr = 3;
					else if( pCfg[2] & MASK_2_SORTERS )			// 00000010
						lpCfg->Sorters_Nr = 2;
					else if( pCfg[2] & MASK_1_SORTER )			// 00000001
						lpCfg->Sorters_Nr = 1;
				}
			}
		}
		if( Model )
		{
			// Convert the c string to a managed String.
//			String ^ myManagedString = Marshal::PtrToStringAnsi((IntPtr) (char *) myString);
			Model = Marshal::PtrToStringAnsi((IntPtr) (char *) cModel);
		}
		if( FwVersion )
			FwVersion = Marshal::PtrToStringAnsi((IntPtr) (char *) cVersion);
		if( Date )
			Date = Marshal::PtrToStringAnsi((IntPtr) (char *) cDate);
		if( UnitID )
			UnitID = Marshal::PtrToStringAnsi((IntPtr) (char *) cUnitID);
//		wcArr = Marshal::PtrToStringBSTR(aa);
	}

	return rc;
} // LsFamily::LSIdentify

void LsFamily::LsApi::LSDebug(String ^ss)
{
	LPWSTR pString;

	pString = (LPWSTR)(void*)Marshal::StringToHGlobalUni( ss );
	OutputDebugString( pString );
	Marshal::FreeHGlobal( (IntPtr)pString );
}

int LsFamily::LsApi::LSLoadString(Int32 hConnect, Int32 hWnd, LsDefines::PrintFont Format, String ^sPrint, UInt32 StartNumber, Int16 Step)
{
	int rc;
	char *pString;

	// Convert from String to char
	pString = (char*)(void*)Marshal::StringToHGlobalAnsi(sPrint);

	if (hConnect == 2 )
		rc = ::LSLoadString(hConnect,(HWND)hWnd,(char)Format,sPrint->Length,pString );
	else 
		rc = ::LSLoadStringWithCounterEx(hConnect, (HWND)hWnd, (char)Format, pString, sPrint->Length, StartNumber, Step);

	Marshal::FreeHGlobal( (IntPtr)pString);

	return rc;
} // LsFamily::LSLoadString

int LsFamily::LsApi::LSLoadMultiStrings(Int32 hConnect, Int32 hWnd, LsDefines::PrintFont Font1, String ^sPrint1, LsDefines::PrintFont Font2, String ^sPrint2, LsDefines::PrintFont Font3, String ^sPrint3, LsDefines::PrintFont Font4, String ^sPrint4)
{
	int rc;
	char *pString1, *pString2, *pString3, *pString4;

	// Convert from String to char
	pString1 = (char*)(void*)Marshal::StringToHGlobalAnsi(sPrint1);
	pString2 = (char*)(void*)Marshal::StringToHGlobalAnsi(sPrint2);
	pString3 = (char*)(void*)Marshal::StringToHGlobalAnsi(sPrint3);
	pString4 = (char*)(void*)Marshal::StringToHGlobalAnsi(sPrint4);

    rc = ::LSLoadMultiStrings(hConnect, (HWND)hWnd,
								(char)Font1, pString1, sPrint1->Length,
								(char)Font2, pString2, sPrint2->Length,
								(char)Font3, pString3, sPrint3->Length,
								(char)Font4, pString4, sPrint4->Length);

	Marshal::FreeHGlobal( (IntPtr)pString4);
	Marshal::FreeHGlobal( (IntPtr)pString3);
	Marshal::FreeHGlobal( (IntPtr)pString2);
	Marshal::FreeHGlobal( (IntPtr)pString1);

	return rc;
} // LsFamily::LSLoadMultiString

int LsFamily::LsApi::LSConfigDoubleLeafingAndDocLength(Int32 hConnect, Int32 hWnd, LsDefines::DoubleLeafing Type , Int32 Value ,Int32 DocMin , Int32 DocMax)
{
	int rc;

    rc = ::LSConfigDoubleLeafingAndDocLength(hConnect, (HWND)hWnd, (long)Type,Value ,DocMin,DocMax);

	return rc;
} // LsFamily::LSDoubleLeafingSensibility

int LsFamily::LsApi::LSDoubleLeafingSensibility(Int32 hConnect, Int32 hWnd, LsDefines::DoubleLeafing Value)
{
	int rc;

    rc = ::LSDoubleLeafingSensibility(hConnect, (HWND)hWnd, 0, (unsigned char)Value);

	return rc;
} // LsFamily::LSDoubleLeafingSensibility

int LsFamily::LsApi::LSDisableWaitDocument(Int32 hConnect, Int32 hWnd, BOOL fDo)
{
	int rc;

    rc = ::LSDisableWaitDocument(hConnect, (HWND)hWnd, fDo);

	return rc;
} // LsFamily::LSDisableWaitDocument

int LsFamily::LsApi::LSModifyPWMUltraViolet(Int32 hConnect, Int32 hWnd,Int16 Value,bool fHighContrast,Int16 Reserved)
{
	int rc;
//	unsigned long nrdoc;
	short Reserved1 = 0;
	long Reserved2 = 0;

	rc = ::LSModifyPWMUltraViolet(hConnect, (HWND)hWnd, Value, fHighContrast, Reserved1);

	return rc ;
}



//questa funzione non viene piu' usata per velocizzare il tutto l'LSMergeImageGrayAndUV 
// e' stata fatta direttamente dentro la GetDocData e la ReadImage
int LsFamily::LsApi::LSMergeImageGrayAndUV(Int32	hWnd,System::Drawing::Bitmap ^hImageGray,System::Drawing::Bitmap ^hImageUV,float Reserved1,float Reserved2,System::Drawing::Bitmap ^%ImageMErged)
{
	#if 0 
	int rc ;
	HANDLE fbImage=NULL, rbImage=NULL, fnImage=NULL, rnImage=NULL;
	char *pBitmapGray= NULL ,*pBitmapUV =NULL, *pImageResult=NULL;
	short DimHeader = 0 ;
	
	const int maxBytesPerData = 256;
    const int maxImageCount = 4;
    const int maxDataCount = 3;
 
	const int *pmaxBytesPerData = &maxBytesPerData, *pmaxImageCount = &maxImageCount, *pmaxDataCount = &maxDataCount;
	const char * argProdId = "1234567890";
	const char * argProdKey = "9Tq2W.?Rg~";
	//const char * argScript = "S:\\ST-ilf-framework\\Vision\\compiled\\init.jls";
	const char * argScript = "C:\\Progetti\\LsApi.Sviluppo\\LsApiClass\\st\\Vision\\compiled\\init.jls";
	
	long CondDib ;

	const char * parguments[] = { argProdId, argProdKey, argScript };
	
	
	if( Miscellaneous::Func::ConvertClassBitmapToDIB(hImageGray, &pBitmapGray) )
	{
		if( Miscellaneous::Func::ConvertClassBitmapToDIB(hImageUV, &pBitmapUV) )
		{
				rc =::LSMergeImageGrayAndUV((HWND)hWnd,(HANDLE)pBitmapGray,(HANDLE)pBitmapUV,Reserved1,Reserved2,&fbImage);
				if (rc == LSAPI_OKAY )
				{
					if (fbImage )
					{
						// Live the bitmap as it's, after create a bitmap class
						System::Drawing::Color pixColor;
						int		DimImage;
						Byte	bfh[14];
						array<Byte> ^a_bfh = gcnew array<Byte>(14);
						array<Byte> ^a_pImage;
						
						// Create the bitmap file header e ...
						Miscellaneous::Func::CreateBitmapFileHeader(fbImage, bfh, &DimImage);

						// Create the stream
						MemoryStream^ memStream = gcnew MemoryStream( DimImage );

						// ... copy it in the stream
						Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
						memStream->Write(a_bfh, 0, sizeof(bfh));

						DimImage = ::GlobalSize( fbImage );
						a_pImage = gcnew array<Byte>(DimImage);
						Marshal::Copy ((IntPtr)fbImage, a_pImage, 0, DimImage);

						// Copy in the stream the image
						memStream->Write(a_pImage, 0, a_pImage->Length);

						// Creo a bitmap class from the stream
						ImageMErged = gcnew System::Drawing::Bitmap( memStream );

						// Delete the temporary aree
						delete a_pImage;
						delete memStream;
						delete a_bfh;

	ST_Image *images = new ST_Image[maxImageCount];
	ST_Data *data = new ST_Data[maxDataCount];
	
	 rc = ST_Initialize (
                    /* const int argumentCount */ 3,
                    /* const char * arguments[] */ parguments,
                    /* const int * maxImageCount */ pmaxImageCount,
                    /* const int * maxDataCount */ pmaxDataCount,
                    /* const int * maxBytesPerData */ pmaxBytesPerData);
 

      if (rc == ST_OK ) 
	  {
		/*BMP pBM[3];
		for(int i=0; i<3; i++) {
			pBM[i].bInfoheader.biBitCount = 8;
			pBM[i].bInfoheader.biHeight = 780;
			pBM[i].bInfoheader.biWidth = 1720;
		}*/

	/*	BITMAPINFOHEADER *fbImage = (BITMAPINFOHEADER*)&pBM[0];
		BITMAPINFOHEADER* pBitmapGray = (BITMAPINFOHEADER*)&pBM[1];
		BITMAPINFOHEADER* pBitmapUV = (BITMAPINFOHEADER*)&pBM[2];*/


		int DimHeader;
		if (((BITMAPINFOHEADER*)fbImage)->biBitCount == 1 )
			DimHeader = BW_BMPHEADER ;
		else if (((BITMAPINFOHEADER*)fbImage)->biBitCount == 4 )
			DimHeader = GR16_BMPHEADER ;
		else if (((BITMAPINFOHEADER*)fbImage)->biBitCount == 8 )
			DimHeader = GR256_BMPHEADER ;
 
		long Width ;

		Width = ((BITMAPINFOHEADER*)pBitmapGray)->biWidth ;
		 if( CondDib = Width % 4 )
			Width += (4-CondDib);

       images[0].ImageType = ST_BYTEIMAGE ;
       images[0].Height = ((BITMAPINFOHEADER*)pBitmapUV)->biHeight ;
       //images[0].Width = ((BITMAPINFOHEADER*)pBitmapGray)->biWidth ;
	   images[0].Width = Width ;
       strcpy((char*)&(images[0].Name ),"UV");
	   images[0].Image = malloc(sizeof(char) * images[0].Height * images[0].Width);
	   memcpy(images[0].Image, pBitmapUV + DimHeader, images[0].Height * images[0].Width);
 
       images[1].ImageType = ST_BYTEIMAGE ;
       images[1].Height = ((BITMAPINFOHEADER*)pBitmapGray)->biHeight ;
       //images[1].Width = ((BITMAPINFOHEADER*)pBitmapUV)->biWidth ;
	    images[1].Width = Width ;
	   strcpy((char*)&(images[1].Name ),"GraySscale");
	   images[1].Image = malloc(sizeof(char) * images[1].Height * images[1].Width);
	   memcpy(images[1].Image, pBitmapGray + DimHeader, images[1].Height * images[1].Width);
 
       images[2].ImageType = ST_BYTEIMAGE ;
       images[2].Height = ((BITMAPINFOHEADER*)fbImage)->biHeight ;
       //images[2].Width = ((BITMAPINFOHEADER*)fbImage)->biWidth ;
	   images[2].Width = Width ;
       strcpy((char*)&(images[2].Name ),"Merged");
	   images[2].Image = malloc(sizeof(char) * images[2].Height * images[2].Width);
	   memcpy(images[2].Image, (char*)fbImage + DimHeader, images[2].Height * images[2].Width);

	    SalvaDIB_Bitmap((BITMAPINFOHEADER*) fbImage,"C:\\aa.bmp");
 
	   images[3].ImageType = images[2].ImageType;
       images[3].Height = images[2].Height;
       images[3].Width = images[2].Width; 
	   strcpy((char*)&(images[3].Name ),"Output");
	   pImageResult = (char*)malloc((images[3].Height * images[3].Width) + DimHeader );
       images[3].Image = pImageResult + DimHeader;
 
	   char amp[255];
		
	   memset(amp,0,255);
	   
       ////prepare the data
       data[0].DataType = ST_STRING;
       strcpy(data[0].Name ,"message");
      // data[0].Data =  new char(255);
	   data[0].Data = amp ; 
       strcpy((char*)data[0].Data ,"");

	   int score = 0;
       data[1].DataType = ST_INT;
       strcpy(data[1].Name ,"fraud_index");
       data[1].Data = &score;
 
	   int chequetype =	1;
       data[2].DataType = ST_INT;
       strcpy(data[2].Name ,"chequetype");
       data[2].Data = &chequetype;

	   LARGE_INTEGER liStart, liEnd, liDiff, liFreq;
	   QueryPerformanceCounter(&liStart);
       rc = ST_SetData(&maxImageCount,images,&maxDataCount,data);
	   char str[22];
	   sprintf(str, "Reply = %d", rc);
	   MessageBoxA(NULL, str, "Titolo", MB_OK);
	   QueryPerformanceCounter(&liEnd);
	   liDiff.QuadPart = liEnd.QuadPart - liStart.QuadPart;
	   QueryPerformanceFrequency(&liFreq);
	   double t = ((double)liDiff.QuadPart)*1000/(double)liFreq.QuadPart;
	   printf("Time: %lf ms\n", t);

	   //sscanf((char*)data[0].Data, "FraudIndex %d", data[1].Data);
       
	   //in (char*)data[0].data e *(int*)data[1].Data we have the message(es "FraudIndex ##") and score 
       //in  image[3] we have image with circles

	   printf("RC:       %d\n", rc);
	   printf("Message:  %s\n", (char*)data[0].Data);
	   printf("Score:    %d\n", *((int*)data[1].Data));


	   	if( CondDib = images[3].Width % 4 )
		images[3].Width += (4-CondDib);

	   NSetInfoBmap_GR256((DWORD*)pImageResult,
						images[3].Width,
						images[3].Height,
						200);

	   SalvaDIB_Bitmap((BITMAPINFOHEADER*) pImageResult,"C:\\result.bmp");

	   
		
       rc = ST_Finalize();

				
	  }
						
	  ::LSFreeImage(0, (HANDLE *)&fbImage);
					}
				}
		}
		else
			 rc = LSAPI_SYSTEM_ERROR;
	}
	else
		 rc = LSAPI_SYSTEM_ERROR;

	return rc ; 
#else
	return 0 ;
#endif 
}





int LsFamily::LsApi::LSDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::Stamp Stamp, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanMode, LsDefines::Feeder Feeder, LsDefines::Sorter Sorter, LsDefines::Wait WaitTimeout, LsDefines::Beep Beep, UInt32 %NrDoc , LsDefines::ScanDocType ScanDocType)
{
	int rc;
	unsigned long nrdoc;
	short Reserved1 = 0;
	long Reserved2 = 0;

	fScaMode_A4 = 0;

	if( ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_BW_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_BW_300 ||
		ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_GRAY_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_GRAY_300 ||
		ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_COLOR_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_COLOR_300 )
	{
		// disable UI
			TWAIN_SetHideUI(TRUE);
		// Test presenza foglio e via !!!
        if (TWAIN_OpenCanonSource())
		{
			long	Cap_lValue;

			
				// Forzo il deskew !!!
			TWAIN_SetCapOneValue(ICAP_AUTOMATICDESKEW, TWTY_BOOL, (TW_BOOL)1);

				// Controlla se ci sono fogli nello sfogliatore
			TWAIN_GetCapCurrent(CCAP_CEI_DOCUMENT_DETECTED, TWTY_INT32, &Cap_lValue);

			// SE ci sono fogli do il via
			if( Cap_lValue )
			{
					// Set Side
				if( Side == LsFamily::LsDefines::Side::SIDE_ALL_IMAGE )
					TWAIN_SetCapOneValue(CAP_DUPLEXENABLED, TWTY_BOOL, (TW_BOOL)1);
				else
					TWAIN_SetCapOneValue(CAP_DUPLEXENABLED, TWTY_BOOL, (TW_BOOL)0);

					// Set color
				if( ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_BW_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_BW_300 )
				{
				   TWAIN_SetCurrentPixelType(TWPT_BW);
				   TWAIN_SetBitDepth(1);
				}
				else if( ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_GRAY_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_GRAY_300 )
				{
				   TWAIN_SetCurrentPixelType(TWPT_GRAY);
				   TWAIN_SetBitDepth(8);
				}
				else if( ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_COLOR_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_COLOR_300 )
				{
				   TWAIN_SetCurrentPixelType(TWPT_RGB);
				   TWAIN_SetBitDepth(24);
				}

					// Set dpi
				if( ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_BW_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_GRAY_200 || ScanMode == LsFamily::LsDefines::ScanMode::SCAN_MODE_A4_COLOR_200 )
	               TWAIN_SetCurrentResolution(200.0);
				else
					TWAIN_SetCurrentResolution(300.0);

				rc = LSAPI_OKAY;
				fScaMode_A4 = 2;
			}
			else
			{
				rc = LSAPI_FEEDER_EMPTY;

				// Chiudo il source
				TWAIN_UnloadSourceManager();
			}
		}
		else
		{
			rc = LSAPI_PAPER_JAM;
		}
	}
	else
	{
		rc = ::LSDocHandle(hConnect, (HWND)hWnd, (short)Stamp, (short)Validate, (short)CodeLine, (char)Side, (short)ScanMode, (short)Feeder, (short)Sorter, (short)WaitTimeout, (short)Beep, &nrdoc, (short)ScanDocType, Reserved2);

		if( rc == LSAPI_OKAY )
		{
	//		if( NrDoc )
				NrDoc = (UInt32)nrdoc;

				ScanModeSelezionato = (short)ScanMode ;  //mi salvo lo ScanMode che ho scelto 
	//			Marshal::WriteInt32(NrDoc, 0, nrdoc);
		}
	}
	return rc;
} // LsFamily::LSDocHandle

int LsFamily::LsApi::LSReadCodeline(Int32 hConnect, Int32 hWnd, String ^%Codeline)
{
	int rc;
	char HwCodeline[256];
	short len_codeline;

	len_codeline = sizeof(HwCodeline);
	rc = ::LSReadCodeline(hConnect, (HWND)hWnd, HwCodeline, &len_codeline, NULL, NULL, NULL, NULL);

	if( rc == LSAPI_OKAY )
	{
		if( Codeline )
		{
			// Se HwCodeline = "" mette Codeline = ""
			Codeline = Marshal::PtrToStringAnsi((IntPtr) (char *) HwCodeline);
			len_codeline = Codeline->Length;
		}
	}

	return rc;
} // LsFamily::LSReadCodeline


#if 0
//Read Image for UV Mode --torna anche il puntatore all'Image UV
int LsFamily::LsApi::LSReadImage(Int32 hConnect, Int32 hWnd, LsDefines::ClearBlack ClearBlack, LsDefines::Side Side, UInt32 NrDoc, System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage ,System::Drawing::Bitmap ^%FrontImage2,System::Drawing::Bitmap ^%RearImage2,System::Drawing::Bitmap ^%ImageMerged,bool fShowImageUV)
{
	int rc;
	HANDLE fbImage=NULL, rbImage=NULL, fnImage=NULL, rnImage=NULL ;
	HANDLE fMerged = NULL ;
	short Reserved1=0 , Reserved2=0 ;
//	System::Drawing::Image ^iBitmap;

	if (ffbImage )
	{
		::LSFreeImage(0, (HANDLE *)&ffbImage);
		ffbImage = 0;
	}

	if (rrbImage )
	{
		::LSFreeImage(0, (HANDLE *)&rrbImage);
		rrbImage= 0;
	}
	
	if (ffnImage )
	{
		::LSFreeImage(0, (HANDLE *)&ffnImage);
		ffnImage = 0;
	}

	rc = ::LSReadImage(hConnect, (HWND)hWnd, (short)ClearBlack, (char)Side, 0, NrDoc, &ffbImage, &rrbImage, &ffnImage, &rnImage);

	
	
	if( rc == LSAPI_OKAY || rc == LSAPI_DOUBLE_LEAFING_WARNING )
	{
		if( (char)Side == LSAPI_SIDE_FRONT_IMAGE || (char)Side == LSAPI_SIDE_ALL_IMAGE )
		{
				// Live the bitmap as it's, after create a bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				Byte	bfh2[14];
				Byte	bfh3[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_bfh2 = gcnew array<Byte>(14);
				array<Byte> ^a_bfh3 = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;
				array<Byte> ^a_pImage2;
				array<Byte> ^a_pImage3;
				// Create the bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(ffbImage, bfh, &DimImage);

				// Create the stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... copy it in the stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( ffbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)ffbImage, a_pImage, 0, DimImage);

				// Copy in the stream the image
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo a bitmap class from the stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				// Delete the temporary aree
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				//::LSFreeImage(0, (HANDLE *)&fbImage);

				//UV conversion 
				if (ffnImage && (ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV || ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV))
				{
					if (fShowImageUV == TRUE )
					{
						//ho chiesto di tornare le tre immagini (GRAY + UV + MERGED )
						Miscellaneous::Func::CreateBitmapFileHeader(ffnImage, bfh2, &DimImage);

						// Create the stream
						MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
				
						// ... copy it in the stream
						Marshal::Copy((IntPtr)bfh2, a_bfh2, 0, sizeof(bfh2));
						memStream2->Write(a_bfh2, 0, sizeof(bfh2));

						DimImage = ::GlobalSize( ffnImage );
						a_pImage2 = gcnew array<Byte>(DimImage);
						Marshal::Copy((IntPtr)ffnImage, a_pImage2, 0, DimImage);

						// Copy in the stream the image
						memStream2->Write(a_pImage2, 0, a_pImage2->Length);

						// Creo a bitmap class from the stream
						FrontImage2 = gcnew System::Drawing::Bitmap( memStream2 );

						// Delete the temporary aree
						delete a_pImage2;
						delete memStream2;
						delete a_bfh2;
						//::LSFreeImage(0, (HANDLE *)&fnImage);

					}
					//altrimenti di default torno l'immagine GRIGIO + MERGED
					rc =::LSMergeImageGrayAndUV((HWND)hWnd,(HANDLE)ffbImage,(HANDLE)ffnImage,Reserved1,Reserved2,&fMerged);
					// Create the bitmap file header e ...
					Miscellaneous::Func::CreateBitmapFileHeader(fMerged, bfh3, &DimImage);

					// Create the stream
					MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
				
					// ... copy it in the stream
					Marshal::Copy((IntPtr)bfh3, a_bfh3, 0, sizeof(bfh3));
					memStream2->Write(a_bfh3, 0, sizeof(bfh3));

					DimImage = ::GlobalSize( fMerged );
					a_pImage3 = gcnew array<Byte>(DimImage);
					Marshal::Copy((IntPtr)fMerged, a_pImage3, 0, DimImage);

					// Copy in the stream the image
					memStream2->Write(a_pImage3, 0, a_pImage3->Length);

					// Creo a bitmap class from the stream
					ImageMerged = gcnew System::Drawing::Bitmap( memStream2 );

					// Delete the temporary aree
					delete a_pImage3;
					delete memStream2;
					delete a_bfh3;
					::LSFreeImage(0, (HANDLE *)&fMerged);

					
				}


			


		}
		if( (char)Side == LSAPI_SIDE_BACK_IMAGE || (char)Side == LSAPI_SIDE_ALL_IMAGE )
		{
			
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(rrbImage, bfh, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( rrbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)rrbImage, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				//::LSFreeImage(0, (HANDLE *)&rbImage);
			

	
		}
	}

	return rc;
}




#endif

//Read Image for UV Mode 
int LsFamily::LsApi::LSReadImage(Int32 hConnect, Int32 hWnd, LsDefines::ClearBlack ClearBlack, LsDefines::Side Side, UInt32 NrDoc, System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage ,System::Drawing::Bitmap ^%FrontImage2,System::Drawing::Bitmap ^%RearImage2,System::Drawing::Bitmap ^%ImageMerged,bool fShowImageUV)
{
	int rc;
	HANDLE fbImage=NULL, rbImage=NULL, fnImage=NULL, rnImage=NULL ;
	HANDLE fMerged = NULL ;
	short Reserved1=0 , Reserved2=0 ;
//	System::Drawing::Image ^iBitmap;


	if (ffbImage )
	{
		::LSFreeImage(0, (HANDLE *)&ffbImage);
		ffbImage = 0;
	}

	if (rrbImage )
	{
		::LSFreeImage(0, (HANDLE *)&rrbImage);
		rrbImage= 0;
	}
	
	if (ffnImage )
	{
		::LSFreeImage(0, (HANDLE *)&ffnImage);
		ffnImage = 0;
	}

	if( fScaMode_A4 )
	{
		if( fScaMode_A4 == 1 )
		{
			TW_INT32 Cap_lValue;

			// Controllo se ci sono ancora fogli
			TWAIN_GetCapCurrent(CCAP_CEI_DOCUMENT_DETECTED, TWTY_INT32, &Cap_lValue);
			if( Cap_lValue == 0 )
			{
				// Chiudo il source
				TWAIN_UnloadSourceManager();

				rc = LSAPI_NO_OTHER_DOCUMENT;
				return rc;
			}
		}

		fScaMode_A4 = 1;

		// Leggo le immagini e sull'ultima chiudo !!!
		rc = LSAPI_OKAY;

			// Leggo il fronte
		if( Side == LsFamily::LsDefines::Side::SIDE_ALL_IMAGE || Side == LsFamily::LsDefines::Side::SIDE_FRONT_IMAGE )
		{
			HANDLE hdib;
			int		DimImage;
			Byte	bfh[14];
			array<Byte> ^a_bfh = gcnew array<Byte>(14);
			array<Byte> ^a_pImage;

			hdib = TWAIN_WaitForNativeXfer((HWND)hWnd);
			unsigned int nErrRC = TWAIN_GetResultCode();
			if (hdib != NULL)
			{
				long	sizeImage;

				// Leggo la dimenzione dell'immagine
				ffbImage = *((HANDLE *)hdib);
				sizeImage = ((BITMAPINFOHEADER *)ffbImage)->biSizeImage;

				// Alloco un 'area per l'immagine
				ffbImage = ::GlobalAlloc(GPTR, sizeImage + 4000);
				memcpy(ffbImage, *((HANDLE *)hdib), sizeImage);

				// Create the bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(ffbImage, bfh, &DimImage);

				// Create the stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... copy it in the stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( ffbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)ffbImage, a_pImage, 0, DimImage);

				// Copy in the stream the image
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo a bitmap class from the stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				// Delete the temporary aree
				delete a_pImage;
				delete memStream;
				delete a_bfh;

					// Libero l'immagine twain
				TWAIN_FreeNative(hdib);
				hdib = NULL;
			}
			else
			{	
				// Chiudo il source
				TWAIN_UnloadSourceManager();

				rc = LSAPI_NO_OTHER_DOCUMENT;
				return rc;
			}
		}

			// Leggo il retro
		if( Side == LsFamily::LsDefines::Side::SIDE_ALL_IMAGE )
		{
			HANDLE hdib;
			int		DimImage;
			Byte	bfh[14];
			array<Byte> ^a_bfh = gcnew array<Byte>(14);
			array<Byte> ^a_pImage;

			long	sizeImage;

			hdib = TWAIN_WaitForNativeXfer((HWND)hWnd);

			// Leggo la dimenzione dell'immagine
			rrbImage = *((HANDLE *)hdib);
			sizeImage = ((BITMAPINFOHEADER *)rrbImage)->biSizeImage;

			// Alloco un 'area per l'immagine
			rrbImage = ::GlobalAlloc(GPTR, sizeImage + 4000);
			memcpy(rrbImage, *((HANDLE *)hdib), sizeImage);

			// Creo il bitmap file header e ...
			Miscellaneous::Func::CreateBitmapFileHeader(rrbImage, bfh, &DimImage);

			// Creo uno stream
			MemoryStream^ memStream = gcnew MemoryStream( DimImage );

			// ... lo copio nello stream
			Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
			memStream->Write(a_bfh, 0, sizeof(bfh));

			DimImage = ::GlobalSize( rrbImage );
			a_pImage = gcnew array<Byte>(DimImage);
			Marshal::Copy((IntPtr)rrbImage, a_pImage, 0, DimImage);

			// Copio nello stream l'immagine a 32 bit
			memStream->Write(a_pImage, 0, a_pImage->Length);

			// Creo la bitmap dall stream
			RearImage = gcnew System::Drawing::Bitmap( memStream );

			// Cancello le aree utilizzate
			delete a_pImage;
			delete memStream;
			delete a_bfh;

				// Libero l'immagine twain
			TWAIN_FreeNative(hdib);
			hdib = NULL;
		}
	}
	else
	{
		rc = ::LSReadImage(hConnect, (HWND)hWnd, (short)ClearBlack, (char)Side, 0, NrDoc, &ffbImage, &rrbImage, &ffnImage, &rnImage);

	
		if( rc == LSAPI_OKAY || rc == LSAPI_DOUBLE_LEAFING_WARNING )
		{
			if( (char)Side == LSAPI_SIDE_FRONT_IMAGE || (char)Side == LSAPI_SIDE_ALL_IMAGE )
			{
					// Live the bitmap as it's, after create a bitmap class
					System::Drawing::Color pixColor;
					int		DimImage;
					Byte	bfh[14];
					Byte	bfh2[14];
					Byte	bfh3[14];
					array<Byte> ^a_bfh = gcnew array<Byte>(14);
					array<Byte> ^a_bfh2 = gcnew array<Byte>(14);
					array<Byte> ^a_bfh3 = gcnew array<Byte>(14);
					array<Byte> ^a_pImage;
					array<Byte> ^a_pImage2;
					array<Byte> ^a_pImage3;
					// Create the bitmap file header e ...
					Miscellaneous::Func::CreateBitmapFileHeader(ffbImage, bfh, &DimImage);

					// Create the stream
					MemoryStream^ memStream = gcnew MemoryStream( DimImage );

					// ... copy it in the stream
					Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
					memStream->Write(a_bfh, 0, sizeof(bfh));

					DimImage = ::GlobalSize( ffbImage );
					a_pImage = gcnew array<Byte>(DimImage);
					Marshal::Copy((IntPtr)ffbImage, a_pImage, 0, DimImage);

					// Copy in the stream the image
					memStream->Write(a_pImage, 0, a_pImage->Length);

					// Creo a bitmap class from the stream
					FrontImage = gcnew System::Drawing::Bitmap( memStream );

					// Delete the temporary aree
					delete a_pImage;
					delete memStream;
					delete a_bfh;
					//::LSFreeImage(0, (HANDLE *)&fbImage);

					//UV conversion 
					if (ffnImage && (ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV || ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV))
					{
						if (fShowImageUV == TRUE )
						{
							//ho chiesto di tornare le tre immagini (GRAY + UV + MERGED )
							Miscellaneous::Func::CreateBitmapFileHeader(ffnImage, bfh2, &DimImage);

							// Create the stream
							MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
					
							// ... copy it in the stream
							Marshal::Copy((IntPtr)bfh2, a_bfh2, 0, sizeof(bfh2));
							memStream2->Write(a_bfh2, 0, sizeof(bfh2));

							DimImage = ::GlobalSize( ffnImage );
							a_pImage2 = gcnew array<Byte>(DimImage);
							Marshal::Copy((IntPtr)ffnImage, a_pImage2, 0, DimImage);

							// Copy in the stream the image
							memStream2->Write(a_pImage2, 0, a_pImage2->Length);

							// Creo a bitmap class from the stream
							FrontImage2 = gcnew System::Drawing::Bitmap( memStream2 );

							// Delete the temporary aree
							delete a_pImage2;
							delete memStream2;
							delete a_bfh2;
							//::LSFreeImage(0, (HANDLE *)&fnImage);

						}
						//altrimenti di default torno l'immagine GRIGIO + MERGED
						rc =::LSMergeImageGrayAndUV((HWND)hWnd,(HANDLE)ffbImage,(HANDLE)ffnImage,Reserved1,Reserved2,&fMerged);
						// Create the bitmap file header e ...
						Miscellaneous::Func::CreateBitmapFileHeader(fMerged, bfh3, &DimImage);

						// Create the stream
						MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
					
						// ... copy it in the stream
						Marshal::Copy((IntPtr)bfh3, a_bfh3, 0, sizeof(bfh3));
						memStream2->Write(a_bfh3, 0, sizeof(bfh3));

						DimImage = ::GlobalSize( fMerged );
						a_pImage3 = gcnew array<Byte>(DimImage);
						Marshal::Copy((IntPtr)fMerged, a_pImage3, 0, DimImage);

						// Copy in the stream the image
						memStream2->Write(a_pImage3, 0, a_pImage3->Length);

						// Creo a bitmap class from the stream
						ImageMerged = gcnew System::Drawing::Bitmap( memStream2 );

						// Delete the temporary aree
						delete a_pImage3;
						delete memStream2;
						delete a_bfh3;
						::LSFreeImage(0, (HANDLE *)&fMerged);
					}
			}
			if( (char)Side == LSAPI_SIDE_BACK_IMAGE || (char)Side == LSAPI_SIDE_ALL_IMAGE )
			{
				
					// Lascio la bitmap cos� come e la copio in una bitmap class
					System::Drawing::Color pixColor;
					int		DimImage;
					Byte	bfh[14];
					array<Byte> ^a_bfh = gcnew array<Byte>(14);
					array<Byte> ^a_pImage;

					// Creo il bitmap file header e ...
					Miscellaneous::Func::CreateBitmapFileHeader(rrbImage, bfh, &DimImage);

					// Creo uno stream
					MemoryStream^ memStream = gcnew MemoryStream( DimImage );

					// ... lo copio nello stream
					Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
					memStream->Write(a_bfh, 0, sizeof(bfh));

					DimImage = ::GlobalSize( rrbImage );
					a_pImage = gcnew array<Byte>(DimImage);
					Marshal::Copy((IntPtr)rrbImage, a_pImage, 0, DimImage);

					// Copio nello stream l'immagine a 32 bit
					memStream->Write(a_pImage, 0, a_pImage->Length);

					// Creo la bitmap dall stream
					RearImage = gcnew System::Drawing::Bitmap( memStream );

					// Cancello le aree utilizzate
					delete a_pImage;
					delete memStream;
					delete a_bfh;
					//::LSFreeImage(0, (HANDLE *)&rbImage);
				

		
			}
		}
	}

	return rc;
}
int LsFamily::LsApi::LSReadImage(Int32 hConnect, Int32 hWnd, LsDefines::ClearBlack ClearBlack, LsDefines::Side Side, UInt32 NrDoc, System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage ,System::Drawing::Bitmap ^%FrontImage2, System::Drawing::Bitmap ^%RearImage2 )
{
	int rc;
	HANDLE fbImage=NULL, rbImage=NULL, fnImage=NULL, rnImage=NULL ;
	HANDLE fMerged = NULL ;
	short Reserved1=0 , Reserved2=0 ;
//	System::Drawing::Image ^iBitmap;

	if (ffbImage )
		::LSFreeImage(0, (HANDLE *)&ffbImage);

	if (rrbImage )
		::LSFreeImage(0, (HANDLE *)&rrbImage);
	
	if (ffnImage )
		::LSFreeImage(0, (HANDLE *)&ffnImage);

	rc = ::LSReadImage(hConnect, (HWND)hWnd, (short)ClearBlack, (char)Side, 0, NrDoc, &ffbImage, &rrbImage, &ffnImage, &rnImage);

	
	if( rc == LSAPI_OKAY || rc == LSAPI_DOUBLE_LEAFING_WARNING )
	{
		if( (char)Side == LSAPI_SIDE_FRONT_IMAGE || (char)Side == LSAPI_SIDE_ALL_IMAGE )
		{
			if( 0 )
			{
				// Convert the bitmap to color, after create a bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	*pImage32;
//				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				Miscellaneous::Func::ConvertBitmapTo32Bit((Byte *)fbImage, &pImage32, &DimImage);

				

				// Creoate a stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)pImage32, a_pImage, 0, DimImage);

				// Copy the 32 bit image to stream
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo a bitmap class from stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				// Delete temporary aree
				delete a_pImage;
				delete memStream;
				::GlobalFree( pImage32 );
				::LSFreeImage(0, (HANDLE *)&fbImage);
			}
			else
			{
				// Live the bitmap as it's, after create a bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				Byte	bfh2[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_bfh2 = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;
				array<Byte> ^a_pImage2;
				// Create the bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(ffbImage, bfh, &DimImage);

				// Create the stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... copy it in the stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( ffbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)ffbImage, a_pImage, 0, DimImage);

				// Copy in the stream the image
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo a bitmap class from the stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				// Delete the temporary aree
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				//::LSFreeImage(0, (HANDLE *)&fbImage);

				//UV conversion 
				if (ffnImage && (ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV || ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV))
				{
					//so k ho selezionato UV e faccio tornare direttamente l'immagine MERGE
					rc =::LSMergeImageGrayAndUV((HWND)hWnd,(HANDLE)ffbImage,(HANDLE)ffnImage,Reserved1,Reserved2,&fMerged);
					// Create the bitmap file header e ...
					Miscellaneous::Func::CreateBitmapFileHeader(fMerged, bfh2, &DimImage);

					// Create the stream
					MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
				
					// ... copy it in the stream
					Marshal::Copy((IntPtr)bfh2, a_bfh2, 0, sizeof(bfh2));
					memStream2->Write(a_bfh2, 0, sizeof(bfh2));

					DimImage = ::GlobalSize( fMerged );
					a_pImage2 = gcnew array<Byte>(DimImage);
					Marshal::Copy((IntPtr)fMerged, a_pImage2, 0, DimImage);

					// Copy in the stream the image
					memStream2->Write(a_pImage2, 0, a_pImage2->Length);

					// Creo a bitmap class from the stream
					FrontImage2 = gcnew System::Drawing::Bitmap( memStream2 );

					// Delete the temporary aree
					delete a_pImage2;
					delete memStream2;
					delete a_bfh2;
					//::LSFreeImage(0, (HANDLE *)&fnImage);


					
				}


			}

			// -----------------Old
//			// Create a image object and after a Bitmap object
//			rc = ::LSSaveDIB(0, fbImage, TMP_PATH_IMAGE);
//			iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE, true);
////			iBitmap = Drawing::Image::FromHbitmap( (IntPtr)fbImage );
//			BackImage = gcnew Drawing::Bitmap( iBitmap );
//			Miscellaneous::Func::SetResolution(rbImage, BackImage);
//
//			::LSFreeImage(0, (HANDLE *)&rbImage);
//			delete iBitmap;
		}
		if( (char)Side == LSAPI_SIDE_BACK_IMAGE || (char)Side == LSAPI_SIDE_ALL_IMAGE )
		{
			if( 0 )
			{
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	*pImage32;
//				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				Miscellaneous::Func::ConvertBitmapTo32Bit((Byte *)rbImage, &pImage32, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)pImage32, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				::GlobalFree( pImage32 );
				::LSFreeImage(0, (HANDLE *)&rbImage);
			}
			else
			{
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(rrbImage, bfh, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( rrbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)rrbImage, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				//::LSFreeImage(0, (HANDLE *)&rbImage);
			}

			// -----------------Old
//			// Create a image object and after a Bitmap object
//			rc = ::LSSaveDIB(0, rbImage, TMP_PATH_IMAGE);
//			iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE, true);
////			iBitmap = Drawing::Image::FromHbitmap( (IntPtr)rbImage );
//			BackImage = gcnew Drawing::Bitmap( iBitmap );
//			Miscellaneous::Func::SetResolution(rbImage, BackImage);
//
//			::LSFreeImage(0, (HANDLE *)&rbImage);
//			delete iBitmap;
		}
	}

	return rc;
} // LsFamily::LSReadImage





int LsFamily::LsApi::LSSaveImage(Int32 hConnect, Int32 hWnd, System::Drawing::Bitmap ^hImage, String ^FileName, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber,LsDefines::Side Side)
{
	int rc;
	//char *pBitmap;
	char *pFileName;
	String ^tmpFName;


	//if( Miscellaneous::Func::ConvertClassBitmapToDIB(hImage, &pBitmap) )
	//{
	if( (char)Side == LSAPI_SIDE_FRONT_IMAGE ) //|| (char)Side == LSAPI_SIDE_ALL_IMAGE )
	{
		if( FileFormat == LsDefines::FileType::FILE_BMP )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".bmp", 0, true) &&
				System::String::Compare(FileName, (FileName->Length -4), ".dib", 0, true) )
				tmpFName = FileName->Concat(FileName, ".bmp");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			//rc = ::LSSaveDIB((HWND)hWnd, pBitmap, pFileName);
			rc = ::LSSaveDIB((HWND)hWnd, ffbImage, pFileName);
		}

		else if( FileFormat == LsDefines::FileType::FILE_JPEG )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".jpg", 0, true) )
				tmpFName = FileName->Concat(FileName, ".jpg");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			//rc = ::LSSaveJPEG((HWND)hWnd, pBitmap, Quality, pFileName);
			rc = ::LSSaveJPEG((HWND)hWnd, ffbImage, Quality, pFileName);
		}

		else if( FileFormat == LsDefines::FileType::FILE_TIF ||
				 FileFormat == LsDefines::FileType::FILE_CCITT ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP4 )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".tif", 0, true) )
				tmpFName = FileName->Concat(FileName, ".tif");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			//rc = ::LSSaveTIFF((HWND)hWnd, pBitmap, pFileName, (int)FileFormat, (int)SaveMode, PageNumber);
			rc = ::LSSaveTIFF((HWND)hWnd, ffbImage, pFileName, (int)FileFormat, (int)SaveMode, PageNumber);
			
		}

		else
			rc = LsReply::LS_INVALID_FILEFORMAT;

		// Release the temporary aree
		delete tmpFName;
		Marshal::FreeHGlobal( (IntPtr)pFileName);
		//GlobalFree( pBitmap );
	//} // if( pBitmap )
	//else
	//	rc = LSAPI_SYSTEM_ERROR;
	}


	if( (char)Side == LSAPI_SIDE_BACK_IMAGE )// || (char)Side == LSAPI_SIDE_ALL_IMAGE )
	{
		if( FileFormat == LsDefines::FileType::FILE_BMP )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".bmp", 0, true) &&
				System::String::Compare(FileName, (FileName->Length -4), ".dib", 0, true) )
				tmpFName = FileName->Concat(FileName, ".bmp");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			//rc = ::LSSaveDIB((HWND)hWnd, pBitmap, pFileName);
			rc = ::LSSaveDIB((HWND)hWnd, rrbImage, pFileName);
		}

		else if( FileFormat == LsDefines::FileType::FILE_JPEG )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".jpg", 0, true) )
				tmpFName = FileName->Concat(FileName, ".jpg");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			rc = ::LSSaveJPEG((HWND)hWnd, rrbImage, Quality, pFileName);
		}

		else if( FileFormat == LsDefines::FileType::FILE_TIF ||
				 FileFormat == LsDefines::FileType::FILE_CCITT ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP4 )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".tif", 0, true) )
				tmpFName = FileName->Concat(FileName, ".tif");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			rc = ::LSSaveTIFF((HWND)hWnd, rrbImage, pFileName, (int)FileFormat, (int)SaveMode, PageNumber);
		}

		else
			rc = LsReply::LS_INVALID_FILEFORMAT;

		// Release the temporary aree
		delete tmpFName;
		Marshal::FreeHGlobal( (IntPtr)pFileName);
		//GlobalFree( pBitmap );
	//} // if( pBitmap )
	//else
	//	rc = LSAPI_SYSTEM_ERROR;
	}

	if( (char)Side == LSAPI_SIDE_UV_FRONT_IMAGE )// || (char)Side == LSAPI_SIDE_ALL_IMAGE )
	{
		if( FileFormat == LsDefines::FileType::FILE_BMP )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".bmp", 0, true) &&
				System::String::Compare(FileName, (FileName->Length -4), ".dib", 0, true) )
				tmpFName = FileName->Concat(FileName, ".bmp");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			//rc = ::LSSaveDIB((HWND)hWnd, pBitmap, pFileName);
			rc = ::LSSaveDIB((HWND)hWnd, ffnImage, pFileName);
		}

		else if( FileFormat == LsDefines::FileType::FILE_JPEG )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".jpg", 0, true) )
				tmpFName = FileName->Concat(FileName, ".jpg");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			rc = ::LSSaveJPEG((HWND)hWnd, ffnImage, Quality, pFileName);
		}

		else if( FileFormat == LsDefines::FileType::FILE_TIF ||
				 FileFormat == LsDefines::FileType::FILE_CCITT ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
				 FileFormat == LsDefines::FileType::FILE_CCITT_GROUP4 )
		{
			if( System::String::Compare(FileName, (FileName->Length -4), ".tif", 0, true) )
				tmpFName = FileName->Concat(FileName, ".tif");
			else
				tmpFName = FileName;

			// Convert from String to char
			pFileName = (char*)(void*)Marshal::StringToHGlobalAnsi(tmpFName);

			rc = ::LSSaveTIFF((HWND)hWnd, ffnImage, pFileName, (int)FileFormat, (int)SaveMode, PageNumber);
		}

		else
			rc = LsReply::LS_INVALID_FILEFORMAT;


	
		// Release the temporary aree
		delete tmpFName;
		Marshal::FreeHGlobal( (IntPtr)pFileName);
		//GlobalFree( pBitmap );
	//} // if( pBitmap )
	//else
	//	rc = LSAPI_SYSTEM_ERROR;
	}


	return rc;
} // LsFamily::LSSaveImage


int LsFamily::LsApi::LSFreeImage(Int32 hWnd, System::Drawing::Bitmap ^hImage)
{
	int rc;
	IntPtr hBitmap;

	delete hImage;

	rc = LSAPI_OKAY;

	return rc;
} // LsFamily::LSFreeImage


int LsFamily::LsApi::LSReset(Int32 hConnect, Int32 hWnd, LsDefines::Reset ResetType)
{
	int rc;

	rc = ::LSReset(hConnect, (HWND)hWnd, (char)ResetType);

	return rc;
} // LsFamily::LSReset

int LsFamily::LsApi::LSUnitStatus(Int32 hConnect, Int32 hWnd, LsUnitStatus ^lpStatus)
{
	int rc;
	unsigned char SenseKey;
	unsigned char pStatus[20];
	char cModel[20];

	memset(pStatus, 0, sizeof(pStatus));
	// Identify for know the unit model connected
	rc = LSIdentifyEx(hConnect, (HWND)hWnd, NULL, cModel, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

//	if( rc == LSAPI_OKAY )
	{
		rc = LSPeripheralStatus(hConnect, (HWND)hWnd, &SenseKey, pStatus);

//		if( rc == LSAPI_OKAY )
		{
			if( lpStatus )
			{
	//			::Buffer::SetByte(lppStatuss, 0, pStatus[0]);
	//			::Buffer::SetByte(lppStatuss, 1, pStatus[1]);
	//			::Buffer::SetByte(lppStatuss, 2, pStatus[2]);
	//			::Buffer::SetByte(lppStatuss, 3, pStatus[3]);

				// Set the status
				lpStatus->UnitStatus = SenseKey;

				// Test sensor status Ls100
				if( ! strncmp(cModel, MODEL_LS100, strlen(MODEL_LS100)) )
					
				{
					// First Byte
					if( pStatus[0] & 0x02 )
					{
						if( pStatus[0] & 0x01 )
							lpStatus->Photo_Feeder = TRUE;
						else
							lpStatus->Photo_Feeder = FALSE;
					}
					if( pStatus[0] & 0x08 )
					{
						if( pStatus[0] & 0x04 )
							lpStatus->Photo_Sorter = TRUE;
						else
							lpStatus->Photo_Sorter = FALSE;
					}
					if( pStatus[0] & 0x10 )
						lpStatus->Photo_MICR = TRUE;
					else
						lpStatus->Photo_MICR = FALSE;
					if( pStatus[0] & 0x20 )
						lpStatus->Photo_Path_Ls100 = TRUE;
					else
						lpStatus->Photo_Path_Ls100 = FALSE;
					if( pStatus[0] & 0x40 )
						lpStatus->Photo_Scanners = TRUE;
					else
						lpStatus->Photo_Scanners = FALSE;
					if( pStatus[0] & 0x80 )
						lpStatus->Unit_Just_ON = TRUE;
					else
						lpStatus->Unit_Just_ON = FALSE;

					// Second Byte
					if( pStatus[1] & 0x10 )
						lpStatus->Photo_Double_Leafing_Down = TRUE; // DOWN
					else
						lpStatus->Photo_Double_Leafing_Down = FALSE; // DOWN
					if( pStatus[1] & 0x20 )
						lpStatus->Photo_Double_Leafing_Up = TRUE; // UP
					else
						lpStatus->Photo_Double_Leafing_Up = FALSE; // UP
				}
				// Test sensor status Ls40
				if (! strncmp(cModel, MODEL_LS40, strlen(MODEL_LS40)) )
				
				{
					// First Byte
					if( pStatus[0] & 0x01 )
						lpStatus->Photo_Feeder = TRUE;
					else
						lpStatus->Photo_Feeder = FALSE;
					
					/*if( pStatus[0] & 0x02 )
					{
						if( pStatus[0] & 0x04 )
							lpStatus->Photo_Sorter = TRUE;
						else
							lpStatus->Photo_Sorter = FALSE;
					}
					if( pStatus[0] & 0x10 )
						lpStatus->Photo_MICR = TRUE;
					else
						lpStatus->Photo_MICR = FALSE;
					if( pStatus[0] & 0x20 )
						lpStatus->Photo_Path_Ls100 = TRUE;
					else
						lpStatus->Photo_Path_Ls100 = FALSE;
					if( pStatus[0] & 0x40 )
						lpStatus->Photo_Scanners = TRUE;
					else
						lpStatus->Photo_Scanners = FALSE;*/
					if( pStatus[0] & 0x80 )
						lpStatus->Unit_Just_ON = TRUE;
					else
						lpStatus->Unit_Just_ON = FALSE;

					// Second Byte
					//if( pStatus[1] & 0x10 )
					//	lpStatus->Photo_Double_Leafing_Down = TRUE; // DOWN
					//else
					//	lpStatus->Photo_Double_Leafing_Down = FALSE; // DOWN
					//if( pStatus[1] & 0x20 )
					//	lpStatus->Photo_Double_Leafing_Up = TRUE; // UP
					//else
					//	lpStatus->Photo_Double_Leafing_Up = FALSE; // UP

				}

				if( ! strncmp(cModel, MODEL_LS150, strlen(MODEL_LS150)) )
				{
					// First byte
					if( pStatus[0] & 0x01 )
						lpStatus->Photo_Feeder = TRUE;
					else
						lpStatus->Photo_Feeder = FALSE;
					if( pStatus[0] & 0x02 )
						lpStatus->Photo_MICR = TRUE;
					else
						lpStatus->Photo_MICR = FALSE;
					if( pStatus[0] & 0x04 )
						lpStatus->Photo_Card = TRUE;
					else
						lpStatus->Photo_Card = FALSE;
					if( pStatus[0] & 0x08 )
						lpStatus->Photo_Scanners = TRUE;
					else
						lpStatus->Photo_Scanners = FALSE;
					if( pStatus[0] & 0x10 )
						lpStatus->Bins_All_Full = TRUE;
					else
						lpStatus->Bins_All_Full = FALSE;
					if( pStatus[0] & 0x80 )
						lpStatus->Unit_Just_ON = TRUE;
					else
						lpStatus->Unit_Just_ON = FALSE;

					// Second Byte
					if( pStatus[1] & 0x10 )
						lpStatus->Photo_Double_Leafing_Down = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Down = FALSE;
					if( pStatus[1] & 0x20 )
						lpStatus->Photo_Double_Leafing_Middle = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Middle = FALSE;
					if( pStatus[1] & 0x40 )
						lpStatus->Photo_Double_Leafing_Up = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Up = FALSE;
				}

				if( ! strncmp(cModel, MODEL_LS520, strlen(MODEL_LS520)) ||
					! strncmp(cModel, MODEL_LS515, strlen(MODEL_LS515)) )
				{
					// First Byte
					if( pStatus[0] & 0x01 )
						lpStatus->Photo_Feeder = TRUE;
					else
						lpStatus->Photo_Feeder = FALSE;
					if( pStatus[0] & 0x02 )
						lpStatus->Photo_MICR = TRUE;
					else
						lpStatus->Photo_MICR = FALSE;
					if( pStatus[0] & 0x04 )
						lpStatus->Photo_Stamp = TRUE;
					else
						lpStatus->Photo_Stamp = FALSE;
					if( pStatus[0] & 0x08 )
						lpStatus->Photo_Scanners = TRUE;
					else
						lpStatus->Photo_Scanners = FALSE;
					if( pStatus[0] & 0x80 )
						lpStatus->Unit_Just_ON = TRUE;
					else
						lpStatus->Unit_Just_ON = FALSE;

					// Second Byte
					if( pStatus[1] & 0x01 )
						lpStatus->Photo_Exit = TRUE;
					else
						lpStatus->Photo_Exit = FALSE;
					if( pStatus[1] & 0x02 )
						lpStatus->Bin_1_Full = TRUE;
					else
						lpStatus->Bin_1_Full = FALSE;
					if( pStatus[1] & 0x04 )
						lpStatus->Bin_2_Full = TRUE;
					else
						lpStatus->Bin_2_Full = FALSE;
//					if( (pStatus[1] & 0x02) && (pStatus[1] & 0x04) )
//						lpStatus->Bins_All_Full = TRUE;
//					else
//						lpStatus->Bins_All_Full = FALSE;
					if( pStatus[1] & 0x08 )
						lpStatus->Photo_Double_Leafing_Down = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Down = FALSE;
					if( pStatus[1] & 0x10 )
						lpStatus->Photo_Double_Leafing_Middle = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Middle = FALSE;
					if( pStatus[1] & 0x20 )
						lpStatus->Photo_Double_Leafing_Up = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Up = FALSE;
				}

				if( ! strncmp(cModel, MODEL_LS800, strlen(MODEL_LS800)) ||
					! strncmp(cModel, MODEL_LS800_NCR, strlen(MODEL_LS800_NCR)) )
				{
					// First Byte
					if( pStatus[0] & 0x01 )
						lpStatus->Sorter_1_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_1_input_pocket_1 = FALSE;
					if( pStatus[0] & 0x02 )
						lpStatus->Sorter_1_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_1_pocket_1_full = FALSE;
					if( pStatus[0] & 0x04 )
						lpStatus->Sorter_1_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_1_input_pocket_2 = FALSE;
					if( pStatus[0] & 0x08 )
						lpStatus->Sorter_1_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_1_pocket_2_full = FALSE;
					if( pStatus[0] & 0x10 )
						lpStatus->Sorter_1_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_1_input_pocket_3 = FALSE;
					if( pStatus[0] & 0x20 )
						lpStatus->Sorter_1_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_1_pocket_3_full = FALSE;

					// Second Byte
					if( pStatus[1] & 0x01 )
						lpStatus->Sorter_2_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_2_input_pocket_1 = FALSE;
					if( pStatus[1] & 0x02 )
						lpStatus->Sorter_2_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_2_pocket_1_full = FALSE;
					if( pStatus[1] & 0x04 )
						lpStatus->Sorter_2_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_2_input_pocket_2 = FALSE;
					if( pStatus[1] & 0x08 )
						lpStatus->Sorter_2_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_2_pocket_2_full = FALSE;
					if( pStatus[1] & 0x10 )
						lpStatus->Sorter_2_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_2_input_pocket_3 = FALSE;
					if( pStatus[1] & 0x20 )
						lpStatus->Sorter_2_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_2_pocket_3_full = FALSE;

					// Third Byte
					if( pStatus[2] & 0x01 )
						lpStatus->Sorter_3_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_3_input_pocket_1 = FALSE;
					if( pStatus[2] & 0x02 )
						lpStatus->Sorter_3_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_3_pocket_1_full = FALSE;
					if( pStatus[2] & 0x04 )
						lpStatus->Sorter_3_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_3_input_pocket_2 = FALSE;
					if( pStatus[2] & 0x08 )
						lpStatus->Sorter_3_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_3_pocket_2_full = FALSE;
					if( pStatus[2] & 0x10 )
						lpStatus->Sorter_3_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_3_input_pocket_3 = FALSE;
					if( pStatus[2] & 0x20 )
						lpStatus->Sorter_3_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_3_pocket_3_full = FALSE;

					// Fourth Byte
					if( pStatus[3] & 0x01 )
						lpStatus->Sorter_4_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_4_input_pocket_1 = FALSE;
					if( pStatus[3] & 0x02 )
						lpStatus->Sorter_4_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_4_pocket_1_full = FALSE;
					if( pStatus[3] & 0x04 )
						lpStatus->Sorter_4_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_4_input_pocket_2 = FALSE;
					if( pStatus[3] & 0x08 )
						lpStatus->Sorter_4_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_4_pocket_2_full = FALSE;
					if( pStatus[3] & 0x10 )
						lpStatus->Sorter_4_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_4_input_pocket_3 = FALSE;
					if( pStatus[3] & 0x20 )
						lpStatus->Sorter_4_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_4_pocket_3_full = FALSE;

					// Fifth Byte
					if( pStatus[4] & 0x01 )
						lpStatus->Sorter_5_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_5_input_pocket_1 = FALSE;
					if( pStatus[4] & 0x02 )
						lpStatus->Sorter_5_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_5_pocket_1_full = FALSE;
					if( pStatus[4] & 0x04 )
						lpStatus->Sorter_5_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_5_input_pocket_2 = FALSE;
					if( pStatus[4] & 0x08 )
						lpStatus->Sorter_5_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_5_pocket_2_full = FALSE;
					if( pStatus[4] & 0x10 )
						lpStatus->Sorter_5_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_5_input_pocket_3 = FALSE;
					if( pStatus[4] & 0x20 )
						lpStatus->Sorter_5_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_5_pocket_3_full = FALSE;

					// Seventh Byte
					if( pStatus[6] & 0x04 )
						lpStatus->Photo_Path_Feeder = TRUE;
					else
						lpStatus->Photo_Path_Feeder = FALSE;
					if( pStatus[6] & 0x08 )
						lpStatus->Photo_Double_Leafing_Down = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Down = FALSE;
					if( pStatus[6] & 0x10 )
						lpStatus->Photo_Double_Leafing_Middle = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Middle = FALSE;
					if( pStatus[6] & 0x20 )
						lpStatus->Photo_Double_Leafing_Up = TRUE;
					else
						lpStatus->Photo_Double_Leafing_Up = FALSE;

					// Eighth Byte
					if( pStatus[7] & 0x01 )
						lpStatus->Photo_Feeder = FALSE;
					else
						lpStatus->Photo_Feeder = TRUE;
					if( pStatus[7] & 0x02 )
						lpStatus->Photo_Path_Module_Begin = TRUE;
					else
						lpStatus->Photo_Path_Module_Begin = FALSE;
					if( pStatus[7] & 0x04 )
						lpStatus->Photo_Path_Binary_Rigth = TRUE;
					else
						lpStatus->Photo_Path_Binary_Rigth = FALSE;
					if( pStatus[7] & 0x08 )
						lpStatus->Photo_Path_Binary_Left = TRUE;
					else
						lpStatus->Photo_Path_Binary_Left = FALSE;
					if( pStatus[7] & 0x10 )
						lpStatus->Photo_Path_Module_End = TRUE;
					else
						lpStatus->Photo_Path_Module_End = FALSE;

					// Tenth Byte
					if( pStatus[9] & 0x01 )
						lpStatus->Sorter_6_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_6_input_pocket_1 = FALSE;
					if( pStatus[9] & 0x02 )
						lpStatus->Sorter_6_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_6_pocket_1_full = FALSE;
					if( pStatus[9] & 0x04 )
						lpStatus->Sorter_6_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_6_input_pocket_2 = FALSE;
					if( pStatus[9] & 0x08 )
						lpStatus->Sorter_6_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_6_pocket_2_full = FALSE;
					if( pStatus[9] & 0x10 )
						lpStatus->Sorter_6_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_6_input_pocket_3 = FALSE;
					if( pStatus[9] & 0x20 )
						lpStatus->Sorter_6_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_6_pocket_3_full = FALSE;

					// Eleventh Byte
					if( pStatus[10] & 0x01 )
						lpStatus->Sorter_7_input_pocket_1 = TRUE;
					else
						lpStatus->Sorter_7_input_pocket_1 = FALSE;
					if( pStatus[10] & 0x02 )
						lpStatus->Sorter_7_pocket_1_full = TRUE;
					else
						lpStatus->Sorter_7_pocket_1_full = FALSE;
					if( pStatus[10] & 0x04 )
						lpStatus->Sorter_7_input_pocket_2 = TRUE;
					else
						lpStatus->Sorter_7_input_pocket_2 = FALSE;
					if( pStatus[10] & 0x08 )
						lpStatus->Sorter_7_pocket_2_full = TRUE;
					else
						lpStatus->Sorter_7_pocket_2_full = FALSE;
					if( pStatus[10] & 0x10 )
						lpStatus->Sorter_7_input_pocket_3 = TRUE;
					else
						lpStatus->Sorter_7_input_pocket_3 = FALSE;
					if( pStatus[10] & 0x20 )
						lpStatus->Sorter_7_pocket_3_full = TRUE;
					else
						lpStatus->Sorter_7_pocket_3_full = FALSE;
				}
			}
		}
	}

	return rc;
} // LsFamily::LSUnitStatus



// ---- Ls515 callback routine ----------------------------

int __stdcall OnCodelineRead(S_CODELINE_INFO *CodelineInfo)
//int __clrcall LsFamily::LsApi::OnCodelineRead(S_CODELINE_INFO *CodelineInfo)
{
	String		^CodelineReadWH;
	Int32		Pocket;
	LsFamily::LsDefines::PrintFont	Font;
	String		^StrToPrint;
	char		*pString;

//	Object			^sender;
//	EventArgs		^e;
//	LsFamily::LS515CodelineEventHandler ^pEvent;
//	LS515OnCodelineCallBack		pCallBack;

//	sender = gcnew Object();
//	e = gcnew LsFamily::LsApiEventArgs();

//	LsFamily::LsApi ^LsClass = gcnew LsFamily::LsApi;
//	pEvent = gcnew LsFamily::LS515CodelineEventHandler(sender, e);

//	pEvent->Invoke(sender, e);

//	LsFamily::LsApiEventArgs par;

	CodelineReadWH = gcnew String(CodelineInfo->CodelineRead);
	LsFamily::LsApi::Ls515CallBack(CodelineReadWH, CodelineInfo->NrDoc, Pocket, Font, StrToPrint);
//	LsFamily::LsApi::OnLs515CodelineRead(gcnew LsFamily::LsApiEventArgs());
//	LsClass->OnLS515CodelineRead(sender, e);
//	LsFamily::LsApi::OnLS515CodelineRead(7, 7.44);

	// Compile the parameter of return
	CodelineInfo->Sorter = Pocket;
	if( StrToPrint )
	{
		CodelineInfo->FormatString = (char)Font;
		// Convert from String to char
		pString = (char*)(void*)Marshal::StringToHGlobalAnsi(StrToPrint);
		strcpy_s(CodelineInfo->StringToPrint, sizeof(CodelineInfo->StringToPrint), pString);
		Marshal::FreeHGlobal( (IntPtr)pString);
	}

	return 0;
} // OnCodelineRead

//int LsFamily::LsApi::LSAutoDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::Stamp Stamp, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanMode, LsDefines::Sorter Sorter, Int16 NumDocument, LsDefines::ClearBlack ClearBlack, LsDefines::ImageSave SaveImage, String ^DirectoryFile, String ^BaseFilename, LsDefines::Unit UnitMeasure, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber, LsDefines::Wait WaitTimeout, LsDefines::Beep Beep)
int LsFamily::LsApi::LSAutoDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::Stamp Stamp, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanMode, LsDefines::Sorter Sorter, Int16 NumDocument, LsDefines::ClearBlack ClearBlack, LsDefines::ImageSave SaveImage, String ^DirectoryFile, String ^BaseFilename, LsDefines::Unit UnitMeasure, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber, LsDefines::Wait WaitTimeout, LsDefines::Beep Beep, LsFamily::LS515OnCodelineCallBack ^pCallBack)
{
	int rc;
	char *pDirectoryFile, *pBaseFilename;
//	S_CODELINE_INFO CodelineInfo;


	// Save callback routine
	Ls515CallBack = pCallBack;

	// Convert from String to char
	pDirectoryFile = (char*)(void*)Marshal::StringToHGlobalAnsi(DirectoryFile);
	pBaseFilename = (char*)(void*)Marshal::StringToHGlobalAnsi(BaseFilename);

	rc = ::LSAutoDocHandle(hConnect, (HWND)hWnd, (short)Stamp, (short)Validate, (short)CodeLine, (short)ScanMode, (short)LsDefines::Feeder::FEED_AUTO, (short)Sorter, NumDocument, (short)ClearBlack, (char)Side, 0, (short)SaveImage, pDirectoryFile, pBaseFilename, (float)pos_x, (float)pos_y, (float)sizeW, (float)sizeH, (UnitMeasure == LsDefines::Unit::UNIT_INCH ? LSAPI_BOTTOM_RIGHT_INCH : LSAPI_BOTTOM_RIGHT_MM), 0, (short)FileFormat, Quality, (int)SaveMode, PageNumber, (short)WaitTimeout, (short)Beep, (Sorter == LsFamily::LsDefines::Sorter::SORTER_ON_CODELINE_CALLBACK ? OnCodelineRead : NULL), NULL, NULL);

	ScanModeSelezionato = (short)ScanMode ;  //mi salvo lo ScanMode che ho scelto 	
	GlobalQuality = (short)Quality ;
	GloabalFileType = (short)FileFormat ;
	
	Marshal::FreeHGlobal((IntPtr)pBaseFilename);
	Marshal::FreeHGlobal((IntPtr)pDirectoryFile);

	return rc;
} // LsFamily::LSAutoDocHandle



// ---- Ls800 callback routines ---------------------------
int __stdcall SortOnCodelineRead(S_CODELINE_INFO_LS800 *CodelineInfo)
{
	String		^CodelineReadWH;
	Int32		Pocket;
	LsFamily::LsDefines::PrintFont	Font;
	String		^StrToPrint;
	char		*pString;
	

	CodelineReadWH = gcnew String(CodelineInfo->CodelineRead);
	LsFamily::LsApi::Ls800cCallBack(CodelineReadWH, CodelineInfo->NrDoc, Pocket, Font, StrToPrint);

	CodelineInfo->Sorter = Pocket - (Int32)LsFamily::LsDefines::Sorter::SORTER_POCKET_0_SELECTED;
	
	if( StrToPrint )
	{
		CodelineInfo->FormatString1 = (char)Font;
		// Convert from String to char
		pString = (char*)(void*)Marshal::StringToHGlobalAnsi(StrToPrint);
		strcpy_s(CodelineInfo->StringToPrint1, sizeof(CodelineInfo->StringToPrint1), pString);
		Marshal::FreeHGlobal( (IntPtr)pString);
	}

	return 0;
}

int __stdcall SortOnImageRead(S_IMAGE_INFO_LS800 *ImageInfo)
{
	String		^CodelineReadWH;
	System::Drawing::Bitmap ^FrontImage;
	Int32		Pocket;
	LsFamily::LsDefines::PrintFont	Font;
	String		^StrToPrint;
	char		*pString;
	System::Drawing::Image ^iBitmap;


	if( ImageInfo->hImage )
	{
		// Create a image object and after a Bitmap object
		::LSSaveDIB(0, ImageInfo->hImage, TMP_PATH_IMAGE_CALLBACK);

		iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE_CALLBACK, true);
		FrontImage = gcnew Drawing::Bitmap( iBitmap );
		Miscellaneous::Func::SetResolution(ImageInfo->hImage, FrontImage);

//		::LSFreeImage(0, (HANDLE *)&(ImageInfo->hImage));
		delete iBitmap;
		delete FrontImage;
	}
	
	CodelineReadWH = gcnew String(ImageInfo->CodelineRead);
	LsFamily::LsApi::Ls800iCallBack(FrontImage, CodelineReadWH, ImageInfo->NrDoc, Pocket, Font, StrToPrint);

	// Compile the parameter of return
	ImageInfo->Sorter = Pocket - (Int32)LsFamily::LsDefines::Sorter::SORTER_POCKET_0_SELECTED;
	
	if( StrToPrint )
	{
		ImageInfo->FormatString1 = (char)Font;
		// Convert from String to char
		pString = (char*)(void*)Marshal::StringToHGlobalAnsi(StrToPrint);
		strcpy_s(ImageInfo->StringToPrint1, sizeof(ImageInfo->StringToPrint1), pString);
		Marshal::FreeHGlobal( (IntPtr)pString);
	}

	return 0;
}

int LsFamily::LsApi::LS800AutoDocHandle(Int32 hConnect, Int32 hWnd, LsDefines::PrintValidate Validate, LsDefines::CodelineToRead CodeLine, LsDefines::Side Side, LsDefines::ScanMode ScanModeFront, LsDefines::ScanMode ScanModeRear, LsDefines::ClearBlack ClearBlack, Int16 NumDocument, LsDefines::ImageSave SaveImage, String ^DirectoryFile, String ^BaseFilename, LsDefines::Unit Unit, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::FileType FileFormat, Int16 Quality, LsDefines::FileAttribute SaveMode, Int16 PageNumber, LsDefines::Beep Beep, LsFamily::LS800OnCodelineCallBack ^pcCallBack, LsFamily::LS800OnImageCallBack ^piCallBack)
{
	int rc;
	char *pDirectoryFile, *pBaseFilename;
	BOOL fOnCodeline;


	// Save callback routines
	Ls800cCallBack = pcCallBack;
	Ls800iCallBack = piCallBack;
	if( Ls800iCallBack )
		fOnCodeline = false;
	else
		fOnCodeline = true;

	// Convert from String to char
	pDirectoryFile = (char*)(void*)Marshal::StringToHGlobalAnsi(DirectoryFile);
	pBaseFilename = (char*)(void*)Marshal::StringToHGlobalAnsi(BaseFilename);

	rc = ::LS800AutoDocHandle(hConnect, (HWND)hWnd, (char)Validate, (short)CodeLine, (char)Side, (short)ScanModeFront, (short)ScanModeRear, (short)ClearBlack, NumDocument, (short)SaveImage, pDirectoryFile, pBaseFilename, (short)Unit, (float)pos_x, (float)pos_y, (float)sizeW, (float)sizeH, 0, (short)FileFormat, Quality, (int)SaveMode, PageNumber, (short)Beep, (fOnCodeline ? SortOnCodelineRead : NULL), (fOnCodeline ? NULL : SortOnImageRead), NULL, 0, 0, NULL);

	Marshal::FreeHGlobal((IntPtr)pBaseFilename);
	Marshal::FreeHGlobal((IntPtr)pDirectoryFile);

	return rc;
} // LsFamily::LS800AutoDocHandle


// LSGetDocData for UV Mode  ---torna anche il puntatore all'Image UV 
// fSaveImage = se e' a TRUE la GetDocData non salva piu' le immagini tramite LsApi ma tramite
// LsSaveJpeg ,Dib o tif
//uso FilenameRear2 per la salvare su disco il merge tra l'immagine grigio e l'uv
int LsFamily::LsApi::LSGetDocData(Int32 hConnect, Int32 hWnd, UInt32 %NrDoc, String ^%FilenameFront, String ^%FilenameRear, String ^%FilenameFront2, String ^%FilenameRear2,System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage , System::Drawing::Bitmap ^%FrontImage2, System::Drawing::Bitmap ^%RearImage2, System::Drawing::Bitmap ^%ImageMerged , String ^%CodelineSW, String ^%CodelineHW,bool fShowImageUV,bool fSaveImage,LsDefines::FileType FileFormat)
{
	int rc;
	int rcGetDocData ;
	unsigned long nrDoc;
	char pFilenameFront[_MAX_PATH], pFilenameBack[_MAX_PATH],pFilenameFront2[_MAX_PATH];
	HANDLE fbImage=NULL, rbImage=NULL,fnImage=NULL,ImageBW = NULL ;
    char pCodelineSW[256], pCodelineHW[128];
	short DocToRead;
	long ErrorType;
	HANDLE fMerged = NULL ;
	short Reserved1 = 0 , Reserved2 = 0 ; 
//	System::Drawing::Image ^iBitmap;
	int		DimImage;
	char *pFront , *pBack , *pFront2 ,*pGUVimage ;


	rcGetDocData = ::LSGetDocData(hConnect, (HWND)hWnd, &nrDoc, pFilenameFront, pFilenameBack, pFilenameFront2, NULL, (LPHANDLE *)&fbImage, (LPHANDLE *)&rbImage, (LPHANDLE *)&fnImage, NULL, pCodelineSW, pCodelineHW, NULL, NULL, &DocToRead, &ErrorType, NULL, NULL);

	if( rcGetDocData == LSAPI_OKAY || rcGetDocData == LSAPI_DOUBLE_LEAFING_WARNING ||  rcGetDocData == LSAPI_LOOP_INTERRUPTED ||
		rcGetDocData == LSAPI_SORTER1_FULL || rcGetDocData == LSAPI_SORTER2_FULL ||
		((rcGetDocData >= LsFamily::LsReply::LS_SORTER_1_POCKET_1_FULL) &&
		 (rcGetDocData <= LsFamily::LsReply::LS_SORTER_7_POCKET_3_FULL)) )
	{
//		if( NrDoc )
			NrDoc = (UInt32)nrDoc;

		if( CodelineSW )
			CodelineSW = Marshal::PtrToStringAnsi((IntPtr) (char *) pCodelineSW);

		if( CodelineHW )
			CodelineHW = Marshal::PtrToStringAnsi((IntPtr) (char *) pCodelineHW);
		
		if (fSaveImage == TRUE )
		{
			if (fbImage )
			{
				pFront = (char*)(void*)Marshal::StringToHGlobalAnsi(FilenameFront);
				if (FileFormat == LsFamily::LsDefines::FileType::FILE_BMP  )
					rc = ::LSSaveDIB((HWND)hWnd, fbImage, pFront );
				else if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT  || 
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_TIF) 
				{
					if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 )
					{
							rc = ::LSConvertImageToBW((HWND)hWnd,4,fbImage,&ImageBW,250,0);
							rc = ::LSSaveTIFF((HWND)hWnd, ImageBW,pFront,(int)FileFormat,0 ,1 );
							::LSFreeImage((HWND)hWnd,&ImageBW);	
					}
					else
						rc = ::LSSaveTIFF((HWND)hWnd, fbImage,pFront,(int)FileFormat,0 ,1 );
				}
				else 
					rc = ::LSSaveJPEG((HWND)hWnd, fbImage, GlobalQuality, pFront);
			}
			if (rbImage )
			{	
				pBack = (char*)(void*)Marshal::StringToHGlobalAnsi(FilenameRear);
				
				if (FileFormat == LsFamily::LsDefines::FileType::FILE_BMP  )
					rc = ::LSSaveDIB((HWND)hWnd, rbImage, pBack );
				else if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT  || 
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_TIF) 
					{
						if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 )
						{
							rc = ::LSConvertImageToBW((HWND)hWnd,4,rbImage,&ImageBW,250,0);
							rc = ::LSSaveTIFF((HWND)hWnd, ImageBW,pBack,(int)FileFormat,0 ,1 );
							::LSFreeImage((HWND)hWnd,&ImageBW);	
						}
						else
						rc = ::LSSaveTIFF((HWND)hWnd, rbImage,pBack,(int)FileFormat,0 ,1 );
					}
				else 
					rc = ::LSSaveJPEG((HWND)hWnd, rbImage, GlobalQuality, pBack);
			}

			if (fnImage )
			{
				pFront2 = (char*)(void*)Marshal::StringToHGlobalAnsi(FilenameFront2);
				
				if (FileFormat == LsFamily::LsDefines::FileType::FILE_BMP  )
					rc = ::LSSaveDIB((HWND)hWnd, fnImage, pFront2 );
				else if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT  || 
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 ||
					FileFormat == LsFamily::LsDefines::FileType::FILE_TIF) 
					{
						if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 )
						{
							rc = ::LSConvertImageToBW((HWND)hWnd,4,fnImage,&ImageBW,250,0);
							rc = ::LSSaveTIFF((HWND)hWnd, ImageBW,pFront2,(int)FileFormat,0 ,1 );
							::LSFreeImage((HWND)hWnd,&ImageBW);	
						}
						else
							rc = ::LSSaveTIFF((HWND)hWnd, fnImage,pFront2,(int)FileFormat,0 ,1 );
					}
				else 
					rc = ::LSSaveJPEG((HWND)hWnd, fnImage, GlobalQuality, pFront2);
			}

		}//if (fSaveImage == TRUE )

		//Gray Image
		if( fbImage )
		{
			// -----------------Old
			//// Create a image object and after a Bitmap object
			/*::LSSaveDIB(0, fbImage, TMP_PATH_IMAGE);

			iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE, true);
			FrontImage = gcnew Drawing::Bitmap( iBitmap );
			Miscellaneous::Func::SetResolution(fbImage, FrontImage);

			::LSFreeImage(0, (HANDLE *)&rbImage);
			delete iBitmap;*/
#if 1
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				Byte	bfh[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;
				
				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(fbImage, bfh, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( fbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)fbImage, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				if (ScanModeSelezionato != (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV && ScanModeSelezionato != (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV)
					::LSFreeImage(0, (HANDLE *)&fbImage);
#endif 
		}

		if (fnImage && (ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV || ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV))
		{
				
				if (fShowImageUV == TRUE )
				{
						Byte	bfh2[14];
						array<Byte> ^a_bfh2 = gcnew array<Byte>(14);
						array<Byte> ^a_pImage2;
						//ho chiesto di tornare le tre immagini (GRAY + UV + MERGED )
						Miscellaneous::Func::CreateBitmapFileHeader(fnImage, bfh2, &DimImage);

						// Create the stream
						MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
				
						// ... copy it in the stream
						Marshal::Copy((IntPtr)bfh2, a_bfh2, 0, sizeof(bfh2));
						memStream2->Write(a_bfh2, 0, sizeof(bfh2));

						DimImage = ::GlobalSize( fnImage );
						a_pImage2 = gcnew array<Byte>(DimImage);
						Marshal::Copy((IntPtr)fnImage, a_pImage2, 0, DimImage);

						// Copy in the stream the image
						memStream2->Write(a_pImage2, 0, a_pImage2->Length);

						// Creo a bitmap class from the stream
						FrontImage2 = gcnew System::Drawing::Bitmap( memStream2 );

						// Delete the temporary aree
						delete a_pImage2;
						delete memStream2;
						delete a_bfh2;
						//::LSFreeImage(0, (HANDLE *)&fnImage);

				}
					Byte	bfh3[14];
					array<Byte> ^a_bfh3 = gcnew array<Byte>(14);
					array<Byte> ^a_pImage3;
					//altrimenti di default torno l'immagine GRIGIO + MERGED
					rc =::LSMergeImageGrayAndUV((HWND)hWnd,(HANDLE)fbImage,(HANDLE)fnImage,Reserved1,Reserved2,&fMerged);
					// Create the bitmap file header e ...
					Miscellaneous::Func::CreateBitmapFileHeader(fMerged, bfh3, &DimImage);

					// Create the stream
					MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );
				
					// ... copy it in the stream
					Marshal::Copy((IntPtr)bfh3, a_bfh3, 0, sizeof(bfh3));
					memStream2->Write(a_bfh3, 0, sizeof(bfh3));

					DimImage = ::GlobalSize( fMerged );
					a_pImage3 = gcnew array<Byte>(DimImage);
					Marshal::Copy((IntPtr)fMerged, a_pImage3, 0, DimImage);

					// Copy in the stream the image
					memStream2->Write(a_pImage3, 0, a_pImage3->Length);

					// Creo a bitmap class from the stream
					ImageMerged = gcnew System::Drawing::Bitmap( memStream2 );

					// Delete the temporary aree
					delete a_pImage3;
					delete memStream2;
					delete a_bfh3;

					//salvo l'immagine guv su disco
					if (fMerged )
					{
						pGUVimage = (char*)(void*)Marshal::StringToHGlobalAnsi(FilenameRear2);
						
						if (FileFormat == LsFamily::LsDefines::FileType::FILE_BMP  )
							rc = ::LSSaveDIB((HWND)hWnd, fMerged, pGUVimage );
						else if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT  || 
								FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_1DIM ||
								FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP3_2DIM ||
								FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 ||
								FileFormat == LsFamily::LsDefines::FileType::FILE_TIF) 
							{
								if (FileFormat == LsFamily::LsDefines::FileType::FILE_CCITT_GROUP4 )
								{
									rc = ::LSConvertImageToBW((HWND)hWnd,4,fMerged,&ImageBW,250,0);
									rc = ::LSSaveTIFF((HWND)hWnd, ImageBW,pGUVimage,(int)FileFormat,0 ,1 );
									::LSFreeImage((HWND)hWnd,&ImageBW);	
								}
								else
									rc = ::LSSaveTIFF((HWND)hWnd, fMerged,pGUVimage,(int)FileFormat,0 ,1 );
						}
								else 
							rc = ::LSSaveJPEG((HWND)hWnd, fMerged, GlobalQuality, pGUVimage);
					
						
						
						
						//rc = ::LSSaveJPEG((HWND)hWnd, fnImage, GlobalQuality, pFront2);
					}
					::LSFreeImage(0, (HANDLE *)&fbImage);
					::LSFreeImage(0, (HANDLE *)&fnImage);
					::LSFreeImage(0, (HANDLE *)&fMerged);
					
		}

		if( rbImage )
		{
			if( 0 )
			{
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	*pImage32;
//				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				Miscellaneous::Func::ConvertBitmapTo32Bit((Byte *)rbImage, &pImage32, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)pImage32, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				::GlobalFree( pImage32 );
				::LSFreeImage(0, (HANDLE *)&rbImage);
			}
			else
			{
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(rbImage, bfh, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( rbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)rbImage, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				::LSFreeImage(0, (HANDLE *)&rbImage);
			}

			// -----------------Old
			//// Create a image object and after a Bitmap object
			//::LSSaveDIB(0, rbImage, TMP_PATH_IMAGE);

			//iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE, true);
			//RearImage = gcnew Drawing::Bitmap( iBitmap );
			//Miscellaneous::Func::SetResolution(rbImage, RearImage);

			//::LSFreeImage(0, (HANDLE *)&rbImage);
			//delete iBitmap;
		}

		if( FilenameFront )
			FilenameFront = Marshal::PtrToStringAnsi((IntPtr) (char *) pFilenameFront);

		if( FilenameRear )
			FilenameRear = Marshal::PtrToStringAnsi((IntPtr) (char *) pFilenameBack);

		


	} // if( rc == LSAPI_OKAY )

	//torno il reply della GetDocData 
	return rcGetDocData;
} // LsFamily::LSGetDocData




int LsFamily::LsApi::LSGetDocData(Int32 hConnect, Int32 hWnd, UInt32 %NrDoc, String ^%FilenameFront, String ^%FilenameRear, String ^%FilenameFront2, String ^%FilenameRear2,System::Drawing::Bitmap ^%FrontImage, System::Drawing::Bitmap ^%RearImage , System::Drawing::Bitmap ^%FrontImage2, System::Drawing::Bitmap ^%RearImage2, String ^%CodelineSW, String ^%CodelineHW)
{
	int rc;
	unsigned long nrDoc;
	char pFilenameFront[_MAX_PATH], pFilenameBack[_MAX_PATH],pFilenameFront2[_MAX_PATH];
	HANDLE fbImage=NULL, rbImage=NULL,fnImage=NULL;
    char pCodelineSW[256], pCodelineHW[128];
	short DocToRead;
	long ErrorType;
	HANDLE fMerged = NULL ;
	short Reserved1 = 0 , Reserved2 = 0 ; 
//	System::Drawing::Image ^iBitmap;


	rc = ::LSGetDocData(hConnect, (HWND)hWnd, &nrDoc, pFilenameFront, pFilenameBack, pFilenameFront2, NULL, (LPHANDLE *)&fbImage, (LPHANDLE *)&rbImage, (LPHANDLE *)&fnImage, NULL, pCodelineSW, pCodelineHW, NULL, NULL, &DocToRead, &ErrorType, NULL, NULL);

	if( rc == LSAPI_OKAY || rc == LSAPI_DOUBLE_LEAFING_WARNING || rc == LSAPI_LOOP_INTERRUPTED || 
		rc == LSAPI_SORTER1_FULL || rc == LSAPI_SORTER2_FULL ||
		((rc >= LsFamily::LsReply::LS_SORTER_1_POCKET_1_FULL) &&
		 (rc <= LsFamily::LsReply::LS_SORTER_7_POCKET_3_FULL)) )
	{
//		if( NrDoc )
			NrDoc = (UInt32)nrDoc;

		if( CodelineSW )
			CodelineSW = Marshal::PtrToStringAnsi((IntPtr) (char *) pCodelineSW);

		if( CodelineHW )
			CodelineHW = Marshal::PtrToStringAnsi((IntPtr) (char *) pCodelineHW);

		if( fbImage )
		{
			if( 0 )
			{
				// Converto la bitmap a colori, poi la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	*pImage32;
//				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				Miscellaneous::Func::ConvertBitmapTo32Bit((Byte *)fbImage, &pImage32, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)pImage32, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				
				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				::GlobalFree( pImage32 );
				::LSFreeImage(0, (HANDLE *)&fbImage);
			}
			else
			{
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(fbImage, bfh, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( fbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)fbImage, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				FrontImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				if (ScanModeSelezionato != (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV && ScanModeSelezionato != (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV)
					::LSFreeImage(0, (HANDLE *)&fbImage);
			}

			// ------------------- Old
			//// Create a image object and after a Bitmap object
			//::LSSaveDIB(0, fbImage, TMP_PATH_IMAGE);

			//iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE, true);
			//FrontImage = gcnew Drawing::Bitmap( iBitmap );
			//Miscellaneous::Func::SetResolution(fbImage, FrontImage);

			//::LSFreeImage(0, (HANDLE *)&fbImage);
			//delete iBitmap;
		}

		//if( fnImage )  //Image Uv
		if (fnImage && (ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR100_AND_UV || ScanModeSelezionato == (short)LsFamily::LsDefines::ScanMode::SCAN_MODE_256GR200_AND_UV))
		{
				
				rc =::LSMergeImageGrayAndUV((HWND)hWnd,(HANDLE)fbImage,(HANDLE)fnImage,Reserved1,Reserved2,&fMerged);

				//Cancello l'immagine grigia dopo averla usata nella Merge
				::LSFreeImage(0, (HANDLE *)&fbImage); 
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh2[14];
				array<Byte> ^a_bfh2 = gcnew array<Byte>(14);
				array<Byte> ^a_pImage2;

				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(fMerged, bfh2, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream2 = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh2, a_bfh2, 0, sizeof(bfh2));
				memStream2->Write(a_bfh2, 0, sizeof(bfh2));

				DimImage = ::GlobalSize( fMerged );
				a_pImage2 = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)fMerged, a_pImage2, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream2->Write(a_pImage2, 0, a_pImage2->Length);

				// Creo la bitmap dall stream
				FrontImage2= gcnew System::Drawing::Bitmap( memStream2 );

				// Cancello le aree utilizzate
				delete a_pImage2;
				delete memStream2;
				delete a_bfh2;
				::LSFreeImage(0, (HANDLE *)&fnImage);
		
		}
		if( rbImage )
		{
			if( 0 )
			{
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	*pImage32;
//				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				Miscellaneous::Func::ConvertBitmapTo32Bit((Byte *)rbImage, &pImage32, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)pImage32, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				::GlobalFree( pImage32 );
				::LSFreeImage(0, (HANDLE *)&rbImage);
			}
			else
			{
				// Lascio la bitmap cos� come e la copio in una bitmap class
				System::Drawing::Color pixColor;
				int		DimImage;
				Byte	bfh[14];
				array<Byte> ^a_bfh = gcnew array<Byte>(14);
				array<Byte> ^a_pImage;

				// Creo il bitmap file header e ...
				Miscellaneous::Func::CreateBitmapFileHeader(rbImage, bfh, &DimImage);

				// Creo uno stream
				MemoryStream^ memStream = gcnew MemoryStream( DimImage );

				// ... lo copio nello stream
				Marshal::Copy((IntPtr)bfh, a_bfh, 0, sizeof(bfh));
				memStream->Write(a_bfh, 0, sizeof(bfh));

				DimImage = ::GlobalSize( rbImage );
				a_pImage = gcnew array<Byte>(DimImage);
				Marshal::Copy((IntPtr)rbImage, a_pImage, 0, DimImage);

				// Copio nello stream l'immagine a 32 bit
				memStream->Write(a_pImage, 0, a_pImage->Length);

				// Creo la bitmap dall stream
				RearImage = gcnew System::Drawing::Bitmap( memStream );

				// Cancello le aree utilizzate
				delete a_pImage;
				delete memStream;
				delete a_bfh;
				::LSFreeImage(0, (HANDLE *)&rbImage);
			}

			// -----------------Old
			//// Create a image object and after a Bitmap object
			//::LSSaveDIB(0, rbImage, TMP_PATH_IMAGE);

			//iBitmap = Drawing::Image::FromFile(TMP_PATH_IMAGE, true);
			//RearImage = gcnew Drawing::Bitmap( iBitmap );
			//Miscellaneous::Func::SetResolution(rbImage, RearImage);

			//::LSFreeImage(0, (HANDLE *)&rbImage);
			//delete iBitmap;
		}

		if( FilenameFront )
			FilenameFront = Marshal::PtrToStringAnsi((IntPtr) (char *) pFilenameFront);

		if( FilenameRear )
			FilenameRear = Marshal::PtrToStringAnsi((IntPtr) (char *) pFilenameBack);
	} // if( rc == LSAPI_OKAY )

	return rc;
} // LsFamily::LSGetDocData



int LsFamily::LsApi::LSStopAutoDocHandle(Int32 hConnect, Int32 hWnd)
{
	int rc;

	rc = ::LSStopAutoDocHandle(hConnect, (HWND)hWnd);

	return rc;
} // LsFamily::LSStopAutoDocHandle




int LsFamily::LsApi::LSReadBadgeWithTimeout(Int32 hConnect, Int32 hWnd, LsDefines::Badge Tracks, UInt32 Timeout, String ^%BadgeTracks)
{
	int rc;
	char BadgeCodeline[512];
	short len_codeline;

	len_codeline = sizeof(BadgeCodeline);
	rc = ::LSReadBadgeWithTimeout(hConnect, (HWND)hWnd, (unsigned char)Tracks, len_codeline, BadgeCodeline, &len_codeline, Timeout);

	if( rc == LSAPI_OKAY )
	{
		if( BadgeCodeline )
			BadgeTracks = Marshal::PtrToStringAnsi((IntPtr) (char *) BadgeCodeline);
	}

	return rc;
} // LsFamily::LSReadBadgeWithTimeout



int LsFamily::LsApi::LSReadBadge(Int32 hConnect, Int32 hWnd, LsDefines::Badge Tracks, String ^%BadgeTracks)
{
	int rc;
	char BadgeCodeline[512];
	short len_codeline;

	len_codeline = sizeof(BadgeCodeline);
	rc = ::LSReadBadge(hConnect, (HWND)hWnd, (unsigned char)Tracks, len_codeline, BadgeCodeline, &len_codeline);

	if( rc == LSAPI_OKAY )
	{
		if( BadgeCodeline )
			BadgeTracks = Marshal::PtrToStringAnsi((IntPtr) (char *) BadgeCodeline);
	}

	return rc;
} // LsFamily::LSReadBadge



int LsFamily::LsApi::LSCodelineReadFromBitmap(Int32 hWnd, System::Drawing::Bitmap ^hImage, String ^codelineType, LsDefines::Unit UnitMeasure, Double pos_x, Double pos_y, Double sizeW, Double sizeH, LsDefines::BlankInCodeline PutBlanks, String ^%Codeline)
{
	int rc;
	char CodelineRead[256];
	int len_codeline;
	char FontToRead[12];
	READOPTIONS ro;
	int ii;
	char *pBitmap;


	if( Miscellaneous::Func::ConvertClassBitmapToDIB(hImage, &pBitmap) )
	{
//		rc = ::LSSaveDIB(0, pBitmap, TMP_PATH_IMAGE);
		len_codeline = sizeof(CodelineRead);
		ro.PutBlanks = (BOOL)PutBlanks;
		ro.TypeRead = 'N';
		memset(FontToRead, 0, sizeof(FontToRead));
//		codelineType->CopyTo(0, FontToRead, 0, codelineType->Length);
		for( ii = 0; ((ii < codelineType->Length) && (ii < (sizeof(FontToRead) - 1))); ii ++)
			FontToRead[ii] = (char)codelineType[ii];//->Chars(ii);
		rc = ::LSCodelineReadFromBitmap((HWND)hWnd, (HANDLE)pBitmap, FontToRead, (short)UnitMeasure, (float)pos_x, (float)pos_y, (float)sizeW, (float)sizeH, &ro, CodelineRead, (UINT *)&len_codeline);

		if( rc == LSAPI_OKAY )
		{
			if( Codeline )
			{
				Codeline = Marshal::PtrToStringAnsi((IntPtr) (char *) CodelineRead);
			}
		}

		GlobalFree( pBitmap );
	} // if( pBitmap )
	else
		rc = LSAPI_SYSTEM_ERROR;

	return rc;
} // LsFamily::LSCodelineReadFromBitmap


int LsFamily::LsApi::LSReadBarcodeFromBitmap(Int32 hWnd, System::Drawing::Bitmap ^hImage, LsDefines::CodelineToRead TypeBarcode, Int32 pos_x, Int32 pos_y, Int32 sizeW, Int32 sizeH, String ^%Codeline)
{
	int rc;
	char CodelineRead[256];
	int len_codeline;
	char *pBitmap;


	if( Miscellaneous::Func::ConvertClassBitmapToDIB(hImage, &pBitmap) )
	{
//		rc = ::LSSaveDIB(0, pBitmap, TMP_PATH_IMAGE);
		len_codeline = sizeof(CodelineRead);
		rc = ::LSReadBarcodeFromBitmap((HWND)hWnd, (HANDLE)pBitmap, (char)TypeBarcode, pos_x, pos_y, sizeW, sizeH, CodelineRead, (UINT *)&len_codeline);

		if( rc == LSAPI_OKAY )
		{
			if( Codeline )
			{
				Codeline = Marshal::PtrToStringAnsi((IntPtr) (char *) CodelineRead);
			}
		}

		GlobalFree( pBitmap );
	} // if( pBitmap )
	else
		rc = LSAPI_SYSTEM_ERROR;

	return rc;
} // LsFamily::LSReadBarcodeFromBitmap

int LsFamily::LsApi::LSReadPdfFromBitmap(Int32 hWnd, System::Drawing::Bitmap ^hImage, String ^%Codeline)
{
	int rc;
	char CodelineRead[256];
	int len_codeline;
	char *pBitmap;
	char ErrorRate;


	if( Miscellaneous::Func::ConvertClassBitmapToDIB(hImage, &pBitmap) )
	{
//		rc = ::LSSaveDIB(0, pBitmap, TMP_PATH_IMAGE);
		len_codeline = sizeof(CodelineRead);
		rc = ::LSReadPdf417FromBitmap((HWND)hWnd, (HANDLE)pBitmap, CodelineRead, (UINT *)&len_codeline ,&ErrorRate, 0, 0, 0, 0 );
				
		if( rc == LSAPI_OKAY )
		{
			if( Codeline )
			{
				Codeline = Marshal::PtrToStringAnsi((IntPtr) (char *) CodelineRead);
			}
		}

		GlobalFree( pBitmap );
	} // if( pBitmap )
	else
		rc = LSAPI_SYSTEM_ERROR;

	return rc;
} // LsFamily::LSReadPdfFromBitmap




int LsFamily::LsApi::LSHistory(Int32 hConnect, Int32 hWnd, LsHistory ^lpCfg,String ^%stTime)
{
	int rc;
	S_HISTORY_LS150 sHistory;
	S_HISTORY_LS40 sHistory40;
	S_HISTORY_LS100 sHistory100 ;
	S_HISTORY_LS5xx sHistory5xx ;
	S_HISTORY_LS800	sHistory800 ;
	
	char cModel[20];
	char stTime_app[16];
	LARGE_INTEGER totTime;
	unsigned long totHours;
	short totMinutes;
	short totSeconds;


	
	rc = LSUnitIdentify(hConnect, (HWND)hWnd, NULL, cModel, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

	if( rc == LSAPI_OKAY )
	{
		if  (! strncmp(cModel, MODEL_LS40, strlen(MODEL_LS40)))
		{
			memset(&sHistory40 , 0, sizeof(sHistory40) );

			rc = LSHistoryCommand(hConnect , (HWND)hWnd , LSAPI_CMD_READ_HISTORY , &sHistory40);	
			if (rc == LSAPI_OKAY )
			{
				lpCfg->doc_sorted = sHistory40.doc_sorted ;
				lpCfg->bourrage_feeder  = sHistory40.bourrage;
				lpCfg->doc_retain = sHistory40.doc_retain ;
				lpCfg->doc_cmc7_err = sHistory40.doc_cmc7_err ;
				lpCfg->doc_e13b_err = sHistory40.doc_e13b_err ;
				lpCfg->num_turn_on = sHistory40.num_turn_on ;
				lpCfg->doc_ink_jet = sHistory40.doc_ink_jet ;
				lpCfg->doc_stamp = sHistory40.doc_stamp ;
				totTime.QuadPart  = sHistory40.time_peripheral_on ;
			}
		}
		else if  (! strncmp(cModel, MODEL_LS100, strlen(MODEL_LS100)))
		{
			memset(&sHistory100 , 0, sizeof(sHistory100) );

			rc = LSHistoryCommand(hConnect , (HWND)hWnd , LSAPI_CMD_READ_HISTORY , &sHistory100);	
			if (rc == LSAPI_OKAY )
			{
				lpCfg->doc_sorted = sHistory100.doc_sorted ;
				lpCfg->bourrage_feeder  = sHistory100.bourrage_feeder ;
				lpCfg->bourrage_micr = sHistory100.bourrage_micr ;
				lpCfg->doc_retain = sHistory100.doc_retain ;
				lpCfg->bourrage_exit  = sHistory100.bourrage_exit ;
				lpCfg->doc_cmc7_err = sHistory100.doc_cmc7_err ;
				lpCfg->doc_e13b_err = sHistory100.doc_e13b_err ;
				lpCfg->num_turn_on = sHistory100.num_turn_on ;
				lpCfg->doc_ink_jet = sHistory100.doc_ink_jet ;
				lpCfg->doc_stamp = sHistory100.doc_stamp ;
				totTime.QuadPart  = sHistory100.time_peripheral_on ;
			}
		}
		else if  (! strncmp(cModel, MODEL_LS150, strlen(MODEL_LS150)))
		{
			memset(&sHistory , 0, sizeof(sHistory) );

			rc = LSHistoryCommand(hConnect , (HWND)hWnd , LSAPI_CMD_READ_HISTORY , &sHistory);	
			if (rc == LSAPI_OKAY )
			{
				lpCfg->doc_sorted = sHistory.doc_sorted ;
				lpCfg->jams_card = sHistory.jams_card ;
				lpCfg->jams_micr = sHistory.jams_micr ;
				lpCfg->doc_retain = sHistory.doc_retain ;
				lpCfg->jams_scanner = sHistory.jams_scanner ;
				lpCfg->doc_cmc7_err = sHistory.doc_cmc7_err ;
				lpCfg->doc_e13b_err = sHistory.doc_e13b_err ;
				lpCfg->num_turn_on = sHistory.num_turn_on ;
				lpCfg->doc_ink_jet = sHistory.doc_ink_jet ;
				lpCfg->doc_stamp = sHistory.doc_stamp ;
				totTime.QuadPart = sHistory.time_peripheral_on ;
			}
			
		}
		
		else if  (! strncmp(cModel, MODEL_LS520, strlen(MODEL_LS520)) || 
					! strncmp(cModel, MODEL_LS515, strlen(MODEL_LS515)))
		{
			memset(&sHistory5xx , 0, sizeof(sHistory5xx) );

			rc = LSHistoryCommand(hConnect , (HWND)hWnd , LSAPI_CMD_READ_HISTORY , &sHistory5xx);	
			if (rc == LSAPI_OKAY )
			{
				lpCfg->num_doc_handled  = sHistory5xx.num_doc_handled  ;
				lpCfg->bourrage_feeder  = sHistory5xx.bourrage_feeder  ;
				lpCfg->doc_retain_scan  = sHistory5xx.doc_retain_scan  ;
				lpCfg->doc_retain_micr  = sHistory5xx.doc_retain_micr ;
				lpCfg->bourrage_stamp  = sHistory5xx.bourrage_stamp  ;
				lpCfg->bourrage_micr = sHistory5xx.bourrage_micr ;
				lpCfg->bourrage_film  = sHistory5xx.bourrage_film ;
				lpCfg->doc_cmc7_err  = sHistory5xx.doc_cmc7_err ;
				lpCfg->doc_e13b_err  = sHistory5xx.doc_e13b_err  ;
				lpCfg->doc_barcode_err = sHistory5xx.doc_barcode_err  ;
				lpCfg->doc_optic_err = sHistory5xx.doc_optic_err ;
				lpCfg->nr_power_on = sHistory5xx.nr_power_on ;
				totTime.QuadPart = sHistory5xx.time_peripheral_on ;

				// Aggiorno le ore di utilizzo peripferica
				// Leggo la somma delle ore e ...
				totHours = sHistory5xx.time_peripheral_on / 3600;
				totMinutes = (short)(sHistory5xx.time_peripheral_on % 3600);
				totSeconds = totMinutes % 60;
				totMinutes = totMinutes / 60;

				sprintf_s(stTime_app, "%ld:%02d:%02d", totHours, totMinutes, totSeconds);
				
				if( stTime_app )
					stTime = Marshal::PtrToStringAnsi((IntPtr) (char *) stTime_app);

				return rc ;
			}
			
		}
		else if( ! strncmp(cModel, MODEL_LS800, strlen(MODEL_LS800)) ||
				! strncmp(cModel, MODEL_LS800_NCR, strlen(MODEL_LS800_NCR)) )
		{
			memset(&sHistory800 , 0, sizeof(sHistory800) );

			rc = LSHistoryCommand(hConnect , (HWND)hWnd , LSAPI_CMD_READ_HISTORY , &sHistory800);	
			if (rc == LSAPI_OKAY )
			{
				lpCfg->num_doc_handled  = sHistory800.num_doc_handled  ;
				lpCfg->jam_feeder = sHistory800.jam_feeder   ;
				lpCfg->jam_front_scanner  = sHistory800.jam_front_scanner   ;
				lpCfg->jam_track_left  = sHistory800.jam_track_left  ;
				lpCfg->jam_track_right  = sHistory800.jam_track_right   ;
				lpCfg->jam_back_scanner = sHistory800.jam_back_scanner  ;
				lpCfg->jam_in_the_sorters  = sHistory800.jam_in_the_sorters  ;
				lpCfg->doc_cmc7_err  = sHistory800.doc_cmc7_err ;
				lpCfg->doc_e13b_err  = sHistory800.doc_e13b_err  ;
				lpCfg->doc_printed = sHistory800.doc_printed   ;
				lpCfg->nr_double_leafing = sHistory800.nr_double_leafing ;
				lpCfg->nr_power_on = sHistory800.nr_power_on ;
				totTime.QuadPart = sHistory800.time_peripheral_on ;

			}
		}
		totTime.QuadPart *= HISTORY_TIME_UNIT;
		totHours = (unsigned long)(totTime.QuadPart / 3600);
		totMinutes = (short)(totTime.QuadPart % 3600);
		totSeconds = totMinutes % 60;
		totMinutes = totMinutes / 60;
				
		sprintf_s(stTime_app, "%ld:%02d:%02d", totHours, totMinutes, totSeconds);
				
		if( stTime_app )
			stTime = Marshal::PtrToStringAnsi((IntPtr) (char *) stTime_app);


	}
	return rc ;
}


short Reply ;


