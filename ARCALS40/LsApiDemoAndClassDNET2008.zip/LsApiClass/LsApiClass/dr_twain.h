/******************************************************

  dr_twain.h
  Copyright CANON ELECTRONICS INC. 2004-2008

  TWAIN capabilities of Canon DR Series Driver

******************************************************/

#ifndef _DR_TWAIN_H_INCLUDED_
#define _DR_TWAIN_H_INCLUDED_

#ifndef CAP_CUSTOMBASE
#define CAP_CUSTOMBASE    0x8000
#endif

#define CCAP_CEI_DETECTPAGESIZE                             (CAP_CUSTOMBASE + 0)
#define CCAP_CEI_BLANKSKIP                                  (CAP_CUSTOMBASE + 1)
#define CCAP_CEI_BLANKSKIPSLICE                             (CAP_CUSTOMBASE + 2)
#define CCAP_CEI_MANUALFEED                                 (CAP_CUSTOMBASE + 3)
#define     CTWMF_OFF                                           0
#define     CTWMF_ON                                            1
#define     CTWMF_BUTTON                                        2
#define     CTWMF_AUTOSTART                                     3
#define CCAP_CEI_AUTOSTARTDELAY                             (CAP_CUSTOMBASE + 4)
#define CCAP_CEI_SCANSPEED                                  (CAP_CUSTOMBASE + 5)
#define CCAP_CEI_MARGIN                                     (CAP_CUSTOMBASE + 6)
#define CCAP_CEI_MARGINLENGTH                               (CAP_CUSTOMBASE + 7)
#define CCAP_CEI_DROPOUT                                    (CAP_CUSTOMBASE + 8)
#define     CTWDO_NONE                                          0
#define     CTWDO_RED                                           1
#define     CTWDO_GREEN                                         2
#define     CTWDO_BLUE                                          3
#define     CTWDO_CUSTOM                                        4
#define CCAP_CEI_EDGEEMPHASIS                               (CAP_CUSTOMBASE + 9)
#define CCAP_CEI_DETECTJOBSEPTYPE                           (CAP_CUSTOMBASE + 10)
#define     CTWDJ_OFF                                           0
#define     CTWDJ_BATCH                                         1
#define     CTWDJ_FILE                                          2
#define     CTWDJ_FILEANDBATCH                                  (CTWDJ_BATCH | CTWDJ_FILE)
#define CCAP_CEI_NOISEFILTER                                (CAP_CUSTOMBASE + 11)
#define     CTWNF_NONE                                          0
#define     CTWNF_BLACK                                         1
#define     CTWNF_WHITE                                         2
#define     CTWNF_BLACKWHITE                                    3
#define CCAP_CEI_NOTCHFILTER                                (CAP_CUSTOMBASE + 12)
#define CCAP_CEI_DESKEW                                     (CAP_CUSTOMBASE + 13)
#define CCAP_CEI_REVERSESCANTYPE                            (CAP_CUSTOMBASE + 14)
#define CCAP_CEI_AUTOJOBSEP                                 (CAP_CUSTOMBASE + 15)
#define     CTWAJ_OFF                                           0
#define     CTWAJ_AUTO                                          1
#define     CTWAJ_BUTTON                                        2
#define CCAP_CEI_SCANMODE                                   (CAP_CUSTOMBASE + 16)
#define     CTWSM_ONECONT                                       0
#define     CTWSM_FILE                                          1
#define     CTWSM_BATCH                                         2
#define     CTWSM_PAGE                                          3
#define CCAP_CEI_EDGEEMPHASISENABLED                        (CAP_CUSTOMBASE + 17)
#define CCAP_CEI_LASTERROR                                  (CAP_CUSTOMBASE + 18)
#define CCAP_CEI_JOBSEPDETECTED                             (CAP_CUSTOMBASE + 19)
#define CCAP_CEI_AEADJUSTMENT                               (CAP_CUSTOMBASE + 20)
#define CCAP_CEI_PANELTYPE                                  (CAP_CUSTOMBASE + 21)
#define     CTWPT_NONE                                          0
#define     CTWPT_NORMAL                                        1
#define     CTWPT_SIMPLE                                        2
#define CCAP_CEI_PANELMODE                                  (CAP_CUSTOMBASE + 22)
#define     CTWPM_OFF                                           0
#define     CTWPM_AUTO                                          1
#define     CTWPM_ALWAYS                                        2
#define CCAP_CEI_PRESCANMODE                                (CAP_CUSTOMBASE + 23)
#define     CTWPSM_OFF                                          0
#define     CTWPSM_AUTO                                         1
#define     CTWPSM_MANUAL                                       2
#define     CTWPSM_ALL                                          3
#define CCAP_CEI_PRESCAN                                    (CAP_CUSTOMBASE + 24)
#define CCAP_CEI_NOPAGETIMEOUT                              (CAP_CUSTOMBASE + 25)
#define CCAP_CEI_BLANKSKIPSLICE2                            (CAP_CUSTOMBASE + 26)
#define CCAP_CEI_PATCHCODEENABLE                            (CAP_CUSTOMBASE + 27)
#define CCAP_CEI_PATCHORIENTATION                           (CAP_CUSTOMBASE + 28)
#define     CTWPO_PORT                                          1
#define     CTWPO_LAND                                          2
#define     CTWPO_180                                           3
#define     CTWPO_270                                           4
#define CCAP_CEI_BATCHNUM                                   (CAP_CUSTOMBASE + 29)
#define CCAP_CEI_FILENUM                                    (CAP_CUSTOMBASE + 30)
#define CCAP_CEI_PAGENUM                                    (CAP_CUSTOMBASE + 31)
#define CCAP_CEI_FILMUSE                                    (CAP_CUSTOMBASE + 32)
#define     CTWFU_NONE                                          0
#define     CTWFU_BATCH                                         1
#define     CTWFU_FILE                                          2
#define     CTWFU_PAGE                                          4
#define     CTWFU_BATCHFILE                                     (CTWFU_BATCH | CTWFU_FILE)
#define     CTWFU_BATCHPAGE                                     (CTWFU_BATCH | CTWFU_PAGE)
#define     CTWFU_FILEPAGE                                      (CTWFU_FILE | CTWFU_PAGE)
#define     CTWFU_BATCHFILEPAGE                                 (CTWFU_BATCH | CTWFU_FILE | CTWFU_PAGE)
#define     CTWFU_ALL                                           (CTWFU_BATCH | CTWFU_FILE | CTWFU_PAGE)
#define CCAP_CEI_FILMADDRESSMODE                            (CAP_CUSTOMBASE + 33)
#define     CTWFAM_ABSOLUTE                                     0
#define     CTWFAM_RELATIVE_FORWARD                             1
#define     CTWFAM_RELATIVE_REVERSE                             2
#define CCAP_CEI_FILMPARAMS                                 (CAP_CUSTOMBASE + 34)
#define     CTWFP_SEND                                          1
#define     CTWFP_READ                                          2
#define CCAP_CEI_CARTRIDGENUM                               (CAP_CUSTOMBASE + 35)
#define CCAP_CEI_DETECTPATCHTYPE                            (CAP_CUSTOMBASE + 36)
#define     CTWDPT_PAGE                                         1
#define     CTWDPT_FILE                                         2
#define     CTWDPT_BATCH                                        4
#define     CTWDPT_TRANSFER                                     8
#define CCAP_CEI_CROPDETECT                                 (CAP_CUSTOMBASE + 37)
#define     CTWFCD_OFF                                          0
#define     CTWFCD_BORDER                                       1
#define     CTWFCD_EDGE                                         2
#define     CTWFCD_CONTOUR                                      3
#define CCAP_CEI_CROPMETHOD                                 (CAP_CUSTOMBASE + 38)
#define     CTWFCM_WHITEFILL                                    0
#define     CTWFCM_REGISTER                                     1
#define     CTWFCM_INVERT                                       2
#define     CTWFCM_BLACKFILL                                    3
#define CCAP_CEI_OPTIONUNIT                                 (CAP_CUSTOMBASE + 40)
#define     CTWOU_NONE                                          0x0000
#define     CTWOU_FS                                            0x0001
#define     CTWOU_KEYBOARD                                      0x0002
#define     CTWOU_PRINTER                                       0x0004
#define     CTWOU_AUTOROTATION                                  0x0008
#define CCAP_CEI_TEXTENHANCE                                (CAP_CUSTOMBASE + 41)
#define CCAP_CEI_SCANNERBUTTON                              (CAP_CUSTOMBASE + 42)
#define     CTWSB_NONE                                          0x0000
#define     CTWSB_START                                         0x0001
#define     CTWSB_STOP                                          0x0002
#define CCAP_CEI_MEDIANFILTER                               (CAP_CUSTOMBASE + 43)
#define CCAP_CEI_ICON16                                     (CAP_CUSTOMBASE + 45)
#define CCAP_CEI_ICON32                                     (CAP_CUSTOMBASE + 46)
#define CCAP_CEI_CLEARFSC                                   (CAP_CUSTOMBASE + 47)
#define CCAP_CEI_NEGAPOSI                                   (CAP_CUSTOMBASE + 48)
#define     CTWNP_NEGA                                          0
#define     CTWNP_POSI                                          1
#define     CTWNP_AUTO                                          2
#define CCAP_CEI_BORDERMODE                                 (CAP_CUSTOMBASE + 49)
#define     CTWBM_NONE                                          0
#define     CTWBM_FRAMING                                       1
#define     CTWBM_ERASE                                         2
#define     CTWBM_MARGIN                                        3
#define CCAP_CEI_COLORENHANCE                               (CAP_CUSTOMBASE + 50)
#define     CTWCE_NONE                                          0
#define     CTWCE_RED                                           1
#define     CTWCE_GREEN                                         2
#define     CTWCE_BLUE                                          3
#define     CTWCE_CUSTOM                                        4
#define CCAP_CEI_SMOOTHING                                  (CAP_CUSTOMBASE + 51)
#define CCAP_CEI_WINDOW                                     (CAP_CUSTOMBASE + 52)
#define     CTWCW_BOTH                                          0
#define     CTWCW_FRONT                                         1
#define     CTWCW_BACK                                          (-1)
#define CCAP_CEI_SCANNEDPAGECOUNT                           (CAP_CUSTOMBASE + 53)
#define CCAP_CEI_FEEDCOUNT                                  (CAP_CUSTOMBASE + 54)
#define CCAP_CEI_FOLDLARGESIZE                              (CAP_CUSTOMBASE + 55)
#define CCAP_CEI_RECOGNIZE_DIRECTION                        (CAP_CUSTOMBASE + 59)
#define CCAP_CEI_DETECTPAGESIZE_METHOD                      (CAP_CUSTOMBASE + 60)
#define     CTWDPM_EDGE                                         1
#define     CTWDPM_HARDWARE                                     2
#define CCAP_CEI_DUPLEXORIENTATION                          (CAP_CUSTOMBASE + 61)
#define     CTWDO_BOOK                                          1
#define     CTWDO_CALENDAR                                      2
#define CCAP_CEI_DETECTDBLFEED_THICKNESS                    (CAP_CUSTOMBASE + 62)
#define CCAP_CEI_DETECTDBLFEED_LENGTH                       (CAP_CUSTOMBASE + 63)
#define CCAP_CEI_DETECTDBLFEED_ULTRASONIC                   (CAP_CUSTOMBASE + 64)
#define CCAP_CEI_INCREASE_THINLINE                          (CAP_CUSTOMBASE + 65)
#define CCAP_CEI_DETECTSTAPLE                               (CAP_CUSTOMBASE + 66)
#define CCAP_CEI_VERIFYCOUNT                                (CAP_CUSTOMBASE + 67)
#define CCAP_CEI_STARTBUTTON_COLOR                          (CAP_CUSTOMBASE + 68)
#define     CTWSBC_UNKNOWN                                      0
#define     CTWSBC_RED                                          1
#define     CTWSBC_GREEN                                        2
#define CCAP_CEI_PANELSTATUSTEXT                            (CAP_CUSTOMBASE + 69)
#define CCAP_CEI_JOBNUMBER                                  (CAP_CUSTOMBASE + 70)
#define CCAP_CEI_JOBTITLE                                   (CAP_CUSTOMBASE + 71)
#define CCAP_CEI_CURRENTJOBNUMBER                           (CAP_CUSTOMBASE + 72)
#define CCAP_CEI_WINDOWCOUNTFRONT                           (CAP_CUSTOMBASE + 73)
#define CCAP_CEI_WINDOWCOUNTBACK                            (CAP_CUSTOMBASE + 74)
#define CCAP_CEI_DETECTPAGESIZE_OPTION                      (CAP_CUSTOMBASE + 76)
#define     CTWDPO_ALLPAGES                                     0
#define     CTWDPO_FIRSTPAGEONLY                                1
#define CCAP_CEI_AREA_XPOSITION                             (CAP_CUSTOMBASE + 77)
#define CCAP_CEI_AREA_YPOSITION                             (CAP_CUSTOMBASE + 78)
#define CCAP_CEI_PAGESIZE_LEGAL                             (CAP_CUSTOMBASE + 79)
#define CCAP_CEI_PAGESIZE_ROTATED                           (CAP_CUSTOMBASE + 80)
#define CCAP_CEI_DOCUMENT_DETECTED                          (CAP_CUSTOMBASE + 81)
#define CCAP_CEI_SCANNER_PANELCOUNTER                       (CAP_CUSTOMBASE + 82)
#define CCAP_CEI_SCANNER_TOTALCOUNTER                       (CAP_CUSTOMBASE + 83)
#define CCAP_CEI_PAGESIZE                                   (CAP_CUSTOMBASE + 85)
#define CCAP_CEI_AUTODESKEW                                 (CAP_CUSTOMBASE + 86)
#define CCAP_CEI_TEXTENHANCE_BRIGHTNESS                     (CAP_CUSTOMBASE + 87)
#define CCAP_CEI_ASC_ENABLED                                (CAP_CUSTOMBASE + 88)
#define CCAP_CEI_ASC_BRIGHTNESS                             (CAP_CUSTOMBASE + 89)
#define CCAP_CEI_BATCHSEP_DIALOG                            (CAP_CUSTOMBASE + 90)
typedef struct tagTWAINBATCHSEPDLGINFO {
    DWORD cbSize;
    HWND hWnd;
    LPCSTR lpCaption;
    DWORD dwFlags;
} TWAINBATCHSEPDLGINFO, *LPTWAINBATCHSEPDLGINFO;
#define CCAP_CEI_SCAN_MIXTURE                               (CAP_CUSTOMBASE + 91)
#define CCAP_CEI_EMBOSS_ENHANCE                             (CAP_CUSTOMBASE + 92)
#define CCAP_CEI_TEXTENHANCE_MODE                           (CAP_CUSTOMBASE + 93)
#define     CTWTEM_TEXTENHANCE                                  0
#define     CTWTEM_ADVANCED                                     1
#define     CTWTEM_FAST                                         2
#define     CTWTEM_ADAPTREGION                                  3
#define     CTWTEM_HARDWARE_ADAPTREGION                         4
#define CCAP_CEI_FEEDER_AUTO                                (CAP_CUSTOMBASE + 94)
#define CCAP_CEI_FEEDERMAXWIDTH                             (CAP_CUSTOMBASE + 95)
#define CCAP_CEI_FEEDERMAXLENGTH                            (CAP_CUSTOMBASE + 96)
#define CCAP_CEI_YIELDPROC                                  (CAP_CUSTOMBASE + 97)
typedef int (CALLBACK *CEIYIELDPROC)(void);
#define CCAP_CEI_DOCUMENT_PLACE                             (CAP_CUSTOMBASE + 98)
#define     CTWDP_AUTO                                          0
#define     CTWDP_FLATBED                                       1
#define     CTWDP_FEEDER                                        2
#define CCAP_CEI_LASTPAGE_SIDE                              (CAP_CUSTOMBASE + 99)
#define     CTWLS_FRONT                                         0
#define     CTWLS_BACK                                          1
#define CCAP_CEI_DISABLEITEM                                (CAP_CUSTOMBASE + 100)
#define CCAP_CEI_DELETE_HOLE                                (CAP_CUSTOMBASE + 101)
#define CCAP_CEI_DROPOUT_RGB                                (CAP_CUSTOMBASE + 102)
#define CCAP_CEI_DROPOUT_RANGE                              (CAP_CUSTOMBASE + 103)
#define CCAP_CEI_FEEDER_JAMLESS                             (CAP_CUSTOMBASE + 104)
#define     CTWFJ_OFF                                           0
#define     CTWFJ_ON                                            1
#define     CTWFJ_FEED                                          2
#define     CTWFJ_HARDWARE                                      3
#define CCAP_CEI_DATAORIENTATION                            (CAP_CUSTOMBASE + 105)
#define     CTWDO_PORT                                          1
#define     CTWDO_LAND                                          2
#define     CTWDO_180                                           3
#define     CTWDO_270                                           4
#define CCAP_CEI_TRANSFERMODE                               (CAP_CUSTOMBASE + 106)
#define     CTWTM_DEFAULT                                       0
#define     CTWTM_HIGH                                          1
#define CCAP_CEI_TEXTENHANCE_CONTRAST                       (CAP_CUSTOMBASE + 107)
#define CCAP_CEI_DETECTPAGETYPE                             (CAP_CUSTOMBASE + 108)
#define CCAP_CEI_DETECTPAGETYPE_AMOUNT                      (CAP_CUSTOMBASE + 110)
#define CCAP_CEI_DETECTPAGETYPE_THRESHOLD                   (CAP_CUSTOMBASE + 111)
#define CCAP_CEI_REDUCE_MOIRE                               (CAP_CUSTOMBASE + 112)
#define     CTWRM_OFF                                           1
#define     CTWRM_ON                                            2
#define     CTWRM_FAST                                          CTWRM_ON
#define     CTWRM_FINE                                          3
#define CCAP_CEI_BLANKSKIPSLICE3                            (CAP_CUSTOMBASE + 118)
#define CCAP_CEI_BLEEDTHROUGH                               (CAP_CUSTOMBASE + 119)
#define CCAP_CEI_BLEEDTHROUGH_THRESHOLD                     (CAP_CUSTOMBASE + 120)
#define CCAP_CEI_IMAGEQUALITY                               (CAP_CUSTOMBASE + 121)
#define     CTWIQ_MEDIUM                                        0
#define     CTWIQ_HIGH                                          1
#define     CTWIQ_VERYHIGH                                      2
#define CCAP_CEI_TRANSFERHIGH_JPEGQUALITY                   (CAP_CUSTOMBASE + 122)
#define CCAP_CEI_FEEDERAUTO_OPTION                          (CAP_CUSTOMBASE + 123)
#define     CTWFAO_DEFAULT                                      0
#define     CTWFAO_SIMPLEX                                      CTWFAO_DEFAULT
#define     CTWFAO_DUPLEX                                       1
#define     CTWFAO_BLANKSKIP                                    2
#define CCAP_CEI_BACKGROUNDCOLOR                            (CAP_CUSTOMBASE + 124)
#define     CTWBGC_WHITE                                        0
#define     CTWBGC_BLACK                                        1
#define CCAP_CEI_E_DOCUMENT                                 (CAP_CUSTOMBASE + 125)
#define CCAP_CEI_DETECTDBLFEED_SENSOR_ENABLED               (CAP_CUSTOMBASE + 126)
#define     CTWDFSE_NONE                                        0x0000
#define     CTWDFSE_LEFT                                        0x0001
#define     CTWDFSE_CENTER                                      0x0002
#define     CTWDFSE_RIGHT                                       0x0004
#define CCAP_CEI_DETECTDBLFEED_SENSOR_INDEX                 (CAP_CUSTOMBASE + 127)
#define     CTWDFSI_LEFT                                        0
#define     CTWDFSI_CENTER                                      1
#define     CTWDFSI_RIGHT                                       2
#define CCAP_CEI_DETECTDBLFEED_NONDETECT_STARTY             (CAP_CUSTOMBASE + 128)
#define CCAP_CEI_DETECTDBLFEED_NONDETECT_ENDY               (CAP_CUSTOMBASE + 129)

#define CCAP_QUIETERRORS                                    (CAP_CUSTOMBASE + 0x0100)
#define CCAP_QUIET_NOPAGEDIALOG                             (CAP_CUSTOMBASE + 0x0101)

#endif
