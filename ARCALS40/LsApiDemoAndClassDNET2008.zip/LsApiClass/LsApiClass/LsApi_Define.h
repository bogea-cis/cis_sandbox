// LsApi_define.h

// defines
#define MODEL_LS40						"LS40"
#define MODEL_LS100						"LS100"
#define MODEL_LS150						"LS150"
#define MODEL_LS515						"C.T.S.  LS515"
#define MODEL_LS520						"C.T.S.  LS520"
#define MODEL_LS800						"LS800"
#define MODEL_LS800_NCR					"LS8NCR"

// Mask for nr sorter
#define MASK_1_SORTER					0x01
#define MASK_2_SORTERS					0x02
#define MASK_3_SORTERS					0x03
#define MASK_4_SORTERS					0x04
#define MASK_5_SORTERS					0x05
#define MASK_6_SORTERS					0x06
#define MASK_7_SORTERS					0x07

// Tmp file for image
#define TMP_PATH_IMAGE					".\\tmpImage.bmp"
#define TMP_PATH_IMAGE_CALLBACK			".\\tmpImageCallback.bmp"

