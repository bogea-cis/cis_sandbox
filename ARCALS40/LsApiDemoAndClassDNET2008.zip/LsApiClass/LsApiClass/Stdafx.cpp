// stdafx.cpp : file di origine che include solo le inclusioni standard
// LsApiClass.pch sar� l'intestazione precompilata
// stdafx.obj conterr� le informazioni sui tipi precompilati

#include "stdafx.h"
