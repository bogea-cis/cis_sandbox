//
// CTS Electronics
// Corso Vercelli, 332 - 10015 Ivrea (TORINO) Italy
// January 2001
//
// Phone ++39 125 235611
// Telefax ++39 125 235623
//
// www.ctsgroup.it		techsupp@ctsgroup.it
//
//
// All rights reserved
//

#ifndef CTSIQA_H
#define CTSIQA_H


//-----------------------------------------------------------------
//			Defines
//-----------------------------------------------------------------

// parameter Side
#define SIDE_IMAGE_FRONT				0
#define SIDE_IMAGE_REAR					1


// TriState Flag
//enum
//{
//	CONDITION_FLAG_NO_TESTED,
//	CONDITION_FLAG_DEFECT_PRESENT,
//	CONDITION_FLAG_DEFECT_NOT_PRESENT
//};

//-----------------------------------------------------------------
//			Structures
//-----------------------------------------------------------------
//typedef struct IqaTestError
//{
//	long	Size ;
//	long	Function_Paramiter_Error ; 
//	long	UndersizeImage_flag;
//	long	UndersizeImage_error;
//	long	UndersizeImage_Width ; 
//	long	UndersizeImage_Height ; 
//	long	Document_Corners_flag ; 
//	long	Document_Corners_error ;
//	long	Document_Corners_width ; 
//	long	Document_Corners_height ;
//	long	Document_Edges_flag;
//	long	Document_Edges_error ; 
//	long	Document_Edges_width ; 
//	long	Document_Edges_height ;
//	long	Document_Framing_flag ;
//	long	Document_Framing_error ; 
//	long	Document_Framing_left ; 
//	long	Document_Framing_right;
//	long	Document_Framing_top;
//	long	Document_Framing_bottom ;
//	long	Document_Skew_flag ;
//	long	Document_Skew_error ; 
//	long	Document_Skew_value ; 
//	long	OversizeImage_flag ; 
//	long	OversizeImage_error ; 
//	long	OversizeImage_Width ; 
//	long	OversizeImage_Height ; 
//	long	Image_too_Light_flag ;
//	long	Image_too_Ligth_error ; 
//	long	Image_too_Light_AvgBrightness ; 
//	long	Image_too_Light_AvgContrast ; 
//	long	Image_too_Light_PercentBlackPixel ; 
//	long	Image_too_Dark_flag  ; 
//	long	Image_too_Dark_error ; 
//	long	Image_too_Dark_AvgBrightness;
//	long	Image_too_Dark_PercentBlackPixel ; 
//	long	Horizontal_Streaks_flag ; 
//	long	Horizontal_Streaks_error ; 
//	long	Horizontal_Streaks_value ; 
//	long	Below_Compressed_Size_flag ; 
//	long	Below_Compressed_Size_error ; 
//	long	Below_Compressed_Size_value ; 
//	long	Above_Compressed_Size_flag ;
//	long	Above_Compressed_Size_error ; 
//	long	Above_Compressed_Size_value ; 
//	long	Spot_Noise_flag ;
//	long	Sport_Noise_error ; 
//	long	Sport_Noise_value ; 
//	long	Front_Rear_Dimension_Mismatch_flag;
//	long	Front_Rear_Dimension_Mismatch_error ; 
//	long	Front_Rear_Dimension_Mismatch_widthdiff ; 
//	long	Front_Rear_Dimension_Mismatch_heightdiff ; 
//	long	Carbon_Strip_flag ;
//	long	Carbon_Strip_error ; 
//	long	Out_of_Focus_flag ; 
//	long	Out_of_Focus_error ; 
//	long	Out_of_Focus_value ; 
//
//} CTSIQA_TESTS_ERRORS;
//

//-----------------------------------------------------------------
//			Reply Code Functions
//-----------------------------------------------------------------
//#define CTSIQA_OKAY                                            	0

//-----------------------------------------------------------------
//			Reply Code Errors
//-----------------------------------------------------------------
//#define CTSIQA_ERROR_ON_READ_INI_FILE                           -1
//#define CTSIQA_DOCTYPE_NOT_CONFIGURED                           -2
//#define CTSIQA_TEST_NOT_CONFIGURED                              -3
//#define CTSIQA_MISSING_IMAGE                                    -4
//#define CTSIQA_INVALID_SIDE                                     -5
//#define CTSIQA_IMAGE_NOT_CONFORMED                              -6
//#define CTSIQA_INVALID_COLOR                                    -7
//#define CTSIQA_INCOMPATIBLE_IMAGE                               -8
//#define CTSIQA_DEFECT_EDGE_BOTTOM                               -9
//#define CTSIQA_DEFECT_EDGE_TOP                                  -10
//#define CTSIQA_DEFECT_EDGE_LEFT                                 -11
//#define CTSIQA_DEFECT_EDGE_RIGHT                                -12
//#define CTSIQA_DEFECT_CORNER_LOWERLEFT                          -13
//#define CTSIQA_DEFECT_CORNER_LOWERRIGHT                         -14
//#define CTSIQA_DEFECT_CORNER_UPPERLEFT                          -15
//#define CTSIQA_DEFECT_CORNER_UPPERRIGHT                         -16
//#define CTSIQA_DEFECT_BOTTOM_EDGE_HORIZONTALSCANLINES           -17
//#define CTSIQA_DEFECT_TOP_EDGE_HORIZONTALSCANLINES              -18
//#define CTSIQA_DEFECT_LEFT_EDGE_VERTICAL_SCANLINEWIDTH          -19
//#define CTSIQA_DEFECT_RIGHT_EDGE_VERTICAL_SCANLINEWIDTH         -20
//#define CTSIQA_STRING_TRUNCATED	                                -21
//#define CTSIQA_ILLEGAL_USE					-22
//#define CTSIQA_SESSION_NOT_CONFIGURED 				-23



//-----------------------------------------------------------------
//			Reply Code on load file CtsIqa.ini
//-----------------------------------------------------------------
//#define CTSIQA_ERROR_TO_OPEN_INI_FILE				-101
//#define CTSIQA_ERROR_ON_SYNTAX_LINE				-102
//#define CTSIQA_ERROR_MISSING_DOCTYPE_VALUE        		-103
//#define CTSIQA_ERROR_ON_SYNTAX_SECTION				-104



//-----------------------------------------------------------------
//			Reply Code Warning
//-----------------------------------------------------------------




//-----------------------------------------------------------------
//			Export Function
//-----------------------------------------------------------------
extern int APIENTRY CTSIQACheckImageIQA(int DocType, BITMAPINFOHEADER *pImage, BITMAPINFOHEADER *pImageRear, char *pFilenameFrontCompressed, char *pFilenameRearCompressed);
extern int APIENTRY GetIQALoadIniError(char *DetailError, long llString);
extern int APIENTRY GetIQATestsErrors(CTSIQA_TESTS_ERRORS *stTestErrorsFront, CTSIQA_TESTS_ERRORS *stTestErrorsRear);
extern int APIENTRY CTSIQALibraryVersion(char *VersionLibrary, short LengthStr);

extern int APIENTRY CTSIQAUndersizeImage(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQAOversizeImage(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQAImageLight(int DocType, int Side, BITMAPINFOHEADER *pImage) ;
extern int APIENTRY CTSIQAFocus(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQAImageDark(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQAStreaks(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQACarbon(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQAEdges(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQACorner(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQADimensionMismatch(int DocType, BITMAPINFOHEADER *pImage, BITMAPINFOHEADER *pImageRear);
extern int APIENTRY CTSIQAFramingError(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQASkew(int DocType, int Side, BITMAPINFOHEADER *pImage);
extern int APIENTRY CTSIQABelowCompressedSizeImage(int DocType, int Side, char *ImageFileName );
extern int APIENTRY CTSIQAAboveCompressedSizeImage(int DocType, int Side, char *ImageFileName);
extern int APIENTRY CTSIQANoise(int DocType, int Side, BITMAPINFOHEADER *pImage);


#endif //CTSIQA_H
