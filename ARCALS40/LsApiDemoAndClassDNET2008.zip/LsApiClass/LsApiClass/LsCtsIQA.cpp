// File DLL principale.

// Assembly marked as compliant.
//[assembly: CLSCompliantAttribute(true)]

#include "stdafx.h"

#include "LsApi_Define.h"
#include "LsApiClass.h"
#include "Miscellaneous.h"


int LsFamily::CtsIQA::CheckImage(Int32 DocType, System::Drawing::Bitmap ^fImage, System::Drawing::Bitmap ^rImage, String ^pFnameFrontCompressed, String ^pFnameRearCompressed)
{
	int rc;
	HWND hWnd = 0;
	HANDLE pFront = NULL, pRear = NULL;
	char *pFNameFront = NULL, *pFNameRear = NULL;

	if( pFnameFrontCompressed )
		pFNameFront = (char*)(void*)Marshal::StringToHGlobalAnsi(pFnameFrontCompressed);
	if( pFnameRearCompressed )
		pFNameRear = (char*)(void*)Marshal::StringToHGlobalAnsi(pFnameRearCompressed);

	if( fImage)
		Miscellaneous::Func::ConvertClassBitmapToDIB(fImage, (char **)(&pFront));
	if( rImage )
		Miscellaneous::Func::ConvertClassBitmapToDIB(rImage, (char **)(&pRear));

	rc = ::LSIQACheckImage(hWnd, DocType, pFront, pRear, pFNameFront, pFNameRear);

	if( pFront )
		Marshal::FreeHGlobal( (IntPtr)pFront );
	if( pRear )
		Marshal::FreeHGlobal( (IntPtr)pRear );
	if( pFNameFront )
		Marshal::FreeHGlobal( (IntPtr)pFNameFront);
	if( pFNameRear )
		Marshal::FreeHGlobal( (IntPtr)pFNameRear);

	return rc;
} // CtsIQA::CheckImage

int LsFamily::CtsIQA::GetLoadIniError(String ^%DetailError)
{
	int rc;
	HWND hWnd = 0;
	char sError[1024];

	rc = ::LSIQAgetLoadIniError(hWnd, sError, sizeof(sError));

		if( DetailError )
			DetailError = Marshal::PtrToStringAnsi((IntPtr) (char *) sError);

	return 0;
} // CtsIQA::CheckImage

int LsFamily::CtsIQA::GetTestsErrors(IqaTestError ^stTestErrorsFront, IqaTestError ^stTestErrorsRear)
{
	int rc;
	HWND hWnd = 0;
	CTSIQA_TESTS_ERRORS sErrorFront, sErrorRear;

	// Copio la size
	if( stTestErrorsFront )
	{
		sErrorFront.Size = stTestErrorsFront->Size;
	}

	if( stTestErrorsFront )
	{
		sErrorRear.Size = stTestErrorsRear->Size;
	}

	rc = ::LSIQAGetTestsErrors(hWnd, &sErrorFront, &sErrorRear);

	if( rc == LSAPI_CTSIQA_OKAY )
	{
		if( stTestErrorsFront )
		{
			stTestErrorsFront->Function_Paramiter_Error = sErrorFront.Function_Paramiter_Error;
			stTestErrorsFront->UndersizeImage_flag = sErrorFront.UndersizeImage_flag;
			stTestErrorsFront->UndersizeImage_error = sErrorFront.UndersizeImage_error;
			stTestErrorsFront->UndersizeImage_Width = sErrorFront.UndersizeImage_Width;
			stTestErrorsFront->UndersizeImage_Height = sErrorFront.UndersizeImage_Height;
			stTestErrorsFront->Document_Corners_flag = sErrorFront.Document_Corners_flag;
			stTestErrorsFront->Document_Corners_error = sErrorFront.Document_Corners_error;
			stTestErrorsFront->Document_Corners_width = sErrorFront.Document_Corners_width;
			stTestErrorsFront->Document_Corners_height = sErrorFront.Document_Corners_height;
			stTestErrorsFront->Document_Edges_flag = sErrorFront.Document_Edges_flag;
			stTestErrorsFront->Document_Edges_error = sErrorFront.Document_Edges_error;
			stTestErrorsFront->Document_Edges_width = sErrorFront.Document_Edges_width;
			stTestErrorsFront->Document_Edges_height = sErrorFront.Document_Edges_height;
			stTestErrorsFront->Document_Framing_flag = sErrorFront.Document_Framing_flag;
			stTestErrorsFront->Document_Framing_error = sErrorFront.Document_Framing_error;
			stTestErrorsFront->Document_Framing_left = sErrorFront.Document_Framing_left;
			stTestErrorsFront->Document_Framing_right = sErrorFront.Document_Framing_right;
			stTestErrorsFront->Document_Framing_top = sErrorFront.Document_Framing_top;
			stTestErrorsFront->Document_Framing_bottom = sErrorFront.Document_Framing_bottom;
			stTestErrorsFront->Document_Skew_flag = sErrorFront.Document_Skew_flag;
			stTestErrorsFront->Document_Skew_error = sErrorFront.Document_Skew_error;
			stTestErrorsFront->Document_Skew_value = sErrorFront.Document_Skew_value;
			stTestErrorsFront->OversizeImage_flag = sErrorFront.OversizeImage_flag;
			stTestErrorsFront->OversizeImage_error = sErrorFront.OversizeImage_error;
			stTestErrorsFront->OversizeImage_Width = sErrorFront.OversizeImage_Width;
			stTestErrorsFront->OversizeImage_Height = sErrorFront.OversizeImage_Height;
			stTestErrorsFront->Image_too_Light_flag = sErrorFront.Image_too_Light_flag; 
			stTestErrorsFront->Image_too_Ligth_error = sErrorFront.Image_too_Ligth_error;
			stTestErrorsFront->Image_too_Light_AvgBrightness = sErrorFront.Image_too_Light_AvgBrightness;
			stTestErrorsFront->Image_too_Light_AvgContrast = sErrorFront.Image_too_Light_AvgContrast;
			stTestErrorsFront->Image_too_Light_PercentBlackPixel = sErrorFront.Image_too_Light_PercentBlackPixel;
			stTestErrorsFront->Image_too_Dark_flag = sErrorFront.Image_too_Dark_flag;
			stTestErrorsFront->Image_too_Dark_error = sErrorFront.Image_too_Dark_error;
			stTestErrorsFront->Image_too_Dark_AvgBrightness = sErrorFront.Image_too_Dark_AvgBrightness;
			stTestErrorsFront->Image_too_Dark_PercentBlackPixel = sErrorFront.Image_too_Dark_PercentBlackPixel;
			stTestErrorsFront->Horizontal_Streaks_flag = sErrorFront.Horizontal_Streaks_flag;
			stTestErrorsFront->Horizontal_Streaks_error = sErrorFront.Horizontal_Streaks_error;
			stTestErrorsFront->Horizontal_Streaks_value = sErrorFront.Horizontal_Streaks_value;
			stTestErrorsFront->Below_Compressed_Size_flag = sErrorFront.Below_Compressed_Size_flag;
			stTestErrorsFront->Below_Compressed_Size_error = sErrorFront.Below_Compressed_Size_error;
			stTestErrorsFront->Below_Compressed_Size_value = sErrorFront.Below_Compressed_Size_value;
			stTestErrorsFront->Above_Compressed_Size_flag = sErrorFront.Above_Compressed_Size_flag;
			stTestErrorsFront->Above_Compressed_Size_error = sErrorFront.Above_Compressed_Size_error;
			stTestErrorsFront->Above_Compressed_Size_value = sErrorFront.Above_Compressed_Size_value;
			stTestErrorsFront->Spot_Noise_flag = sErrorFront.Spot_Noise_flag;
			stTestErrorsFront->Sport_Noise_error = sErrorFront.Sport_Noise_error;
			stTestErrorsFront->Sport_Noise_value = sErrorFront.Sport_Noise_value;
			stTestErrorsFront->Front_Rear_Dimension_Mismatch_flag = sErrorFront.Front_Rear_Dimension_Mismatch_flag;
			stTestErrorsFront->Front_Rear_Dimension_Mismatch_error = sErrorFront.Front_Rear_Dimension_Mismatch_error;
			stTestErrorsFront->Front_Rear_Dimension_Mismatch_widthdiff = sErrorFront.Front_Rear_Dimension_Mismatch_widthdiff;
			stTestErrorsFront->Front_Rear_Dimension_Mismatch_heightdiff = sErrorFront.Front_Rear_Dimension_Mismatch_heightdiff;
			stTestErrorsFront->Carbon_Strip_flag = sErrorFront.Carbon_Strip_flag;
			stTestErrorsFront->Carbon_Strip_error = sErrorFront.Carbon_Strip_error;
			stTestErrorsFront->Out_of_Focus_flag = sErrorFront.Out_of_Focus_flag;
			stTestErrorsFront->Out_of_Focus_error = sErrorFront.Out_of_Focus_error;
			stTestErrorsFront->Out_of_Focus_value = sErrorFront.Out_of_Focus_value;
		}

		if( stTestErrorsFront )
		{
			stTestErrorsRear->Function_Paramiter_Error = sErrorRear.Function_Paramiter_Error;
			stTestErrorsRear->UndersizeImage_flag = sErrorRear.UndersizeImage_flag;
			stTestErrorsRear->UndersizeImage_error = sErrorRear.UndersizeImage_error;
			stTestErrorsRear->UndersizeImage_Width = sErrorRear.UndersizeImage_Width;
			stTestErrorsRear->UndersizeImage_Height = sErrorRear.UndersizeImage_Height;
			stTestErrorsRear->Document_Corners_flag = sErrorRear.Document_Corners_flag;
			stTestErrorsRear->Document_Corners_error = sErrorRear.Document_Corners_error;
			stTestErrorsRear->Document_Corners_width = sErrorRear.Document_Corners_width;
			stTestErrorsRear->Document_Corners_height = sErrorRear.Document_Corners_height;
			stTestErrorsRear->Document_Edges_flag = sErrorRear.Document_Edges_flag;
			stTestErrorsRear->Document_Edges_error = sErrorRear.Document_Edges_error;
			stTestErrorsRear->Document_Edges_width = sErrorRear.Document_Edges_width;
			stTestErrorsRear->Document_Edges_height = sErrorRear.Document_Edges_height;
			stTestErrorsRear->Document_Framing_flag = sErrorRear.Document_Framing_flag;
			stTestErrorsRear->Document_Framing_error = sErrorRear.Document_Framing_error;
			stTestErrorsRear->Document_Framing_left = sErrorRear.Document_Framing_left;
			stTestErrorsRear->Document_Framing_right = sErrorRear.Document_Framing_right;
			stTestErrorsRear->Document_Framing_top = sErrorRear.Document_Framing_top;
			stTestErrorsRear->Document_Framing_bottom = sErrorRear.Document_Framing_bottom;
			stTestErrorsRear->Document_Skew_flag = sErrorRear.Document_Skew_flag;
			stTestErrorsRear->Document_Skew_error = sErrorRear.Document_Skew_error;
			stTestErrorsRear->Document_Skew_value = sErrorRear.Document_Skew_value;
			stTestErrorsRear->OversizeImage_flag = sErrorRear.OversizeImage_flag;
			stTestErrorsRear->OversizeImage_error = sErrorRear.OversizeImage_error;
			stTestErrorsRear->OversizeImage_Width = sErrorRear.OversizeImage_Width;
			stTestErrorsRear->OversizeImage_Height = sErrorRear.OversizeImage_Height;
			stTestErrorsRear->Image_too_Light_flag = sErrorRear.Image_too_Light_flag; 
			stTestErrorsRear->Image_too_Ligth_error = sErrorRear.Image_too_Ligth_error;
			stTestErrorsRear->Image_too_Light_AvgBrightness = sErrorRear.Image_too_Light_AvgBrightness;
			stTestErrorsRear->Image_too_Light_AvgContrast = sErrorRear.Image_too_Light_AvgContrast;
			stTestErrorsRear->Image_too_Light_PercentBlackPixel = sErrorFront.Image_too_Light_PercentBlackPixel;
			stTestErrorsRear->Image_too_Dark_flag = sErrorFront.Image_too_Dark_flag;
			stTestErrorsRear->Image_too_Dark_error = sErrorFront.Image_too_Dark_error;
			stTestErrorsRear->Image_too_Dark_AvgBrightness = sErrorFront.Image_too_Dark_AvgBrightness;
			stTestErrorsRear->Image_too_Dark_PercentBlackPixel = sErrorFront.Image_too_Dark_PercentBlackPixel;
			stTestErrorsRear->Horizontal_Streaks_flag = sErrorFront.Horizontal_Streaks_flag;
			stTestErrorsRear->Horizontal_Streaks_error = sErrorFront.Horizontal_Streaks_error;
			stTestErrorsRear->Horizontal_Streaks_value = sErrorFront.Horizontal_Streaks_value;
			stTestErrorsRear->Below_Compressed_Size_flag = sErrorFront.Below_Compressed_Size_flag;
			stTestErrorsRear->Below_Compressed_Size_error = sErrorFront.Below_Compressed_Size_error;
			stTestErrorsRear->Below_Compressed_Size_value = sErrorFront.Below_Compressed_Size_value;
			stTestErrorsRear->Above_Compressed_Size_flag = sErrorFront.Above_Compressed_Size_flag;
			stTestErrorsRear->Above_Compressed_Size_error = sErrorFront.Above_Compressed_Size_error;
			stTestErrorsRear->Above_Compressed_Size_value = sErrorFront.Above_Compressed_Size_value;
			stTestErrorsRear->Spot_Noise_flag = sErrorFront.Spot_Noise_flag;
			stTestErrorsRear->Sport_Noise_error = sErrorFront.Sport_Noise_error;
			stTestErrorsRear->Sport_Noise_value = sErrorRear.Sport_Noise_value;
			stTestErrorsRear->Front_Rear_Dimension_Mismatch_flag = sErrorRear.Front_Rear_Dimension_Mismatch_flag;
			stTestErrorsRear->Front_Rear_Dimension_Mismatch_error = sErrorRear.Front_Rear_Dimension_Mismatch_error;
			stTestErrorsRear->Front_Rear_Dimension_Mismatch_widthdiff = sErrorRear.Front_Rear_Dimension_Mismatch_widthdiff;
			stTestErrorsRear->Front_Rear_Dimension_Mismatch_heightdiff = sErrorRear.Front_Rear_Dimension_Mismatch_heightdiff;
			stTestErrorsRear->Carbon_Strip_flag = sErrorRear.Carbon_Strip_flag;
			stTestErrorsRear->Carbon_Strip_error = sErrorRear.Carbon_Strip_error;
			stTestErrorsRear->Out_of_Focus_flag = sErrorRear.Out_of_Focus_flag;
			stTestErrorsRear->Out_of_Focus_error = sErrorRear.Out_of_Focus_error;
			stTestErrorsRear->Out_of_Focus_value = sErrorRear.Out_of_Focus_value;
		}
	}

	return 0;
} // CtsIQA::CheckImage
