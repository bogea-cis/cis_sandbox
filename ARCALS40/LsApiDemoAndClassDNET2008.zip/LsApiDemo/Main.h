//**************************************************************************
//  MODULE:   MAIN.h
//
//  PURPOSE:  Main application
//
//  FUNCTIONS: 
//
//	AUTHOR :  
//**************************************************************************


//-----------------------------------------------------------------------------
//      Defines
//-----------------------------------------------------------------------------
#define APP_TITLE						"CtsLsDemo  -*-  Ver. 1.00"

#define TITLE_POPUP						"LsApi Demo test"
#define TITLE_ERROR						"LsApi Demo ERROR"


#define FILE_CONF						"LsApiDemo.cfg"

#define FILE_CODELINE					"CodelineLS.txt"

#define SAVE_DIRECTORY_IMAGE			"Images"
#define NAME_IMAGE						"Image_"


#define HSCROLLMIN						0
#define HSCROLLMAX						100
#define SCROLLSTEP						20


#define MASK_FEEDER_EMPTY				0x01
#define MASK_OCR_HW						0x02
#define MASK_LS515D						0x04	// Maschera per LS515 con netto image
#define MASK_LS515C						0x08	// Maschera per LS515 a colori

#define TYPE_LS100_1					101
#define TYPE_LS100_2					102
#define TYPE_LS100_3					103
#define TYPE_LS100_4					104
#define TYPE_LS100_5					105

#define TYPE_LS500						500
#define TYPE_LS505						505
#define TYPE_LS510S						510
#define TYPE_LS510D						511
#define TYPE_LS515S						515
#define TYPE_LS515C						516
#define TYPE_LS515D						517
#define TYPE_LS515_3					5153
#define TYPE_LS515_5					5155
#define TYPE_LS515_6					5156
#define TYPE_LS510D_PTT					530


// define per gestire il TypeOfDecode
#define DECODE_NONE						0x00		// No read Codeline
#define DECODE_MICR						0x01		// decodifico micr
#define DECODE_OCR						0x02		// decodifico ocr
#define DECODE_BARCODE					0x04		// decodifico barcode
#define DECODE_PDF417					0x08		// decodifico pdf417
#define DECODE_BARCODE_HW				0x10		// decodifico barcode on board
#define DECODE_OCR_HW					0x20		// decodifico ocr on board


//define delle stringhe per combo box
#define STR_MUTILREAD					"MultiRead"
#define STR_OCRA						"OCRA"
#define STR_OCRB						"OCRB"
#define STR_OCRB_ALPHA					"OCRB AlphaNuMeric"
#define STR_OCRB_ITALY					"OCRB Italy"
#define STR_E13B						"E13B Optical"
#define STR_E13BOPT						"E13B Opt X Switch"

#define STR_BARCODE_2_OF_5				"Barcode 2 of 5"
#define STR_BARCODE_CODE39				"Barcode CODE39"


// Procedura di ConnectDlg
#define MAX_PORT						4
#define	MAX_BAUD						1
#define	MAX_PARITY						3
#define	MAX_SIZE						1
#define	MAX_STOP						1


// String for identify the periferal connected
#define MODEL_LS500						"C.T.S.  LS500"
#define MODEL_LS505						"C.T.S.  LS505"
#define MODEL_LS510S					"C.T.S.  LS510S"
#define MODEL_LS510D					"C.T.S.  LS510D"
#define MODEL_LS515						"C.T.S.  LS515"
#define MODEL_LS515S					"C.T.S.  LS515S"


//-----------------------------------------------------------------------------
//		Structures
//-----------------------------------------------------------------------------

// Structure for the save the setting
typedef struct tagPARAUTODOCHANDLE
{
	short	Stamp;
	short	Validate;
	BOOL	PrintBold;
	char	szValidateText[128];
	char	CodelineType;
	short	Sorter;
	short	ScanMode;
	char	Side;
	short	ReadMode;
	short   SaveFormat;
	short	SaveImage;
	short	Qual;
	BOOL	SaveCodeline;
	BOOL	ResetFileCodeline;
	short	ClearBlack;
	short	NumDoc;
	char	BeepOnError;
	short	WaitTimeout;
	BOOL	LinearEntry;
	short	PercentSpeedMeno;
	short	PercentSpeedPiu;
	DATASORTERSELECT	DataSorter[MAX_CRITERIA];
	BOOL	ViewOnlyLastImage;
	BOOL	DoCheckCodeline;
	char	CodelineBase[CODE_LINE_LENGTH];
	short	SorterStamp;
	short	SorterValidate;
	BOOL	SorterPrintBold;
	char	SorterszValidateText[128];
	char	SorterSide;
	BOOL	DoubleLeafingBlock;
	unsigned char	DoubleLeafingLevel;
	long	TimeOutSlowRead;
	short	ValueImageCalibration;
	short	StampPosition;
	unsigned char	BadgeTrack;
	short	Unit_measure;
	float	Codeline_Sw_x;   //file://per ocr
	float	Codeline_Sw_y;   //file://per ocr
	float	Codeline_Sw_w;   //file://per ocr
	float	Codeline_Sw_h;   //file://per ocr
	char	CodelineOptType; 
	float	Barcode_Sw_x;   //per Barcode
	float	Barcode_Sw_y;   //per Barcode
	float	Barcode_Sw_w;   //per Barcode
	float	Barcode_Sw_h;   //per Barcode
	char	Barcodetype;   // tipo di barcode
	short	Barcode_Unit_measure; // unit� di misura per Barcode
	char	TypeOfDecod;

	short	Peripheral;

	//LS100
	BOOL	OverlappedMode;
	char	Endorse_str[200];
	float	Codeline_Hw_x;				//per codeline hw
	float	Codeline_Hw_y;				//per codeline hw
	float	Codeline_Hw_w;				//per codeline hw
	float	Codeline_Hw_h;				//per codeline hw
	short	Codeline_Hw_Unit_measure;	// unit� di misura per Codeline Hw
	char	Codeline_Hw_Type;			// tipo di codeline Hw
	short	FrontStamp;
	short	BackStamp;
	int		PieceImage_x;
	int		PieceImage_y;
	int		PieceImage_width;
	int		PieceImage_height;
	short	SingleImageColor;
	short	Invalidation_Offset1;
	short	Invalidation_Offset2;
	short	Invalidation_Offset3;
	char	Invalidation_str1[200];
	char	Invalidation_str2[200];
	char	Invalidation_str3[200];

	short	Sorter_PrintValidate;
	BOOL	Sorter_PrintBold;
	char	Sorter_Endorse_str[200];
	char	Sorter_Side;
	short	Sorter_Stamp;
	short	Sorter_Eject;
	float	Pdf417_Sw_x;
	float	Pdf417_Sw_y;
	float	Pdf417_Sw_w;
	float	Pdf417_Sw_h;

} PARAUTODOCHANDLE, *LPPARAUTODOCHANDLE;

typedef struct{
	BOOL	Micr;
	BOOL	InkjetPrinter;
	BOOL	VoidingStamp;
	BOOL	ScannerFront;
	BOOL	ScannerBack;
	short	BadgeReader;
} PERIPHERAL_IDENTIFY;

PERIPHERAL_IDENTIFY PeriphFeatures;

enum
{
	BADGE_NO_PRESENT,
	BADGE_TRACKS_1_2,
	BADGE_TRACKS_2_3,
};


// Functions prototype
BOOL CALLBACK DlgProcDocumentHandle100(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

void EnableChoiceOpticForBarcode(HWND hwnd, BOOL Flag);
BOOL CALLBACK DlgProcDecoSwParOCR(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgProcDecoSwParPdf(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
void SetButtonInc(HWND hDlg);
void SetButtonMM(HWND hDlg);

void EnableChoiceOptic(HWND hwnd, BOOL Flag);
void EnableOpticMainOcr(HWND hwnd, BOOL Flag);
void SetObjOpticParameterMainOcr(HWND hDlg);
void EnableOpticMainOcrHw(HWND hwnd, BOOL Flag);
void SetObjOpticParameterMainOcrHw(HWND hDlg);
void EnableOpticMainPdf(HWND hwnd, BOOL Flag);
void SetObjOpticParameterMainPdf(HWND hDlg);

void DoLSReset(HWND hDlg, short TypePeripheral);

void ShowCodelineAndImage(HWND hDlg, unsigned char *BufFrontImage, unsigned char *BufBackImage,
						  unsigned char *BufFrontNettoImage, unsigned char *BufBackNettoImage,
						  char *BufCodelineSW, char *BufCodelineHW, char *BufBarcode, char *BufOptical);

int DisplayIdentify(HWND hWnd, char *IdentStr, LPSTR VendorMod,
					LPSTR ProductVer, LPSTR Lema, LPSTR InkJet);
void SaveConfiguration(unsigned char *IdentStr);
