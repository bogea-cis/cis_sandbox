//**************************************************************************
//  MODULE:   Mask.C
//
//  PURPOSE:  LS100 Application for Windows 
//
//  FUNCTIONS: 
// 
//	AUTHOR :  
//**************************************************************************

// --------------------------------------------------------------
//                  INCLUDES
// --------------------------------------------------------------
#include <windows.h>            // required for all Windows applications
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <ctype.h>
#include <dlgs.h>
#include <stdio.h>
#include <process.h>



#include "lsApi.h"

#include "Main.h"
#include "resource.h"



// --------------------------------------------------------------
//                  DEFINES
// --------------------------------------------------------------
#define DUMP_DEFAULT_FILE			"DumpMemory.txt"

#define OFF_PHOTO_1					0x0002
#define OFF_PHOTO_2					0x0003
#define OFF_PHOTO_3					0x0004
#define PHOTO_INI_DUMP				0x8d50
#define PHOTO_DUMP_SIZE_MEMORY		0x10

#define HISTORY_TIME_UNIT			300			// seconds

#define SETUP_MICR_ITEM				2
#define SETUP_STAMP_ITEM			2
#define SETUP_SCANNER_ITEM			3
#define SETUP_BADGE_ITEM			3

#define SETUP_ONLY_FRONT			0
#define SETUP_ONLY_REAR				1
#define SETUP_FRONT_REAR			2

#define TEXT_MM						"MM"
#define TEXT_INC					"INCH"




// --------------------------------------------------------------
//                  EXTERNAL FUNCTION
// --------------------------------------------------------------
extern int CheckReply(HWND hwnd, int ChReply, LPSTR Requester);
extern BOOL GetFileName(HWND hwnd, LPSTR pszTitle, LPSTR pszFilter, LPSTR pszFile);
extern int DoIdentify(HWND hWnd, BOOL ViewFeatures);


// --------------------------------------------------------------
//                  EXTERNAL VARIABLES
// --------------------------------------------------------------
extern HINSTANCE hInst;
extern short hLS;
extern HWND hDecoSw;

extern PARAUTODOCHANDLE stParDocHandle;

extern short	TypeLS;
extern char		IdentStr[8];
extern char		Model[20];
extern char		Version[20];
extern char		Lema[20];
extern char		InkJet[20];

extern unsigned long  NrDoc;

extern char CodelineRead[CODE_LINE_LENGTH];


// --------------------------------------------------------------
//                  INTERNAL FUNCTION
// --------------------------------------------------------------
BOOL CALLBACK DlgProcDecoSwParBarcode(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgProcSetString(HWND hDlg, UINT message, UINT wParam, LONG lParam);
BOOL CALLBACK DlgProcSetStrings(HWND hDlg, UINT message, UINT wParam, LONG lParam);
BOOL CALLBACK DlgProcSetStringForRet(HWND hDlg, UINT message, UINT wParam, LONG lParam);
BOOL CALLBACK DlgProcDecoSwParOCRHw(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);

int	DoDumpMemory(HWND hWnd, char *pBuff, long iniAddr);

void EstrazioneDatiPhoto(unsigned char *pd);

int DoMICRCalibration(HWND hWnd, long NrDocToRead, float *Percentile);
void SetButtonInc(HWND hDlg);
void SetButtonMM(HWND hDlg);
void SetObjOpticParameterMainOcr100(HWND hDlg);
void SetObjOpticParameterMainBarcode(HWND hDlg);


// --------------------------------------------------------------
//                  INTERNAL VARIABLES
// --------------------------------------------------------------
long nrDocProcessed;
long nrJamFeeder;
long nrJamPath;
long nrJamBin;
long nrDocPrint;
long nrDocStamp;
long nrDoubleLeafing;
long nrErrMICR;
long nrErrOptic;
long nrErrBarcode;

long totHours;
short totMinutes;
short totSeconds;

unsigned char PhotoValue[4];

UCHAR TableMicr[SETUP_MICR_ITEM][20] = {"Not Present", "Present"};
UCHAR TableStamp[SETUP_STAMP_ITEM][20] = {"Not Present", "Present"};
UCHAR TableScanner[SETUP_SCANNER_ITEM][20] = {"Only Front", "Only Rear", "Front and Rear"};
UCHAR TableBadge[SETUP_BADGE_ITEM][20] = {"Not Present", "Tracks 1/2", "Tracks 2/3"};


UCHAR TableCom[MAX_PORT][10] = {"COM1", "COM2", "COM3", "COM4"};

UCHAR TableBaud[MAX_BAUD][10] = {"115200"};
DWORD BaudTable[] = {CBR_115200};

UCHAR TableParity[MAX_PARITY][20] = {"No Parity", "Odd Parity", "Even Parity"};
BYTE ParityTable[] = {NOPARITY, ODDPARITY, EVENPARITY};

UCHAR TableByteSize[MAX_SIZE][10] = {"8"};
BYTE ByteSizeTable[] = {8};

UCHAR TableStopBit[MAX_STOP][10] = {"1"};
BYTE StopBitTable[] = {ONESTOPBIT};

HWND hDecoSw;





//***************************************************************************
// FUNCTION  : EnableOpticMainBarcode
//
// PURPOSE   : abilita/dis la parte di finestra per le coordinate
//				dell'ottico 
//
// PARAMETER : 
//***************************************************************************
void EnableOpticMainBarcode(HWND hwnd, BOOL Flag)
{
	long CurrItem;

	
	SetDlgItemText(hwnd,IDC_STATIC1,"Barcode Decode Information");
	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TYPE_OPT), FALSE);
	EnableWindow(GetDlgItem(hwnd, IDC_U_MEASURE), FALSE);
	EnableWindow(GetDlgItem(hwnd, IDC_S_MEASURE), FALSE);
	EnableWindow(GetDlgItem(hwnd, IDC_S_TYPE_OPT), FALSE);
	if( Flag )
	{
		switch( stParDocHandle.Barcodetype )
		{
		case READ_BARCODE_2_OF_5:
			CurrItem = 6;
			break;
		default:
			CurrItem = 1;
			break;
		}
		SendMessage(GetDlgItem(hwnd, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);

	} // end if
} // End EnableOpticMainBarcode



//***************************************************************************
// FUNCTION  : EnableTIFFChoice
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
void EnableTIFFChoice(HWND hwnd, BOOL Flag)
{

	EnableWindow(GetDlgItem(hwnd, IDC_TIFF_TYPE), Flag);

	EnableWindow(GetDlgItem(hwnd, IDC_TIFF_TYPE_1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TIFF_TYPE_2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TIFF_TYPE_3), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TIFF_TYPE_4), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TIFF_TYPE_5), Flag);

} // EnableTIFFChoice


//***************************************************************************
// FUNCTION  : DlgProcDocumentHandle
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
BOOL CALLBACK DlgProcDocumentHandle100(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	int CheckVal;

	switch (message)
	{
		case WM_INITDIALOG:

			// Overlapped Mode
			if( stParDocHandle.OverlappedMode )
				CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE, BST_UNCHECKED); 

			// Timeout
			if( stParDocHandle.WaitTimeout == WAIT_YES )
				CheckDlgButton(hDlg, IDC_WAIT_TIMEOUT, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_WAIT_TIMEOUT, BST_UNCHECKED); 

			// Front Stamp
			if(stParDocHandle.FrontStamp == FRONT_STAMP)
				CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_UNCHECKED); 

			// Beep
			if(stParDocHandle.BeepOnError == BEEP)
				CheckDlgButton(hDlg, IDC_BEEP, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_BEEP, BST_UNCHECKED); 

			// Print Validate
			if( stParDocHandle.Validate == PRINT_VALIDATE )
				CheckDlgButton(hDlg, IDC_PRINT_ENDORSE, BST_CHECKED);
			if( stParDocHandle.PrintBold )
				CheckDlgButton(hDlg, IDC_BOLD, BST_CHECKED);
			
			if( IdentStr[1] & 0x04 )
				EnableWindow(GetDlgItem(hDlg, IDC_INVALIDATION_STR), TRUE);
			if( IdentStr[1] & 0x08 )
				EnableWindow(GetDlgItem(hDlg, IDC_ENDORSEMENT_STR), TRUE);

			// CodelineOptType
			if( stParDocHandle.TypeOfDecod & DECODE_MICR )
				CheckDlgButton(hDlg, IDC_CODELINE_MICR,	BST_CHECKED);
			if( stParDocHandle.TypeOfDecod & DECODE_BARCODE )
			{	
				CheckDlgButton(hDlg, IDC_BARCODE,	BST_CHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE),TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE),TRUE);
				EnableOpticMainBarcode(hDlg, TRUE);
			}
			if( stParDocHandle.TypeOfDecod & DECODE_PDF417 )
			{	
				CheckDlgButton(hDlg, IDC_BARCODE_PDF417,	BST_CHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_PDF), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_PDF), TRUE);
			}
			if( stParDocHandle.TypeOfDecod & DECODE_OCR )
			{	
				CheckDlgButton(hDlg, IDC_CODELINE_OCR,	BST_CHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), TRUE);
				EnableOpticMainOcr(hDlg, TRUE);
			}
			if( stParDocHandle.TypeOfDecod & DECODE_OCR_HW )
			{	
				CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW,	BST_CHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), TRUE);
				EnableOpticMainOcrHw(hDlg, TRUE);
			}
			// Save Codeline on file
			if( stParDocHandle.SaveCodeline )
			{
				CheckDlgButton(hDlg, IDC_SAVE_CODELINE, BST_CHECKED);

				EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), TRUE);

				if( stParDocHandle.ResetFileCodeline )
					CheckDlgButton(hDlg, IDC_RESET_FILE, BST_CHECKED);
			}

			// Save Image on file
			if( stParDocHandle.SaveImage == IMAGE_SAVE_BOTH )
			{
				if( stParDocHandle.SaveFormat == SAVE_JPEG )
				{
					CheckDlgButton(hDlg, IDC_FILE_JPEG, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), TRUE);
				}
				else if( stParDocHandle.SaveFormat == SAVE_BMP )
				{
					CheckDlgButton(hDlg, IDC_FILE_BMP, BST_CHECKED);
				}
				else if( stParDocHandle.SaveFormat == FILE_TIF )
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_CHECKED);
					EnableTIFFChoice(hDlg, TRUE);
					CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_1);
				}
				else if( stParDocHandle.SaveFormat == FILE_CCITT )
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_CHECKED);
					EnableTIFFChoice(hDlg, TRUE);
					CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_2);
				}
				else if( stParDocHandle.SaveFormat == FILE_CCITT_GROUP3_1DIM )
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_CHECKED);
					EnableTIFFChoice(hDlg, TRUE);
					CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_3);
				}
				else if( stParDocHandle.SaveFormat == FILE_CCITT_GROUP3_2DIM )
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_CHECKED);
					EnableTIFFChoice(hDlg, TRUE);
					CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_4);
				}
				else if( stParDocHandle.SaveFormat == FILE_CCITT_GROUP4 )
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_CHECKED);
					EnableTIFFChoice(hDlg, TRUE);
					CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_5);
				}
			}

			// Quality
			SetDlgItemInt(hDlg, IDC_QUALITY, stParDocHandle.Qual, TRUE);

			// ScanMode
			if( TypeLS == TYPE_LS100_2 || TypeLS == TYPE_LS100_3 )
			{
				EnableWindow(GetDlgItem(hDlg, IDC_SCANMODE_BW_TIFF), TRUE);
			}
			if( TypeLS == TYPE_LS100_4 )
			{
				EnableWindow(GetDlgItem(hDlg, IDC_SCANMODE_BW_TIFF), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_SCANMODE_COLOR), TRUE);
			}

			switch( stParDocHandle.ScanMode)
			{
			case SCAN_MODE_BW:
				CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE_BW);
				CheckDlgButton(hDlg, IDC_SCANMODE_BW, BST_CHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), FALSE);
				CheckDlgButton(hDlg, IDC_CODELINE_OCR,	BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW,	BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);

				CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);

				break;

			case SCAN_MODE_16GR100:
				CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE16GR100);
				CheckDlgButton(hDlg, IDC_SCANMODE16GR100, BST_CHECKED);

				CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
				
				CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);
				EnableChoiceOptic(hDlg,FALSE);
				break;

			case SCAN_MODE_16GR200:
				CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE16GR200);
				CheckDlgButton(hDlg, IDC_SCANMODE16GR200, BST_CHECKED);
				break;

			case SCAN_MODE_256GR100:
				CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE256GR100);
				CheckDlgButton(hDlg, IDC_SCANMODE256GR100, BST_CHECKED);

				CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED);

				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);

				CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);

				EnableChoiceOptic(hDlg,FALSE);
				break;

			case SCAN_MODE_256GR200:
				CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE256GR200);
				CheckDlgButton(hDlg, IDC_SCANMODE256GR200, BST_CHECKED);
				break;

			case SCAN_MODE_BW_TIFF:
				if( TypeLS == TYPE_LS100_2 || TypeLS == TYPE_LS100_3 || TypeLS == TYPE_LS100_4 )
				{
					CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE_BW_TIFF);
					CheckDlgButton(hDlg, IDC_SCANMODE_BW_TIFF, BST_CHECKED);

					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), FALSE);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR,	BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW,	BST_UNCHECKED);
				}
				else
				{
					CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE_BW);
					CheckDlgButton(hDlg, IDC_SCANMODE_BW, BST_CHECKED);
				}
				break;

			case SCAN_MODE_COLOR_200:
				if( TypeLS == TYPE_LS100_4 )
				{
					CheckDlgButton(hDlg, IDC_SCANMODE_COLOR, BST_CHECKED);

					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), FALSE);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR,	BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW,	BST_UNCHECKED);
				}
				else
				{
					CheckRadioButton(hDlg, IDC_SCANMODE_BW_TIFF, IDC_SCANMODE256GR200, IDC_SCANMODE_BW);
					CheckDlgButton(hDlg, IDC_SCANMODE_BW, BST_CHECKED);
				}
				break;

			}

			// NumDoc
			if(stParDocHandle.NumDoc == 0)
			{
				CheckRadioButton(hDlg, IDC_ALLNUMDOC, IDC_FIXEDNUMDOC, IDC_ALLNUMDOC);
			}
			else
			{
				CheckRadioButton(hDlg, IDC_ALLNUMDOC, IDC_FIXEDNUMDOC, IDC_FIXEDNUMDOC);
				SetDlgItemInt (hDlg, IDC_NUMDOC, stParDocHandle.NumDoc, TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), TRUE);
			}

			// Doc. retained
			if( stParDocHandle.Sorter == HOLD_DOCUMENT )
			{
				CheckDlgButton(hDlg, IDC_DOC_RETAINED, BST_CHECKED);
			}

			// ClearBlack
			if(stParDocHandle.ClearBlack == CLEAR_ALL_BLACK)
				CheckDlgButton(hDlg, IDC_CLEARIMAGE, BST_CHECKED);
			else
				CheckDlgButton(hDlg, IDC_CLEARIMAGE, BST_UNCHECKED);

			// Side
			switch (stParDocHandle.Side)
			{
				case SIDE_FRONT_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEFRONT);
					break;

				case SIDE_BACK_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEBACK);
					break;

				case SIDE_ALL_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEALL);
					break;

				case SIDE_NONE_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDENONE);
					break;
			}

			// Check Codeline
			if( stParDocHandle.DoCheckCodeline )
			{
				CheckDlgButton(hDlg, IDC_DO_CHECK, BST_CHECKED);

				CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE, BST_UNCHECKED);

				EnableWindow(GetDlgItem(hDlg, IDC_DOC_RETAINED), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), FALSE);
			}
			if( stParDocHandle.CodelineBase[0] )
				SetDlgItemText(hDlg, IDC_CHECK_CODELINE, stParDocHandle.CodelineBase);

			return TRUE;



		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{

			case IDC_CODELINE_MICR:
				if(IsDlgButtonChecked(hDlg, IDC_CODELINE_MICR) == BST_CHECKED)
					CheckDlgButton(hDlg, IDC_CODELINE_MICR, BST_UNCHECKED); 
				else
				{
					CheckDlgButton(hDlg, IDC_CODELINE_MICR,		BST_CHECKED);
					EnableOpticMainOcr(hDlg,FALSE);
					EnableOpticMainBarcode(hDlg,FALSE);

				}
				break;

			case IDC_BARCODE:
				if(IsDlgButtonChecked(hDlg, IDC_BARCODE) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED); 
					EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);
					EnableOpticMainBarcode(hDlg,FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), TRUE);
				}
				else
				{
					CheckDlgButton(hDlg, IDC_BARCODE,BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), TRUE);
					EnableOpticMainBarcode(hDlg,TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED); 
				}
				if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED); 
					CheckDlgButton(hDlg, IDC_SIDENONE, BST_UNCHECKED); 
				}
				break;

			case IDC_BARCODE_PDF417:
				if(IsDlgButtonChecked(hDlg, IDC_BARCODE_PDF417) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED); 
					EnableWindow(GetDlgItem(hDlg, IDC_SET_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_PDF), FALSE);
					EnableOpticMainPdf(hDlg,FALSE);

					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), TRUE);
				}
				else
				{
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417,	BST_CHECKED);
					EnableOpticMainPdf(hDlg,TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_PDF), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_PDF), TRUE);
					SetObjOpticParameterMainPdf(hDlg);

					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);
				}
				if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED); 
					CheckDlgButton(hDlg, IDC_SIDENONE, BST_UNCHECKED); 
				}
				break;

			case IDC_CODELINE_OCR:
				if(IsDlgButtonChecked(hDlg, IDC_CODELINE_OCR) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_CODELINE_OCR, BST_UNCHECKED); 
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), FALSE);
					EnableOpticMainOcr(hDlg,FALSE);
				}
				else
				{
					CheckDlgButton(hDlg, IDC_CODELINE_OCR, BST_CHECKED); 
					EnableOpticMainOcr(hDlg,TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), TRUE);
					SetObjOpticParameterMainOcr(hDlg);
				}
				if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED); 
					CheckDlgButton(hDlg, IDC_SIDENONE, BST_UNCHECKED); 
				}
				break;

			case IDC_CODELINE_OCR_HW:
				if(IsDlgButtonChecked(hDlg, IDC_CODELINE_OCR_HW) == BST_CHECKED)
				{
					CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW, BST_UNCHECKED); 
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), FALSE);
					EnableOpticMainOcrHw(hDlg,FALSE);
				}
				else
				{
					CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW, BST_CHECKED); 
					EnableOpticMainOcrHw(hDlg, TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), TRUE);
					SetObjOpticParameterMainOcrHw(hDlg);
				}
				break;

			case IDC_SAVE_CODELINE:
				if(IsDlgButtonChecked(hDlg, IDC_SAVE_CODELINE) == BST_CHECKED)
				{
					stParDocHandle.SaveCodeline = TRUE;

					EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), TRUE);

					if( stParDocHandle.ResetFileCodeline )
						CheckDlgButton(hDlg, IDC_RESET_FILE, BST_CHECKED);
				}
				else
				{
					stParDocHandle.SaveCodeline = FALSE;

					EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), FALSE);
				}
				break;

			case IDC_RESET_FILE:
				if( IsDlgButtonChecked(hDlg, IDC_RESET_FILE) == BST_CHECKED )
					stParDocHandle.ResetFileCodeline = TRUE;
				else
					stParDocHandle.ResetFileCodeline = FALSE;
				break;

			case IDC_FILE_JPEG:
				if( IsDlgButtonChecked(hDlg, IDC_FILE_JPEG) == BST_CHECKED )
				{
					CheckDlgButton(hDlg, IDC_FILE_JPEG, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
				}
				else
				{
					CheckDlgButton(hDlg, IDC_FILE_JPEG, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), TRUE);

					CheckDlgButton(hDlg, IDC_FILE_BMP, BST_UNCHECKED);

					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_UNCHECKED);
					EnableTIFFChoice(hDlg, FALSE);
				}
				break;

			case IDC_FILE_BMP:
				if( IsDlgButtonChecked(hDlg, IDC_FILE_BMP) == BST_CHECKED )
					CheckDlgButton(hDlg, IDC_FILE_BMP, BST_UNCHECKED);
				else
				{
					CheckDlgButton(hDlg, IDC_FILE_BMP, BST_CHECKED);

					CheckDlgButton(hDlg, IDC_FILE_JPEG, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);

					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_UNCHECKED);
					EnableTIFFChoice(hDlg, FALSE);
				}
				break;

			case IDC_FILE_TIFF:
				if( IsDlgButtonChecked(hDlg, IDC_FILE_TIFF) == BST_CHECKED )
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_UNCHECKED);
					EnableTIFFChoice(hDlg, FALSE);
				}
				else
				{
					CheckDlgButton(hDlg, IDC_FILE_TIFF, BST_CHECKED);
					EnableTIFFChoice(hDlg, TRUE);

					CheckDlgButton(hDlg, IDC_FILE_JPEG, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);

					CheckDlgButton(hDlg, IDC_FILE_BMP, BST_UNCHECKED);

					if( stParDocHandle.SaveFormat == FILE_TIF )
						CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_1);
					else if( stParDocHandle.SaveFormat == FILE_CCITT )
						CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_2);
					else if( stParDocHandle.SaveFormat == FILE_CCITT_GROUP3_1DIM )
						CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_3);
					else if( stParDocHandle.SaveFormat == FILE_CCITT_GROUP3_2DIM )
						CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_4);
					else if( stParDocHandle.SaveFormat == FILE_CCITT_GROUP4 )
						CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_5);
					else	// default
						CheckRadioButton(hDlg, IDC_TIFF_TYPE_1, IDC_TIFF_TYPE_5, IDC_TIFF_TYPE_1);
				}
				break;

			case IDC_QUALITY:
				CheckVal = GetDlgItemInt(hDlg, IDC_QUALITY, NULL, FALSE);
				if( (CheckVal < 2) || (CheckVal > 255) )
				{
					MessageBeep (0);

					CheckVal = 128;
					SetDlgItemInt(hDlg, IDC_QUALITY, CheckVal, FALSE);
				}
				break;

			case IDC_SCANMODE_BW_TIFF:
			case IDC_SCANMODE_BW:
				switch( HIWORD(wParam) )
				{
				case BN_CLICKED:
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417,	BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR,		BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW,	BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE,	BST_UNCHECKED);
					
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), FALSE);
					
					CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);
					break;
				}
				return TRUE;

			case IDC_SCANMODE16GR100:
			case IDC_SCANMODE256GR100:
				switch( HIWORD(wParam) )
				{
				case BN_CLICKED:
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417,	BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR), TRUE);
					if( IdentStr[1] & MASK_OCR_HW )
					{
						if( TypeLS == TYPE_LS100_3 || TypeLS == TYPE_LS100_4 || TypeLS == TYPE_LS100_5 )
						{
							EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), TRUE);
							EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), TRUE);
							EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), TRUE);
						}
					}
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), TRUE);					
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);					
					CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);
				break;
				}
				return TRUE;

			case IDC_SCANMODE16GR200:
			case IDC_SCANMODE256GR200:
				switch( HIWORD(wParam) )
				{
				case BN_CLICKED:
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), TRUE);
					if( IdentStr[1] & MASK_OCR_HW )
					{
						if( TypeLS == TYPE_LS100_3 || TypeLS == TYPE_LS100_4 || TypeLS == TYPE_LS100_5 )
						{
							EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), TRUE);
							EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), TRUE);
							EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), TRUE);
						}
					}
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR), TRUE);
					break;
				}
				return TRUE;

			case IDC_SCANMODE_COLOR_100:
			case IDC_SCANMODE_COLOR:
				switch( HIWORD(wParam) )
				{
				case BN_CLICKED:
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417,	BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW,	BST_UNCHECKED);
					CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE,	BST_UNCHECKED);


					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_PDF), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_CODELINE_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR_HW), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), FALSE);
					
					CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_BARCODE), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);
					break;
				}
				return TRUE;

			case IDC_ALLNUMDOC:
				EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), FALSE);
				break;

			case IDC_FIXEDNUMDOC:
				EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), TRUE);
				if(stParDocHandle.NumDoc == 0)
					SetDlgItemInt (hDlg, IDC_NUMDOC, 1, TRUE);
				else
					SetDlgItemInt (hDlg, IDC_NUMDOC, stParDocHandle.NumDoc, TRUE);
				break;

			case IDC_NUMDOC:
				if( GetDlgItemInt(hDlg, IDC_NUMDOC, NULL, FALSE) == 0 )
					SetDlgItemInt (hDlg, IDC_NUMDOC, 1, TRUE);
				break;


			case IDC_AGG_CODELINE:
				SetDlgItemText(hDlg, IDC_CHECK_CODELINE, CodelineRead);
				return TRUE;


			case IDC_DO_CHECK:
				if( IsDlgButtonChecked(hDlg, IDC_DO_CHECK) == BST_CHECKED )
				{
					CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE, BST_UNCHECKED);

					EnableWindow(GetDlgItem(hDlg, IDC_DOC_RETAINED), FALSE);

					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), FALSE);
				}
				else
				{
					EnableWindow(GetDlgItem(hDlg, IDC_DOC_RETAINED), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), TRUE);
				}

				return TRUE;

			case IDC_OVERLAPPED_MODE:
				CheckDlgButton(hDlg, IDC_DO_CHECK, BST_UNCHECKED);
				return TRUE;

			case IDC_DOC_RETAINED:
				if( IsDlgButtonChecked(hDlg, IDC_DOC_RETAINED) == BST_CHECKED )
				{
					CheckDlgButton(hDlg, IDC_OVERLAPPED_MODE, BST_UNCHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_DO_CHECK), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), FALSE);
				}
				else
				{
					EnableWindow(GetDlgItem(hDlg, IDC_DO_CHECK), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_OVERLAPPED_MODE), TRUE);
				}

				return TRUE;

			case IDC_UNIT_INC:
				return TRUE;

			case IDC_UNIT_MM:
				return TRUE;

			case IDC_VIEW_BARCODE:
				EnableOpticMainBarcode(hDlg,TRUE);
				SetObjOpticParameterMainBarcode(hDlg);				
				return TRUE;

			case IDC_VIEW_PDF:
				EnableOpticMainPdf(hDlg, TRUE);
				SetObjOpticParameterMainPdf(hDlg);
				return TRUE;

			case IDC_VIEW_OCR:
				EnableOpticMainOcr(hDlg, TRUE);
				SetObjOpticParameterMainOcr(hDlg);
				return TRUE;

			case IDC_VIEW_OCR_HW:
				EnableOpticMainOcrHw(hDlg, TRUE);
				SetObjOpticParameterMainOcrHw(hDlg);
				return TRUE;

			case IDC_SET_BARCODE:
				DialogBox(hInst, MAKEINTRESOURCE (IDD_DECO_PAR_SW), hDlg, DlgProcDecoSwParBarcode);
				SendMessage(hDlg, WM_COMMAND, IDC_VIEW_BARCODE, 0);
				return TRUE;

			case IDC_SET_PDF:
				DialogBox(hInst, MAKEINTRESOURCE (IDD_DECO_PAR_SW), hDlg, DlgProcDecoSwParPdf);
				SendMessage(hDlg, WM_COMMAND, IDC_VIEW_PDF, 0);
				return TRUE;

			case IDC_SET_OCR:
				DialogBox(hInst, MAKEINTRESOURCE (IDD_DECO_PAR_SW), hDlg, DlgProcDecoSwParOCR);
				SendMessage(hDlg, WM_COMMAND, IDC_VIEW_OCR, 0);
				return TRUE;

			case IDC_SET_OCR_HW:
				DialogBox(hInst, MAKEINTRESOURCE (IDD_DECO_PAR_SW), hDlg, DlgProcDecoSwParOCRHw);
				SendMessage(hDlg, WM_COMMAND, IDC_VIEW_OCR_HW, 0);
				return TRUE;

			case IDC_INVALIDATION_STR:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_SET_STRINGS), hDlg, DlgProcSetStrings);
				return TRUE;

			case IDC_ENDORSEMENT_STR:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_SET_STRING), hDlg, DlgProcSetString);
				return TRUE;

			case IDC_SIDENONE:
				CheckDlgButton(hDlg, IDC_BARCODE, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_CODELINE_OCR, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_CODELINE_OCR_HW, BST_UNCHECKED);
				return TRUE;


			case IDOK:
				// Overlapped Mode
				if( IsDlgButtonChecked(hDlg, IDC_OVERLAPPED_MODE) == BST_CHECKED )
					stParDocHandle.OverlappedMode = TRUE;
				else
					stParDocHandle.OverlappedMode = FALSE;

				// Front Stamp
				if( IsDlgButtonChecked(hDlg, IDC_FRONTSTAMP) == BST_CHECKED )
					stParDocHandle.FrontStamp = FRONT_STAMP;
				else
					stParDocHandle.FrontStamp = NO_STAMP;

				// Beep
				if( IsDlgButtonChecked(hDlg, IDC_BEEP) == BST_CHECKED )
					stParDocHandle.BeepOnError = BEEP;
				else
					stParDocHandle.BeepOnError = NO_BEEP;

				// Print Validate
				if( IsDlgButtonChecked(hDlg, IDC_PRINT_ENDORSE) == BST_CHECKED )
					stParDocHandle.Validate = PRINT_VALIDATE;
				else
					stParDocHandle.Validate = NO_PRINT_VALIDATE;
				if( IsDlgButtonChecked(hDlg, IDC_BOLD) == BST_CHECKED )
					stParDocHandle.PrintBold = TRUE;
				else
					stParDocHandle.PrintBold = FALSE;

				stParDocHandle.TypeOfDecod = 0;
				
				if( IsDlgButtonChecked(hDlg, IDC_CODELINE_MICR) == BST_CHECKED )
					stParDocHandle.TypeOfDecod |= DECODE_MICR;
				if( IsDlgButtonChecked(hDlg, IDC_BARCODE_PDF417) == BST_CHECKED )
					stParDocHandle.TypeOfDecod |= DECODE_PDF417;
				if( IsDlgButtonChecked(hDlg, IDC_BARCODE) == BST_CHECKED )
					stParDocHandle.TypeOfDecod |= DECODE_BARCODE;
				if( IsDlgButtonChecked(hDlg,  IDC_CODELINE_OCR) == BST_CHECKED)
					stParDocHandle.TypeOfDecod |= DECODE_OCR;
				if( IsDlgButtonChecked(hDlg,  IDC_CODELINE_OCR_HW) == BST_CHECKED)
					stParDocHandle.TypeOfDecod |= DECODE_OCR_HW;

				//TimeOut
				if(IsDlgButtonChecked(hDlg, IDC_WAIT_TIMEOUT) == BST_CHECKED)
					stParDocHandle.WaitTimeout = WAIT_YES;
				else
					stParDocHandle.WaitTimeout = WAIT_NO;

				// ScanMode
				if( IsDlgButtonChecked(hDlg, IDC_SCANMODE_BW_TIFF) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_BW_TIFF;
				else if( IsDlgButtonChecked(hDlg, IDC_SCANMODE_BW) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_BW;
				else if( IsDlgButtonChecked(hDlg, IDC_SCANMODE16GR100) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_16GR100;
				else if( IsDlgButtonChecked(hDlg, IDC_SCANMODE16GR200) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_16GR200;
				else if( IsDlgButtonChecked(hDlg, IDC_SCANMODE256GR100) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_256GR100;
				else if( IsDlgButtonChecked(hDlg, IDC_SCANMODE256GR200) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_256GR200;
				else if( IsDlgButtonChecked(hDlg, IDC_SCANMODE_COLOR) == BST_CHECKED)
					stParDocHandle.ScanMode = SCAN_MODE_COLOR_200;

				// NumDoc
				if(IsDlgButtonChecked(hDlg, IDC_ALLNUMDOC) == BST_CHECKED)
					stParDocHandle.NumDoc = 0;
				else 
					stParDocHandle.NumDoc = GetDlgItemInt(hDlg, IDC_NUMDOC, NULL, FALSE);

				// Doc. retained
				if( IsDlgButtonChecked(hDlg, IDC_DOC_RETAINED) == BST_CHECKED )
					stParDocHandle.Sorter = HOLD_DOCUMENT;
				else
					stParDocHandle.Sorter = SORTER_BAY1;

				// ClearBlack
				if(IsDlgButtonChecked(hDlg, IDC_CLEARIMAGE) == BST_CHECKED)
					stParDocHandle.ClearBlack = CLEAR_ALL_BLACK;
				else 
					stParDocHandle.ClearBlack = NO_CLEAR_BLACK;

				// Side
				if(IsDlgButtonChecked(hDlg, IDC_SIDEFRONT) == BST_CHECKED)
					stParDocHandle.Side = SIDE_FRONT_IMAGE;
				else if(IsDlgButtonChecked(hDlg, IDC_SIDEBACK) == BST_CHECKED)
					stParDocHandle.Side = SIDE_BACK_IMAGE;
				else if(IsDlgButtonChecked(hDlg, IDC_SIDEALL) == BST_CHECKED)
					stParDocHandle.Side = SIDE_ALL_IMAGE;
				else if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
				{
					stParDocHandle.Side = SIDE_NONE_IMAGE;
				}


				// SAVE ON FILE
				// handle is always saved, it is used to show the image
				stParDocHandle.SaveImage = IMAGE_SAVE_HANDLE;
				if( IsDlgButtonChecked(hDlg, IDC_FILE_JPEG) == BST_CHECKED )
				{
					stParDocHandle.SaveImage = IMAGE_SAVE_BOTH;
					stParDocHandle.SaveFormat = SAVE_JPEG;
				}
				else if( IsDlgButtonChecked(hDlg, IDC_FILE_BMP) == BST_CHECKED )
				{
					stParDocHandle.SaveImage = IMAGE_SAVE_BOTH;
					stParDocHandle.SaveFormat = SAVE_BMP;
				}
				else if( IsDlgButtonChecked(hDlg, IDC_FILE_TIFF) == BST_CHECKED )
				{
					stParDocHandle.SaveImage = IMAGE_SAVE_BOTH;
					if( IsDlgButtonChecked(hDlg, IDC_TIFF_TYPE_1) == BST_CHECKED )
						stParDocHandle.SaveFormat = FILE_TIF;
					else if( IsDlgButtonChecked(hDlg, IDC_TIFF_TYPE_2) == BST_CHECKED )
						stParDocHandle.SaveFormat = FILE_CCITT;
					else if( IsDlgButtonChecked(hDlg, IDC_TIFF_TYPE_3) == BST_CHECKED )
						stParDocHandle.SaveFormat = FILE_CCITT_GROUP3_1DIM;
					else if( IsDlgButtonChecked(hDlg, IDC_TIFF_TYPE_4) == BST_CHECKED )
						stParDocHandle.SaveFormat = FILE_CCITT_GROUP3_2DIM;
					else if( IsDlgButtonChecked(hDlg, IDC_TIFF_TYPE_5) == BST_CHECKED )
						stParDocHandle.SaveFormat = FILE_CCITT_GROUP4;
				}

				// Quality
				stParDocHandle.Qual = GetDlgItemInt(hDlg, IDC_QUALITY, NULL, FALSE);

				// Check Codeline
				if( IsDlgButtonChecked(hDlg, IDC_DO_CHECK) == BST_CHECKED)
					stParDocHandle.DoCheckCodeline = TRUE;
				else
					stParDocHandle.DoCheckCodeline = FALSE;
				GetDlgItemText(hDlg, IDC_CHECK_CODELINE, stParDocHandle.CodelineBase, CODE_LINE_LENGTH);


				EndDialog (hDlg, TRUE);
				return (TRUE);

			case IDCANCEL:
				EndDialog (hDlg, FALSE);
				return (TRUE);

		} // End switch WM_COMMAND
	} // End switch message

	return (FALSE);
}  // DlgProcDocumentHandle


// *******************************************************************
// *    DoReadBadge
// *******************************************************************
int DoReadBadge(HWND hWnd, unsigned char Traccia, char *Buff, short *llString)
{
	int		Reply;
	short	hLS;
	short	llBuffer;


	// Connect peripheral
	Reply = LSConnect(hWnd, hInst, LS_100_USB, &hLS);
	if (Reply != LS_OKAY)
	{
		if( CheckReply(hWnd, Reply, "LSConnect"))
		    return Reply;
	}

	llBuffer = *llString;		// ll Buffer

	Reply = LSReadBadge(hLS, hWnd, Traccia, llBuffer, Buff, llString);
	if (Reply != LS_OKAY)
	{
		CheckReply(hWnd, Reply, "LSReadBadge");
	}

	LSDisconnect(hLS, hWnd);

	return Reply;
} // End DoReadBadge()



void SorterReadSelection(HWND hDlg)
{
	// Print Validate
	if( IsDlgButtonChecked(hDlg, IDC_PRINT_ENDORSE) == BST_CHECKED )
		stParDocHandle.Sorter_PrintValidate = PRINT_VALIDATE;
	else
		stParDocHandle.Sorter_PrintValidate = NO_PRINT_VALIDATE;
	if( IsDlgButtonChecked(hDlg, IDC_BOLD) == BST_CHECKED )
		stParDocHandle.Sorter_PrintBold = TRUE;
	else
		stParDocHandle.Sorter_PrintBold = FALSE;

	// Side
	if( IsDlgButtonChecked(hDlg, IDC_SIDEALL) == BST_CHECKED)
		stParDocHandle.Sorter_Side = SIDE_ALL_IMAGE;
	if( IsDlgButtonChecked(hDlg, IDC_SIDEFRONT) == BST_CHECKED)
		stParDocHandle.Sorter_Side = SIDE_FRONT_IMAGE;
	if( IsDlgButtonChecked(hDlg, IDC_SIDEBACK) == BST_CHECKED)
		stParDocHandle.Sorter_Side = SIDE_BACK_IMAGE;
	else if( IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
		stParDocHandle.Sorter_Side = SIDE_NONE_IMAGE;

	if( IsDlgButtonChecked(hDlg, IDC_FRONTSTAMP) == BST_CHECKED )
		stParDocHandle.Sorter_Stamp = FRONT_STAMP;
	else
		stParDocHandle.Sorter_Stamp = NO_STAMP;
} // SorterReadSelection


// Dialog of ouput document holder
int CALLBACK DlgProcSorter(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch( message )
	{
	case WM_INITDIALOG:

		// Print Validate
		if( stParDocHandle.Sorter_PrintValidate == PRINT_VALIDATE )
			CheckDlgButton(hDlg, IDC_PRINT_ENDORSE, BST_CHECKED);
		if( stParDocHandle.Sorter_PrintBold )
			CheckDlgButton(hDlg, IDC_BOLD, BST_CHECKED);

		if( IdentStr[1] & 0x04 )
			EnableWindow(GetDlgItem(hDlg, IDC_INVALIDATION_STR), TRUE);
		if( IdentStr[1] & 0x08 )
			EnableWindow(GetDlgItem(hDlg, IDC_ENDORSEMENT_STR), TRUE);

		// Side
		switch (stParDocHandle.Sorter_Side)
		{
			case SIDE_ALL_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEALL);
				CheckDlgButton(hDlg, IDC_SIDEALL, BST_CHECKED);
			break;

			case SIDE_FRONT_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEFRONT);
				CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED);
			break;

			case SIDE_BACK_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEBACK);
				CheckDlgButton(hDlg, IDC_SIDEBACK, BST_CHECKED);
			break;

			case SIDE_NONE_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDENONE);
				CheckDlgButton(hDlg, IDC_SIDENONE, BST_CHECKED);
			break;
		}

		// Stamp
		if( stParDocHandle.Sorter_Stamp == FRONT_STAMP )
			CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_CHECKED);
		// SORTER
		if (stParDocHandle.Sorter_Eject == EJECT_DOCUMENT )
		{
			CheckDlgButton(hDlg, IDC_EJECT, BST_CHECKED);
			EnableWindow(GetDlgItem(hDlg, IDC_SIDEALL), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_SIDEFRONT), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_SIDEBACK), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_SIDENONE), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_FRONTSTAMP), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_PRINT_ENDORSE), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_ENDORSEMENT_STR), FALSE);
			CheckDlgButton(hDlg, IDC_SIDENONE, BST_CHECKED);
		}
		return TRUE;


	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDC_INVALIDATION_STR:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_SET_STRINGS), hDlg, DlgProcSetStrings);
			break;

		case IDC_ENDORSEMENT_STR:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_SET_STRING), hDlg, DlgProcSetStringForRet);
			break;
		case IDC_EJECT:
			if ( IsDlgButtonChecked(hDlg,IDC_EJECT ) ==  BST_CHECKED)
			{
				stParDocHandle.Sorter_Eject = EJECT_DOCUMENT;
				EnableWindow(GetDlgItem(hDlg, IDC_SIDEALL), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SIDEFRONT), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SIDEBACK), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SIDENONE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_FRONTSTAMP), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_PRINT_ENDORSE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_ENDORSEMENT_STR), FALSE);
				CheckDlgButton(hDlg, IDC_SIDEALL, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_SIDEBACK, BST_UNCHECKED);
				CheckDlgButton(hDlg, IDC_SIDENONE, BST_CHECKED);
			}
			else
			{
				stParDocHandle.Sorter_Eject = SORTER_BAY1;
				EnableWindow(GetDlgItem(hDlg, IDC_SIDEALL), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_SIDEFRONT), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_SIDEBACK), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_SIDENONE), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_FRONTSTAMP), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_PRINT_ENDORSE), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_ENDORSEMENT_STR), TRUE);
			}
			break;
		case IDOK:
			SorterReadSelection( hDlg );
			EndDialog(hDlg, 1);
			break;
		}
		return TRUE;
	}

    return FALSE;
}	// DlgProcSorter



//void SetObjOpticParameterMainOcr100
//
//
void SetObjOpticParameterMainOcr100(HWND hDlg)
{
	char str[16];

	if(stParDocHandle.Unit_measure == UNIT_MM)
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Codeline_Sw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Codeline_Sw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Codeline_Sw_w,TRUE);
	}
	else 
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_INC);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_w);
		SetDlgItemText(hDlg, IDC_W, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_x);
		SetDlgItemText(hDlg, IDC_X, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_y);
		SetDlgItemText(hDlg, IDC_Y, str);

	}
	sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_h);
	SetDlgItemText(hDlg, IDC_H, str);

	switch( stParDocHandle.CodelineOptType )
		{
		case READ_CODELINE_SW_OCRA:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRA);
			break;
		case READ_CODELINE_SW_OCRB_NUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB);
			break;
		case READ_CODELINE_SW_OCRB_ALFANUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB_ALPHA);
			break;
		case READ_CODELINE_SW_E13B:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13B);
			break;
		case READ_CODELINE_SW_E13B_X_OCRB:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13BOPT);
			break;
		case READ_CODELINE_SW_MULTI_READ:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_MUTILREAD);
			break;
		}
} // SetObjOpticParameterMainOcr100



//void SetObjOpticParameterMainBarcode
//
//
void SetObjOpticParameterMainBarcode(HWND hDlg)
{
	char str[16];

	if(stParDocHandle.Barcode_Unit_measure == UNIT_MM)
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Barcode_Sw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Barcode_Sw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Barcode_Sw_w,TRUE);
	}
	else 
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_INC);
		sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_w);
		SetDlgItemText(hDlg, IDC_W, str);
		sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_x);
		SetDlgItemText(hDlg, IDC_X, str);
		sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_y);
		SetDlgItemText(hDlg, IDC_Y, str);

	}
	sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_h);
	SetDlgItemText(hDlg, IDC_H, str);

	switch( stParDocHandle.Barcodetype )
	{
	case READ_BARCODE_2_OF_5:
		SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_BARCODE_2_OF_5);
		break;
	}

} // SetObjOpticParameterMainBarcode




BOOL CALLBACK DlgProcDecoSwParBarcode(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	char str[10];
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	HWND hCombo;
	int CurrItem;


	switch( msg )
	{
		case WM_INITDIALOG:
			SetWindowText(hDlg, "Parametrer for Barcode Window");
			
			if(stParDocHandle.Barcode_Unit_measure == UNIT_MM)
			{
				SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Barcode_Sw_x,TRUE);
				SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Barcode_Sw_y,TRUE);
				SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Barcode_Sw_w,TRUE);
				SetDlgItemInt(hDlg,IDC_H,(int)stParDocHandle.Barcode_Sw_h,TRUE);
				CheckDlgButton(hDlg,IDC_UNIT_MM,TRUE);
			}
			else
			{
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_w);
				SetDlgItemText(hDlg, IDC_W, str);
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_x);
				SetDlgItemText(hDlg, IDC_X, str);
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_y);
				SetDlgItemText(hDlg, IDC_Y, str);
			}

			EnableWindow(GetDlgItem(hDlg, IDC_UNIT_INC), FALSE);
			CheckDlgButton(hDlg,IDC_UNIT_MM,TRUE);

			//set barcode type
			hCombo = GetDlgItem(hDlg, IDC_COMBOPTICAL);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)"Barcode 2 of 5");
			switch( stParDocHandle.Barcodetype )
			{
			case READ_BARCODE_2_OF_5:
				CurrItem = 0;
				break;
			default:
				CurrItem = 1;
				break;
			}
			SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);
			
			return TRUE;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
			
			case IDC_UNIT_INC:
				// if not seleted
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_INC) == BST_CHECKED)
					SetButtonInc(hDlg);
				break;

			case IDC_UNIT_MM:
				// if not selected
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_MM) == BST_CHECKED)
					SetButtonMM(hDlg);
				break;

			case IDOK:
				// read the codeline type

				if( IsDlgButtonChecked(hDlg, IDC_UNIT_MM) == BST_CHECKED )
					stParDocHandle.Barcode_Unit_measure = UNIT_MM;
				else if( IsDlgButtonChecked(hDlg, IDC_UNIT_INC) == BST_CHECKED )
					stParDocHandle.Barcode_Unit_measure = UNIT_INCH;
			
				// Reads the coordinate
				if( stParDocHandle.Barcode_Unit_measure == UNIT_MM)
				{
					stParDocHandle.Barcode_Sw_x = (float)GetDlgItemInt(hDlg, IDC_X, NULL, FALSE);
					stParDocHandle.Barcode_Sw_y = (float)GetDlgItemInt(hDlg, IDC_Y, NULL, FALSE);
					stParDocHandle.Barcode_Sw_w = (float)GetDlgItemInt(hDlg, IDC_W, NULL, FALSE);
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));
					stParDocHandle.Barcode_Sw_h = (float)atof(Sw_h);
				}
				else 
				{
					GetDlgItemText(hDlg, IDC_X, Sw_x, sizeof(Sw_x));
					GetDlgItemText(hDlg, IDC_Y, Sw_y, sizeof(Sw_y));
					GetDlgItemText(hDlg, IDC_W, Sw_w, sizeof(Sw_w));
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));

					stParDocHandle.Barcode_Sw_x = (float)atof(Sw_x);
					stParDocHandle.Barcode_Sw_y = (float)atof(Sw_y);
					stParDocHandle.Barcode_Sw_w = (float)atof(Sw_w);
					stParDocHandle.Barcode_Sw_h = (float)atof(Sw_h);
				}
				EndDialog(hDlg, IDOK);
				return TRUE;
			return TRUE;
			}
	}

	return FALSE;
} // DlgProcDecoSwParBarcode


//***************************************************************************
// FUNCTION  : DlgProcSetStrings
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
BOOL CALLBACK DlgProcSetStrings(HWND hDlg, UINT message, UINT wParam, LONG lParam)
{

	switch( message )
	{
	case WM_INITDIALOG:

		SetDlgItemInt(hDlg, IDC_OFFSET_1, stParDocHandle.Invalidation_Offset1, FALSE);
		SetDlgItemInt(hDlg, IDC_OFFSET_2, stParDocHandle.Invalidation_Offset2, FALSE);
		SetDlgItemInt(hDlg, IDC_OFFSET_3, stParDocHandle.Invalidation_Offset3, FALSE);
		SetDlgItemText(hDlg, IDC_STRING_1, stParDocHandle.Invalidation_str1);
		SetDlgItemText(hDlg, IDC_STRING_2, stParDocHandle.Invalidation_str2);
		SetDlgItemText(hDlg, IDC_STRING_3, stParDocHandle.Invalidation_str3);

		return TRUE;


	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDOK:

			stParDocHandle.Invalidation_Offset1 = GetDlgItemInt(hDlg, IDC_OFFSET_1, NULL, FALSE);
			stParDocHandle.Invalidation_Offset2 = GetDlgItemInt(hDlg, IDC_OFFSET_2, NULL, FALSE);
			stParDocHandle.Invalidation_Offset3 = GetDlgItemInt(hDlg, IDC_OFFSET_3, NULL, FALSE);

			GetDlgItemText(hDlg, IDC_STRING_1, stParDocHandle.Invalidation_str1, sizeof(stParDocHandle.Invalidation_str1));
			GetDlgItemText(hDlg, IDC_STRING_2, stParDocHandle.Invalidation_str2, sizeof(stParDocHandle.Invalidation_str2));
			GetDlgItemText(hDlg, IDC_STRING_3, stParDocHandle.Invalidation_str3, sizeof(stParDocHandle.Invalidation_str3));

			EndDialog(hDlg, TRUE);
			return TRUE;


		case IDCANCEL:
			EndDialog (hDlg, FALSE);
			return TRUE;
		}
	} // End switch

	return FALSE;
} // DlgProcSetStrings


//***************************************************************************
// FUNCTION  : DlgProcSetString
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
BOOL CALLBACK DlgProcSetString(HWND hDlg, UINT message, UINT wParam, LONG lParam)
{

	switch( message )
	{
	case WM_INITDIALOG:

		SetDlgItemText(hDlg, IDC_STRING_1, stParDocHandle.Endorse_str);

		return TRUE;


	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDOK:

			GetDlgItemText(hDlg, IDC_STRING_1, stParDocHandle.Endorse_str, sizeof(stParDocHandle.Endorse_str));

			EndDialog(hDlg, TRUE);
			return TRUE;


		case IDCANCEL:
			EndDialog (hDlg, FALSE);
			return TRUE;
		}
	} // End switch

	return FALSE;
} // DlgProcSetString


//***************************************************************************
// FUNCTION  : DlgProcSetStringForRet
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
BOOL CALLBACK DlgProcSetStringForRet(HWND hDlg, UINT message, UINT wParam, LONG lParam)
{

	switch( message )
	{
	case WM_INITDIALOG:

		SetDlgItemText(hDlg, IDC_STRING_1, stParDocHandle.Sorter_Endorse_str);

		return TRUE;


	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDOK:

			GetDlgItemText(hDlg, IDC_STRING_1, stParDocHandle.Sorter_Endorse_str, sizeof(stParDocHandle.Sorter_Endorse_str));

			EndDialog(hDlg, TRUE);
			return TRUE;


		case IDCANCEL:
			EndDialog (hDlg, FALSE);
			return TRUE;
		}
	} // End switch

	return FALSE;
} // DlgProcSetStringForRet


BOOL CALLBACK DlgProcDecoSwParOCRHw(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HWND hCombo;
	int CurrItem;
	char str[10];
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	
	
	switch( msg )
	{
		case WM_INITDIALOG:
			SetWindowText(hDlg, "Parametrer for Ocr Hw Window");

			hCombo = GetDlgItem(hDlg, IDC_COMBOPTICAL);		
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_MUTILREAD);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_OCRA);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_OCRB);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_OCRB_ALPHA);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_E13B);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_E13BOPT);

			EnableWindow(GetDlgItem(hDlg, IDC_H), FALSE);

			if(stParDocHandle.Codeline_Hw_Unit_measure == UNIT_MM)
			{
				SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Codeline_Hw_x,TRUE);
				SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Codeline_Hw_y,TRUE);
				SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Codeline_Hw_w,TRUE);
				CheckDlgButton(hDlg,IDC_UNIT_MM,TRUE);
			}
			else
			{
				sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_w);
				SetDlgItemText(hDlg, IDC_W, str);
				sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_x);
				SetDlgItemText(hDlg, IDC_X, str);
				sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_y);
				SetDlgItemText(hDlg, IDC_Y, str);
				CheckDlgButton(hDlg,IDC_UNIT_INC,TRUE);
			}
			sprintf(str, "%.2f", OCR_VALUE_IN_MM);
			SetDlgItemText(hDlg, IDC_H, str);
			switch( stParDocHandle.Codeline_Hw_Type )
			{
			case READ_CODELINE_SW_OCRA:
				CurrItem = 1;
				break;
			case READ_CODELINE_SW_OCRB_NUM:
				CurrItem = 2;
				break;
			case READ_CODELINE_SW_OCRB_ALFANUM:
				CurrItem = 3;
				break;
			case READ_CODELINE_SW_E13B:
				CurrItem = 4;
				break;
			case READ_CODELINE_SW_E13B_X_OCRB:
				CurrItem = 5;
				break;
			case READ_CODELINE_SW_MULTI_READ:
				CurrItem = 0;
				break;
			default:
				CurrItem = 2;
				break;
			}

			SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);
		return TRUE;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
			case IDC_UNIT_INC:
				// if not selected
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_INC) == BST_CHECKED)
				{
					SetButtonInc(hDlg);
				}
				break;

			case IDC_UNIT_MM:
				// if not selected
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_MM) == BST_CHECKED)
				{
					SetButtonMM(hDlg);
				}
				break;

			case IDOK:
				// find out which is the codeline choosen
				CurrItem = SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_GETCURSEL, 0, 0);
				switch( CurrItem )
				{
				case 0:
					stParDocHandle.Codeline_Hw_Type = READ_CODELINE_SW_MULTI_READ;
					break;
				case 1:
					stParDocHandle.Codeline_Hw_Type = READ_CODELINE_SW_OCRA;
					break;
				case 2:
					stParDocHandle.Codeline_Hw_Type = READ_CODELINE_SW_OCRB_NUM;
					break;
				case 3:
					stParDocHandle.Codeline_Hw_Type = READ_CODELINE_SW_OCRB_ALFANUM;
					break;
				case 4:
					stParDocHandle.Codeline_Hw_Type = READ_CODELINE_SW_E13B;
					break;
				case 5:
					stParDocHandle.Codeline_Hw_Type = READ_CODELINE_SW_E13B_X_OCRB;
					break;
				}
				if( IsDlgButtonChecked(hDlg, IDC_UNIT_MM) == BST_CHECKED )
					stParDocHandle.Codeline_Hw_Unit_measure = UNIT_MM;
				else if( IsDlgButtonChecked(hDlg, IDC_UNIT_INC) == BST_CHECKED )
					stParDocHandle.Codeline_Hw_Unit_measure = UNIT_INCH;

				// Reads the coordinate
				if( stParDocHandle.Codeline_Hw_Unit_measure == UNIT_MM)
				{
					GetDlgItemText(hDlg,IDC_X,str,8);
					if (str[0] =='-')
						stParDocHandle.Codeline_Hw_x = 0 - (float)atoi(&str[1]);
					else
						stParDocHandle.Codeline_Hw_x = (float)GetDlgItemInt(hDlg, IDC_X, NULL, FALSE);

					stParDocHandle.Codeline_Hw_y = (float)GetDlgItemInt(hDlg, IDC_Y, NULL, FALSE);
					GetDlgItemText(hDlg,IDC_W,str,8);
					if (str[0] =='-')
						stParDocHandle.Codeline_Sw_w = 0 - (float)atoi(&str[1]);
					else
						stParDocHandle.Codeline_Hw_w = (float)GetDlgItemInt(hDlg, IDC_W, NULL, FALSE);
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));
					stParDocHandle.Codeline_Hw_h = (float)atof(Sw_h);
				}
				else 
				{
					GetDlgItemText(hDlg, IDC_X, Sw_x, sizeof(Sw_x));
					GetDlgItemText(hDlg, IDC_Y, Sw_y, sizeof(Sw_y));
					GetDlgItemText(hDlg, IDC_W, Sw_w, sizeof(Sw_w));
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));

					stParDocHandle.Codeline_Hw_x = (float)atof(Sw_x);
					stParDocHandle.Codeline_Hw_y = (float)atof(Sw_y);
					stParDocHandle.Codeline_Hw_w = (float)atof(Sw_w);
					stParDocHandle.Codeline_Hw_h = (float)atof(Sw_h);
				}
				
				EndDialog(hDlg, IDOK);

				return TRUE;
		}
		return TRUE;	
	}

	return FALSE;
} // DlgProcDecoSwParOCRHw
