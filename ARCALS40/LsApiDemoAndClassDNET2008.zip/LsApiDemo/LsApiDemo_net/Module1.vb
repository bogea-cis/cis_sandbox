Module Module1

    'Modulo per variabili globali
    'Public LsDefines As LsFamily.LsDefines
    Public cApplFunc As ApplClass

    ' Peripheral choose
    Public LsUnitType As Integer = 0
    Public ImagePath As String
    Public ScanMode_Card As Int16
    Public fAutoFeed As Boolean
    Public fstop As Boolean = False
    Public NrDocToProcess As Short  'Nr documenti da processare con AutoDocHandle()
    Public CurrPocket As LsFamily.LsDefines.Sorter = LsFamily.LsDefines.Sorter.SORTER_POCKET_1
    Public NrTot_Pocket As Short
    Public fReceipt As Integer




End Module
