﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistory150
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.IDC_TOT_TIME = New System.Windows.Forms.Label
        Me.IDC_DOC_STAMPED = New System.Windows.Forms.Label
        Me.IDC_DOC_PRINTED = New System.Windows.Forms.Label
        Me.IDC_POWER_ON = New System.Windows.Forms.Label
        Me.IDC_ERR_E13B = New System.Windows.Forms.Label
        Me.IDC_ERR_CMC7 = New System.Windows.Forms.Label
        Me.IDC_RETAINED_DOC = New System.Windows.Forms.Label
        Me.IDC_JAM_SCANNER = New System.Windows.Forms.Label
        Me.IDC_JAM_MICR = New System.Windows.Forms.Label
        Me.IDC_JAM_CARD = New System.Windows.Forms.Label
        Me.IDC_DOC_PROCESSED = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(129, 312)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 24)
        Me.Button1.TabIndex = 68
        Me.Button1.Text = "Ok"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'IDC_TOT_TIME
        '
        Me.IDC_TOT_TIME.AutoSize = True
        Me.IDC_TOT_TIME.Location = New System.Drawing.Point(242, 272)
        Me.IDC_TOT_TIME.Name = "IDC_TOT_TIME"
        Me.IDC_TOT_TIME.Size = New System.Drawing.Size(67, 13)
        Me.IDC_TOT_TIME.TabIndex = 67
        Me.IDC_TOT_TIME.Text = "0000000000"
        '
        'IDC_DOC_STAMPED
        '
        Me.IDC_DOC_STAMPED.AutoSize = True
        Me.IDC_DOC_STAMPED.Location = New System.Drawing.Point(261, 229)
        Me.IDC_DOC_STAMPED.Name = "IDC_DOC_STAMPED"
        Me.IDC_DOC_STAMPED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_STAMPED.TabIndex = 66
        Me.IDC_DOC_STAMPED.Text = "0000000000"
        '
        'IDC_DOC_PRINTED
        '
        Me.IDC_DOC_PRINTED.AutoSize = True
        Me.IDC_DOC_PRINTED.Location = New System.Drawing.Point(261, 203)
        Me.IDC_DOC_PRINTED.Name = "IDC_DOC_PRINTED"
        Me.IDC_DOC_PRINTED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PRINTED.TabIndex = 65
        Me.IDC_DOC_PRINTED.Text = "0000000000"
        '
        'IDC_POWER_ON
        '
        Me.IDC_POWER_ON.AutoSize = True
        Me.IDC_POWER_ON.Location = New System.Drawing.Point(261, 180)
        Me.IDC_POWER_ON.Name = "IDC_POWER_ON"
        Me.IDC_POWER_ON.Size = New System.Drawing.Size(67, 13)
        Me.IDC_POWER_ON.TabIndex = 64
        Me.IDC_POWER_ON.Text = "0000000000"
        '
        'IDC_ERR_E13B
        '
        Me.IDC_ERR_E13B.AutoSize = True
        Me.IDC_ERR_E13B.Location = New System.Drawing.Point(261, 155)
        Me.IDC_ERR_E13B.Name = "IDC_ERR_E13B"
        Me.IDC_ERR_E13B.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_E13B.TabIndex = 63
        Me.IDC_ERR_E13B.Text = "0000000000"
        '
        'IDC_ERR_CMC7
        '
        Me.IDC_ERR_CMC7.AutoSize = True
        Me.IDC_ERR_CMC7.Location = New System.Drawing.Point(261, 129)
        Me.IDC_ERR_CMC7.Name = "IDC_ERR_CMC7"
        Me.IDC_ERR_CMC7.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_CMC7.TabIndex = 62
        Me.IDC_ERR_CMC7.Text = "0000000000"
        '
        'IDC_RETAINED_DOC
        '
        Me.IDC_RETAINED_DOC.AutoSize = True
        Me.IDC_RETAINED_DOC.Location = New System.Drawing.Point(261, 104)
        Me.IDC_RETAINED_DOC.Name = "IDC_RETAINED_DOC"
        Me.IDC_RETAINED_DOC.Size = New System.Drawing.Size(67, 13)
        Me.IDC_RETAINED_DOC.TabIndex = 61
        Me.IDC_RETAINED_DOC.Text = "0000000000"
        '
        'IDC_JAM_SCANNER
        '
        Me.IDC_JAM_SCANNER.AutoSize = True
        Me.IDC_JAM_SCANNER.Location = New System.Drawing.Point(261, 81)
        Me.IDC_JAM_SCANNER.Name = "IDC_JAM_SCANNER"
        Me.IDC_JAM_SCANNER.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_SCANNER.TabIndex = 60
        Me.IDC_JAM_SCANNER.Text = "0000000000"
        '
        'IDC_JAM_MICR
        '
        Me.IDC_JAM_MICR.AutoSize = True
        Me.IDC_JAM_MICR.Location = New System.Drawing.Point(261, 57)
        Me.IDC_JAM_MICR.Name = "IDC_JAM_MICR"
        Me.IDC_JAM_MICR.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_MICR.TabIndex = 59
        Me.IDC_JAM_MICR.Text = "0000000000"
        '
        'IDC_JAM_CARD
        '
        Me.IDC_JAM_CARD.AutoSize = True
        Me.IDC_JAM_CARD.Location = New System.Drawing.Point(261, 33)
        Me.IDC_JAM_CARD.Name = "IDC_JAM_CARD"
        Me.IDC_JAM_CARD.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_CARD.TabIndex = 58
        Me.IDC_JAM_CARD.Text = "0000000000"
        '
        'IDC_DOC_PROCESSED
        '
        Me.IDC_DOC_PROCESSED.AutoSize = True
        Me.IDC_DOC_PROCESSED.Location = New System.Drawing.Point(261, 9)
        Me.IDC_DOC_PROCESSED.Name = "IDC_DOC_PROCESSED"
        Me.IDC_DOC_PROCESSED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PROCESSED.TabIndex = 57
        Me.IDC_DOC_PROCESSED.Text = "0000000000"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(43, 272)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(180, 13)
        Me.Label11.TabIndex = 56
        Me.Label11.Text = "Total time of work (hh:mm:ss) ..........."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 229)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(194, 13)
        Me.Label10.TabIndex = 55
        Me.Label10.Text = "Nr. of documents stamped ...................."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 203)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(195, 13)
        Me.Label9.TabIndex = 54
        Me.Label9.Text = "Nr. of documents printed ......................."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 180)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(196, 13)
        Me.Label8.TabIndex = 53
        Me.Label8.Text = "Nr. of power ON of the peripheral .........."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 155)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(194, 13)
        Me.Label7.TabIndex = 52
        Me.Label7.Text = "Nr. error in read E13B codeline ............."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 129)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(194, 13)
        Me.Label6.TabIndex = 51
        Me.Label6.Text = "Nr. error in read CMC7 codeline ............"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(195, 13)
        Me.Label5.TabIndex = 50
        Me.Label5.Text = "Nr. documents retained ........................."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(197, 13)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "Nr. jammed at the scanner photo ..........."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(197, 13)
        Me.Label3.TabIndex = 48
        Me.Label3.Text = "Nr. jammed in the read MICR photo ......."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(199, 13)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "Nr. jammed in card entry ........................."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 13)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Nr. documents processed succefully ....."
        '
        'frmHistory150
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 345)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.IDC_TOT_TIME)
        Me.Controls.Add(Me.IDC_DOC_STAMPED)
        Me.Controls.Add(Me.IDC_DOC_PRINTED)
        Me.Controls.Add(Me.IDC_POWER_ON)
        Me.Controls.Add(Me.IDC_ERR_E13B)
        Me.Controls.Add(Me.IDC_ERR_CMC7)
        Me.Controls.Add(Me.IDC_RETAINED_DOC)
        Me.Controls.Add(Me.IDC_JAM_SCANNER)
        Me.Controls.Add(Me.IDC_JAM_MICR)
        Me.Controls.Add(Me.IDC_JAM_CARD)
        Me.Controls.Add(Me.IDC_DOC_PROCESSED)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmHistory150"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "History150"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents IDC_TOT_TIME As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_STAMPED As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PRINTED As System.Windows.Forms.Label
    Friend WithEvents IDC_POWER_ON As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_E13B As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_CMC7 As System.Windows.Forms.Label
    Friend WithEvents IDC_RETAINED_DOC As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_SCANNER As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_MICR As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_CARD As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PROCESSED As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
