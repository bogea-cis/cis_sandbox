Public Class formBadge
    Inherits System.Windows.Forms.Form


#Region " Codice generato da Progettazione Windows Form "

    Public Sub New()
        MyBase.New()

        'Chiamata richiesta da Progettazione Windows Form.
        InitializeComponent()

        'Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent()

    End Sub

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue � richiesta da Progettazione Windows Form.
    'Pu� essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cbTrack1 As System.Windows.Forms.CheckBox
    Friend WithEvents cbTrack2 As System.Windows.Forms.CheckBox
    Friend WithEvents cbTrack3 As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lbTrack1 As System.Windows.Forms.Label
    Friend WithEvents lbTrack2 As System.Windows.Forms.Label
    Friend WithEvents lbTrack3 As System.Windows.Forms.Label
    Friend WithEvents btBadgeRead As System.Windows.Forms.Button
    Friend WithEvents btBadgeExit As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbTimeout As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cbTrack3 = New System.Windows.Forms.CheckBox
        Me.cbTrack2 = New System.Windows.Forms.CheckBox
        Me.cbTrack1 = New System.Windows.Forms.CheckBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lbTrack1 = New System.Windows.Forms.Label
        Me.lbTrack2 = New System.Windows.Forms.Label
        Me.lbTrack3 = New System.Windows.Forms.Label
        Me.btBadgeRead = New System.Windows.Forms.Button
        Me.btBadgeExit = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.tbTimeout = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tbTimeout)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cbTrack3)
        Me.GroupBox1.Controls.Add(Me.cbTrack2)
        Me.GroupBox1.Controls.Add(Me.cbTrack1)
        Me.GroupBox1.Location = New System.Drawing.Point(48, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(632, 64)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Tracks to Read"
        '
        'cbTrack3
        '
        Me.cbTrack3.Location = New System.Drawing.Point(296, 32)
        Me.cbTrack3.Name = "cbTrack3"
        Me.cbTrack3.Size = New System.Drawing.Size(80, 24)
        Me.cbTrack3.TabIndex = 2
        Me.cbTrack3.Text = "Track 3"
        '
        'cbTrack2
        '
        Me.cbTrack2.Location = New System.Drawing.Point(168, 32)
        Me.cbTrack2.Name = "cbTrack2"
        Me.cbTrack2.Size = New System.Drawing.Size(80, 24)
        Me.cbTrack2.TabIndex = 1
        Me.cbTrack2.Text = "Track 2"
        '
        'cbTrack1
        '
        Me.cbTrack1.Location = New System.Drawing.Point(48, 32)
        Me.cbTrack1.Name = "cbTrack1"
        Me.cbTrack1.Size = New System.Drawing.Size(80, 24)
        Me.cbTrack1.TabIndex = 0
        Me.cbTrack1.Text = "Track 1"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Track 1 :"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 176)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Track 2 :"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 23)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Track 3 :"
        '
        'lbTrack1
        '
        Me.lbTrack1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbTrack1.Location = New System.Drawing.Point(80, 128)
        Me.lbTrack1.Name = "lbTrack1"
        Me.lbTrack1.Size = New System.Drawing.Size(600, 23)
        Me.lbTrack1.TabIndex = 4
        '
        'lbTrack2
        '
        Me.lbTrack2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbTrack2.Location = New System.Drawing.Point(80, 176)
        Me.lbTrack2.Name = "lbTrack2"
        Me.lbTrack2.Size = New System.Drawing.Size(600, 23)
        Me.lbTrack2.TabIndex = 5
        '
        'lbTrack3
        '
        Me.lbTrack3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbTrack3.Location = New System.Drawing.Point(80, 224)
        Me.lbTrack3.Name = "lbTrack3"
        Me.lbTrack3.Size = New System.Drawing.Size(600, 56)
        Me.lbTrack3.TabIndex = 6
        '
        'btBadgeRead
        '
        Me.btBadgeRead.Location = New System.Drawing.Point(211, 320)
        Me.btBadgeRead.Name = "btBadgeRead"
        Me.btBadgeRead.TabIndex = 7
        Me.btBadgeRead.Text = "&Read"
        '
        'btBadgeExit
        '
        Me.btBadgeExit.Location = New System.Drawing.Point(443, 320)
        Me.btBadgeExit.Name = "btBadgeExit"
        Me.btBadgeExit.TabIndex = 9
        Me.btBadgeExit.Text = "E&xit"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(448, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 23)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Timeout (ms.) :"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbTimeout
        '
        Me.tbTimeout.Location = New System.Drawing.Point(552, 32)
        Me.tbTimeout.Name = "tbTimeout"
        Me.tbTimeout.Size = New System.Drawing.Size(64, 22)
        Me.tbTimeout.TabIndex = 4
        Me.tbTimeout.Text = "4000"
        '
        'formBadge
        '
        Me.AcceptButton = Me.btBadgeRead
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(728, 360)
        Me.Controls.Add(Me.btBadgeExit)
        Me.Controls.Add(Me.btBadgeRead)
        Me.Controls.Add(Me.lbTrack3)
        Me.Controls.Add(Me.lbTrack2)
        Me.Controls.Add(Me.lbTrack1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "formBadge"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Read Badge"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub formBadge_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' Tracks
        Select Case cApplFunc.Badge_Tracks
            Case LsFamily.LsDefines.Badge.BADGE_READ_TRACK_1
                cbTrack1.Checked = True
            Case LsFamily.LsDefines.Badge.BADGE_READ_TRACK_2
                cbTrack2.Checked = True
            Case LsFamily.LsDefines.Badge.BADGE_READ_TRACK_3
                cbTrack3.Checked = True
            Case LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2
                cbTrack1.Checked = True
                cbTrack2.Checked = True
            Case LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_2_3
                cbTrack2.Checked = True
                cbTrack3.Checked = True
            Case LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2_3
                cbTrack1.Checked = True
                cbTrack2.Checked = True
                cbTrack3.Checked = True
        End Select

        ' Timeout
        tbTimeout.Text = cApplFunc.Badge_Timeout.ToString

    End Sub

    Private Sub formBadge_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed

        Me.Close()
    End Sub

    Private Function ReadBadge(ByVal TracksToRead As Int16, ByRef TracksReads As String, ByRef CharReads As Int16) As Int32
        Dim Ls As LsFamily.LsApi = New LsFamily.LsApi
        Dim hLs As Int16
        Dim rc As Int32

        rc = Ls.LSConnect(0, LsUnitType, hLs, False)
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReadBadgeWithTimeout(hLs, 0, TracksToRead, cApplFunc.Badge_Timeout, TracksReads)
            Ls.LSDisconnect(hLs, 0)
        End If

        Return rc
    End Function

    Private Sub btBadgeRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btBadgeRead.Click
        Dim rc As Int32
        Dim ii As Int16
        Dim nextTrack As Int16
        Dim BuffTracks As String = New String(Chr(0), 256)
        Dim CharReads As Int16
        '        Dim BuffShow As String

        btBadgeRead.Enabled = False
        btBadgeExit.Enabled = False
        lbTrack1.Text = ""
        lbTrack2.Text = ""
        lbTrack3.Text = ""

        ' Badge Tracks
        If (cbTrack1.Checked = True And cbTrack2.Checked = True And cbTrack3.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2_3
        ElseIf (cbTrack2.Checked = True And cbTrack3.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_2_3
        ElseIf (cbTrack1.Checked = True And cbTrack2.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2
        ElseIf (cbTrack1.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_1
        ElseIf (cbTrack2.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_2
        ElseIf (cbTrack3.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_3
        Else ' default 2 e 3
            MessageBox.Show("Select least one track", Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        ' Timeout
        Try
            cApplFunc.Badge_Timeout = Convert.ToUInt32(tbTimeout.Text)
        Catch ex As OverflowException
            Console.WriteLine("{0} is outside the range of the Int32 type.", tbTimeout.Text)
        Catch ex As FormatException
            Console.WriteLine("The {0} value '{1}' is not in a recognizable format.", _
                              tbTimeout.Text.GetType().Name, tbTimeout.Text)
        End Try


        rc = ReadBadge(cApplFunc.Badge_Tracks, BuffTracks, CharReads)
        If (rc = LsFamily.LsReply.LS_OKAY) Then

            If (cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_1) Then
                lbTrack1.Text = BuffTracks
            End If
            If (cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_2) Then
                lbTrack2.Text = BuffTracks
            End If
            If (cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_3) Then
                lbTrack3.Text = BuffTracks
            End If
            If (cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2) Then
                For ii = 0 To BuffTracks.Length - 1
                    If (ii And BuffTracks.Chars(ii) = Chr(116)) Then
                        nextTrack += 1
                    End If

                    If (nextTrack = 0) Then
                        lbTrack1.Text += BuffTracks.Chars(ii)
                    Else
                        lbTrack2.Text += BuffTracks.Chars(ii)
                    End If
                Next
            End If
            If (cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_2_3) Then
                For ii = 0 To BuffTracks.Length - 1
                    If (ii And BuffTracks.Chars(ii) = Chr(116)) Then
                        nextTrack += 1
                    End If

                    If (nextTrack = 0) Then
                        lbTrack2.Text += BuffTracks.Chars(ii)
                    Else
                        lbTrack3.Text += BuffTracks.Chars(ii)
                    End If
                Next
            End If
            If (cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2_3) Then
                For ii = 0 To BuffTracks.Length - 1
                    If (ii And BuffTracks.Chars(ii) = Chr(116)) Then
                        nextTrack += 1
                    End If

                    If (nextTrack = 0) Then
                        lbTrack1.Text += BuffTracks.Chars(ii)
                    ElseIf (nextTrack = 1) Then
                        lbTrack2.Text += BuffTracks.Chars(ii)
                    Else
                        lbTrack3.Text += BuffTracks.Chars(ii)
                    End If
                Next
            End If
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "Read Badge"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        btBadgeRead.Enabled = True
        btBadgeExit.Enabled = True

    End Sub

    Private Sub btBadgeExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btBadgeExit.Click

        ' Badge Tracks
        If (cbTrack1.Checked = True And cbTrack2.Checked = True And cbTrack3.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2_3
        ElseIf (cbTrack2.Checked = True And cbTrack3.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_2_3
        ElseIf (cbTrack1.Checked = True And cbTrack2.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_1_2
        ElseIf (cbTrack1.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_1
        ElseIf (cbTrack2.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_2
        ElseIf (cbTrack3.Checked = True) Then
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACK_3
        Else ' default 2 e 3
            cApplFunc.Badge_Tracks = LsFamily.LsDefines.Badge.BADGE_READ_TRACKS_2_3
        End If

        ' Timeout
        cApplFunc.Badge_Timeout = Convert.ToUInt32(tbTimeout.Text)

        Me.Close()
    End Sub
End Class
