﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCtsMonitor
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox
        Me.LPerif = New System.Windows.Forms.Label
        Me.cmdResult = New System.Windows.Forms.Button
        Me.cmdMonitor = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'richTextBox1
        '
        Me.richTextBox1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.richTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.richTextBox1.Location = New System.Drawing.Point(0, 62)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.ReadOnly = True
        Me.richTextBox1.Size = New System.Drawing.Size(681, 407)
        Me.richTextBox1.TabIndex = 3
        Me.richTextBox1.Text = ""
        '
        'LPerif
        '
        Me.LPerif.AutoSize = True
        Me.LPerif.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LPerif.Location = New System.Drawing.Point(372, 18)
        Me.LPerif.Name = "LPerif"
        Me.LPerif.Size = New System.Drawing.Size(50, 24)
        Me.LPerif.TabIndex = 7
        Me.LPerif.Text = "CTS"
        '
        'cmdResult
        '
        Me.cmdResult.Location = New System.Drawing.Point(22, 9)
        Me.cmdResult.Name = "cmdResult"
        Me.cmdResult.Size = New System.Drawing.Size(112, 33)
        Me.cmdResult.TabIndex = 8
        Me.cmdResult.Text = "&Clear Monitor Now"
        Me.cmdResult.UseVisualStyleBackColor = True
        '
        'cmdMonitor
        '
        Me.cmdMonitor.Location = New System.Drawing.Point(155, 9)
        Me.cmdMonitor.Name = "cmdMonitor"
        Me.cmdMonitor.Size = New System.Drawing.Size(112, 33)
        Me.cmdMonitor.TabIndex = 9
        Me.cmdMonitor.Text = "&Monitor Now"
        Me.cmdMonitor.UseVisualStyleBackColor = True
        '
        'frmCtsMonitor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(681, 469)
        Me.Controls.Add(Me.cmdMonitor)
        Me.Controls.Add(Me.cmdResult)
        Me.Controls.Add(Me.LPerif)
        Me.Controls.Add(Me.richTextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmCtsMonitor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CtsMonitor"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents richTextBox1 As System.Windows.Forms.RichTextBox
    Private WithEvents LPerif As System.Windows.Forms.Label
    Friend WithEvents cmdResult As System.Windows.Forms.Button
    Friend WithEvents cmdMonitor As System.Windows.Forms.Button
End Class
