﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formAbout
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formAbout))
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lAbout7 = New System.Windows.Forms.Label
        Me.llCtsSito = New System.Windows.Forms.LinkLabel
        Me.lAbout6 = New System.Windows.Forms.Label
        Me.lAbout4 = New System.Windows.Forms.Label
        Me.lAbout3 = New System.Windows.Forms.Label
        Me.lAbout2 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 202)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(195, 13)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "For sales :      sales@ctsgroup.it"
        Me.Label3.Visible = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 182)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(195, 13)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "For support :  techsupp@ctsgroup.it"
        Me.Label2.Visible = False
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 156)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 19)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Tel. +39 0125 235611"
        Me.Label1.Visible = False
        '
        'lAbout7
        '
        Me.lAbout7.Location = New System.Drawing.Point(186, 107)
        Me.lAbout7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lAbout7.Name = "lAbout7"
        Me.lAbout7.Size = New System.Drawing.Size(90, 19)
        Me.lAbout7.TabIndex = 29
        Me.lAbout7.Text = "Visit our Web Site :"
        Me.lAbout7.Visible = False
        '
        'llCtsSito
        '
        Me.llCtsSito.BackColor = System.Drawing.Color.Transparent
        Me.llCtsSito.ForeColor = System.Drawing.Color.Transparent
        Me.llCtsSito.Location = New System.Drawing.Point(639, 432)
        Me.llCtsSito.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.llCtsSito.Name = "llCtsSito"
        Me.llCtsSito.Size = New System.Drawing.Size(88, 19)
        Me.llCtsSito.TabIndex = 28
        Me.llCtsSito.TabStop = True
        Me.llCtsSito.Text = "www.ctsgroup.it"
        '
        'lAbout6
        '
        Me.lAbout6.Location = New System.Drawing.Point(24, 107)
        Me.lAbout6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lAbout6.Name = "lAbout6"
        Me.lAbout6.Size = New System.Drawing.Size(54, 16)
        Me.lAbout6.TabIndex = 27
        Me.lAbout6.Text = "ITALY"
        Me.lAbout6.Visible = False
        '
        'lAbout4
        '
        Me.lAbout4.Location = New System.Drawing.Point(24, 88)
        Me.lAbout4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lAbout4.Name = "lAbout4"
        Me.lAbout4.Size = New System.Drawing.Size(96, 13)
        Me.lAbout4.TabIndex = 26
        Me.lAbout4.Text = "10015      Ivrea (TO)"
        Me.lAbout4.Visible = False
        '
        'lAbout3
        '
        Me.lAbout3.Location = New System.Drawing.Point(24, 68)
        Me.lAbout3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lAbout3.Name = "lAbout3"
        Me.lAbout3.Size = New System.Drawing.Size(102, 13)
        Me.lAbout3.TabIndex = 25
        Me.lAbout3.Text = "Corso Vercelli 332"
        Me.lAbout3.Visible = False
        '
        'lAbout2
        '
        Me.lAbout2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lAbout2.Location = New System.Drawing.Point(18, 36)
        Me.lAbout2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lAbout2.Name = "lAbout2"
        Me.lAbout2.Size = New System.Drawing.Size(186, 26)
        Me.lAbout2.TabIndex = 24
        Me.lAbout2.Text = "CTS Electronics S.p.A."
        Me.lAbout2.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.LsApiDemo.My.Resources.Resources.Link_ico
        Me.PictureBox1.Location = New System.Drawing.Point(731, 407)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(24, 26)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(794, 568)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 22
        Me.PictureBox2.TabStop = False
        '
        'formAbout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(794, 568)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lAbout7)
        Me.Controls.Add(Me.llCtsSito)
        Me.Controls.Add(Me.lAbout6)
        Me.Controls.Add(Me.lAbout4)
        Me.Controls.Add(Me.lAbout3)
        Me.Controls.Add(Me.lAbout2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formAbout"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LsFamily Demo About"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lAbout7 As System.Windows.Forms.Label
    Friend WithEvents llCtsSito As System.Windows.Forms.LinkLabel
    Friend WithEvents lAbout6 As System.Windows.Forms.Label
    Friend WithEvents lAbout4 As System.Windows.Forms.Label
    Friend WithEvents lAbout3 As System.Windows.Forms.Label
    Friend WithEvents lAbout2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
End Class
