Public Class formCard
    Inherits System.Windows.Forms.Form


#Region " Codice generato da Progettazione Windows Form "

    Public Sub New()
        MyBase.New()

        'Chiamata richiesta da Progettazione Windows Form.
        InitializeComponent()

        'Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent()

    End Sub

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue � richiesta da Progettazione Windows Form.
    'Pu� essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbSideNone As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideRear As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideFront As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideAll As System.Windows.Forms.RadioButton
    Friend WithEvents bc16g300 As System.Windows.Forms.Button
    Friend WithEvents bc256g300 As System.Windows.Forms.Button
    Friend WithEvents cbPdf147 As System.Windows.Forms.CheckBox
    Friend WithEvents bcCancel As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.rbSideNone = New System.Windows.Forms.RadioButton
        Me.rbSideRear = New System.Windows.Forms.RadioButton
        Me.rbSideFront = New System.Windows.Forms.RadioButton
        Me.rbSideAll = New System.Windows.Forms.RadioButton
        Me.bc16g300 = New System.Windows.Forms.Button
        Me.bc256g300 = New System.Windows.Forms.Button
        Me.bcCancel = New System.Windows.Forms.Button
        Me.cbPdf147 = New System.Windows.Forms.CheckBox
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbSideNone)
        Me.GroupBox3.Controls.Add(Me.rbSideRear)
        Me.GroupBox3.Controls.Add(Me.rbSideFront)
        Me.GroupBox3.Controls.Add(Me.rbSideAll)
        Me.GroupBox3.Location = New System.Drawing.Point(33, 42)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(74, 111)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Side"
        '
        'rbSideNone
        '
        Me.rbSideNone.Location = New System.Drawing.Point(13, 83)
        Me.rbSideNone.Name = "rbSideNone"
        Me.rbSideNone.Size = New System.Drawing.Size(54, 21)
        Me.rbSideNone.TabIndex = 3
        Me.rbSideNone.Text = "None"
        '
        'rbSideRear
        '
        Me.rbSideRear.Location = New System.Drawing.Point(13, 62)
        Me.rbSideRear.Name = "rbSideRear"
        Me.rbSideRear.Size = New System.Drawing.Size(54, 21)
        Me.rbSideRear.TabIndex = 2
        Me.rbSideRear.Text = "Rear"
        '
        'rbSideFront
        '
        Me.rbSideFront.Location = New System.Drawing.Point(13, 42)
        Me.rbSideFront.Name = "rbSideFront"
        Me.rbSideFront.Size = New System.Drawing.Size(54, 20)
        Me.rbSideFront.TabIndex = 1
        Me.rbSideFront.Text = "Front"
        '
        'rbSideAll
        '
        Me.rbSideAll.Location = New System.Drawing.Point(13, 21)
        Me.rbSideAll.Name = "rbSideAll"
        Me.rbSideAll.Size = New System.Drawing.Size(54, 21)
        Me.rbSideAll.TabIndex = 0
        Me.rbSideAll.Text = "All"
        '
        'bc16g300
        '
        Me.bc16g300.Location = New System.Drawing.Point(140, 49)
        Me.bc16g300.Name = "bc16g300"
        Me.bc16g300.Size = New System.Drawing.Size(80, 19)
        Me.bc16g300.TabIndex = 3
        Me.bc16g300.Text = "&16 Gray 300 dpi"
        '
        'bc256g300
        '
        Me.bc256g300.Location = New System.Drawing.Point(140, 90)
        Me.bc256g300.Name = "bc256g300"
        Me.bc256g300.Size = New System.Drawing.Size(80, 20)
        Me.bc256g300.TabIndex = 4
        Me.bc256g300.Text = "&256 Gray 300 dpi"
        '
        'bcCancel
        '
        Me.bcCancel.Location = New System.Drawing.Point(196, 200)
        Me.bcCancel.Name = "bcCancel"
        Me.bcCancel.Size = New System.Drawing.Size(80, 20)
        Me.bcCancel.TabIndex = 5
        Me.bcCancel.Text = "&Cancel"
        '
        'cbPdf147
        '
        Me.cbPdf147.Location = New System.Drawing.Point(140, 133)
        Me.cbPdf147.Name = "cbPdf147"
        Me.cbPdf147.Size = New System.Drawing.Size(92, 20)
        Me.cbPdf147.TabIndex = 6
        Me.cbPdf147.Text = "Pdf147Sw"
        '
        'formCard
        '
        Me.AcceptButton = Me.bc256g300
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 232)
        Me.Controls.Add(Me.cbPdf147)
        Me.Controls.Add(Me.bcCancel)
        Me.Controls.Add(Me.bc256g300)
        Me.Controls.Add(Me.bc16g300)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "formCard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Card Resolution"
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub formCard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' Side
        Select Case cApplFunc.Side
            Case LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
                rbSideAll.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
                rbSideFront.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
                rbSideRear.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
                rbSideNone.Checked = True
            Case Else
                rbSideFront.Checked = True
        End Select


        If (cApplFunc.fReadPdf = True) Then
            cbPdf147.Checked = True
        End If


    End Sub

    Private Sub formCard_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed

        cApplFunc.ScanMode_Card = 0

    End Sub

    Private Sub bc16g300_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bc16g300.Click

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then

            ' Side
            If rbSideAll.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
            ElseIf rbSideFront.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
            ElseIf rbSideRear.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
            ElseIf rbSideNone.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
            End If

            ScanMode_Card = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_300

            If (cbPdf147.Checked = True) Then
                cApplFunc.fReadPdf = True
            Else
                cApplFunc.fReadPdf = False
            End If

            Me.Close()
        Else
            MessageBox.Show("The Unit don't support this feature !", Form1.TITLE_POPUP, MessageBoxButtons.OK) ', MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub bc256g300_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bc256g300.Click

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT) Then

            ' Side
            If rbSideAll.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
            ElseIf rbSideFront.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
            ElseIf rbSideRear.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
            ElseIf rbSideNone.Checked = True Then
                cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
            End If

            ScanMode_Card = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_300

            If (cbPdf147.Checked = True) Then
                cApplFunc.fReadPdf = True
            Else
                cApplFunc.fReadPdf = False
            End If

            Me.Close()
        Else
            MessageBox.Show("The Unit don't support this feature !", Form1.TITLE_POPUP, MessageBoxButtons.OK) ', MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub bcCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bcCancel.Click

        ScanMode_Card = 0

        Me.Close()
    End Sub
End Class
