﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolSplitLSmodel = New System.Windows.Forms.ToolStripSplitButton
        Me.LS40MenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS100IPMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS100USBMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS150usbMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS515usbMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS520usbMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS800usbMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LS150IpMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Ls40A4MenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Ls150A4MenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripIdentify = New System.Windows.Forms.ToolStripButton
        Me.ToolStripStatus = New System.Windows.Forms.ToolStripButton
        Me.ToolStripUnitMonitoring = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripAutoFeed = New System.Windows.Forms.ToolStripButton
        Me.TA4Scan = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSingleDOc = New System.Windows.Forms.ToolStripButton
        Me.ToolStripMultiDoc = New System.Windows.Forms.ToolStripButton
        Me.ToolStripDoubleLeafing = New System.Windows.Forms.ToolStripButton
        Me.ToolStripRetainedDoc = New System.Windows.Forms.ToolStripButton
        Me.ToolStripOptions = New System.Windows.Forms.ToolStripButton
        Me.TOptionA4 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripTestCinghia = New System.Windows.Forms.ToolStripButton
        Me.ToolStripReset = New System.Windows.Forms.ToolStripButton
        Me.ToolStripClear = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripCard = New System.Windows.Forms.ToolStripButton
        Me.ToolStripBadge = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripAbout = New System.Windows.Forms.ToolStripButton
        Me.ToolStripExit = New System.Windows.Forms.ToolStripButton
        Me.ImageLsModel = New System.Windows.Forms.ImageList(Me.components)
        Me.lNrDocProc = New System.Windows.Forms.Label
        Me.ImageDoubleFeed = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.White
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(48, 48)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolSplitLSmodel, Me.ToolStripSeparator1, Me.ToolStripIdentify, Me.ToolStripStatus, Me.ToolStripUnitMonitoring, Me.ToolStripSeparator2, Me.ToolStripAutoFeed, Me.TA4Scan, Me.ToolStripSingleDOc, Me.ToolStripMultiDoc, Me.ToolStripDoubleLeafing, Me.ToolStripRetainedDoc, Me.ToolStripOptions, Me.TOptionA4, Me.ToolStripSeparator3, Me.ToolStripTestCinghia, Me.ToolStripReset, Me.ToolStripClear, Me.ToolStripSeparator4, Me.ToolStripCard, Me.ToolStripBadge, Me.ToolStripSeparator5, Me.ToolStripAbout, Me.ToolStripExit})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1018, 55)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolSplitLSmodel
        '
        Me.ToolSplitLSmodel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolSplitLSmodel.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LS40MenuItem, Me.LS100IPMenuItem, Me.LS100USBMenuItem, Me.LS150usbMenuItem, Me.LS515usbMenuItem, Me.LS520usbMenuItem, Me.LS800usbMenuItem, Me.LS150IpMenuItem, Me.Ls40A4MenuItem, Me.Ls150A4MenuItem})
        Me.ToolSplitLSmodel.Image = CType(resources.GetObject("ToolSplitLSmodel.Image"), System.Drawing.Image)
        Me.ToolSplitLSmodel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolSplitLSmodel.Name = "ToolSplitLSmodel"
        Me.ToolSplitLSmodel.Size = New System.Drawing.Size(64, 52)
        Me.ToolSplitLSmodel.Text = "Select LS Unit"
        '
        'LS40MenuItem
        '
        Me.LS40MenuItem.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LS40MenuItem.Image = CType(resources.GetObject("LS40MenuItem.Image"), System.Drawing.Image)
        Me.LS40MenuItem.Name = "LS40MenuItem"
        Me.LS40MenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS40MenuItem.Text = "Ls40"
        '
        'LS100IPMenuItem
        '
        Me.LS100IPMenuItem.Image = CType(resources.GetObject("LS100IPMenuItem.Image"), System.Drawing.Image)
        Me.LS100IPMenuItem.Name = "LS100IPMenuItem"
        Me.LS100IPMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS100IPMenuItem.Text = "Ls100"
        Me.LS100IPMenuItem.Visible = False
        '
        'LS100USBMenuItem
        '
        Me.LS100USBMenuItem.Image = CType(resources.GetObject("LS100USBMenuItem.Image"), System.Drawing.Image)
        Me.LS100USBMenuItem.Name = "LS100USBMenuItem"
        Me.LS100USBMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS100USBMenuItem.Text = "Ls100"
        '
        'LS150usbMenuItem
        '
        Me.LS150usbMenuItem.Image = CType(resources.GetObject("LS150usbMenuItem.Image"), System.Drawing.Image)
        Me.LS150usbMenuItem.Name = "LS150usbMenuItem"
        Me.LS150usbMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS150usbMenuItem.Text = "Ls150"
        '
        'LS515usbMenuItem
        '
        Me.LS515usbMenuItem.Image = CType(resources.GetObject("LS515usbMenuItem.Image"), System.Drawing.Image)
        Me.LS515usbMenuItem.Name = "LS515usbMenuItem"
        Me.LS515usbMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS515usbMenuItem.Text = "Ls515"
        '
        'LS520usbMenuItem
        '
        Me.LS520usbMenuItem.Image = CType(resources.GetObject("LS520usbMenuItem.Image"), System.Drawing.Image)
        Me.LS520usbMenuItem.Name = "LS520usbMenuItem"
        Me.LS520usbMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS520usbMenuItem.Text = "Ls520"
        Me.LS520usbMenuItem.Visible = False
        '
        'LS800usbMenuItem
        '
        Me.LS800usbMenuItem.Image = CType(resources.GetObject("LS800usbMenuItem.Image"), System.Drawing.Image)
        Me.LS800usbMenuItem.Name = "LS800usbMenuItem"
        Me.LS800usbMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS800usbMenuItem.Text = "Ls800"
        '
        'LS150IpMenuItem
        '
        Me.LS150IpMenuItem.Image = CType(resources.GetObject("LS150IpMenuItem.Image"), System.Drawing.Image)
        Me.LS150IpMenuItem.Name = "LS150IpMenuItem"
        Me.LS150IpMenuItem.Size = New System.Drawing.Size(184, 54)
        Me.LS150IpMenuItem.Text = "Ls150Ip"
        Me.LS150IpMenuItem.Visible = False
        '
        'Ls40A4MenuItem
        '
        Me.Ls40A4MenuItem.Image = CType(resources.GetObject("Ls40A4MenuItem.Image"), System.Drawing.Image)
        Me.Ls40A4MenuItem.Name = "Ls40A4MenuItem"
        Me.Ls40A4MenuItem.Size = New System.Drawing.Size(184, 54)
        Me.Ls40A4MenuItem.Text = "Ls40 + A4"
        '
        'Ls150A4MenuItem
        '
        Me.Ls150A4MenuItem.Image = CType(resources.GetObject("Ls150A4MenuItem.Image"), System.Drawing.Image)
        Me.Ls150A4MenuItem.Name = "Ls150A4MenuItem"
        Me.Ls150A4MenuItem.Size = New System.Drawing.Size(184, 54)
        Me.Ls150A4MenuItem.Text = "Ls150 + A4"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 55)
        '
        'ToolStripIdentify
        '
        Me.ToolStripIdentify.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripIdentify.Enabled = False
        Me.ToolStripIdentify.Image = CType(resources.GetObject("ToolStripIdentify.Image"), System.Drawing.Image)
        Me.ToolStripIdentify.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripIdentify.Name = "ToolStripIdentify"
        Me.ToolStripIdentify.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripIdentify.Text = "ToolStripButton1"
        Me.ToolStripIdentify.ToolTipText = "Unit Identify"
        '
        'ToolStripStatus
        '
        Me.ToolStripStatus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripStatus.Enabled = False
        Me.ToolStripStatus.Image = CType(resources.GetObject("ToolStripStatus.Image"), System.Drawing.Image)
        Me.ToolStripStatus.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatus.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripStatus.Name = "ToolStripStatus"
        Me.ToolStripStatus.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripStatus.Text = "Unit Status"
        '
        'ToolStripUnitMonitoring
        '
        Me.ToolStripUnitMonitoring.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripUnitMonitoring.Enabled = False
        Me.ToolStripUnitMonitoring.Image = CType(resources.GetObject("ToolStripUnitMonitoring.Image"), System.Drawing.Image)
        Me.ToolStripUnitMonitoring.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripUnitMonitoring.Name = "ToolStripUnitMonitoring"
        Me.ToolStripUnitMonitoring.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripUnitMonitoring.Text = "Unit Monitoring"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 55)
        '
        'ToolStripAutoFeed
        '
        Me.ToolStripAutoFeed.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripAutoFeed.Enabled = False
        Me.ToolStripAutoFeed.Image = CType(resources.GetObject("ToolStripAutoFeed.Image"), System.Drawing.Image)
        Me.ToolStripAutoFeed.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripAutoFeed.Name = "ToolStripAutoFeed"
        Me.ToolStripAutoFeed.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripAutoFeed.Text = "Auto Feed"
        '
        'TA4Scan
        '
        Me.TA4Scan.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TA4Scan.Enabled = False
        Me.TA4Scan.Image = CType(resources.GetObject("TA4Scan.Image"), System.Drawing.Image)
        Me.TA4Scan.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TA4Scan.Name = "TA4Scan"
        Me.TA4Scan.Size = New System.Drawing.Size(52, 52)
        Me.TA4Scan.Text = "Process Doc. A4"
        Me.TA4Scan.Visible = False
        '
        'ToolStripSingleDOc
        '
        Me.ToolStripSingleDOc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripSingleDOc.Enabled = False
        Me.ToolStripSingleDOc.Image = CType(resources.GetObject("ToolStripSingleDOc.Image"), System.Drawing.Image)
        Me.ToolStripSingleDOc.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripSingleDOc.Name = "ToolStripSingleDOc"
        Me.ToolStripSingleDOc.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripSingleDOc.Text = "Process Doc."
        '
        'ToolStripMultiDoc
        '
        Me.ToolStripMultiDoc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripMultiDoc.Enabled = False
        Me.ToolStripMultiDoc.Image = CType(resources.GetObject("ToolStripMultiDoc.Image"), System.Drawing.Image)
        Me.ToolStripMultiDoc.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripMultiDoc.Name = "ToolStripMultiDoc"
        Me.ToolStripMultiDoc.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripMultiDoc.Text = "Process Multi Doc."
        '
        'ToolStripDoubleLeafing
        '
        Me.ToolStripDoubleLeafing.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripDoubleLeafing.Enabled = False
        Me.ToolStripDoubleLeafing.Image = CType(resources.GetObject("ToolStripDoubleLeafing.Image"), System.Drawing.Image)
        Me.ToolStripDoubleLeafing.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDoubleLeafing.Name = "ToolStripDoubleLeafing"
        Me.ToolStripDoubleLeafing.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripDoubleLeafing.Text = "Double Leafing set : Error"
        '
        'ToolStripRetainedDoc
        '
        Me.ToolStripRetainedDoc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripRetainedDoc.Enabled = False
        Me.ToolStripRetainedDoc.Image = CType(resources.GetObject("ToolStripRetainedDoc.Image"), System.Drawing.Image)
        Me.ToolStripRetainedDoc.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripRetainedDoc.Name = "ToolStripRetainedDoc"
        Me.ToolStripRetainedDoc.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripRetainedDoc.Text = "RetainedDoc"
        '
        'ToolStripOptions
        '
        Me.ToolStripOptions.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripOptions.Enabled = False
        Me.ToolStripOptions.Image = CType(resources.GetObject("ToolStripOptions.Image"), System.Drawing.Image)
        Me.ToolStripOptions.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripOptions.Name = "ToolStripOptions"
        Me.ToolStripOptions.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripOptions.Text = "Options"
        '
        'TOptionA4
        '
        Me.TOptionA4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TOptionA4.Enabled = False
        Me.TOptionA4.Image = CType(resources.GetObject("TOptionA4.Image"), System.Drawing.Image)
        Me.TOptionA4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TOptionA4.Name = "TOptionA4"
        Me.TOptionA4.Size = New System.Drawing.Size(52, 52)
        Me.TOptionA4.Text = "Options A4"
        Me.TOptionA4.Visible = False
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 55)
        '
        'ToolStripTestCinghia
        '
        Me.ToolStripTestCinghia.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripTestCinghia.Enabled = False
        Me.ToolStripTestCinghia.Image = CType(resources.GetObject("ToolStripTestCinghia.Image"), System.Drawing.Image)
        Me.ToolStripTestCinghia.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripTestCinghia.Name = "ToolStripTestCinghia"
        Me.ToolStripTestCinghia.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripTestCinghia.Text = "Belt Cleaning"
        '
        'ToolStripReset
        '
        Me.ToolStripReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripReset.Enabled = False
        Me.ToolStripReset.Image = CType(resources.GetObject("ToolStripReset.Image"), System.Drawing.Image)
        Me.ToolStripReset.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripReset.Name = "ToolStripReset"
        Me.ToolStripReset.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripReset.Text = "Reset"
        '
        'ToolStripClear
        '
        Me.ToolStripClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripClear.Enabled = False
        Me.ToolStripClear.Image = CType(resources.GetObject("ToolStripClear.Image"), System.Drawing.Image)
        Me.ToolStripClear.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripClear.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripClear.Name = "ToolStripClear"
        Me.ToolStripClear.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripClear.Text = "Clear Screen"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 55)
        '
        'ToolStripCard
        '
        Me.ToolStripCard.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripCard.Enabled = False
        Me.ToolStripCard.Image = CType(resources.GetObject("ToolStripCard.Image"), System.Drawing.Image)
        Me.ToolStripCard.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripCard.Name = "ToolStripCard"
        Me.ToolStripCard.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripCard.Text = "Process Card"
        '
        'ToolStripBadge
        '
        Me.ToolStripBadge.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripBadge.Enabled = False
        Me.ToolStripBadge.Image = CType(resources.GetObject("ToolStripBadge.Image"), System.Drawing.Image)
        Me.ToolStripBadge.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripBadge.Name = "ToolStripBadge"
        Me.ToolStripBadge.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripBadge.Text = "Read Badge"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 55)
        '
        'ToolStripAbout
        '
        Me.ToolStripAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripAbout.Image = CType(resources.GetObject("ToolStripAbout.Image"), System.Drawing.Image)
        Me.ToolStripAbout.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripAbout.Name = "ToolStripAbout"
        Me.ToolStripAbout.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripAbout.Text = "About LS Family"
        '
        'ToolStripExit
        '
        Me.ToolStripExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripExit.Image = CType(resources.GetObject("ToolStripExit.Image"), System.Drawing.Image)
        Me.ToolStripExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripExit.Name = "ToolStripExit"
        Me.ToolStripExit.Size = New System.Drawing.Size(52, 52)
        Me.ToolStripExit.Text = "Exit"
        '
        'ImageLsModel
        '
        Me.ImageLsModel.ImageStream = CType(resources.GetObject("ImageLsModel.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageLsModel.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageLsModel.Images.SetKeyName(0, "LS100.png")
        Me.ImageLsModel.Images.SetKeyName(1, "LS100.png")
        Me.ImageLsModel.Images.SetKeyName(2, "LS150.png")
        Me.ImageLsModel.Images.SetKeyName(3, "LS515.png")
        Me.ImageLsModel.Images.SetKeyName(4, "LS515.png")
        Me.ImageLsModel.Images.SetKeyName(5, "LS800.png")
        Me.ImageLsModel.Images.SetKeyName(6, "LS40.png")
        Me.ImageLsModel.Images.SetKeyName(7, "LS150.png")
        Me.ImageLsModel.Images.SetKeyName(8, "LS40.png")
        Me.ImageLsModel.Images.SetKeyName(9, "LS100.png")
        Me.ImageLsModel.Images.SetKeyName(10, "LS40COMBO.png")
        Me.ImageLsModel.Images.SetKeyName(11, "LS150COMBO.png")
        '
        'lNrDocProc
        '
        Me.lNrDocProc.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lNrDocProc.AutoSize = True
        Me.lNrDocProc.BackColor = System.Drawing.Color.FromArgb(CType(CType(132, Byte), Integer), CType(CType(194, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.lNrDocProc.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lNrDocProc.ForeColor = System.Drawing.Color.White
        Me.lNrDocProc.Location = New System.Drawing.Point(775, 713)
        Me.lNrDocProc.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lNrDocProc.Name = "lNrDocProc"
        Me.lNrDocProc.Size = New System.Drawing.Size(172, 19)
        Me.lNrDocProc.TabIndex = 2
        Me.lNrDocProc.Text = "Doc. per Minute : 0        "
        '
        'ImageDoubleFeed
        '
        Me.ImageDoubleFeed.ImageStream = CType(resources.GetObject("ImageDoubleFeed.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageDoubleFeed.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageDoubleFeed.Images.SetKeyName(0, "DETDOUBLE.png")
        Me.ImageDoubleFeed.Images.SetKeyName(1, "no_DETDOUBLE.png")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1018, 742)
        Me.Controls.Add(Me.lNrDocProc)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LsFamily Demo  * Rel 1.09 22-02-11 "
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolSplitLSmodel As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents LS100IPMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LS100USBMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LS150usbMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LS515usbMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LS520usbMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LS800usbMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripIdentify As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripStatus As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSingleDOc As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripMultiDoc As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripOptions As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripDoubleLeafing As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripReset As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripClear As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripCard As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripBadge As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripAbout As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripExit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ImageLsModel As System.Windows.Forms.ImageList
    Friend WithEvents lNrDocProc As System.Windows.Forms.Label
    Friend WithEvents ImageDoubleFeed As System.Windows.Forms.ImageList
    Friend WithEvents LS40MenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripRetainedDoc As System.Windows.Forms.ToolStripButton
    Friend WithEvents LS150IpMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripUnitMonitoring As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripTestCinghia As System.Windows.Forms.ToolStripButton
    Friend WithEvents Ls40A4MenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ls150A4MenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TOptionA4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents TA4Scan As System.Windows.Forms.ToolStripButton
    Public WithEvents ToolStripAutoFeed As System.Windows.Forms.ToolStripButton

End Class
