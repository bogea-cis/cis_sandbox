﻿Public Class FImages


    Public EstFile As String
    Public Scanmode As Int16
    Private Sub TImages_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TImages.AfterSelect
       
    End Sub

    Private Sub TImages_NodeMouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TImages.NodeMouseDoubleClick
        Dim ss As String
        Dim svet() As String
        Dim altessaCodeline As Int16
        altessaCodeline = 0
        ss = Application.StartupPath + "\\Images\\Image_"
        Try
            If (e.Node.Text.Contains("Codeline") = False And e.Node.Text.Contains("Document") = False) Then
                svet = e.Node.Parent.Text.Split(" ")
                ss += (System.Convert.ToInt16(svet(1)) - 1).ToString("0000")
                Select Case e.Node.Text
                    Case Form1.IMG_FRONT
                        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
                            ss += "FB"
                        Else
                            ss += "FF"
                        End If

                    Case Form1.IMG_REAR
                        ss += "BB"
                    Case Form1.IMG_FRONTUV
                        ss += "FN"
                    Case Form1.IMG_MERGED
                        ss += "GUV"
                    Case Else

                End Select


                ss += EstFile

                Dim fff As New Form2()


                If (Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_300 Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_300 Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_300 Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR300_AND_UV) Then
                    fff.Size = New Size(Image.FromFile(ss).Width / 3, (Image.FromFile(ss).Height / 3) + altessaCodeline)
                ElseIf (Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_BW Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_200 Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_200 Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_200 Or _
                        Scanmode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR200_AND_UV) Then
                    fff.Size = New Size(Image.FromFile(ss).Width / 2, (Image.FromFile(ss).Height / 2) + altessaCodeline)
                Else
                    fff.Size = New Size(Image.FromFile(ss).Width, Image.FromFile(ss).Height)
                End If



                fff.pbImage.Image = Image.FromFile(ss)
                fff.Text = ss
                fff.Location = New Point(Me.Width, 0)

                fff.MdiParent = Me.ParentForm
                fff.Show()

            End If
        Catch
            MessageBox.Show("Error on Save Image!!", Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try




    End Sub

    Private Sub FImages_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    
    Private Sub TImages_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TImages.KeyDown
        'If (e.Control = True And e.Shift = True And e.KeyCode = Keys.F4) Then
        '    Form1.ToolStripAutoFeed_Click(sender, e)
        'ElseIf (e.Control = True And e.Shift = True) Then
        '    If (fAutoFeed = True) Then
        '        Form1.ToolStripAutoFeed_Click(sender, e)
        '    End If
        '    End If

    End Sub
End Class