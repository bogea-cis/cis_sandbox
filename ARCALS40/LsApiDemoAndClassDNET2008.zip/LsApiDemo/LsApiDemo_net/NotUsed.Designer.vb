﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NotUsed
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.cbWarnig = New System.Windows.Forms.CheckBox
        Me.cbDisable = New System.Windows.Forms.CheckBox
        Me.gbDoubleLeafing = New System.Windows.Forms.GroupBox
        Me.lbDoubleLeafing = New System.Windows.Forms.Label
        Me.tbDoubleLeafing = New System.Windows.Forms.TrackBar
        Me.GroupBox9.SuspendLayout()
        Me.gbDoubleLeafing.SuspendLayout()
        CType(Me.tbDoubleLeafing, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.cbWarnig)
        Me.GroupBox9.Controls.Add(Me.cbDisable)
        Me.GroupBox9.Location = New System.Drawing.Point(28, 27)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(198, 39)
        Me.GroupBox9.TabIndex = 3
        Me.GroupBox9.TabStop = False
        '
        'cbWarnig
        '
        Me.cbWarnig.AutoSize = True
        Me.cbWarnig.Location = New System.Drawing.Point(90, 16)
        Me.cbWarnig.Name = "cbWarnig"
        Me.cbWarnig.Size = New System.Drawing.Size(66, 17)
        Me.cbWarnig.TabIndex = 15
        Me.cbWarnig.Text = "Warning"
        Me.cbWarnig.UseVisualStyleBackColor = True
        '
        'cbDisable
        '
        Me.cbDisable.AutoSize = True
        Me.cbDisable.Location = New System.Drawing.Point(22, 16)
        Me.cbDisable.Name = "cbDisable"
        Me.cbDisable.Size = New System.Drawing.Size(61, 17)
        Me.cbDisable.TabIndex = 2
        Me.cbDisable.Text = "Disable"
        Me.cbDisable.UseVisualStyleBackColor = True
        '
        'gbDoubleLeafing
        '
        Me.gbDoubleLeafing.Controls.Add(Me.lbDoubleLeafing)
        Me.gbDoubleLeafing.Controls.Add(Me.tbDoubleLeafing)
        Me.gbDoubleLeafing.Location = New System.Drawing.Point(31, 85)
        Me.gbDoubleLeafing.Name = "gbDoubleLeafing"
        Me.gbDoubleLeafing.Size = New System.Drawing.Size(153, 90)
        Me.gbDoubleLeafing.TabIndex = 4
        Me.gbDoubleLeafing.TabStop = False
        Me.gbDoubleLeafing.Text = "Double Leafing level"
        '
        'lbDoubleLeafing
        '
        Me.lbDoubleLeafing.Location = New System.Drawing.Point(27, 62)
        Me.lbDoubleLeafing.Name = "lbDoubleLeafing"
        Me.lbDoubleLeafing.Size = New System.Drawing.Size(113, 14)
        Me.lbDoubleLeafing.TabIndex = 2
        Me.lbDoubleLeafing.Text = " 2          3        4(d)"
        '
        'tbDoubleLeafing
        '
        Me.tbDoubleLeafing.LargeChange = 1
        Me.tbDoubleLeafing.Location = New System.Drawing.Point(20, 28)
        Me.tbDoubleLeafing.Maximum = 4
        Me.tbDoubleLeafing.Minimum = 2
        Me.tbDoubleLeafing.Name = "tbDoubleLeafing"
        Me.tbDoubleLeafing.Size = New System.Drawing.Size(107, 45)
        Me.tbDoubleLeafing.TabIndex = 0
        Me.tbDoubleLeafing.Value = 2
        '
        'NotUsed
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.gbDoubleLeafing)
        Me.Controls.Add(Me.GroupBox9)
        Me.Name = "NotUsed"
        Me.Text = "NotUsed"
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.gbDoubleLeafing.ResumeLayout(False)
        Me.gbDoubleLeafing.PerformLayout()
        CType(Me.tbDoubleLeafing, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents cbWarnig As System.Windows.Forms.CheckBox
    Friend WithEvents cbDisable As System.Windows.Forms.CheckBox
    Friend WithEvents gbDoubleLeafing As System.Windows.Forms.GroupBox
    Friend WithEvents lbDoubleLeafing As System.Windows.Forms.Label
    Friend WithEvents tbDoubleLeafing As System.Windows.Forms.TrackBar
End Class
