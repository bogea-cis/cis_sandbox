﻿Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Threading
Imports System.Runtime.Serialization.Formatters.Binary


Public Class Form1

    ' defines and enum
    Public Const TITLE_POPUP = "Ls Demo Test"
    Const MAX_CHILD_FORM = 20
    Public Const ALTEZZA_CODELINE = 33
    Public Const HISTORY_TIME_UNIT = 300      'secondi
    Public Const Y_CONST = 50
    Public Const IMG_FRONT = "Front Image"
    Public Const IMG_REAR = "Rear Image"
    Public Const IMG_FRONTUV = "Front UV Image"
    Public Const IMG_MERGED = "Merged Image"



    Enum LsModelIcon
        MenuIco_Ls100eth
        MenuIco_Ls100usb
        MenuIco_LS150usb
        MenuIco_LS515usb
        MenuIco_LS520usb
        MenuIco_LS800usb
        MenuIco_Ls40usb
        MenuIco_Ls150eth
        MenuIco_Ls40
        MenuIco_Ls100
        MenuIco_Ls40_LsCombo
        MenuIco_Ls150_LsCombo
    End Enum

    Enum DoubleLeafingIcon
        DL_Error
        DL_Warning
    End Enum

    ' Allocco la classe LsFamily
    Dim Ls As LsFamily.LsApi
    Dim LsDefines As LsFamily.LsDefines
    Dim fcan As FCanonOption
    'Dim CtsIQA As LsFamily.CtsIQA

    ' child windows
    Dim childForm As Integer = 0
    Dim childForms(MAX_CHILD_FORM) As Form2
    Dim fClearImage As Boolean
    'Dim NrDocVideo As Int16

    Dim fform As FImages
    Dim yfinestra As Int16

    Public hLS As Integer


    Dim A4Side As Short
    Dim A4Resolution As Short
    Dim A4Scanmode As Short

    Dim NrDocTot As Integer


    Public Structure ReceiptItem
        Dim FrontImage As Image
        Dim RearImage As Image
        Dim Codeline As String
    End Structure

    Dim Receipt As New List(Of ReceiptItem)
    Dim ReceiptPage As Integer
    Dim Ryp As New Point(0, 0)


    Public Function EnableTest() As Boolean

        ToolStripIdentify.Enabled = True
        ToolStripStatus.Enabled = True
        ToolStripUnitMonitoring.Enabled = True
        If (LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_150_ETH) Then
            ToolStripAutoFeed.Enabled = True
        End If

        ToolStripSingleDOc.Enabled = True
        ToolStripRetainedDoc.Enabled = True
        ToolStripOptions.Enabled = True

        ToolStripReset.Enabled = True
        ToolStripClear.Enabled = True

        If (LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_40_USB Or LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT) Then
            ToolStripMultiDoc.Enabled = True
        End If


        If (LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_40_USB Or _
            LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_150_ETH Or _
            LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT) Then
            ToolStripDoubleLeafing.Enabled = True
        End If


        Return True
    End Function

    Public Function ReadIniFile()

        Const LSPRINT_CONFIGURATION_FILE = "LsDemo.ini"

        Dim riga As String = ""    'Stringa di supporto, funzionerà da buffer
        Dim app() As String
        Dim aaa As String = ""

        ReadIniFile = 0

        Try
            Dim tr As TextReader = File.OpenText(LSPRINT_CONFIGURATION_FILE)

            Do
                riga = tr.ReadLine() 'Legge la riga dal file output.txt
                If (riga <> Nothing) Then
                    app = riga.Split("=")

                    app(0) = app(0).Trim()

                    If (app(0).Equals("LsPrint")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("TRUE")) Then
                            fReceipt = 1
                        End If

                    ElseIf (app(0).Equals("Ls40")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            LS40MenuItem.Visible = False
                        End If

                    ElseIf (app(0).Equals("Ls100")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            LS100USBMenuItem.Visible = False
                        End If

                    ElseIf (app(0).Equals("Ls150")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            LS150usbMenuItem.Visible = False
                        End If

                    ElseIf (app(0).Equals("Ls515")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            LS515usbMenuItem.Visible = False
                        End If

                    ElseIf (app(0).Equals("Ls800")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            LS800usbMenuItem.Visible = False
                        End If

                    ElseIf (app(0).Equals("Ls40+A4")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            Ls40A4MenuItem.Visible = False
                        End If

                    ElseIf (app(0).Equals("Ls150+A4")) Then

                        app(1) = app(1).ToUpper()
                        app(1) = app(1).Trim

                        If (app(1).Equals("FALSE")) Then
                            Ls150A4MenuItem.Visible = False
                        End If
                    End If

                End If

                'Loop While (riga <> Nothing)
            Loop While (riga IsNot Nothing)

            'Chiusura dei due file, liberiamo gli handles
            tr.Close()

            ' passo da qui se non trovo il file di configurazione
        Catch e As FileNotFoundException

        End Try

        Return True
    End Function


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Model As String = New String("", 20)
        Dim Version As String = New String("", 20)
        Dim FwDate As String = New String("", 20)
        Dim UnitID As String = New String("", 20)
        Dim sPrint As String = "CTS Electronics test print"
        Dim CodelineRead As String = New String(" ", 256)
        Dim fImage As Bitmap = Nothing
        Dim rImage As Bitmap = Nothing

        Ls = New LsFamily.LsApi
        'CtsIQA = New LsFamily.CtsIQA
        cApplFunc = New ApplClass

        ImagePath = Application.StartupPath + "\" + ApplClass.SAVE_DIRECTORY_IMAGE
        Directory.CreateDirectory(ImagePath)
        cApplFunc.ReadConfiguration(cApplFunc, LsDefines)

        Try
            Me.BackgroundImage = Image.FromFile(Application.StartupPath + "\background.jpg")
        Catch ex As Exception
            Me.BackgroundImage = Nothing

        End Try


        'Leggo un file ini per sapere se e' presente la stampante LsPrint e su queli perferiche abilitare 
        ReadIniFile()


    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed

        cApplFunc.SaveConfiguration(cApplFunc)

    End Sub

    Public Sub PulisciVideata(ByVal tipoPulizia As Integer)
        Dim tmpchildForm As Integer
        yfinestra = 0
        Do While (tmpchildForm <= MAX_CHILD_FORM)
            If (childForms(tmpchildForm) Is Nothing) Then
            Else


                childForms(tmpchildForm).Close()
                childForms(tmpchildForm).Dispose()
                childForms(tmpchildForm) = Nothing
            End If
            tmpchildForm += 1
        Loop
        If tipoPulizia = 1 Then
            'If fform.Visible = True Then
            '    fform.Close()
            'End If
            For Each fff As Form In Me.MdiChildren
                fff.Close()
                fff.Dispose()
                fff = Nothing
            Next
        End If
        

    End Sub

    Private Sub miClearScreen_Click()
        PulisciVideata(1)


        childForm = 0
        fClearImage = False
    End Sub

    Private Function ControllaWith(ByRef Formim As Form2, ByVal Txt As String) As String
        Dim DS As String = "" ' stringa definitiva 
        Dim ST As String ' sottostriga temporanea 
        Dim SO As String ' stringa originale 
        Dim LS As Integer ' Lunghezza stringa originale 
        Dim x As Integer
        Dim start As Integer = 0
        Dim testo As String = ""
        SO = Txt
        LS = SO.Length
        Dim i As Integer = 0
        x = 1
        Do While i + start <= LS
            testo = SO.Substring(start, i)
            If ((testo.Length * 6.5) + 6) > Formim.Width Then
                ST = testo.Substring(0, i)
                Do While Not ST.EndsWith(" ")
                    ST = ST.Substring(0, (ST.Length - 1))
                Loop
                ST = ST.Substring(0, (ST.Length - 1))
                ST = ST + vbCrLf
                DS = DS + ST
                x += 1
                start = DS.Length - x
                i = 0 - 1
            End If
            i += 1
        Loop
        DS = DS + testo
        Return DS
    End Function


    Public Sub SetFormImage(ByRef Formim As Form2, ByVal rc As Int32, ByVal NrDoc As UInt32, _
                            ByVal TypeImage As String, ByVal CodelineHW As String, _
                            ByVal CodelineSW As String, ByVal ViewCodeline As Boolean, _
                            ByVal ImageView As Bitmap, ByVal ScanMode As Int16)

        Dim sorter As Int16
        Dim altessaCodeline As Int16
        altessaCodeline = ALTEZZA_CODELINE
        Dim lunghezzaCodeline As Int16
        Dim sb As New System.Text.StringBuilder
        Dim str1 As String = New String(" ", 256)
        Dim str2 As String = New String(" ", 256)
        Dim str3 As String = New String(" ", 256)




        If (rc = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then
            Formim.Text = TypeImage + " Image " & NrDoc.ToString & " -*- Warning Double Leafing"
        ElseIf ((rc >= LsFamily.LsReply.LS_SORTER_1_POCKET_1_FULL) And (rc >= LsFamily.LsReply.LS_SORTER_1_POCKET_1_FULL)) Then
            sorter = rc - LsFamily.LsReply.LS_SORTER_1_POCKET_1_FULL + 1
            Formim.Text = TypeImage + " Image " & NrDoc.ToString & " -*- Pochet " & sorter.ToString & " full"
        ElseIf (rc = LsFamily.LsReply.LS_SORTER1_FULL) Then
            Formim.Text = TypeImage + " Image " & NrDoc.ToString & " -*- Pochet 1 full"
        ElseIf (rc = LsFamily.LsReply.LS_SORTER2_FULL) Then
            Formim.Text = TypeImage + " Image " & NrDoc.ToString & " -*- Pochet 2 full"
        Else
            Formim.Text = TypeImage + " Image " & NrDoc.ToString
        End If

        If (ViewCodeline = True) Then

            If CodelineHW <> Nothing Then
                If CodelineHW.Length > 0 Then


                    lunghezzaCodeline = CodelineHW.Length()

                    'If (lunghezzaCodeline > 80 And lunghezzaCodeline < 160) Then
                    '    str1 = CodelineHW.Substring(0, 80)
                    '    str2 = CodelineHW.Substring(80, 80)
                    '    Formim.lCodeline.Text = str1 & vbNewLine & str2

                    'ElseIf (lunghezzaCodeline > 160 And lunghezzaCodeline < 256) Then
                    '    str1 = CodelineHW.Substring(0, 80)
                    '    str2 = CodelineHW.Substring(80, 80)
                    '    str3 = CodelineHW.Substring(160, CodelineHW.Length - 160)

                    '    altessaCodeline = ALTEZZA_CODELINE + 20
                    '    Formim.lCodeline.Width += 20
                    '    Formim.lCodeline.Text = str1 & vbNewLine & str2 & vbNewLine & str3
                    'Else
                    Formim.lCodeline.Text = CodelineHW
                    'End If

                End If
            End If
            If (CodelineSW <> Nothing) Then
                If CodelineSW.Length > 0 Then
                    If (CodelineHW <> Nothing) Then
                        Formim.lCodeline.Text += CodelineHW & " -OCR- " & CodelineSW
                    Else
                        Formim.lCodeline.Text += CodelineSW
                    End If
                End If
            End If

            If CodelineHW = Nothing And CodelineSW = Nothing Then
                altessaCodeline = 0
                Formim.SplitContainer1.Panel1Collapsed = True
                'Formim.SplitContainer1.Hide()
            End If


            ' set image


        Else
            ' viecodeline = False
            Formim.SplitContainer1.Panel1Collapsed = True

        End If
        If (ImageView Is Nothing) Then
        Else
            ' scalo la finestra in base alla dimensione dell'' immagine
            If (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_300 Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_300 Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_300 Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR300_AND_UV) Then
                childForms(childForm).Size = New Size(ImageView.Width / 3, (ImageView.Height / 3) + altessaCodeline)
            ElseIf (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_BW Or _
                    ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_200 Or _
                    ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_200 Or _
                    ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_200 Or _
                    ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR200_AND_UV) Then
                childForms(childForm).Size = New Size(ImageView.Width / 2, (ImageView.Height / 2) + altessaCodeline)
            Else
                Formim.Size = New Size(ImageView.Width, ImageView.Height)
            End If
            Formim.ScanMode = ScanMode
            Formim.altessaCodeline = altessaCodeline
            Formim.pbImage.Image = ImageView
        End If

    End Sub

    Private Sub CalcolosizeH(ByVal ScanMode As Int16, ByVal ImageView As Bitmap, ByRef HeightImmReal As Int16)

        ' scalo la finestra in base alla dimensione dell'' immagine
        If (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_300 Or _
            ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_300 Or _
            ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_300 Or _
            ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR300_AND_UV) Then
            'childForms(childForm).Size = New Size(ImageView.Width / 3, (ImageView.Height / 3) + ALTEZZA_CODELINE)
            HeightImmReal = (ImageView.Height / 3 + ALTEZZA_CODELINE)
        ElseIf (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_BW Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_200 Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_200 Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_200 Or _
                ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR200_AND_UV) Then
            HeightImmReal = (ImageView.Height / 2 + ALTEZZA_CODELINE)
        Else
            HeightImmReal = (ImageView.Height + ALTEZZA_CODELINE)
        End If
    End Sub
    Private Sub ShowCodelineAndImages(ByVal FileFormat As Int16, ByVal Side As Int16, ByVal ScanMode As Int16, ByVal rc As Int32, ByVal NrDoc As UInt32, ByVal CodelineHW As String, ByVal CodelineSW As String, ByVal FrontImage As Bitmap, ByVal BackImage As Bitmap, ByVal FrontImage2 As Bitmap, ByVal ImageMerged As Bitmap)

        Dim ImageMerge As Image = Nothing
        Dim viewCodeline As Boolean
        Dim treenode As TreeNode
        Dim xFinestra As Integer
        Dim item As New ReceiptItem()
        Dim sizeH As Short

        If Not (fform Is Nothing) Then
            treenode = New TreeNode()
            treenode.Text = "Document " + (NrDoc).ToString("0000")
            If (CodelineHW <> "") Then
                treenode.Nodes.Add("Codeline HW: " + CodelineHW)
            End If
            If (Not (CodelineSW Is Nothing)) Then
                treenode.Nodes.Add("Codeline SW: " + CodelineSW)
            End If
            If FileFormat = LsFamily.LsDefines.ImageSave.IMAGE_SAVE_BOTH Then
                If (Not (FrontImage Is Nothing)) Then
                    treenode.Nodes.Add(IMG_FRONT)
                End If
                If Not (BackImage Is Nothing) Then
                    treenode.Nodes.Add(IMG_REAR)
                End If

                If Not (FrontImage2 Is Nothing) Then
                    treenode.Nodes.Add(IMG_FRONTUV)
                End If

                If Not (ImageMerged Is Nothing) Then
                    treenode.Nodes.Add(IMG_MERGED)
                End If
            End If



            fform.TImages.Nodes.Add(treenode)
            xFinestra = fform.Width
        Else
            xFinestra = 0
        End If

        If (Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Or Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE) Then

            If (BackImage.Size.IsEmpty = False) Then


                If (fClearImage) Then
                    PulisciVideata(0)
                End If


                CalcolosizeH(ScanMode, BackImage, sizeH)

                'tolgo i primi 50 del tool strip e tutte scritte dei singoli form
                If (yfinestra + sizeH > (Me.Height - 100)) Then
                    PulisciVideata(0)
                    yfinestra = 0
                End If

                childForms(childForm) = New Form2
                childForms(childForm).Location = New Point(xFinestra, yfinestra)
                yfinestra = yfinestra + Y_CONST
                childForms(childForm).MdiParent = Me

                If (cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE) Then
                    viewCodeline = True
                Else
                    ' se all image la codeline la visualizzo nel fronte
                    viewCodeline = False
                End If

                ' setto la videata con l'immagine
                SetFormImage(childForms(childForm), rc, NrDoc, "Rear", CodelineHW, CodelineSW, viewCodeline, BackImage, ScanMode)

                childForms(childForm).Show()

                If (childForm = MAX_CHILD_FORM) Then
                    childForm = 0
                    fClearImage = True
                Else
                    childForm += 1
                    fClearImage = False
                End If
            End If
        End If

        If (Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Or Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE) Then

            If (FrontImage.Size.IsEmpty = False) Then

                If (fClearImage) Then
                    PulisciVideata(0)
                End If

                CalcolosizeH(ScanMode, FrontImage, sizeH)

              

                If (yfinestra + sizeH > (Me.Height - 100)) Then
                    PulisciVideata(0)
                    yfinestra = 0
                End If

                childForms(childForm) = New Form2
                childForms(childForm).Location = New Point(xFinestra, yfinestra)
                yfinestra = yfinestra + Y_CONST

                childForms(childForm).MdiParent = Me
                ' visualizzo sempre il riquadro della codeline , se la codeline c'è
                viewCodeline = True
                ' setto la videata con l'immagine
                SetFormImage(childForms(childForm), rc, NrDoc, "Front", CodelineHW, CodelineSW, viewCodeline, FrontImage, ScanMode)


                childForms(childForm).Show()

                If (childForm = MAX_CHILD_FORM) Then
                    childForm = 0
                    fClearImage = True
                Else
                    childForm += 1
                    fClearImage = False
                End If
            End If
        End If

        'UV image if present
        If (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR200_AND_UV Or _
            ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR300_AND_UV Or _
            ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR100_AND_UV) Then

            If (ImageMerged.Size.IsEmpty = False) Then

                'se il flag e' selezionato faccio vedere anche l'immagine UV orginale
                If (cApplFunc.ShowUvImage = True) Then

                    If (fClearImage) Then
                        PulisciVideata(0)
                    End If

                    CalcolosizeH(ScanMode, ImageMerged, sizeH)

                    If (yfinestra + sizeH > (Me.Height - 100)) Then
                        PulisciVideata(0)
                        yfinestra = 0
                    End If

                    childForms(childForm) = New Form2
                    childForms(childForm).Location = New Point(xFinestra, yfinestra)
                    yfinestra = yfinestra + Y_CONST
                    childForms(childForm).MdiParent = Me

                    viewCodeline = True
                    ' setto la videata con l'immagine
                    SetFormImage(childForms(childForm), rc, NrDoc, "Front Ultra Violet", CodelineHW, CodelineSW, viewCodeline, FrontImage2, ScanMode)

                    childForms(childForm).Show()

                    If (childForm = MAX_CHILD_FORM) Then
                        childForm = 0
                        fClearImage = True
                    Else
                        childForm += 1
                        fClearImage = False
                    End If
                    ' End If
                End If

                If (fClearImage) Then
                    PulisciVideata(0)
                End If

                childForms(childForm) = New Form2
                childForms(childForm).Location = New Point(xFinestra, yfinestra)
                yfinestra = yfinestra + Y_CONST
                childForms(childForm).MdiParent = Me


                SetFormImage(childForms(childForm), rc, NrDoc, "Front Ultra Violet Merged", CodelineHW, CodelineSW, viewCodeline, ImageMerged, ScanMode)


                childForms(childForm).Show()
                'FrontImage.Dispose()
                If (childForm = MAX_CHILD_FORM) Then
                    childForm = 0
                    fClearImage = True
                Else
                    childForm += 1
                    fClearImage = False
                End If
            End If


        End If

        If (Side = LsFamily.LsDefines.Side.SIDE_NONE_IMAGE) Then

            If (fClearImage) Then
                PulisciVideata(0)
            End If

            childForms(childForm) = New Form2
            childForms(childForm).Location = New Point(xFinestra, yfinestra)
            yfinestra = yfinestra + Y_CONST
            childForms(childForm).MdiParent = Me

            SetFormImage(childForms(childForm), rc, NrDoc, "", CodelineHW, CodelineSW, True, Nothing, ScanMode)


            childForms(childForm).Size = New Size(700, 64)
            childForms(childForm).Show()

            If (childForm = MAX_CHILD_FORM) Then
                childForm = 0
                fClearImage = True
            Else
                childForm += 1
                fClearImage = False
            End If
        End If


        If (cApplFunc.RecPrintRearImg Or cApplFunc.RecPrintFrontImg) Then
            item.Codeline = CodelineHW
            item.FrontImage = FrontImage
            item.RearImage = BackImage
            Receipt.Add(item)
        End If





        ' Forzo una schedulazione dei messagi window
        Application.DoEvents()

    End Sub

    Public Sub ResetValoriDefault()
        If (cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_BW_200 Or cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_BW_300 Or _
                cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_GRAY_200 Or cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_GRAY_300 Or _
                cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_COLOR_200 Or cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_COLOR_300) Then
            cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_200
        End If
    End Sub


    Public Sub SetPrintValue()

        Dim PrintFont1 As Byte
        Dim Endorse_str As String
        Dim PrintFont2 As Byte
        Dim Endorse_str2 As String
        Dim PrintFont3 As Byte
        Dim Endorse_str3 As String
        Dim PrintFont4 As Byte
        Dim Endorse_str4 As String
        Dim PrintFormat As Byte
        Dim LsCfg As LsFamily.LsConfiguration = New LsFamily.LsConfiguration
        Dim PrintValidate As Int16
        Dim rc As Int32


        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_NO
        If LsCfg.InkJet_Printer_4_lines Then
            If cApplFunc.PrintValidate1 Then
                PrintFont1 = cApplFunc.PrintValidate1
                Endorse_str = cApplFunc.Endorse_str
                PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_WITH_LOGO
            Else
                PrintFont1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Endorse_str = ""
            End If

            If cApplFunc.PrintValidate2 Then
                PrintFont2 = cApplFunc.PrintValidate2
                Endorse_str2 = cApplFunc.Endorse_str2
                PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_WITH_LOGO
            Else
                PrintFont2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Endorse_str2 = ""
            End If

            If cApplFunc.PrintValidate3 Then
                PrintFont3 = cApplFunc.PrintValidate3
                Endorse_str3 = cApplFunc.Endorse_str3
                PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_WITH_LOGO
            Else
                PrintFont3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Endorse_str3 = ""
            End If

            If cApplFunc.PrintValidate4 Then
                PrintFont4 = cApplFunc.PrintValidate4
                Endorse_str4 = cApplFunc.Endorse_str4
                PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_WITH_LOGO
            Else
                PrintFont4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Endorse_str4 = ""
            End If

            rc = Ls.LSLoadMultiStrings(hLS, 0, PrintFont1, Endorse_str, PrintFont2, Endorse_str2, PrintFont3, Endorse_str3, PrintFont4, Endorse_str4)

        ElseIf LsCfg.InkJet_Printer Then
            Select Case cApplFunc.PrintValidate
                Case formOptions.ComboFont.COMBO_NO_PRINT
                    PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_NO
                Case formOptions.ComboFont.COMBO_FONT_NORMAL
                    If (cApplFunc.Print_High) Then
                        PrintFormat = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL
                        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_YES
                    Else
                        PrintFormat = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_YES
                    End If
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    If (cApplFunc.Print_High) Then
                        PrintFormat = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_YES
                    Else
                        PrintFormat = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_YES
                    End If
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    If (cApplFunc.Print_High) Then
                        PrintFormat = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL_15_CHAR
                        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_YES
                    Else
                        PrintFormat = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                        PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_YES
                    End If
                Case Else
                    PrintValidate = LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_NO
            End Select

            If (PrintValidate <> LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_NO) Then
                rc = Ls.LSLoadString(hLS, 0, PrintFormat, cApplFunc.Endorse_str, 1, 3)
            End If
        End If

    End Sub

    Public Sub SetSorterValue()
        'Sorters
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_ETH Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_LSCONNECT) Then
            cApplFunc.Sorter = cApplFunc.Sorter_Ls100
        End If
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
            cApplFunc.Sorter = cApplFunc.Sorter_Ls150
        End If
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_LSCONNECT) Then
            cApplFunc.Sorter = cApplFunc.Sorter_Ls520
        End If
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            cApplFunc.Sorter = cApplFunc.Sorter_Ls800
        End If
    End Sub

    Public Sub DoOcr(ByVal FrontImage As Image, ByRef CodelineSw As String)

        Dim len_codeline As Int16
        Dim FontToRead As String = Nothing

        CodelineSw = New String(" ")

        Select Case cApplFunc.OCR_Type
            Case LsFamily.LsDefines.CodelineToRead.READ_CODELINE_SW_OCRA
                FontToRead = "A"
            Case LsFamily.LsDefines.CodelineToRead.READ_CODELINE_SW_OCRB_NUM
                FontToRead = "B"
            Case LsFamily.LsDefines.CodelineToRead.READ_CODELINE_SW_OCRB_ALFANUM
                FontToRead = "C"
            Case LsFamily.LsDefines.CodelineToRead.READ_CODELINE_SW_OCRB_ITALY
                FontToRead = "F"
            Case LsFamily.LsDefines.CodelineToRead.READ_CODELINE_SW_E13B
                FontToRead = "E"
            Case LsFamily.LsDefines.CodelineToRead.READ_CODELINE_SW_E13B_X_OCRB
                FontToRead = "X"

        End Select

        len_codeline = 256
        Ls.LSCodelineReadFromBitmap(0, FrontImage, FontToRead, cApplFunc.OCR_Unit, cApplFunc.OCR_x, cApplFunc.OCR_y, cApplFunc.OCR_w, cApplFunc.OCR_h, 1, CodelineSw)
    End Sub

    Public Sub DoBarcode(ByVal FrontImage As Image, ByRef CodelineSw As String)
        Dim BarcodeToread As Int16

        CodelineSw = New String(" ")

        If (cApplFunc.Barcode_Type) Then
            Select Case cApplFunc.Barcode_Type
                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_2_OF_5
                    BarcodeToread = 50 'LSAPI_READ_BARCODE_2_OF_5
                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE128
                    BarcodeToread = 52 'LSAPI_READ_BARCODE_CODE128'
                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE39
                    BarcodeToread = 51 'LSAPI_READ_BARCODE_CODE39'
                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_EAN13
                    BarcodeToread = 53 'LSAPI_READ_BARCODE_EAN13' 
            End Select

        End If
        Ls.LSReadBarcodeFromBitmap(0, FrontImage, BarcodeToread, cApplFunc.Barcode_x, cApplFunc.Barcode_y, cApplFunc.Barcode_w, cApplFunc.Barcode_h, CodelineSw)
    End Sub

    Private Sub OneDocHandle()

        Dim rcDocH As Int32
        Dim LsCfg As LsFamily.LsConfiguration = New LsFamily.LsConfiguration
        Dim NrDoc As UInt32
        Dim CodelineHw As String = Nothing
        Dim CodelineSw As String = Nothing
        Dim len_codeline As Int16
        Dim FrontImage As Image = Nothing
        Dim BackImage As Image = Nothing
        Dim FrontImage2 As Image = Nothing
        Dim ImageMerged As Image = Nothing
        Dim rc As Int32
        Dim PrintValidate As Int16
        Dim Stamp As Int16

        PulisciVideata(1)

        rc = LsFamily.LsReply.LS_OKAY

        'se avevo selezionato al giro precende lo scanner A4 rimaneva il suo scanmode selezionato
        ResetValoriDefault()


        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            MultiDocHandle(True)

        Else
            rc = Ls.LSConnect(0, LsUnitType, hLS, True)
            If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

                rc = Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_ERROR)
                rc = Ls.LSIdentify(hLS, 0, LsCfg, 0, 0, 0, 0)

                'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB) Then
                rc = Ls.LSConfigDoubleLeafingAndDocLength(hLS, 0, cApplFunc.DuobleLeafingLevel, cApplFunc.Sensibility, cApplFunc.DocMin, cApplFunc.DocMax)

                If (rc <> LsFamily.LsReply.LS_OKAY) Then
                    MessageBox.Show(cApplFunc.CheckReply(rc, "LSConfigDoubleLeafingAndDocLength"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

                'Else

                '    If (cApplFunc.DuobleLeafingLevel = LsFamily.LsDefines.DoubleLeafing.DOUBLE_LEAFING_DISABLE) Then
                '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingLevel)
                '    Else
                '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingValue)
                '    End If
                'End If

                rc = Ls.LSDisableWaitDocument(hLS, 0, cApplFunc.WaitDoc)

                'setto i valori di stampa 
                SetPrintValue()

                If (cApplFunc.FrontStamp) Then
                    Stamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
                End If

                'setto i valori dei sorter delle varie macchine 
                SetSorterValue()

                'Uv
                If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
                    If (LsCfg.ScannerUltraViolet) Then
                        Ls.LSModifyPWMUltraViolet(hLS, 0, cApplFunc.PWMvalue, cApplFunc.HightContrast, 0)
                    End If
                End If

                rcDocH = Ls.LSDocHandle(hLS, 0, Stamp, PrintValidate, cApplFunc.Codeline_HW, cApplFunc.Side, cApplFunc.ScanMode, LsFamily.LsDefines.Feeder.FEED_AUTO, cApplFunc.Sorter, LsFamily.LsDefines.Wait.WAIT_YES, cApplFunc.Beep, NrDoc, LsFamily.LsDefines.ScanDocType.SCAN_PAPER_DOCUMENT)
                If (rcDocH = LsFamily.LsReply.LS_OKAY Or rcDocH = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then

                    If (rcDocH = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then
                        MessageBox.Show(cApplFunc.CheckReply(rcDocH, "LSDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                    If (cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR Or _
                        cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_E13B_MICR_WITH_OCR) Then
                        CodelineHw = New String(" ")

                        len_codeline = 256
                        rc = Ls.LSReadCodeline(hLS, 0, CodelineHw)
                        If (rc = LsFamily.LsReply.LS_OKAY) Then
                        End If
                    End If

                    'In FrontImage2 ho gia' l'immagine Merge tra UV e Gray
                    ' rc = Ls.LSReadImage(hLS, 0, LsFamily.LsDefines.ClearBlack.CLEAR_BLACK_YES, cApplFunc.Side, NrDoc, FrontImage, BackImage, FrontImage2, Nothing)
                    rc = Ls.LSReadImage(hLS, 0, cApplFunc.ClearBlack, cApplFunc.Side, NrDoc, FrontImage, BackImage, FrontImage2, Nothing, ImageMerged, cApplFunc.ShowUvImage)
                    If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then


                        'If selected read the OCR codeline
                        If (cApplFunc.CodelineType = ApplClass.DECODE_OCR) Then

                            DoOcr(FrontImage, CodelineSw)

                        ElseIf cApplFunc.CodelineType = ApplClass.DECODE_BARCODE Then

                            DoBarcode(FrontImage, CodelineSw)

                        End If
                    End If

                    '  Salvo le immagini su file
                    If cApplFunc.SaveMode = LsFamily.LsDefines.ImageSave.IMAGE_SAVE_BOTH Then
                        If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then

                            'Non ho implementato il Salvataggio dele MergeGrayAndUv su disco perche' ci metteva troppo 
                            'dovevo riusare la MergeGrayandUv e risalvare con la SaveDib
                            Ls.LSSaveImage(hLS, 0, FrontImage, ImagePath + "\Front_Image", cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE)

                            If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
                                If (LsCfg.ScannerUltraViolet And (cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR100_AND_UV Or _
                                                                  cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR200_AND_UV)) Then
                                    Ls.LSSaveImage(hLS, 0, FrontImage2, ImagePath + "\Front_ImageUV", cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_FRONT_UV)


                                End If
                            End If

                        End If
                        If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then

                            Ls.LSSaveImage(hLS, 0, BackImage, ImagePath + "\Rear_Image", cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_BACK_IMAGE)
                        End If
                    End If

                    'quando facevo DoubleLeafingWarnig mi tornava sempre -22
                    If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then
                        NrDoc = 1 'Convert.ToUInt32(1) ' BACO di VB.net 2003 !!!
                        ShowCodelineAndImages(cApplFunc.SaveMode, cApplFunc.Side, cApplFunc.ScanMode, rcDocH, NrDoc, CodelineHw, CodelineSw, FrontImage, BackImage, FrontImage2, ImageMerged)
                        'CtsIQA.CheckImage(1, FrontImage, BackImage, Nothing, Nothing)
                    End If
                Else
                    If (rcDocH = LsFamily.LsReply.LS_FEEDER_EMPTY) Then
                        MessageBox.Show(cApplFunc.CheckReply(rcDocH, "LSDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show(cApplFunc.CheckReply(rcDocH, "LSDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If

                End If

                rc = Ls.LSDisconnect(hLS, 0)
            Else
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If

    End Sub



    '    Public Sub Ls515CodelineRead(ByVal sender As Object, ByVal e As LsFamily.LsApiEventArgs)
    Public Shared Function Ls515CodelineRead(ByVal CodelineReadHW As String, ByVal NrDoc As Int32, ByRef Pocket As Int32, ByRef Font As LsFamily.LsDefines.PrintFont, ByRef StringToPrint As String)

        ' Pocket selection
        Pocket = CurrPocket
        If CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_2 Then
            CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1
        Else
            CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_2
        End If

        ' Font and print selection
        Select Case cApplFunc.PrintValidate
            Case 0
                Font = 0
                StringToPrint = Nothing

            Case 1
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case 2
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case 3
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL_15_CHAR
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case Else
                Font = 0
                StringToPrint = Nothing
        End Select

        Return True
    End Function


    Public Shared Function Ls800CodelineRead(ByVal CodelineReadHW As String, ByVal NrDoc As Int32, ByRef Pocket As Int32, ByRef Font As LsFamily.LsDefines.PrintFont, ByRef StringToPrint As String)

        ' Pocket selection
        Pocket = CurrPocket

        ' Check the pocket
        If (cApplFunc.Sorter_Ls800 = LsFamily.LsDefines.Sorter.SORTER_CIRCULAR) Then
            If CurrPocket >= (NrTot_Pocket + LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED) Then
                'CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1_SELECTED
                CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED
            Else
                CurrPocket += 1
            End If
        End If


        ' Font and print selection
        Select Case cApplFunc.PrintValidate
            Case 0
                Font = 0
                StringToPrint = Nothing

            Case 1
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case 2
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case 3
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL_15_CHAR
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case Else
                Font = 0
                StringToPrint = Nothing
        End Select

        Return True
    End Function



    Public Shared Function Ls800ImageRead(ByVal hImage As Bitmap, ByVal CodelineReadHW As String, ByVal NrDoc As Int32, ByRef Pocket As Int32, ByRef Font As LsFamily.LsDefines.PrintFont, ByRef StringToPrint As String)

        ' Pocket selection
        Pocket = CurrPocket

        ' Check the pocket
        If (cApplFunc.Sorter_Ls800 = LsFamily.LsDefines.Sorter.SORTER_CIRCULAR) Then
            If CurrPocket >= (NrTot_Pocket + LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED) Then
                'CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1_SELECTED
                CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED
            Else
                CurrPocket += 1
            End If
        End If


        ' Font and print selection
        Select Case cApplFunc.PrintValidate
            Case 0
                Font = 0
                StringToPrint = Nothing

            Case 1
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case 2
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_BOLD
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case 3
                If (cApplFunc.Print_High) Then
                    Font = LsFamily.LsDefines.PrintFont.PRINT_UP_FORMAT_NORMAL_15_CHAR
                Else
                    Font = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                End If
                StringToPrint = String.Copy(cApplFunc.Endorse_str)

            Case Else
                Font = 0
                StringToPrint = Nothing
        End Select

        Return True
    End Function

    Private Sub RetainedMode()
        Dim rc As Int32
        Dim rcDocH As Int32
        Dim LsCfg As LsFamily.LsConfiguration = New LsFamily.LsConfiguration
        Dim NrDoc As UInt32
        Dim CodelineHw As String = Nothing
        Dim CodelineSw As String = Nothing
        Dim len_codeline As Int16
        Dim FrontImage As Image = Nothing
        Dim BackImage As Image = Nothing
        Dim FrontImage2 As Image = Nothing
        Dim PrintValidate As Int16
        Dim Stamp As Int16
        Dim BarcodeToread As Int16
        Dim aa As formRetainedOption = New formRetainedOption
        Dim NomeFileImmagine As String = New String(" ", 256)
        Dim NomeFileImmagineRetro As String = New String(" ", 256)
        Dim estensione As String = New String(" ", 256)

        Dim IndImgF As Int16
        Dim IndImgR As Int16

        rc = Ls.LSConnect(0, LsUnitType, hLS, True)
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_ERROR)
            rc = Ls.LSIdentify(hLS, 0, LsCfg, 0, 0, 0, 0)

            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB) Then
            rc = Ls.LSConfigDoubleLeafingAndDocLength(hLS, 0, cApplFunc.DuobleLeafingLevel, cApplFunc.Sensibility, cApplFunc.DocMin, cApplFunc.DocMax)
            'Else
            '    If (cApplFunc.DuobleLeafingLevel = LsFamily.LsDefines.DoubleLeafing.DOUBLE_LEAFING_DISABLE) Then
            '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingLevel)
            '    Else
            '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingValue)
            '    End If
            'End If
            rc = Ls.LSDisableWaitDocument(hLS, 0, cApplFunc.WaitDoc)

            'setto i valori di stampa 
            SetPrintValue()

            If (cApplFunc.FrontStamp) Then
                Stamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
            End If

            'Sorters
            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_ETH) Then
            'cApplFunc.Sorter = cApplFunc.Sorter_Ls100
            'End If
            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB) Then
            'cApplFunc.Sorter = cApplFunc.Sorter_Ls150
            'End If
            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB) Then
            'cApplFunc.Sorter = cApplFunc.Sorter_Ls520
            'End If
            'forzo il sorter a Retained 
            cApplFunc.Sorter = cApplFunc.Sorter_HoldDocument


            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB) Then
            'rcDocH = Ls.LSDocHandle(hLS, 0, Stamp, PrintValidate, cApplFunc.Codeline_HW, cApplFunc.Side, cApplFunc.ScanMode, LsFamily.LsDefines.Feeder.FEED_FROM_PATH, cApplFunc.Sorter, LsFamily.LsDefines.Wait.WAIT_YES, cApplFunc.Beep, NrDoc)
            'Else
            rcDocH = Ls.LSDocHandle(hLS, 0, Stamp, PrintValidate, cApplFunc.Codeline_HW, cApplFunc.Side, cApplFunc.ScanMode, LsFamily.LsDefines.Feeder.FEED_AUTO, cApplFunc.Sorter, LsFamily.LsDefines.Wait.WAIT_YES, cApplFunc.Beep, NrDoc, LsFamily.LsDefines.ScanDocType.SCAN_PAPER_DOCUMENT)
            'End If


            If (rcDocH = LsFamily.LsReply.LS_OKAY Or rcDocH = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then

                If (cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR) Then
                    CodelineHw = New String(" ")

                    len_codeline = 256
                    rc = Ls.LSReadCodeline(hLS, 0, CodelineHw)
                    If (rc = LsFamily.LsReply.LS_OKAY) Then
                    End If
                End If

                rc = Ls.LSReadImage(hLS, 0, cApplFunc.ClearBlack, cApplFunc.Side, NrDoc, FrontImage, BackImage, FrontImage2, Nothing)
                If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then

                    'If selected read the OCR codeline
                    If (cApplFunc.CodelineType = ApplClass.DECODE_OCR) Then

                        DoOcr(FrontImage, CodelineSw)

                    ElseIf cApplFunc.CodelineType = ApplClass.DECODE_BARCODE Then
                        'Codeline = cApplFunc.Barcode_Type
                        CodelineSw = New String(" ")

                        If (cApplFunc.Barcode_Type) Then
                            Select Case cApplFunc.Barcode_Type
                                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_2_OF_5
                                    BarcodeToread = 50 'LSAPI_READ_BARCODE_2_OF_5
                                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE128
                                    BarcodeToread = 52 'LSAPI_READ_BARCODE_CODE128'
                                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE39
                                    BarcodeToread = 51 'LSAPI_READ_BARCODE_CODE39'
                                Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_EAN13
                                    BarcodeToread = 53 'LSAPI_READ_BARCODE_EAN13' 
                            End Select

                        End If
                        Ls.LSReadBarcodeFromBitmap(0, FrontImage, BarcodeToread, cApplFunc.Barcode_x, cApplFunc.Barcode_y, cApplFunc.Barcode_w, cApplFunc.Barcode_h, CodelineSw)
                    Else
                    End If
                End If

                '  Salvo le immagini su file
                If (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_BMP) Then
                    estensione = ".bmp"
                ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_JPEG) Then
                    estensione = ".jpg"
                ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT Or _
                        cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_1DIM Or _
                        cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_2DIM Or _
                        cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP4 Or _
                        cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_TIF) Then
                    estensione = ".tif"
                End If
                If cApplFunc.SaveMode = LsFamily.LsDefines.ImageSave.IMAGE_SAVE_BOTH Then
                    If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then
                        IndImgF = 0
                        NomeFileImmagine = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FF" + estensione


                        Ls.LSSaveImage(hLS, 0, FrontImage, NomeFileImmagine, cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE)
                    End If
                    If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then
                        IndImgR = 0
                        NomeFileImmagineRetro = ImagePath + "\Image_" + IndImgR.ToString("0000") + "BB" + estensione

                        Ls.LSSaveImage(hLS, 0, BackImage, NomeFileImmagineRetro, cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_BACK_IMAGE)
                    End If
                End If

                NrDoc = 1 'Convert.ToUInt32(1) ' BACO di VB.net 2003 !!!
                ShowCodelineAndImages(cApplFunc.SaveMode, cApplFunc.Side, cApplFunc.ScanMode, rcDocH, NrDoc, CodelineHw, CodelineSw, FrontImage, BackImage, Nothing, Nothing)
                'CtsIQA.CheckImage(1, FrontImage, BackImage, Nothing, Nothing)
            Else
                MessageBox.Show(cApplFunc.CheckReply(rcDocH, "LSDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If (rcDocH = LsFamily.LsReply.LS_OKAY Or rcDocH = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then

                FrontImage = Nothing
                BackImage = Nothing
                'appear form retained option
                aa.ShowDialog(Me)

                'rifaccio connect perche' ho fatto una peripheral identify nell'altro form
                'non faccio il reset in questo caso
                rc = Ls.LSConnect(0, LsUnitType, hLS, False)

                'print validate ?

                'setto i valori di stampa 
                SetPrintValue()

                'If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then
                'rifaccio DocHandle con i parametri per il retained 
                rcDocH = Ls.LSDocHandle(hLS, 0, cApplFunc.RetainedFrontStamp, PrintValidate, 0, cApplFunc.RetainedSide, cApplFunc.ScanMode, LsFamily.LsDefines.Feeder.FEED_FROM_PATH, cApplFunc.RetainedSorter, LsFamily.LsDefines.Wait.WAIT_YES, cApplFunc.Beep, NrDoc, LsFamily.LsDefines.ScanDocType.SCAN_PAPER_DOCUMENT)
                If (rcDocH = LsFamily.LsReply.LS_OKAY Or rcDocH = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then
                    If (cApplFunc.RetainedSorter <> LsFamily.LsDefines.Sorter.SORTER_DOC_EJECTED) Then
                        If (cApplFunc.RetainedSide <> LsFamily.LsDefines.Side.SIDE_NONE_IMAGE) Then
                            rc = Ls.LSReadImage(hLS, 0, cApplFunc.ClearBlack, cApplFunc.RetainedSide, NrDoc, FrontImage, BackImage, FrontImage2, Nothing)
                        End If

                    End If

                    If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING) Then
                        NrDoc = 1 'Convert.ToUInt32(1) ' BACO di VB.net 2003 !!!
                        '  Salvo le immagini dp il retained  su file
                        If (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_BMP) Then
                            estensione = ".bmp"
                        ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_JPEG) Then
                            estensione = ".jpg"
                        ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT Or _
                                cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_1DIM Or _
                                cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_2DIM Or _
                                cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP4 Or _
                                cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_TIF) Then
                            estensione = ".tif"
                        End If
                        If cApplFunc.SaveMode = LsFamily.LsDefines.ImageSave.IMAGE_SAVE_BOTH Then
                            If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then
                                IndImgF = 1
                                NomeFileImmagine = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FF" + estensione


                                Ls.LSSaveImage(hLS, 0, FrontImage, NomeFileImmagine, cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE)
                            End If
                            If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then
                                IndImgR = 1
                                NomeFileImmagineRetro = ImagePath + "\Image_" + IndImgR.ToString("0000") + "BB" + estensione

                                Ls.LSSaveImage(hLS, 0, BackImage, NomeFileImmagineRetro, cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_BACK_IMAGE)
                            End If
                        End If

                        NrDoc = 2
                        ShowCodelineAndImages(cApplFunc.SaveMode, cApplFunc.RetainedSide, cApplFunc.ScanMode, rcDocH, NrDoc, "", "", FrontImage, BackImage, Nothing, Nothing)
                    Else
                        MessageBox.Show(cApplFunc.CheckReply(rc, "LSReadImage"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show(cApplFunc.CheckReply(rcDocH, "LSDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                'Else
                '    MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                'End If
            End If
            rc = Ls.LSDisconnect(hLS, 0)
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        'End If
    End Sub

    Private Sub MultiDocHandle(ByVal fFeederEmpty As Boolean)
        Dim rc As Int32
        Dim LsCfg As LsFamily.LsConfiguration = New LsFamily.LsConfiguration
        Dim Codeline As Int16
        Dim pos_x As Double
        Dim pos_y As Double
        Dim pos_w As Double
        Dim pos_h As Double
        Dim NrDoc As UInt32
        Dim fileFront As String = New String(" ", 256)
        Dim fileRear As String = New String(" ", 256)
        Dim fileFront2 As String = New String(" ", 256)
        Dim CodelineSw As String = Nothing
        Dim CodelineHw As String = Nothing

        Dim FrontImage As Bitmap = Nothing
        Dim BackImage As Bitmap = Nothing
        Dim FrontImage2 As Bitmap = Nothing
        Dim ImageMerged As Bitmap = Nothing
        Dim PrintValidate As Int16
        Dim Stamp As Int16
        Dim DocPerMin As Int32
        Dim timeStart As Int32
        Dim timeEnd As Int32
        'Dim cb As LsFamily.LsApi.pOnCodeline = AddressOf OnCodeline
        Dim cb As LsFamily.LS515OnCodelineCallBack
        Dim cb800c As LsFamily.LS800OnCodelineCallBack
        Dim cb800i As LsFamily.LS800OnImageCallBack

        Dim nrDocParziali As UInt32
        Dim NomeFileImmagineMerge As String = New String(" ", 256)


        lNrDocProc.Text = "Doc. per Minute : "

        rc = LsFamily.LsReply.LS_OKAY

        'se avevo selezionato al giro precende lo scanner A4 rimaneva il suo scanmode selezionato
        ResetValoriDefault()

        rc = Ls.LSConnect(0, LsUnitType, hLS, True)
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_ERROR)

            'I do a inquiry for keep the unit configuration
            rc = Ls.LSIdentify(hLS, 0, LsCfg, Nothing, Nothing, Nothing, Nothing)
            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB) Then
            rc = Ls.LSConfigDoubleLeafingAndDocLength(hLS, 0, cApplFunc.DuobleLeafingLevel, cApplFunc.Sensibility, cApplFunc.DocMin, cApplFunc.DocMax)

            If (rc <> LsFamily.LsReply.LS_OKAY) Then
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSConfigDoubleLeafingAndDocLength"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            'Else
            '    If (cApplFunc.DuobleLeafingLevel = LsFamily.LsDefines.DoubleLeafing.DOUBLE_LEAFING_DISABLE) Then
            '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingLevel)
            '    Else
            '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingValue)
            '    End If
            'End If
            rc = Ls.LSDisableWaitDocument(hLS, 0, cApplFunc.WaitDoc)

            'setto i valori di stampa 
            SetPrintValue()

            ' Set type codeline to Read
            If (cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR Or _
                cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_E13B_MICR_WITH_OCR) Then
                CodelineHw = New String(" ")
                Codeline = cApplFunc.Codeline_HW
                pos_x = 0
                pos_y = 0
                pos_w = 0
                pos_h = 0
            End If

            If (cApplFunc.FrontStamp) Then
                Stamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
            End If

            'setto i valori dei sorter delle varie macchine 
            SetSorterValue()


            'Uv
            If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
                If (LsCfg.ScannerUltraViolet) Then
                    Ls.LSModifyPWMUltraViolet(hLS, 0, cApplFunc.PWMvalue, cApplFunc.HightContrast, 0)
                End If
            End If

            DocPerMin = 0
            timeStart = Environment.TickCount()

            If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
                If (Codeline = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR) Then
                    cb800c = AddressOf Ls800CodelineRead
                    cb800i = Nothing
                Else
                    cb800c = Nothing
                    cb800i = AddressOf Ls800ImageRead
                End If

                ' Set the initial pocket
                NrTot_Pocket = LsCfg.Sorters_Nr * 3
                If cApplFunc.Sorter = LsFamily.LsDefines.Sorter.SORTER_SEQUENTIAL Then
                    'CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1_SELECTED
                    CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED
                ElseIf cApplFunc.Sorter = LsFamily.LsDefines.Sorter.SORTER_CIRCULAR Then
                    'CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1_SELECTED
                    CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED
                Else
                    CurrPocket = cApplFunc.Sorter
                End If

                rc = Ls.LS800AutoDocHandle(hLS, 0, PrintValidate, Codeline, cApplFunc.Side, cApplFunc.ScanMode, cApplFunc.ScanMode, cApplFunc.ClearBlack, NrDocToProcess, cApplFunc.SaveMode, ImagePath, "Image_", LsFamily.LsDefines.Unit.UNIT_MM, pos_x, pos_y, pos_w, pos_h, cApplFunc.FileFormat, Convert.ToInt16(128), LsFamily.LsDefines.FileAttribute.SAVE_REPLACE, 0, cApplFunc.Beep, cb800c, cb800i)
            Else
                cb = AddressOf Ls515CodelineRead
                CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1

                rc = Ls.LSAutoDocHandle(hLS, 0, Stamp, PrintValidate, Codeline, cApplFunc.Side, cApplFunc.ScanMode, cApplFunc.Sorter, 0, cApplFunc.ClearBlack, cApplFunc.SaveMode, ImagePath, "Image_", LsFamily.LsDefines.Unit.UNIT_MM, pos_x, pos_y, pos_w, pos_h, cApplFunc.FileFormat, cApplFunc.Quality, LsFamily.LsDefines.FileAttribute.SAVE_REPLACE, 0, LsFamily.LsDefines.Wait.WAIT_NO, cApplFunc.Beep, cb)
            End If
            If (rc = LsFamily.LsReply.LS_OKAY) Then

                Do
                    NomeFileImmagineMerge = ImagePath + "\Image_" + nrDocParziali.ToString("0000") + "GUV" + ".jpg"
                    rc = Ls.LSGetDocData(hLS, 0, NrDoc, fileFront, fileRear, fileFront2, NomeFileImmagineMerge, FrontImage, BackImage, FrontImage2, Nothing, ImageMerged, CodelineSw, CodelineHw, cApplFunc.ShowUvImage, False, cApplFunc.FileFormat)

                    If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_DOUBLE_LEAFING_WARNING Or _
                        rc = LsFamily.LsReply.LS_SORTER1_FULL Or rc = LsFamily.LsReply.LS_SORTER2_FULL Or _
                        ((rc >= LsFamily.LsReply.LS_SORTER_1_POCKET_1_FULL) And (rc <= LsFamily.LsReply.LS_SORTER_7_POCKET_3_FULL))) Then
                        Dim FontToRead As String = Nothing

                        timeEnd = Environment.TickCount()
                        DocPerMin += 1

                        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then

                            ' Check the sorter full
                            If (rc >= LsFamily.LsReply.LS_SORTER_1_POCKET_1_FULL) And (rc <= LsFamily.LsReply.LS_SORTER_7_POCKET_3_FULL) Then

                                If (cApplFunc.Sorter_Ls800 = LsFamily.LsDefines.Sorter.SORTER_SEQUENTIAL) Then

                                    ' Stop on last pocket
                                    If CurrPocket = (NrTot_Pocket + LsFamily.LsDefines.Sorter.SORTER_POCKET_0_SELECTED) Then
                                        rc = Ls.LSStopAutoDocHandle(hLS, 0)
                                    Else
                                        ' increase the CurrPocket ONLY if equal to sorter full !
                                        If CurrPocket = rc Then
                                            CurrPocket += 1
                                        End If
                                    End If

                                Else
                                    ' In the other case stop the process
                                    Ls.LSStopAutoDocHandle(hLS, 0)
                                End If
                            End If
                        End If

                        If cApplFunc.CodelineType = ApplClass.DECODE_OCR Then

                            DoOcr(FrontImage, CodelineSw)

                        ElseIf cApplFunc.CodelineType = ApplClass.DECODE_BARCODE Then

                            DoBarcode(FrontImage, CodelineSw)

                        End If
                        'End If

                        'incremento il NrDoc per visualizzarlo a video
                        'la GetDocData dovrebbe tornarlo ???
                        'su Ls100 si incrementa sempre il nr doc e io rimango fregato ! 
                        nrDocParziali = nrDocParziali + 1

                        ShowCodelineAndImages(cApplFunc.SaveMode, cApplFunc.Side, cApplFunc.ScanMode, rc, nrDocParziali, CodelineHw, CodelineSw, FrontImage, BackImage, FrontImage2, ImageMerged)

                        'If Not (FrontImage Is Nothing) Then
                        '    FrontImage.Dispose()
                        '    FrontImage = Nothing
                        'End If

                        ' force Ok for repeat the GetDocData()
                        rc = LsFamily.LsReply.LS_OKAY
                    Else
                        If (fFeederEmpty And rc = LsFamily.LsReply.LS_FEEDER_EMPTY) Then
                            MessageBox.Show(cApplFunc.CheckReply(rc, "LSGetDocData"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                        If (rc <> LsFamily.LsReply.LS_FEEDER_EMPTY) Then
                            MessageBox.Show(cApplFunc.CheckReply(rc, "LSGetDocData"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                    End If

                Loop While ((rc = LsFamily.LsReply.LS_OKAY) And (NrDocToProcess = 0))

            Else
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSAutoDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            rc = Ls.LSDisconnect(hLS, 0)
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        If DocPerMin Then
            DocPerMin = DocPerMin / ((timeEnd - timeStart) / 60000)
        End If
        lNrDocProc.Text = "Doc. per Minute : " + DocPerMin.ToString

    End Sub


    'Private Sub DoAutoFeed()
    '    Dim rc As Int32
    '    Dim UnitStatus As LsFamily.LsUnitStatus
    '    Dim check As Boolean = True

    '    PulisciVideata(1)

    '    rc = Ls.LSConnect(0, LsUnitType, hLS, True)
    '    If (rc = LsFamily.LsReply.LS_OKAY) Then

    '        UnitStatus = New LsFamily.LsUnitStatus
    '        ' Dim d1 As DateTime = DateTime.Now
    '        While (rc = LsFamily.LsReply.LS_OKAY And fAutoFeed)

    '            'LsCfg.Size = Marshal.SizeOf(LsApi.LsConfiguration)
    '            rc = Ls.LSUnitStatus(hLS, 0, UnitStatus)
    '            'Il reply di rc = LsFamily.LsReply.LS_FEEDER_EMPTY lo converto in OK
    '            If (rc = LsFamily.LsReply.LS_FEEDER_EMPTY) Then
    '                rc = LsFamily.LsReply.LS_OKAY
    '            End If

    '            If (rc = LsFamily.LsReply.LS_OKAY And UnitStatus.Photo_Feeder) Then

    '                rc = Ls.LSDisconnect(hLS, 0)
    '                'Invoke(new EventHandler(miDocHandle_Click), new object[] {sender, e});
    '                MultiDocHandle(False)
    '                rc = Ls.LSConnect(0, LsUnitType, hLS, True)
    '            Else
    '                System.Threading.Thread.Sleep(100)
    '            End If


    '            Application.DoEvents()


    '        End While

    '        rc = Ls.LSDisconnect(hLS, 0)



    '    Else
    '        MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    End If

    'End Sub


    Private Sub DoAutoFeed()


        Dim ii As Integer
        Dim ContaSorterFull As Integer
        Dim rc As Short
        Dim LsCfg As LsFamily.LsConfiguration = New LsFamily.LsConfiguration
        Dim PrintValidate As Int16
        Dim NrDoc As Short
        Dim Codeline As Int16
        Dim pos_x As Double
        Dim pos_y As Double
        Dim pos_w As Double
        Dim pos_h As Double
        Dim fileFront As String = New String(" ", 256)
        Dim fileRear As String = New String(" ", 256)
        Dim fileFront2 As String = New String(" ", 256)
        Dim CodelineSw As String = Nothing
        Dim CodelineHw As String = Nothing
        Dim FrontImage As Bitmap = Nothing
        Dim BackImage As Bitmap = Nothing
        Dim FrontImage2 As Bitmap = Nothing
        Dim ImageMerged As Bitmap = Nothing
        Dim Stamp As Int16
        Dim DocPerMin As Int32
        Dim timeStart As Int32
        Dim cb As LsFamily.LS515OnCodelineCallBack
        Dim cb800c As LsFamily.LS800OnCodelineCallBack
        Dim cb800i As LsFamily.LS800OnImageCallBack
        Dim NomeFileImmagine As String = New String(" ", 256)
        Dim NomeFileImmagineRetro As String = New String(" ", 256)
        Dim NomeFileImmagineFront2 As String = New String(" ", 256)
        Dim NomeFileImmagineMerge As String = New String(" ", 256)
        Dim IndImgF As Int16
        Dim IndImgR As Int16
        Dim FontToRead As String = Nothing
        Dim BarcodeToread As Int16

        ContaSorterFull = 0
        ii = 1
   
        rc = LsFamily.LsReply.LS_OKAY

        'se avevo selezionato al giro precende lo scanner A4 rimaneva il suo scanmode selezionato
        ResetValoriDefault()


        rc = Ls.LSConnect(0, LsUnitType, hLS, True)

        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_ERROR)

            'I do a inquiry for keep the unit configuration
            rc = Ls.LSIdentify(hLS, 0, LsCfg, Nothing, Nothing, Nothing, Nothing)
            'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB) Then
            rc = Ls.LSConfigDoubleLeafingAndDocLength(hLS, 0, cApplFunc.DuobleLeafingLevel, cApplFunc.Sensibility, cApplFunc.DocMin, cApplFunc.DocMax)

            If (rc <> LsFamily.LsReply.LS_OKAY) Then
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSConfigDoubleLeafingAndDocLength"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            'Else
            '    If (cApplFunc.DuobleLeafingLevel = LsFamily.LsDefines.DoubleLeafing.DOUBLE_LEAFING_DISABLE) Then
            '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingLevel)
            '    Else
            '        rc = Ls.LSDoubleLeafingSensibility(hLS, 0, cApplFunc.DuobleLeafingValue)
            '    End If
            'End If
            rc = Ls.LSDisableWaitDocument(hLS, 0, cApplFunc.WaitDoc)

            SetPrintValue()

            ' Set type codeline to Read
            If (cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR Or _
                cApplFunc.Codeline_HW = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_E13B_MICR_WITH_OCR) Then
                CodelineHw = New String(" ")
                Codeline = cApplFunc.Codeline_HW
                pos_x = 0
                pos_y = 0
                pos_w = 0
                pos_h = 0
            End If

            If (cApplFunc.FrontStamp) Then
                Stamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
            End If

            'setto i valori dei sorter delle varie macchine 
            SetSorterValue()

            'Uv
            If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
                If (LsCfg.ScannerUltraViolet) Then
                    Ls.LSModifyPWMUltraViolet(hLS, 0, cApplFunc.PWMvalue, cApplFunc.HightContrast, 0)
                End If


            End If

            DocPerMin = 0
            timeStart = Environment.TickCount()

            If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
                If (Codeline = LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR) Then
                    cb800c = AddressOf Ls800CodelineRead
                    cb800i = Nothing
                Else
                    cb800c = Nothing
                    cb800i = AddressOf Ls800ImageRead
                End If

                ' Set the initial pocket
                NrTot_Pocket = LsCfg.Sorters_Nr * 3
                If cApplFunc.Sorter = LsFamily.LsDefines.Sorter.SORTER_SEQUENTIAL Then
                    CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1_SELECTED
                ElseIf cApplFunc.Sorter = LsFamily.LsDefines.Sorter.SORTER_CIRCULAR Then
                    CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1_SELECTED
                Else
                    CurrPocket = cApplFunc.Sorter
                End If

                rc = Ls.LS800AutoDocHandle(hLS, 0, PrintValidate, Codeline, cApplFunc.Side, cApplFunc.ScanMode, cApplFunc.ScanMode, cApplFunc.ClearBlack, NrDocToProcess, cApplFunc.SaveMode, ImagePath, "Image_", LsFamily.LsDefines.Unit.UNIT_MM, pos_x, pos_y, pos_w, pos_h, cApplFunc.FileFormat, Convert.ToInt16(0), LsFamily.LsDefines.FileAttribute.SAVE_REPLACE, 0, cApplFunc.Beep, cb800c, cb800i)
            Else
                cb = AddressOf Ls515CodelineRead
                CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1

                rc = Ls.LSAutoDocHandle(hLS, 0, Stamp, PrintValidate, Codeline, cApplFunc.Side, cApplFunc.ScanMode, cApplFunc.Sorter, 0, cApplFunc.ClearBlack, LsFamily.LsDefines.ImageSave.IMAGE_SAVE_HANDLE, ImagePath, "Image_", LsFamily.LsDefines.Unit.UNIT_MM, pos_x, pos_y, pos_w, pos_h, cApplFunc.FileFormat, 2, LsFamily.LsDefines.FileAttribute.SAVE_REPLACE, 0, LsFamily.LsDefines.Wait.WAIT_NO, cApplFunc.Beep, cb)
            End If
        End If

        If rc = LsFamily.LsReply.LS_OKAY Then

            While (fstop = False)
                'While (fstop = False And fAutoFeed)

                'creo il nome delle immagini per salvarle su disco 
                If (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_BMP) Then
                    NomeFileImmagine = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FF" + ".bmp"
                    NomeFileImmagineRetro = ImagePath + "\Image_" + IndImgR.ToString("0000") + "BB" + ".bmp"
                    NomeFileImmagineFront2 = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FN" + ".bmp"
                    NomeFileImmagineMerge = ImagePath + "\Image_" + IndImgF.ToString("0000") + "GUV" + ".bmp"

                ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_JPEG) Then
                    NomeFileImmagine = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FF" + ".jpg"
                    NomeFileImmagineRetro = ImagePath + "\Image_" + IndImgR.ToString("0000") + "BB" + ".jpg"
                    NomeFileImmagineFront2 = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FN" + ".jpg"
                    NomeFileImmagineMerge = ImagePath + "\Image_" + IndImgF.ToString("0000") + "GUV" + ".jpg"
                ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT Or _
                               cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_1DIM Or _
                               cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_2DIM Or _
                               cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP4 Or _
                               cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_TIF) Then
                    NomeFileImmagine = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FF" + ".tif"
                    NomeFileImmagineRetro = ImagePath + "\Image_" + IndImgR.ToString("0000") + "BB" + ".tif"
                    NomeFileImmagineFront2 = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FN" + ".tif"
                    NomeFileImmagineMerge = ImagePath + "\Image_" + IndImgF.ToString("0000") + "GUV" + ".tif"

                End If

                rc = Ls.LSGetDocData(hLS, 0, NrDoc, NomeFileImmagine, NomeFileImmagineRetro, NomeFileImmagineFront2, NomeFileImmagineMerge, FrontImage, BackImage, FrontImage2, Nothing, ImageMerged, CodelineSw, CodelineHw, cApplFunc.ShowUvImage, True, cApplFunc.FileFormat)

                If (fAutoFeed = False And rc <> 0 And rc <> 40) Then
                    '    'rc1 = Ls.LSStopAutoDocHandle(hLS, 0)
                    fstop = True
                End If

                Application.DoEvents()
                Select Case rc
                    Case LsFamily.LsReply.LS_DOUBLE_LEAFING_ERROR

                        Ls.LSStopAutoDocHandle(hLS, 0)

                        MessageBox.Show(cApplFunc.CheckReply(rc, "LSGetDocData"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)

                        Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_PATH)

                    Case LsFamily.LsReply.LS_PAPER_JAM + _
                          LsFamily.LsReply.LS_JAM_AT_MICR_PHOTO, + _
                          LsFamily.LsReply.LS_JAM_AT_SCANNER_PHOTO, + _
                          LsFamily.LsReply.LS_JAM_DOC_TOO_LONG

                        Ls.LSStopAutoDocHandle(hLS, 0)

                        MessageBox.Show(cApplFunc.CheckReply(rc, "LSGetDocData"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)

                        Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_PATH)
                    Case LsFamily.LsReply.LS_FEEDER_EMPTY

                        Ls.LSStopAutoDocHandle(hLS, 0)

                        cb = AddressOf Ls515CodelineRead
                        CurrPocket = LsFamily.LsDefines.Sorter.SORTER_POCKET_1

                        rc = LsFamily.LsReply.LS_OKAY
                        rc = Ls.LSAutoDocHandle(hLS, 0, Stamp, PrintValidate, Codeline, cApplFunc.Side, cApplFunc.ScanMode, cApplFunc.Sorter, 0, cApplFunc.ClearBlack, LsFamily.LsDefines.ImageSave.IMAGE_SAVE_HANDLE, ImagePath, "Image_", LsFamily.LsDefines.Unit.UNIT_MM, pos_x, pos_y, pos_w, pos_h, cApplFunc.FileFormat, 2, LsFamily.LsDefines.FileAttribute.SAVE_REPLACE, 0, LsFamily.LsDefines.Wait.WAIT_NO, cApplFunc.Beep, cb)

                        Application.DoEvents()

                    Case LsFamily.LsReply.LS_OKAY, LsFamily.LsReply.LS_LOOP_INTERRUPTED

                        'mel caso di loop interrupeted visualizzo le ultime immagini ed esco dal while principale 
                        If (rc = LsFamily.LsReply.LS_LOOP_INTERRUPTED) Then
                            ' fstop = True
                            rc = LsFamily.LsReply.LS_OKAY
                        End If



                        'a qeusto punto avendo l'immagine leggo anche la codeline OCR o BARCODE se richiesta
                        If cApplFunc.CodelineType = ApplClass.DECODE_OCR Then

                            DoOcr(FrontImage, CodelineSw)

                        ElseIf cApplFunc.CodelineType = ApplClass.DECODE_BARCODE Then
                            'Codeline = cApplFunc.Barcode_Type

                            CodelineSw = New String(" ")

                            If (cApplFunc.Barcode_Type) Then
                                Select Case cApplFunc.Barcode_Type
                                    Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_2_OF_5
                                        BarcodeToread = 50 'LSAPI_READ_BARCODE_2_OF_5
                                    Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE128
                                        BarcodeToread = 52 'LSAPI_READ_BARCODE_CODE128'
                                    Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE39
                                        BarcodeToread = 51 'LSAPI_READ_BARCODE_CODE39'
                                    Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_EAN13
                                        BarcodeToread = 53 'LSAPI_READ_BARCODE_EAN13' 
                                End Select

                            End If
                            Ls.LSReadBarcodeFromBitmap(0, FrontImage, BarcodeToread, cApplFunc.Barcode_x, cApplFunc.Barcode_y, cApplFunc.Barcode_w, cApplFunc.Barcode_h, CodelineSw)

                        Else
                        End If

                        'If Not ((FrontImage Is Nothing And BackImage Is Nothing)) Then
                        'visualizzo le immagini a video 
                        ShowCodelineAndImages(cApplFunc.SaveMode, cApplFunc.Side, cApplFunc.ScanMode, rc, NrDocTot, CodelineHw, CodelineSw, FrontImage, BackImage, FrontImage2, ImageMerged)

                        'incremento il numero di documenti globali
                        NrDocTot += 1

                        IndImgF += 1
                        IndImgR += 1
                        ' End If


                    Case Else

                        If (rc <> LsFamily.LsReply.LS_NO_OTHER_DOCUMENT) Then
                            MessageBox.Show(cApplFunc.CheckReply(rc, "LSGetDocData"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If

                        fstop = True

                End Select


                ' processa do non a buon fine
                'Else ' fi reply <> 0
            End While
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSGetDocData"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If



        'Ls.LSStopAutoDocHandle(hLS, 0)
        'MessageBox.Show(cApplFunc.CheckReply(rc, "LSStopAutoDocHandle"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Ls.LSDisconnect(hLS, 0)
        fAutoFeed = False
        ToolStripAutoFeed.Checked = CheckState.Unchecked

        'Riabilito tutti i bottoni
        EnableForAutoFeed()

    End Sub

    Private Sub miCardHandle_Click()
        Dim rc As Int32
        Dim NrDoc As UInt32
        Dim FrontImage As Bitmap = Nothing
        Dim BackImage As Bitmap = Nothing
        Dim CodelineRead As String = New String(" ", 256)
        Dim NomeFileImmagine As String = New String(" ", 256)
        Dim NomeFileImmagineRetro As String = New String(" ", 256)
        Dim IndImgF As Int16
        Dim IndImgR As Int16
        Dim estensione As String = New String(" ", 256)


        rc = Ls.LSConnect(0, LsUnitType, hLS, True)
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReset(hLS, 0, LsFamily.LsDefines.Reset.RESET_ERROR)

            rc = Ls.LSDocHandle(hLS, 0, LsFamily.LsDefines.Stamp.STAMP_NO, LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_NO, LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_NO, cApplFunc.Side, cApplFunc.ScanMode_Card, LsFamily.LsDefines.Feeder.FEED_FROM_PATH, LsFamily.LsDefines.Sorter.SORTER_POCKET_1, LsFamily.LsDefines.Wait.WAIT_YES, LsFamily.LsDefines.Beep.BEEP_NO, NrDoc, LsFamily.LsDefines.ScanDocType.SCAN_CARD)
            If (rc = LsFamily.LsReply.LS_OKAY) Then

                rc = Ls.LSReadImage(hLS, 0, cApplFunc.ClearBlack, cApplFunc.Side, NrDoc, FrontImage, BackImage, Nothing, Nothing)
                If (rc = LsFamily.LsReply.LS_OKAY) Then

                    If (cApplFunc.fReadPdf = True) Then
                        rc = Ls.LSReadPdfFromBitmap(0, FrontImage, CodelineRead)
                        If (rc <> LsFamily.LsReply.LS_OKAY) Then
                            CodelineRead = Nothing
                            MessageBox.Show(cApplFunc.CheckReply(rc, "LSReadPdfFromBitmap"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                    Else
                        CodelineRead = Nothing
                    End If

                    '  Salvo le immagini su file
                    If (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_BMP) Then
                        estensione = ".bmp"
                    ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_JPEG) Then
                        estensione = ".jpg"
                    ElseIf (cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT Or _
                            cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_1DIM Or _
                            cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP3_2DIM Or _
                            cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_CCITT_GROUP4 Or _
                            cApplFunc.FileFormat = LsFamily.LsDefines.FileType.FILE_TIF) Then
                        estensione = ".tif"
                    End If

                    '  Salvo le immagini su file
                    If cApplFunc.SaveMode = LsFamily.LsDefines.ImageSave.IMAGE_SAVE_BOTH Then

                        IndImgR = 0
                        IndImgR = 0


                        NomeFileImmagine = ImagePath + "\Image_" + IndImgF.ToString("0000") + "FF" + estensione
                        NomeFileImmagineRetro = ImagePath + "\Image_" + IndImgR.ToString("0000") + "BB" + estensione

                        If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then
                            Ls.LSSaveImage(hLS, 0, FrontImage, NomeFileImmagine, cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE)
                        End If

                        If cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE Or cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE Then
                            Ls.LSSaveImage(hLS, 0, BackImage, NomeFileImmagineRetro, cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_BACK_IMAGE)
                        End If
                    End If
                    NrDoc = Convert.ToUInt32(1) ' BACO di VB.net 2003 !!!
                    ShowCodelineAndImages(cApplFunc.SaveMode, cApplFunc.Side, cApplFunc.ScanMode, rc, NrDoc, Nothing, Nothing, FrontImage, BackImage, Nothing, Nothing)

                    If (CodelineRead <> Nothing) Then
                        MessageBox.Show(CodelineRead, "CodelineRead", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    End If

                End If
            Else
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSDocHandle"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            rc = Ls.LSDisconnect(hLS, 0)
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub
    Private Sub LS40MenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS40MenuItem.Click

        Dim LsCfg As LsFamily.LsConfiguration
        Dim rc As Short

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB
        LsCfg = New LsFamily.LsConfiguration

        rc = UnitConfig(LsUnitType, LsCfg, 0, 0)


        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_Ls40)
        If (LsCfg.ProcessCard) Then
            ToolStripCard.Enabled = True
        Else
            ToolStripCard.Enabled = False
        End If

        If (LsCfg.Badge_Track12 Or LsCfg.Badge_Track123 Or LsCfg.Badge_Track23) Then
            ToolStripBadge.Enabled = True
        Else
            ToolStripBadge.Enabled = False
        End If


        ToolStripRetainedDoc.Enabled = True
        ToolStripMultiDoc.Enabled = False
        ToolStripDoubleLeafing.Enabled = False
        ToolStripTestCinghia.Enabled = False
        TOptionA4.Visible = False
        TA4Scan.Visible = False

    End Sub

    Private Sub LS100IPMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS100IPMenuItem.Click

        Dim Reply As Short
        Dim hWnd As Short
        Dim LsCfg As LsFamily.LsConfiguration

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_ETH
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_Ls100eth)
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = True
        ToolStripTestCinghia.Enabled = False
        Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, True)


        If (Reply = LsFamily.LsReply.LS_OKAY Or Reply = LsFamily.LsReply.LS_ALREADY_OPEN) Then
            LsCfg = New LsFamily.LsConfiguration

            Reply = Ls.LSIdentify(hLS, hWnd, LsCfg, Nothing, Nothing, Nothing, Nothing)
            If (Reply = LsFamily.LsReply.LS_OKAY) Then
                If (LsCfg.Feeder = True) Then
                    ToolStripRetainedDoc.Enabled = False
                Else
                    ToolStripRetainedDoc.Enabled = True
                End If

                Reply = Ls.LSDisconnect(hLS, hWnd)
            Else
                MessageBox.Show(cApplFunc.CheckReply(Reply, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
        TOptionA4.Visible = False
        TA4Scan.Visible = False
        'ToolStripRetainedDoc.Enabled = False
    End Sub

    Private Sub LS100USBMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS100USBMenuItem.Click

        Dim Reply As Short
        Dim hWnd As Short
        Dim LsCfg As LsFamily.LsConfiguration

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB

        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_Ls100)
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = True
        ToolStripTestCinghia.Enabled = False


        Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, True)


        If (Reply = LsFamily.LsReply.LS_OKAY Or Reply = LsFamily.LsReply.LS_ALREADY_OPEN) Then
            LsCfg = New LsFamily.LsConfiguration

            Reply = Ls.LSIdentify(hLS, hWnd, LsCfg, Nothing, Nothing, Nothing, Nothing)
            If (Reply = LsFamily.LsReply.LS_OKAY) Then
                If (LsCfg.Feeder = True) Then
                    ToolStripRetainedDoc.Enabled = False
                Else
                    ToolStripRetainedDoc.Enabled = True
                End If

                Reply = Ls.LSDisconnect(hLS, hWnd)
            Else
                MessageBox.Show(cApplFunc.CheckReply(Reply, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
        TOptionA4.Visible = False
        TA4Scan.Visible = False

    End Sub

    Private Sub LS150usbMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS150usbMenuItem.Click

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_LS150usb)
        ToolStripCard.Enabled = True
        ToolStripBadge.Enabled = True
        ToolStripRetainedDoc.Enabled = False
        ToolStripTestCinghia.Enabled = True
        ToolStripDoubleLeafing.Enabled = True
        TOptionA4.Visible = False
        TA4Scan.Visible = False
    End Sub

    Private Sub LS515usbMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS515usbMenuItem.Click

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_LS515usb)
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = True
        ToolStripRetainedDoc.Enabled = True
        ToolStripTestCinghia.Enabled = False
        TOptionA4.Visible = False
        TA4Scan.Visible = False
    End Sub

    Private Sub LS520usbMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS520usbMenuItem.Click

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_LS520usb)
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = False
        ToolStripRetainedDoc.Enabled = True
        ToolStripTestCinghia.Enabled = False
        TOptionA4.Visible = False
        TA4Scan.Visible = False
    End Sub

    Private Sub LS800usbMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS800usbMenuItem.Click

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_LS800usb)
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = False
        ToolStripRetainedDoc.Enabled = False
        ToolStripTestCinghia.Enabled = False
        ToolStripAutoFeed.Enabled = False
        ToolStripSingleDOc.Enabled = False
        TOptionA4.Visible = False
        TA4Scan.Visible = False
    End Sub


    Private Sub Ls40A4MenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Ls40A4MenuItem.Click

        Dim LsCfg As LsFamily.LsConfiguration
        Dim rc As Short

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB
        LsCfg = New LsFamily.LsConfiguration

        rc = UnitConfig(LsUnitType, LsCfg, 0, 0)


        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_Ls40_LsCombo)
        If (LsCfg.ProcessCard) Then
            ToolStripCard.Enabled = True
        Else
            ToolStripCard.Enabled = False
        End If

        If (LsCfg.Badge_Track12 Or LsCfg.Badge_Track123 Or LsCfg.Badge_Track23) Then
            ToolStripBadge.Enabled = True
        Else
            ToolStripBadge.Enabled = False
        End If


        ToolStripRetainedDoc.Enabled = True
        ToolStripMultiDoc.Enabled = False
        ToolStripDoubleLeafing.Enabled = False
        ToolStripTestCinghia.Enabled = False
        TOptionA4.Enabled = True
        TOptionA4.Visible = True
        TA4Scan.Visible = True
        TA4Scan.Enabled = True
    End Sub

    Private Sub Ls150A4MenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Ls150A4MenuItem.Click
        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_Ls150_LsCombo)
        ToolStripCard.Enabled = True
        ToolStripBadge.Enabled = True
        ToolStripRetainedDoc.Enabled = False
        ToolStripTestCinghia.Enabled = True
        ToolStripDoubleLeafing.Enabled = True
        TOptionA4.Enabled = True
        TOptionA4.Visible = True
        TA4Scan.Visible = True
        TA4Scan.Enabled = True
    End Sub

    Private Sub ToolStripIdentify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripIdentify.Click

        Dim Reply As Integer
        Dim hWnd As Int32
        Dim LsCfg As LsFamily.LsConfiguration
        Dim Model As String = New String(" ", 20)
        Dim Version As String = New String(" ", 20)
        Dim FwDate As String = New String(" ", 20)
        Dim UnitID As String = New String(" ", 20)

        ToolStrip1.Enabled = False



        Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, True)

        If (Reply = LsFamily.LsReply.LS_OKAY Or Reply = LsFamily.LsReply.LS_ALREADY_OPEN) Then
            LsCfg = New LsFamily.LsConfiguration
            Reply = Ls.LSIdentify(hLS, hWnd, LsCfg, Model, Version, FwDate, UnitID)
            If (Reply = LsFamily.LsReply.LS_OKAY) Then
                cApplFunc.showIdentify(LsCfg, Model, FwDate, Version, Nothing, UnitID)
            End If

            Reply = Ls.LSDisconnect(hLS, hWnd)
        Else
            MessageBox.Show(cApplFunc.CheckReply(Reply, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatus.Click

        Dim Reply As Integer
        Dim hWnd As Int32
        Dim LsStatus As LsFamily.LsUnitStatus

        ToolStrip1.Enabled = False

        Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, True)

        If (Reply = LsFamily.LsReply.LS_OKAY Or Reply = LsFamily.LsReply.LS_ALREADY_OPEN) Then
            LsStatus = New LsFamily.LsUnitStatus

            Reply = Ls.LSUnitStatus(hLS, hWnd, LsStatus)
            'If (Reply = LsFamily.LsReply.LS_OKAY) Then
            cApplFunc.showStatus(LsStatus)
            'End If

            Reply = Ls.LSDisconnect(hLS, hWnd)
        Else
            MessageBox.Show(cApplFunc.CheckReply(Reply, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        ToolStrip1.Enabled = True

    End Sub

    Private Function DisableForAutoFeed() As Int32

        ToolSplitLSmodel.Enabled = False
        ToolStripIdentify.Enabled = False
        ToolStripStatus.Enabled = False
        ToolStripSingleDOc.Enabled = False
        ToolStripMultiDoc.Enabled = False
        ToolStripRetainedDoc.Enabled = False
        ToolStripOptions.Enabled = False
        ToolStripDoubleLeafing.Enabled = False
        ToolStripReset.Enabled = False
        ToolStripClear.Enabled = False
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = False
        ToolStripAbout.Enabled = False
        ToolStripExit.Enabled = False
        ToolStripTestCinghia.Enabled = False
        ToolStripUnitMonitoring.Enabled = False

    End Function

    Private Function EnableForAutoFeed() As Int32

        Dim Reply As Short
        Dim hWnd As Short
        Dim LsCfg As LsFamily.LsConfiguration

        ToolSplitLSmodel.Enabled = True
        ToolStripIdentify.Enabled = True
        ToolStripStatus.Enabled = True
        ToolStripUnitMonitoring.Enabled = True
        ToolStripSingleDOc.Enabled = True
        ToolStripOptions.Enabled = True
        ToolStripReset.Enabled = True
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
            ToolStripTestCinghia.Enabled = True
        End If
        ToolStripClear.Enabled = True
        ToolStripAbout.Enabled = True
        ToolStripExit.Enabled = True

        If (LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_40_USB And _
            LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_150_ETH And _
            LsUnitType <> LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT) Then
            ToolStripMultiDoc.Enabled = True
            ToolStripDoubleLeafing.Enabled = True
        End If



        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_ETH Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_LSCONNECT) Then

            ToolStripBadge.Enabled = True
        End If

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or _
             LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or _
             LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT) Then

            ToolStripCard.Enabled = True
        End If

        'error ? 
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_LSCONNECT) Then
            ToolStripRetainedDoc.Enabled = True
        End If

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_LSCONNECT) Then


            Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, True)


            If (Reply = LsFamily.LsReply.LS_OKAY Or Reply = LsFamily.LsReply.LS_ALREADY_OPEN) Then
                LsCfg = New LsFamily.LsConfiguration

                Reply = Ls.LSIdentify(hLS, hWnd, LsCfg, Nothing, Nothing, Nothing, Nothing)
                If (Reply = LsFamily.LsReply.LS_OKAY) Then
                    If (LsCfg.Feeder = True) Then
                        ToolStripRetainedDoc.Enabled = False
                    Else
                        ToolStripRetainedDoc.Enabled = True
                    End If

                    Reply = Ls.LSDisconnect(hLS, hWnd)
                Else
                    MessageBox.Show(cApplFunc.CheckReply(Reply, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        End If

    End Function

    Public Sub ToolStripAutoFeed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripAutoFeed.Click



        NrDocToProcess = 0


        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            MessageBox.Show("Feature NOT implemented for this model !", Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else

            ' Riabilito solo questo bottone
            DisableForAutoFeed()

            If (ToolStripAutoFeed.CheckState = CheckState.Unchecked) Then
                ToolStripAutoFeed.Checked = CheckState.Checked

                fAutoFeed = True
                fstop = False
                'e un nuovo giro e rinializzo il numero di doc parziali 
                NrDocTot = 1

                yfinestra = 0
                Receipt.Clear()

                StartDocument()

                DoAutoFeed()
                't = New Thread(AddressOf DoAutoFeed)
                't.Start()
            Else
                fAutoFeed = False
                'fstop = True


                Ls.LSStopAutoDocHandle(hLS, 0)

                ToolStripAutoFeed.Checked = CheckState.Unchecked
                't.Abort()
                't = Nothing
                'Riabilito tutti i bottoni
                EnableForAutoFeed()
            End If



        End If 'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then

    End Sub

    Private Sub ToolStripSingleDOc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripSingleDOc.Click

        ToolStrip1.Enabled = False
        NrDocToProcess = 1
        Receipt.Clear()



        OneDocHandle()


        If (Receipt.Count > 0) Then
            Dim pd As New Printing.PrintDocument()
            AddHandler pd.PrintPage, AddressOf Me.pd_PrintPage
            pd.Print()
        End If
        ToolStrip1.Enabled = True

    End Sub
    Public Sub StartDocument()

        PulisciVideata(1)

        Try
            Directory.Delete(Application.StartupPath + "\\Images", True)
            Directory.CreateDirectory(Application.StartupPath + "\\Images")

        Catch ex As Exception

        End Try


        fform = New FImages
        fform.Scanmode = cApplFunc.ScanMode
        fform.StartPosition() = FormStartPosition.Manual
        fform.Location = New Point(0, 0)
        fform.MdiParent = Me
        fform.Dock = DockStyle.Left

        Select Case cApplFunc.FileFormat
            Case LsFamily.LsDefines.FileType.FILE_BMP
                fform.EstFile = ".bmp"
            Case LsFamily.LsDefines.FileType.FILE_JPEG
                fform.EstFile = ".jpg"
            Case LsFamily.LsDefines.FileType.FILE_TIF, _
                LsFamily.LsDefines.FileType.FILE_CCITT, _
                LsFamily.LsDefines.FileType.FILE_CCITT_GROUP4
                fform.EstFile = ".tif"
        End Select


        fform.Show()
    End Sub


    Private Sub ToolStripMultiDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMultiDoc.Click


        ToolStrip1.Enabled = False
        NrDocToProcess = 0

        yfinestra = 0
        Receipt.Clear()

        StartDocument()

        MultiDocHandle(True)


        If (Receipt.Count > 0) Then
            Dim pd As New Printing.PrintDocument()
            AddHandler pd.PrintPage, AddressOf Me.pd_PrintPage
            pd.Print()
        End If
        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripRetainedDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripRetainedDoc.Click
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            MessageBox.Show("Feature NOT implemented for this model !", Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            ToolStrip1.Enabled = False
            NrDocToProcess = 0
            StartDocument()
            RetainedMode()
            ToolStrip1.Enabled = True
        End If
    End Sub

    Private Sub ToolStripOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripOptions.Click

        Dim aa As formOptions = New formOptions

        ToolStrip1.Enabled = False
        aa.ShowDialog(Me)
        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripDoubleLeafing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripDoubleLeafing.Click

        If (ToolStripDoubleLeafing.CheckState = CheckState.Unchecked) Then
            cApplFunc.DuobleLeafingLevel = LsFamily.LsDefines.DoubleLeafing.DOUBLE_LEAFING_DISABLE
            ToolStripDoubleLeafing.Checked = CheckState.Checked
            ToolStripDoubleLeafing.Text = "Double Leafing set : Disable"
            ToolStripDoubleLeafing.Image = ImageDoubleFeed.Images(DoubleLeafingIcon.DL_Warning)
        Else 'If (ToolStripDoubleLeafing.CheckState = CheckState.Checked) Then
            cApplFunc.DuobleLeafingLevel = LsFamily.LsDefines.DoubleLeafing.DOUBLE_LEAFING_ERROR
            ToolStripDoubleLeafing.Checked = CheckState.Unchecked
            ToolStripDoubleLeafing.Text = "Double Leafing set : Error"
            ToolStripDoubleLeafing.Image = ImageDoubleFeed.Images(DoubleLeafingIcon.DL_Error)
            'Else
            '   MsgBox("aa")
        End If

    End Sub

    Private Sub ToolStripReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripReset.Click

        Dim rc As Integer
        Dim hWnd As Int32

        ToolStrip1.Enabled = False

        rc = Ls.LSConnect(hWnd, LsUnitType, hLS, True)

        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReset(hLS, hWnd, LsFamily.LsDefines.Reset.RESET_PATH)
            If (rc = LsFamily.LsReply.LS_OKAY) Then
                MessageBox.Show("Reset Ok !", TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSReset"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            rc = Ls.LSDisconnect(hLS, hWnd)
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripClear.Click

        ToolStrip1.Enabled = False
        miClearScreen_Click()
        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripCard.Click

        Dim ff As formCard = New formCard
        Dim LsCfg As LsFamily.LsConfiguration
        Dim rc As Int32 = LsFamily.LsReply.LS_OKAY



        'Inizializzo i controlli della dialog
        LsCfg = New LsFamily.LsConfiguration
        rc = UnitConfig(LsUnitType, LsCfg, 0, 0)

        'da fare se non faccio StartDocument
        PulisciVideata(1)

        'StartDocument()

        If (rc = LsFamily.LsReply.LS_OKAY) Then

            If LsCfg.ProcessCard Then

                'e.Button.Pushed = True
                ToolStrip1.Enabled = False
                ff.ShowDialog()
                'e.Button.Pushed = False
                ToolStrip1.Enabled = True

                If (ScanMode_Card) Then
                    cApplFunc.ScanMode_Card = ScanMode_Card
                    miCardHandle_Click()
                End If

            Else
                MessageBox.Show("Not possible to capture the image of the card! ", Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Function UnitConfig(ByVal Lsunit As Int16, ByRef LsCfg As LsFamily.LsConfiguration, ByRef Model As String, ByRef Version As String) As Int32
        Dim Ls As LsFamily.LsApi = New LsFamily.LsApi
        Dim hLs As Int16
        Dim rc As Int32

        rc = Ls.LSConnect(0, LsUnitType, hLs, True)
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSIdentify(hLs, 0, LsCfg, Model, Version, 0, 0)
            rc = Ls.LSDisconnect(hLs, 0)
        End If

        Return rc
    End Function

    Private Sub ToolStripBadge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripBadge.Click
        Dim aa As formBadge = New formBadge
        Dim LsCfg As LsFamily.LsConfiguration
        Dim Model As String = New String("", 20)
        Dim Version As String = New String("", 20)
        Dim rc As Int32 = LsFamily.LsReply.LS_OKAY

        'Inizializzo i controlli della dialog
        LsCfg = New LsFamily.LsConfiguration
        rc = UnitConfig(LsUnitType, LsCfg, Model, Version)

        If (rc = LsFamily.LsReply.LS_OKAY) Then

            If LsCfg.Badge_Track12 Or LsCfg.Badge_Track23 Or LsCfg.Badge_Track123 Then

                'e.Button.Pushed = True
                ToolStrip1.Enabled = False
                aa.ShowDialog()
                'e.Button.Pushed = False
                ToolStrip1.Enabled = True

            Else
                MessageBox.Show("Badge Reader not installed !", Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), Form1.TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub ToolStripAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripAbout.Click


        Dim aa As formAbout = New formAbout

        ToolStrip1.Enabled = False
        aa.ShowDialog()
        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripExit.Click
        Me.Close()
    End Sub


    Private Sub LS150IpMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LS150IpMenuItem.Click
        '   Dim Reply As Short
        '   Dim hWnd As Short
        'Dim LsCfg As LsFamily.LsConfiguration

        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_ETH
        EnableTest()

        ToolSplitLSmodel.Image = ImageLsModel.Images(LsModelIcon.MenuIco_Ls150eth)
        ToolStripCard.Enabled = False
        ToolStripBadge.Enabled = False
        ToolStripRetainedDoc.Enabled = False
        ToolStripDoubleLeafing.Enabled = False
        ToolStripAutoFeed.Enabled = False

        ToolStripMultiDoc.Enabled = True

    End Sub




    Private Sub ToolStripUnitMonitoring_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripUnitMonitoring.Click
        Dim Reply As Integer
        Dim hWnd As Int32
        Dim LsHistory As LsFamily.LsHistory
        Dim stTime As String = New String(" ", 16)
        Dim aa As frmCtsMonitor = New frmCtsMonitor

        ToolStrip1.Enabled = False

        Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, False)

        If (Reply = LsFamily.LsReply.LS_OKAY Or Reply = LsFamily.LsReply.LS_ALREADY_OPEN) Then
            LsHistory = New LsFamily.LsHistory
            aa.ShowDialog(Me)
#If 0 Then
            Reply = Ls.LSHistory(hLS, hWnd, LsHistory, stTime)
            If (Reply = LsFamily.LsReply.LS_OKAY) Then

                If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB) Then
                    frmHistory150.IDC_DOC_PROCESSED.Text = LsHistory.doc_sorted
                    frmHistory150.IDC_JAM_CARD.Text = LsHistory.jams_card
                    frmHistory150.IDC_JAM_MICR.Text = LsHistory.jams_micr
                    frmHistory150.IDC_RETAINED_DOC.Text = LsHistory.doc_retain
                    frmHistory150.IDC_JAM_SCANNER.Text = LsHistory.jams_scanner
                    frmHistory150.IDC_ERR_CMC7.Text = LsHistory.doc_cmc7_err
                    frmHistory150.IDC_ERR_E13B.Text = LsHistory.doc_e13b_err
                    frmHistory150.IDC_POWER_ON.Text = LsHistory.num_turn_on
                    frmHistory150.IDC_DOC_PRINTED.Text = LsHistory.doc_ink_jet
                    frmHistory150.IDC_DOC_STAMPED.Text = LsHistory.doc_stamp
                    frmHistory150.IDC_TOT_TIME.Text = stTime
                    frmHistory150.ShowDialog(Me)
                ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB) Then
                    frmHistory40.IDC_DOC_PROCESSED.Text = LsHistory.doc_sorted
                    frmHistory40.IDC_JAM_FEED.Text = LsHistory.bourrage_feeder
                    frmHistory40.IDC_RETAINED_DOC.Text = LsHistory.doc_retain
                    frmHistory40.IDC_ERR_CMC7.Text = LsHistory.doc_cmc7_err
                    frmHistory40.IDC_ERR_E13B.Text = LsHistory.doc_e13b_err
                    frmHistory40.IDC_POWER_ON.Text = LsHistory.num_turn_on
                    frmHistory40.IDC_DOC_PRINTED.Text = LsHistory.doc_ink_jet
                    frmHistory40.IDC_DOC_STAMPED.Text = LsHistory.doc_stamp
                    frmHistory40.IDC_TOT_TIME.Text = stTime
                    frmHistory40.ShowDialog(Me)
                ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or _
                        LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_ETH) Then
                    frmHistory100.IDC_DOC_PROCESSED.Text = LsHistory.doc_sorted
                    frmHistory100.IDC_JAM_FEED.Text = LsHistory.bourrage_feeder
                    frmHistory100.IDC_RETAINED_DOC.Text = LsHistory.doc_retain
                    frmHistory100.IDC_ERR_CMC7.Text = LsHistory.doc_cmc7_err
                    frmHistory100.IDC_ERR_E13B.Text = LsHistory.doc_e13b_err
                    frmHistory100.IDC_POWER_ON.Text = LsHistory.num_turn_on
                    frmHistory100.IDC_DOC_PRINTED.Text = LsHistory.doc_ink_jet
                    frmHistory100.IDC_DOC_STAMPED.Text = LsHistory.doc_stamp
                    frmHistory100.IDC_JAM_MICR.Text = LsHistory.bourrage_micr
                    frmHistory100.IDC_JAM_AT_EXIT.Text = LsHistory.bourrage_exit
                    frmHistory100.IDC_TOT_TIME.Text = stTime
                    frmHistory100.ShowDialog(Me)
                ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or _
                       LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB) Then
                    frmHistory5xx.IDC_DOC_PROCESSED.Text = LsHistory.num_doc_handled
                    frmHistory5xx.IDC_JAM_FEEDER.Text = LsHistory.bourrage_feeder
                    frmHistory5xx.IDC_JAM_SCANNER.Text = LsHistory.bourrage_film
                    frmHistory5xx.IDC_RETAINED_FILM.Text = LsHistory.doc_retain_scan
                    frmHistory5xx.IDC_RETAINED_MICR.Text = LsHistory.doc_retain_micr
                    frmHistory5xx.IDC_ERR_CMC7.Text = LsHistory.doc_cmc7_err
                    frmHistory5xx.IDC_ERR_E13B.Text = LsHistory.doc_e13b_err
                    frmHistory5xx.IDC_POWER_ON.Text = LsHistory.nr_power_on
                    frmHistory5xx.IDC_ERR_BARCODE.Text = LsHistory.doc_barcode_err
                    frmHistory5xx.IDC_ERR_OPTIC.Text = LsHistory.doc_optic_err
                    frmHistory5xx.IDC_JAM_MICR.Text = LsHistory.bourrage_micr
                    frmHistory5xx.IDC_JAM_STAMP.Text = LsHistory.bourrage_stamp
                    frmHistory5xx.IDC_TOT_TIME.Text = stTime
                    frmHistory5xx.ShowDialog(Me)
                ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
                    frmHistory800.IDC_DOC_PROCESSED.Text = LsHistory.num_doc_handled
                    frmHistory800.IDC_JAM_FEED.Text = LsHistory.jam_feeder
                    frmHistory800.IDC_JAM_FRONT_SCANNER.Text = LsHistory.jam_front_scanner
                    frmHistory800.IDC_JAM_LEFT_TRACK.Text = LsHistory.jam_track_left
                    frmHistory800.IDC_JAM_RIGHT_TRACK.Text = LsHistory.jam_track_right
                    frmHistory800.IDC_ERR_CMC7.Text = LsHistory.doc_cmc7_err
                    frmHistory800.IDC_ERR_E13B.Text = LsHistory.doc_e13b_err
                    frmHistory800.IDC_POWER_ON.Text = LsHistory.nr_power_on
                    frmHistory800.IDC_JAM_BACK_SCANNER.Text = LsHistory.jam_back_scanner
                    frmHistory800.IDC_JAM_AT_SORTERS.Text = LsHistory.jam_in_the_sorters
                    frmHistory800.IDC_DOUBLE_LEAFING.Text = LsHistory.nr_double_leafing
                    frmHistory800.IDC_DOC_PRINTED.Text = LsHistory.doc_printed
                    frmHistory800.IDC_TOT_TIME.Text = stTime
                    frmHistory800.ShowDialog(Me)
                End If

                Reply = Ls.LSDisconnect(hLS, hWnd)

            End If
#End If
        Else
            MessageBox.Show(cApplFunc.CheckReply(Reply, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        ToolStrip1.Enabled = True

    End Sub

    Private Sub ToolStripTestCinghia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripTestCinghia.Click
        Dim rc As Integer
        Dim hWnd As Int32

        ToolStrip1.Enabled = False

        rc = Ls.LSConnect(hWnd, LsUnitType, hLS, True)

        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSReset(hLS, hWnd, LsFamily.LsDefines.Reset.RESET_BELT_CLEANING)
            If (rc = LsFamily.LsReply.LS_OKAY) Then
                'MessageBox.Show("Reset Ok !", TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show(cApplFunc.CheckReply(rc, "LSReset"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            rc = Ls.LSDisconnect(hLS, hWnd)
        Else
            MessageBox.Show(cApplFunc.CheckReply(rc, "LSConnect"), TITLE_POPUP, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        ToolStrip1.Enabled = True

    End Sub

    Private Sub pd_PrintPage(ByVal sender As Object, ByVal ev As Printing.PrintPageEventArgs)
        Dim BigFont = New Font("Arial", 40, FontStyle.Regular, GraphicsUnit.Pixel)
        Dim NormalFont = New Font("Arial", 26, FontStyle.Regular, GraphicsUnit.Pixel)
        Dim HeaderImg As New Bitmap("header.bmp")
        Dim PageWidth As Integer = 565
        ev.Graphics.PageUnit = GraphicsUnit.Pixel

        'header
        ev.Graphics.DrawImage(HeaderImg, Ryp)
        Ryp.Y += HeaderImg.Height + 25

        'checks
        For i As Integer = 0 To Receipt.Count - 1
            Ryp.Y += 30

            ev.Graphics.DrawString("#" + (i + 1).ToString(), BigFont, Brushes.Black, 0, Ryp.Y)
            Ryp.Y += BigFont.Height

            ev.Graphics.DrawString("Codeline:", NormalFont, Brushes.Black, 0, Ryp.Y)
            Ryp.Y += NormalFont.Height

            If Receipt(i).Codeline.Length <> 0 Then
                ev.Graphics.DrawString(Receipt(i).Codeline, NormalFont, Brushes.Black, 0, Ryp.Y)
            Else
                ev.Graphics.DrawString("Unable to read codeline", NormalFont, Brushes.Black, 0, Ryp.Y)
            End If
            Ryp.Y += NormalFont.Height


            Try
                If cApplFunc.RecPortrait Then
                    Receipt(i).FrontImage.RotateFlip(RotateFlipType.Rotate90FlipNone)
                End If

                If cApplFunc.RecPrintFrontImg Then
                    Dim ratio As Double = Receipt(i).FrontImage.Width / PageWidth
                    Dim rect As New Rectangle(0, Ryp.Y, PageWidth, Receipt(i).FrontImage.Height / ratio)
                    ev.Graphics.DrawImage(Receipt(i).FrontImage, rect)
                    Ryp.Y += rect.Height
                End If

                If cApplFunc.RecPortrait Then
                    Receipt(i).FrontImage.RotateFlip(RotateFlipType.Rotate270FlipNone)
                End If

            Catch ex As Exception
            End Try

            Try
                If cApplFunc.RecPortrait Then
                    Receipt(i).RearImage.RotateFlip(RotateFlipType.Rotate90FlipNone)
                End If

                If cApplFunc.RecPrintRearImg Then
                    Dim ratio As Double = Receipt(i).RearImage.Width / PageWidth
                    Dim rect As New Rectangle(0, Ryp.Y, PageWidth, Receipt(i).RearImage.Height / ratio)
                    ev.Graphics.DrawImage(Receipt(i).RearImage, rect)
                    Ryp.Y += rect.Height
                End If

                If cApplFunc.RecPortrait Then
                    Receipt(i).RearImage.RotateFlip(RotateFlipType.Rotate270FlipNone)
                End If

            Catch ex As Exception
            End Try
        Next

        'footer
        Ryp.Y += 20
        ev.Graphics.DrawImage(New Bitmap("footer.bmp"), Ryp)
        ReceiptPage = 0
        Ryp.Y = 0

        Receipt.Clear()
    End Sub


    Private Sub TOptionA4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TOptionA4.Click
        fcan = New FCanonOption()

        'fcan.theTwain = theTwain
        'fcan.theTwainOptions = theTwainOptions
        fcan.ShowDialog(Me)
    End Sub

    Private Sub TA4Scan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TA4Scan.Click

        Dim rc As Short
        Dim hWnd As Integer
        Dim numdoc As Integer
        Dim FrontImage As Image = Nothing
        Dim BackImage As Image = Nothing


        A4Scanmode = cApplFunc.ScanMode
        A4Side = cApplFunc.Side
        Dim f As Fimage
        rc = Ls.LSConnect(hWnd, LsUnitType, hLS, True)

        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            rc = Ls.LSDocHandle(hLS, hWnd, LsFamily.LsDefines.Stamp.STAMP_NO, LsFamily.LsDefines.PrintValidate.PRINT_VALIDATE_NO, LsFamily.LsDefines.CodelineToRead.READ_CODELINE_HW_MICR, A4Side, A4Scanmode, LsFamily.LsDefines.Feeder.FEED_AUTO, LsFamily.LsDefines.Sorter.SORTER_POCKET_1, LsFamily.LsDefines.Wait.WAIT_NO, LsFamily.LsDefines.Beep.BEEP_NO, numdoc, LsFamily.LsDefines.ScanDocType.SCAN_PAPER_DOCUMENT)
            If rc = LsFamily.LsReply.LS_OKAY Then
                Do
                    rc = Ls.LSReadImage(hLS, hWnd, LsFamily.LsDefines.ClearBlack.CLEAR_BLACK_NO, A4Side, numdoc, FrontImage, BackImage, Nothing, Nothing, Nothing, False)
                    If ((rc = LsFamily.LsReply.LS_OKAY)) Then
                        If (A4Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE Or A4Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE And (Not (FrontImage Is Nothing))) Then
                            Ls.LSSaveImage(hLS, 0, FrontImage, ImagePath + "\Front_Image", cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE)
                            f = New Fimage()
                            f.Text = "A4 Front Image"
                            f.MdiParent = Me
                            f.Size = New Size(Me.Width, Me.Height)
                            f.PictureBox1.LEADImage = LEAD.Drawing.Image.FromImage(FrontImage)
                            f.PictureBox1.Zoom = (Me.Width) / FrontImage.Width
                            f.Show()
                        End If
                        If (A4Side = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE Or A4Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE And (Not (BackImage Is Nothing))) Then

                            Ls.LSSaveImage(hLS, 0, BackImage, ImagePath + "\Rear_Image", cApplFunc.FileFormat, cApplFunc.Quality, 0, 1, LsFamily.LsDefines.Side.SIDE_BACK_IMAGE)
                            f = New Fimage()
                            f.Text = "A4 Back Image"
                            f.MdiParent = Me
                            f.Size = New Size(Me.Width, Me.Height)
                            f.PictureBox1.LEADImage = LEAD.Drawing.Image.FromImage(BackImage)
                            f.PictureBox1.Zoom = (Me.Width) / FrontImage.Width
                            f.Show()
                        End If
                    End If
                Loop Until rc = LsFamily.LsReply.LS_NO_OTHER_DOCUMENT
            End If
        End If
    End Sub

    
    Private Sub Form1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        If (e.Shift = True And e.KeyCode = Keys.F1) Then
            ToolStripIdentify_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F2) Then
            ToolStripStatus_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F3) Then
            ToolStripUnitMonitoring_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F4) Then
            ToolStripAutoFeed_Click(sender, e)
            'ToolStripSingleDOc_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F5) Then
            ToolStripSingleDOc_Click(sender, e)
            'ToolStripAutoFeed_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F6) Then
            ToolStripRetainedDoc_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F7) Then
            ToolStripOptions_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F8) Then
            ToolStripReset_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F9) Then
            ToolStripClear_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F10) Then
            ToolStripBadge_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F11) Then
            ToolStripAbout_Click(sender, e)
        ElseIf (e.Shift = True And e.KeyCode = Keys.F12) Then
            ToolStripExit_Click(sender, e)
        End If
    End Sub

End Class
