﻿Public Class FCanonOption
    'Public theTwain As LEAD.Drawing.Imaging.Twain.Twain
    'Public theTwainOptions As TwainOptions = Nothing


    Private Sub FCanonOption_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Select Case cApplFunc.ScanMode
            Case LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_BW_200
                rbBWImage.Checked = True
            Case LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_GRAY_200
                rb256g200dpi.Checked = True
            Case LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_GRAY_300
                rb256g300dpi.Checked = True
            Case LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_COLOR_200
                rbColor200dpi.Checked = True
            Case LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_COLOR_300
                rbColor300dpi.Checked = True
            Case Else
                rb256g200dpi.Checked = True
        End Select

        ' Side
        Select Case cApplFunc.Side
            Case LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
                rbSideAll.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
                rbSideFront.Checked = True
            Case Else
                rbSideFront.Checked = True
        End Select

        'Dim count As Integer
        'count = theTwain.GetCapabilitiesCount()
        'EnumCaps(LEAD.Drawing.Imaging.Twain.CapabilityConstants.ICAP_PIXELTYPE)
        'EnumCaps(LEAD.Drawing.Imaging.Twain.CapabilityConstants.CAP_DUPLEXENABLED)     
    End Sub

    'Private Sub EnumCaps(ByVal cap As LEAD.Drawing.Imaging.Twain.CapabilityConstants)
    '    Dim twCap As LEAD.Drawing.Imaging.Twain.LEADTwainCapability = Nothing
    '    Dim curVal As Object = Nothing

    '    Try
    '        Select Case (cap)
    '            Case LEAD.Drawing.Imaging.Twain.CapabilityConstants.ICAP_PIXELTYPE
    '                twCap = theTwain.GetCapability2(cap, LEAD.Drawing.Imaging.Twain.Twain.GetCapabilityConstants.GetValues)
    '                curVal = TwainOptions.FillComboBox(twCap, ComboBoxBitDepth, TwainOptions.PixelTypeNames, True)
    '                ComboBoxBitDepth.Enabled = True
    '                theTwainOptions.PixelType = CType(curVal, LEAD.Drawing.Imaging.Twain.CapabilityValues.PixelTypeConstants)

    '                'Case LEAD.Drawing.Imaging.Twain.CapabilityConstants.ICAP_XRESOLUTION
    '                '    twCap = theTwain.GetCapability2(cap, LEAD.Drawing.Imaging.Twain.Twain.GetCapabilityConstants.GetValues)
    '                '    curVal = TwainOptions.FillComboBox(twCap, ComboBoxResolution, Nothing, False)
    '                '    ComboBoxResolution.Enabled = True
    '                '    theTwainOptions.Resolution = CType(curVal, Single)
    '        End Select
    '    Catch exp As System.Exception
    '        TwainOptions.ShowError(Me, exp.Message)
    '    End Try
    'End Sub
    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If rbBWImage.Checked = True Then
            cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_BW_200
        ElseIf rb256g200dpi.Checked = True Then
            cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_GRAY_200
        ElseIf rb256g300dpi.Checked = True Then
            cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_GRAY_300
        ElseIf rbColor200dpi.Checked = True Then
            cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_COLOR_200
        ElseIf rbColor300dpi.Checked = True Then
            cApplFunc.ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_A4_COLOR_300
        End If

        ' Side
        If rbSideAll.Checked = True Then
            cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
        ElseIf rbSideFront.Checked = True Then
            cApplFunc.Side = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
     
        End If



        'Dim id As ItemData = Nothing
        'Dim twCap As New LEAD.Drawing.Imaging.Twain.LEADTwainCapability()

        'id = CType(ComboBoxBitDepth.Items(ComboBoxBitDepth.SelectedIndex), ItemData)
        'If (Not (id.Data Is Nothing)) Then
        '    theTwainOptions.PixelType = CType(id.Data, LEAD.Drawing.Imaging.Twain.CapabilityValues.PixelTypeConstants)
        'End If
        'TwainOptions.SetCapability( _
        '  theTwain, _
        '  LEAD.Drawing.Imaging.Twain.CapabilityConstants.ICAP_PIXELTYPE, _
        '  theTwainOptions.PixelType, _
        '  LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT16)


        'twCap = theTwain.GetCapability2(LEAD.Drawing.Imaging.Twain.CapabilityConstants.CAP_DUPLEXENABLED, LEAD.Drawing.Imaging.Twain.Twain.GetCapabilityConstants.GetDefault)

        'twCap.CapOneValue.OneValCapValue = C_RearFront.Checked
        'theTwain.SetCapability2(twCap, LEAD.Drawing.Imaging.Twain.Twain.SetCapabilityConstants.Set)

        'twCap = theTwain.GetCapability2(LEAD.Drawing.Imaging.Twain.CapabilityConstants.ICAP_AUTOMATICDESKEW, LEAD.Drawing.Imaging.Twain.Twain.GetCapabilityConstants.GetDefault)
        'twCap.CapOneValue.OneValCapValue = True
        'theTwain.SetCapability2(twCap, LEAD.Drawing.Imaging.Twain.Twain.SetCapabilityConstants.Set)



        Me.Close()

    End Sub
End Class

Public Class ItemData

    Public Sub New(ByVal t As String, ByVal d As Object)
        Text = t
        Data = d
    End Sub

    Public Text As String = ""
    Public Data As Object = Nothing

    Public Overrides Function ToString() As String
        Return Text
    End Function

End Class

Public Class TwainOptions

    Private Shared title As String

    Public Sub New(ByVal t As String)
        title = t
    End Sub

    Public Units As LEAD.Drawing.Imaging.Twain.CapabilityValues.UnitsConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.UnitsConstants.TWUN_PIXELS
    Public LeftMargin As Single = 0.0F
    Public TopMargin As Single = 0.0F
    Public RightMargin As Single = 0.0F
    Public BottomMargin As Single = 0.0F
    Public XferMode As LEAD.Drawing.Imaging.Twain.CapabilityValues.XferMechConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.XferMechConstants.TWSX_NATIVE
    Public Compression As LEAD.Drawing.Imaging.Twain.CapabilityValues.CompressionConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.CompressionConstants.TWCP_NONE
    Public FileFormat As LEAD.Drawing.Imaging.Twain.CapabilityValues.FileFormatConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.FileFormatConstants.TWFF_BMP
    Public FilePath As String = ""
    Public PixelType As LEAD.Drawing.Imaging.Twain.CapabilityValues.PixelTypeConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.PixelTypeConstants.TWPT_GRAY
    Public Orientation As LEAD.Drawing.Imaging.Twain.CapabilityValues.OrientationConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.OrientationConstants.TWOR_ROT0
    Public Duple As LEAD.Drawing.Imaging.Twain.CapabilityValues.DuplexConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.DuplexConstants.TWDX_1PASSDUPLEX
    Public Resolution As Single = 0.0F
    Public HalfTone As String = ""
    Public Contrast As Single = 0.0F
    Public Brightness As Single = 0.0F
    Public HighLight As Single = 0.0F
    Public ImageFilter As LEAD.Drawing.Imaging.Twain.CapabilityValues.ImageFilterConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.ImageFilterConstants.TWIF_NONE
    Public NoiseFilter As LEAD.Drawing.Imaging.Twain.CapabilityValues.NoiseFilterConstants = LEAD.Drawing.Imaging.Twain.CapabilityValues.NoiseFilterConstants.TWNF_NONE
    Public Shared UnitNames() As String = {"Inches", "Centimeters", "Picas", "Points", "Twips", "Pixels"}
    Public Shared PixelTypeNames() As String = {"B&W", "256 Gray", "24-bit RGB", "256 Color", "CMY", "CMYK", "YUV", "YUVK", "CIEXYZ"}
    Public Shared OrientationNames() As String = {"0", "90", "180", "270"}
    Public Shared DuplexNames() As String = {"None", "1 Pass Duplex", "2 Pass Duplex"}
    Public Shared FileFormatNames() As String = {"Tiff", "Pict", "Bmp", "Xbm", "Jfif", "Fpx", "Tiff Multi", "Png", "Spiff", "Exif"}
    Public Shared CompressionNames() As String = {"None", "Pack Bits", "Group 3 1D (no End Of Line)", "Group 3 1D (has End Of Line)", "Group 3 2D", "Group 4", "JPEG", "LZW", "JBIG"}
    Public Shared NullArray() As String = Nothing

    Public Shared Function FillComboBox(ByVal capability As LEAD.Drawing.Imaging.Twain.LEADTwainCapability, ByVal combo As ComboBox, ByVal names() As String, ByVal nullNames As Boolean) As Object
        Dim curVal As Object = Nothing
        Dim capVal As Object = Nothing
        Dim count As Integer
        Dim curIndex As Integer
        Dim index As Integer
        Dim min As Integer
        Dim max As Integer
        Dim def As Integer
        Dim cur As Integer
        Dim stepSize As Integer
        Dim value As Integer
        Dim increment As Boolean
        Dim curIdx As Integer

        combo.Items.Clear()
        Select Case (capability.CapInfo.ContainerType)
            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ONEVALUE
                capVal = capability.CapOneValue.OneValCapValue
                If (capVal Is Nothing) Then
                    ShowError(Nothing, "ERROR ONEVALUE")
                End If

                Select Case (capability.CapOneValue.OneValItemType)
                    Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT8, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT16, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT32, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT8, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT16, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT32
                        If (Not (names Is Nothing) And (nullNames)) Then
                            combo.Items.Insert(0, New ItemData(names(CType(capVal, Integer)), capVal))
                        ElseIf (Not nullNames) Then
                            combo.Items.Insert(0, New ItemData(capVal.ToString(), capVal))
                        End If

                    Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_BOOL
                        combo.Items.Insert(0, New ItemData(capVal.ToString(), capVal))

                    Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_FIX32
                        combo.Items.Insert(0, New ItemData(capVal.ToString(), Nothing))

                End Select

                combo.SelectedIndex = 0
                curVal = capVal

            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ENUMERATION
                count = capability.CapEnum.EnumNumOfItems
                curIndex = capability.CapEnum.EnumCurrentIndex
                For index = 0 To count - 1
                    capVal = capability.CapEnum.GetEnumCapValue(index)

                    Select Case (capability.CapEnum.EnumItemType)
                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT8, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT16, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT32, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT8, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT16, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT32
                            If (Not (names Is Nothing) And (nullNames)) Then
                                combo.Items.Insert(index, New ItemData(names(CType(capVal, Integer)), capVal))
                            ElseIf (Not nullNames) Then
                                combo.Items.Insert(index, New ItemData(capVal.ToString(), capVal))
                            End If

                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_BOOL
                            combo.Items.Insert(index, New ItemData(capVal.ToString(), capVal))

                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_FIX32
                            combo.Items.Insert(index, New ItemData(capVal.ToString(), Nothing))

                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR32, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR64, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR128, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR255, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR1024
                            combo.Items.Insert(index, New ItemData(CType(capVal, String), Nothing))
                    End Select

                    If (index = curIndex) Then
                        curVal = capVal
                    End If
                Next index

                combo.SelectedIndex = curIndex

            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ARRAY
                capVal = capability.CapArray.GetArrayCapValue(0)
                curVal = capVal

                count = capability.CapArray.ArrayNumOfItems
                For index = 0 To count - 1
                    capVal = capability.CapArray.GetArrayCapValue(index)
                    Select Case (capability.CapArray.ArrayItemType)
                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT8, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT16, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_INT32, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT8, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT16, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_UINT32
                            If (Not (names Is Nothing) And (nullNames)) Then
                                combo.Items.Insert(index, New ItemData(capVal.ToString(), Nothing))
                            ElseIf (Not nullNames) Then
                                combo.Items.Insert(index, New ItemData(capVal.ToString(), capVal))
                            End If

                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_BOOL
                            combo.Items.Insert(index, New ItemData(capVal.ToString(), capVal))

                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_FIX32
                            combo.Items.Insert(index, New ItemData(capVal.ToString(), Nothing))

                        Case LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR32, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR64, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR128, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR255, LEAD.Drawing.Imaging.Twain.ItemTypeConstants.TWTY_STR1024
                            combo.Items.Insert(index, New ItemData(CType(capVal, String), Nothing))
                    End Select

                    If (index = 0) Then
                        curVal = capVal
                    End If

                Next index

                combo.SelectedIndex = 0

            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_RANGE
                min = CType(capability.CapRange.RangeMinimumValue, Integer)
                max = CType(capability.CapRange.RangeMaximumValue, Integer)
                stepSize = CType(capability.CapRange.RangeStepSize, Integer)
                def = CType(capability.CapRange.RangeDefaultValue, Integer)
                cur = CType(capability.CapRange.RangeCurrentValue, Integer)

                increment = True
                curIdx = 0
                index = 0

                For value = min To max Step value
                    If (value = cur) Then
                        increment = False
                        curVal = cur
                    End If

                    If increment Then curIdx = curIdx + 1
                    combo.Items.Insert(index, New ItemData(value.ToString(), Nothing))
                    index = index + 1
                    value = value + stepSize
                Next value

                combo.SelectedIndex = curIdx
        End Select

        Return curVal

    End Function

    Public Shared Function FillEditBox(ByVal capability As LEAD.Drawing.Imaging.Twain.LEADTwainCapability, ByVal names() As String) As Object
        Dim curVal As Object = Nothing
        Dim curIndex As Integer

        Select Case (capability.CapInfo.ContainerType)
            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ONEVALUE
                curVal = capability.CapOneValue.OneValCapValue
            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ENUMERATION
                curIndex = capability.CapEnum.EnumCurrentIndex
                curVal = capability.CapEnum.GetEnumCapValue(curIndex)
            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ARRAY
                curVal = capability.CapArray.GetArrayCapValue(0)
            Case LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_RANGE
                curVal = capability.CapRange.RangeCurrentValue
        End Select

        Return curVal
    End Function

    Public Shared Sub SetCapability(ByVal theTwain As LEAD.Drawing.Imaging.Twain.Twain, ByVal capType As LEAD.Drawing.Imaging.Twain.CapabilityConstants, ByVal capVal As Object, ByVal itemType As LEAD.Drawing.Imaging.Twain.ItemTypeConstants)

       



        Dim twCap As New LEAD.Drawing.Imaging.Twain.LEADTwainCapability()

        twCap.CapInfo.CapabilityType = capType
        twCap.CapInfo.ContainerType = LEAD.Drawing.Imaging.Twain.ContainerTypeConstants.TWON_ONEVALUE
        twCap.CapOneValue.OneValItemType = itemType
        twCap.CapOneValue.OneValCapValue = capVal

        theTwain.SetCapability2(twCap, LEAD.Drawing.Imaging.Twain.Twain.SetCapabilityConstants.Set)
    End Sub

    Public Shared Sub ShowError(ByVal owner As IWin32Window, ByVal text As String)
        MessageBox.Show(owner, text, title, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub

    Public Shared Function ParseFloat(ByVal tb As TextBox, ByVal def As Single) As Single
        Dim f As Single
        Try
            f = Single.Parse(tb.Text)
            Return f
        Catch exp As System.Exception
            tb.Text = def.ToString()
            Return def
        End Try
    End Function

    Public Shared Function CheckValidity(ByVal frm As Form) As Boolean
        Return CheckControls(frm, frm.Controls)
    End Function

    Private Shared Function CheckControls(ByVal frm As Form, ByVal ctrlCollection As System.Windows.Forms.Control.ControlCollection) As Boolean
        Dim i As Integer
        Dim str As String
        For i = 0 To ctrlCollection.Count - 1
            If (Not CheckControls(frm, ctrlCollection(i).Controls)) Then Return False

            If (TypeOf ctrlCollection(i) Is TextBox) Then

                str = ctrlCollection(i).Text
                str.Trim()
                If (str = "") Then
                    MessageBox.Show(frm, "Please enter a value!", frm.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    ctrlCollection(i).Focus()
                    Return False
                End If
            End If
        Next i

        Return True
    End Function

End Class