﻿Public Class Form2

    
    
    Public altessaCodeline As Int16
    Public ScanMode As Int16

    Private Sub Form2_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        If Not (Me.pbImage.Image Is Nothing) Then
            Me.pbImage.Image.Dispose()
            Me.pbImage.Image = Nothing
        End If
        

    End Sub

    
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'altessaCodeline = 0

        'If (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_300 Or _
        '         ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_300 Or _
        '         ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_300 Or _
        '         ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR300_AND_UV) Then
        '    Me.Size = New Size(Pimage.Width / 3, (Pimage.Height / 3) + altessaCodeline)
        'ElseIf (ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_BW Or _
        '        ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_16_GRAY_200 Or _
        '        ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256_GRAY_200 Or _
        '        ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_COLOR_200 Or _
        '        ScanMode = LsFamily.LsDefines.ScanMode.SCAN_MODE_256GR200_AND_UV) Then
        '    Me.Size = New Size(Pimage.Width / 2, (Pimage.Height / 2) + altessaCodeline)
        'Else
        '    Me.Size = New Size(Pimage.Width, Pimage.Height)
        'End If
        'Me.pbImage.Image = Pimage

    End Sub

  


End Class