﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistory800
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label
        Me.IDC_DOUBLE_LEAFING = New System.Windows.Forms.Label
        Me.IDC_DOC_PRINTED = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.IDC_TOT_TIME = New System.Windows.Forms.Label
        Me.IDC_POWER_ON = New System.Windows.Forms.Label
        Me.IDC_ERR_E13B = New System.Windows.Forms.Label
        Me.IDC_ERR_CMC7 = New System.Windows.Forms.Label
        Me.IDC_JAM_FEED = New System.Windows.Forms.Label
        Me.IDC_DOC_PROCESSED = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.IDC_JAM_FRONT_SCANNER = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.IDC_JAM_LEFT_TRACK = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.IDC_JAM_RIGHT_TRACK = New System.Windows.Forms.Label
        Me.IDC_JAM_BACK_SCANNER = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.IDC_JAM_AT_SORTERS = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(203, 13)
        Me.Label3.TabIndex = 94
        Me.Label3.Text = "Nr. jammed at back scanner ...................."
        '
        'IDC_DOUBLE_LEAFING
        '
        Me.IDC_DOUBLE_LEAFING.AutoSize = True
        Me.IDC_DOUBLE_LEAFING.Location = New System.Drawing.Point(261, 330)
        Me.IDC_DOUBLE_LEAFING.Name = "IDC_DOUBLE_LEAFING"
        Me.IDC_DOUBLE_LEAFING.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOUBLE_LEAFING.TabIndex = 91
        Me.IDC_DOUBLE_LEAFING.Text = "0000000000"
        '
        'IDC_DOC_PRINTED
        '
        Me.IDC_DOC_PRINTED.AutoSize = True
        Me.IDC_DOC_PRINTED.Location = New System.Drawing.Point(261, 297)
        Me.IDC_DOC_PRINTED.Name = "IDC_DOC_PRINTED"
        Me.IDC_DOC_PRINTED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PRINTED.TabIndex = 90
        Me.IDC_DOC_PRINTED.Text = "0000000000"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(31, 330)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(191, 13)
        Me.Label10.TabIndex = 89
        Me.Label10.Text = "Nr. of double leafing occurs ................."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(31, 297)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(195, 13)
        Me.Label9.TabIndex = 88
        Me.Label9.Text = "Nr. of documents printed ......................."
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(113, 424)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 24)
        Me.Button1.TabIndex = 87
        Me.Button1.Text = "Ok"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'IDC_TOT_TIME
        '
        Me.IDC_TOT_TIME.AutoSize = True
        Me.IDC_TOT_TIME.Location = New System.Drawing.Point(238, 401)
        Me.IDC_TOT_TIME.Name = "IDC_TOT_TIME"
        Me.IDC_TOT_TIME.Size = New System.Drawing.Size(67, 13)
        Me.IDC_TOT_TIME.TabIndex = 86
        Me.IDC_TOT_TIME.Text = "0000000000"
        '
        'IDC_POWER_ON
        '
        Me.IDC_POWER_ON.AutoSize = True
        Me.IDC_POWER_ON.Location = New System.Drawing.Point(261, 365)
        Me.IDC_POWER_ON.Name = "IDC_POWER_ON"
        Me.IDC_POWER_ON.Size = New System.Drawing.Size(67, 13)
        Me.IDC_POWER_ON.TabIndex = 85
        Me.IDC_POWER_ON.Text = "0000000000"
        '
        'IDC_ERR_E13B
        '
        Me.IDC_ERR_E13B.AutoSize = True
        Me.IDC_ERR_E13B.Location = New System.Drawing.Point(261, 238)
        Me.IDC_ERR_E13B.Name = "IDC_ERR_E13B"
        Me.IDC_ERR_E13B.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_E13B.TabIndex = 84
        Me.IDC_ERR_E13B.Text = "0000000000"
        '
        'IDC_ERR_CMC7
        '
        Me.IDC_ERR_CMC7.AutoSize = True
        Me.IDC_ERR_CMC7.Location = New System.Drawing.Point(261, 265)
        Me.IDC_ERR_CMC7.Name = "IDC_ERR_CMC7"
        Me.IDC_ERR_CMC7.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_CMC7.TabIndex = 83
        Me.IDC_ERR_CMC7.Text = "0000000000"
        '
        'IDC_JAM_FEED
        '
        Me.IDC_JAM_FEED.AutoSize = True
        Me.IDC_JAM_FEED.Location = New System.Drawing.Point(261, 49)
        Me.IDC_JAM_FEED.Name = "IDC_JAM_FEED"
        Me.IDC_JAM_FEED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_FEED.TabIndex = 81
        Me.IDC_JAM_FEED.Text = "0000000000"
        '
        'IDC_DOC_PROCESSED
        '
        Me.IDC_DOC_PROCESSED.AutoSize = True
        Me.IDC_DOC_PROCESSED.Location = New System.Drawing.Point(261, 19)
        Me.IDC_DOC_PROCESSED.Name = "IDC_DOC_PROCESSED"
        Me.IDC_DOC_PROCESSED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PROCESSED.TabIndex = 80
        Me.IDC_DOC_PROCESSED.Text = "0000000000"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(41, 401)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(180, 13)
        Me.Label11.TabIndex = 79
        Me.Label11.Text = "Total time of work (hh:mm:ss) ..........."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(31, 365)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(196, 13)
        Me.Label8.TabIndex = 78
        Me.Label8.Text = "Nr. of power ON of the peripheral .........."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(31, 238)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(194, 13)
        Me.Label7.TabIndex = 77
        Me.Label7.Text = "Nr. error in read E13B codeline ............."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(31, 265)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(194, 13)
        Me.Label6.TabIndex = 76
        Me.Label6.Text = "Nr. error in read CMC7 codeline ............"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(196, 13)
        Me.Label4.TabIndex = 74
        Me.Label4.Text = "Nr. jammed in feedering ........................."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 13)
        Me.Label1.TabIndex = 73
        Me.Label1.Text = "Nr. documents processed succefully ....."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(31, 81)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(200, 13)
        Me.Label12.TabIndex = 96
        Me.Label12.Text = "Nr. jammed at front scanner ...................."
        '
        'IDC_JAM_FRONT_SCANNER
        '
        Me.IDC_JAM_FRONT_SCANNER.AutoSize = True
        Me.IDC_JAM_FRONT_SCANNER.Location = New System.Drawing.Point(261, 81)
        Me.IDC_JAM_FRONT_SCANNER.Name = "IDC_JAM_FRONT_SCANNER"
        Me.IDC_JAM_FRONT_SCANNER.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_FRONT_SCANNER.TabIndex = 97
        Me.IDC_JAM_FRONT_SCANNER.Text = "0000000000"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(31, 116)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(201, 13)
        Me.Label13.TabIndex = 98
        Me.Label13.Text = "Nr. jammed in left document track ..........."
        '
        'IDC_JAM_LEFT_TRACK
        '
        Me.IDC_JAM_LEFT_TRACK.AutoSize = True
        Me.IDC_JAM_LEFT_TRACK.Location = New System.Drawing.Point(261, 116)
        Me.IDC_JAM_LEFT_TRACK.Name = "IDC_JAM_LEFT_TRACK"
        Me.IDC_JAM_LEFT_TRACK.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_LEFT_TRACK.TabIndex = 99
        Me.IDC_JAM_LEFT_TRACK.Text = "0000000000"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(31, 146)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(201, 13)
        Me.Label14.TabIndex = 100
        Me.Label14.Text = "Nr. jammed in right document track ........."
        '
        'IDC_JAM_RIGHT_TRACK
        '
        Me.IDC_JAM_RIGHT_TRACK.AutoSize = True
        Me.IDC_JAM_RIGHT_TRACK.Location = New System.Drawing.Point(261, 146)
        Me.IDC_JAM_RIGHT_TRACK.Name = "IDC_JAM_RIGHT_TRACK"
        Me.IDC_JAM_RIGHT_TRACK.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_RIGHT_TRACK.TabIndex = 101
        Me.IDC_JAM_RIGHT_TRACK.Text = "0000000000"
        '
        'IDC_JAM_BACK_SCANNER
        '
        Me.IDC_JAM_BACK_SCANNER.AutoSize = True
        Me.IDC_JAM_BACK_SCANNER.Location = New System.Drawing.Point(261, 179)
        Me.IDC_JAM_BACK_SCANNER.Name = "IDC_JAM_BACK_SCANNER"
        Me.IDC_JAM_BACK_SCANNER.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_BACK_SCANNER.TabIndex = 102
        Me.IDC_JAM_BACK_SCANNER.Text = "0000000000"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 206)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(204, 13)
        Me.Label2.TabIndex = 103
        Me.Label2.Text = "Nr. jammed in the sorters .........................."
        '
        'IDC_JAM_AT_SORTERS
        '
        Me.IDC_JAM_AT_SORTERS.AutoSize = True
        Me.IDC_JAM_AT_SORTERS.Location = New System.Drawing.Point(261, 206)
        Me.IDC_JAM_AT_SORTERS.Name = "IDC_JAM_AT_SORTERS"
        Me.IDC_JAM_AT_SORTERS.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_AT_SORTERS.TabIndex = 104
        Me.IDC_JAM_AT_SORTERS.Text = "0000000000"
        '
        'frmHistory800
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(359, 472)
        Me.Controls.Add(Me.IDC_JAM_AT_SORTERS)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.IDC_JAM_BACK_SCANNER)
        Me.Controls.Add(Me.IDC_JAM_RIGHT_TRACK)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.IDC_JAM_LEFT_TRACK)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.IDC_JAM_FRONT_SCANNER)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.IDC_DOUBLE_LEAFING)
        Me.Controls.Add(Me.IDC_DOC_PRINTED)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.IDC_TOT_TIME)
        Me.Controls.Add(Me.IDC_POWER_ON)
        Me.Controls.Add(Me.IDC_ERR_E13B)
        Me.Controls.Add(Me.IDC_ERR_CMC7)
        Me.Controls.Add(Me.IDC_JAM_FEED)
        Me.Controls.Add(Me.IDC_DOC_PROCESSED)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmHistory800"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "History800"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents IDC_DOUBLE_LEAFING As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PRINTED As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents IDC_TOT_TIME As System.Windows.Forms.Label
    Friend WithEvents IDC_POWER_ON As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_E13B As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_CMC7 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_FEED As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PROCESSED As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_FRONT_SCANNER As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_LEFT_TRACK As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_RIGHT_TRACK As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_BACK_SCANNER As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_AT_SORTERS As System.Windows.Forms.Label
End Class
