﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FCanonOption
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBoxBitDepth = New System.Windows.Forms.ComboBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.C_RearFront = New System.Windows.Forms.CheckBox
        Me.rbSideAll = New System.Windows.Forms.RadioButton
        Me.rbSideFront = New System.Windows.Forms.RadioButton
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.rbBWImage = New System.Windows.Forms.RadioButton
        Me.rbColor200dpi = New System.Windows.Forms.RadioButton
        Me.rbColor300dpi = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rb256g300dpi = New System.Windows.Forms.RadioButton
        Me.rb256g200dpi = New System.Windows.Forms.RadioButton
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBoxBitDepth
        '
        Me.ComboBoxBitDepth.FormattingEnabled = True
        Me.ComboBoxBitDepth.Location = New System.Drawing.Point(388, 194)
        Me.ComboBoxBitDepth.Name = "ComboBoxBitDepth"
        Me.ComboBoxBitDepth.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxBitDepth.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(89, 201)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Set"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(320, 197)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "ScanMode:"
        '
        'C_RearFront
        '
        Me.C_RearFront.AutoSize = True
        Me.C_RearFront.Location = New System.Drawing.Point(388, 235)
        Me.C_RearFront.Name = "C_RearFront"
        Me.C_RearFront.Size = New System.Drawing.Size(78, 17)
        Me.C_RearFront.TabIndex = 5
        Me.C_RearFront.Text = "Rear/Front"
        Me.C_RearFront.UseVisualStyleBackColor = True
        '
        'rbSideAll
        '
        Me.rbSideAll.Location = New System.Drawing.Point(13, 21)
        Me.rbSideAll.Name = "rbSideAll"
        Me.rbSideAll.Size = New System.Drawing.Size(54, 21)
        Me.rbSideAll.TabIndex = 0
        Me.rbSideAll.Text = "All"
        '
        'rbSideFront
        '
        Me.rbSideFront.Location = New System.Drawing.Point(13, 42)
        Me.rbSideFront.Name = "rbSideFront"
        Me.rbSideFront.Size = New System.Drawing.Size(54, 20)
        Me.rbSideFront.TabIndex = 1
        Me.rbSideFront.Text = "Front"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbSideFront)
        Me.GroupBox3.Controls.Add(Me.rbSideAll)
        Me.GroupBox3.Location = New System.Drawing.Point(163, 26)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(73, 71)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Side"
        '
        'rbBWImage
        '
        Me.rbBWImage.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbBWImage.Location = New System.Drawing.Point(7, 22)
        Me.rbBWImage.Name = "rbBWImage"
        Me.rbBWImage.Size = New System.Drawing.Size(119, 20)
        Me.rbBWImage.TabIndex = 0
        Me.rbBWImage.Text = "B/W Image"
        Me.rbBWImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rbColor200dpi
        '
        Me.rbColor200dpi.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbColor200dpi.Location = New System.Drawing.Point(7, 80)
        Me.rbColor200dpi.Name = "rbColor200dpi"
        Me.rbColor200dpi.Size = New System.Drawing.Size(119, 21)
        Me.rbColor200dpi.TabIndex = 8
        Me.rbColor200dpi.Text = "Color 200 dpi"
        Me.rbColor200dpi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rbColor300dpi
        '
        Me.rbColor300dpi.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbColor300dpi.Location = New System.Drawing.Point(7, 102)
        Me.rbColor300dpi.Name = "rbColor300dpi"
        Me.rbColor300dpi.Size = New System.Drawing.Size(119, 21)
        Me.rbColor300dpi.TabIndex = 9
        Me.rbColor300dpi.Text = "Color 300 dpi"
        Me.rbColor300dpi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbColor300dpi)
        Me.GroupBox2.Controls.Add(Me.rb256g300dpi)
        Me.GroupBox2.Controls.Add(Me.rbColor200dpi)
        Me.GroupBox2.Controls.Add(Me.rb256g200dpi)
        Me.GroupBox2.Controls.Add(Me.rbBWImage)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 26)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(141, 143)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Scan Mode"
        '
        'rb256g300dpi
        '
        Me.rb256g300dpi.Appearance = System.Windows.Forms.Appearance.Button
        Me.rb256g300dpi.Location = New System.Drawing.Point(7, 60)
        Me.rb256g300dpi.Name = "rb256g300dpi"
        Me.rb256g300dpi.Size = New System.Drawing.Size(119, 21)
        Me.rb256g300dpi.TabIndex = 6
        Me.rb256g300dpi.Text = "256 gray 300 dpi"
        Me.rb256g300dpi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rb256g200dpi
        '
        Me.rb256g200dpi.Appearance = System.Windows.Forms.Appearance.Button
        Me.rb256g200dpi.Location = New System.Drawing.Point(7, 40)
        Me.rb256g200dpi.Name = "rb256g200dpi"
        Me.rb256g200dpi.Size = New System.Drawing.Size(119, 20)
        Me.rb256g200dpi.TabIndex = 5
        Me.rb256g200dpi.Text = "256 gray 200 dpi"
        Me.rb256g200dpi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FCanonOption
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(247, 236)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.C_RearFront)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBoxBitDepth)
        Me.Name = "FCanonOption"
        Me.Text = "Option"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBoxBitDepth As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents C_RearFront As System.Windows.Forms.CheckBox
    Friend WithEvents rbSideAll As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideFront As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbBWImage As System.Windows.Forms.RadioButton
    Friend WithEvents rbColor200dpi As System.Windows.Forms.RadioButton
    Friend WithEvents rbColor300dpi As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rb256g300dpi As System.Windows.Forms.RadioButton
    Friend WithEvents rb256g200dpi As System.Windows.Forms.RadioButton
End Class
