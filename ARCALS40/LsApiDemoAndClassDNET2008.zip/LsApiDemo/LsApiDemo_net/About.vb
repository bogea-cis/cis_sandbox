﻿Public Class formAbout

    Private Sub llCtsSito_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llCtsSito.LinkClicked

        ' Change the color of the link text by setting LinkVisited 
        ' to True.
        llCtsSito.LinkVisited = True

        Try
            ' Call the Process.Start method to open the default browser 
            ' with a URL:
            System.Diagnostics.Process.Start("http://www.ctsgroup.it")

        Catch ex As Exception
            ' The error message
            MessageBox.Show("Unable to open link that was clicked.")
        End Try

    End Sub

   

  
End Class