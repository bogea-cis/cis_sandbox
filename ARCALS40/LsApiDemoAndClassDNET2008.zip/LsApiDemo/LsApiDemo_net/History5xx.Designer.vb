﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistory5xx
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.IDC_TOT_TIME = New System.Windows.Forms.Label
        Me.IDC_ERR_BARCODE = New System.Windows.Forms.Label
        Me.IDC_POWER_ON = New System.Windows.Forms.Label
        Me.IDC_ERR_E13B = New System.Windows.Forms.Label
        Me.IDC_ERR_CMC7 = New System.Windows.Forms.Label
        Me.IDC_JAM_SCANNER = New System.Windows.Forms.Label
        Me.IDC_JAM_MICR = New System.Windows.Forms.Label
        Me.IDC_JAM_FEEDER = New System.Windows.Forms.Label
        Me.IDC_DOC_PROCESSED = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.IDC_JAM_STAMP = New System.Windows.Forms.Label
        Me.IDC_RETAINED_FILM = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.IDC_RETAINED_MICR = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.IDC_ERR_OPTIC = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(138, 426)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 24)
        Me.Button1.TabIndex = 91
        Me.Button1.Text = "Ok"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'IDC_TOT_TIME
        '
        Me.IDC_TOT_TIME.AutoSize = True
        Me.IDC_TOT_TIME.Location = New System.Drawing.Point(251, 386)
        Me.IDC_TOT_TIME.Name = "IDC_TOT_TIME"
        Me.IDC_TOT_TIME.Size = New System.Drawing.Size(67, 13)
        Me.IDC_TOT_TIME.TabIndex = 90
        Me.IDC_TOT_TIME.Text = "0000000000"
        '
        'IDC_ERR_BARCODE
        '
        Me.IDC_ERR_BARCODE.AutoSize = True
        Me.IDC_ERR_BARCODE.Location = New System.Drawing.Point(270, 300)
        Me.IDC_ERR_BARCODE.Name = "IDC_ERR_BARCODE"
        Me.IDC_ERR_BARCODE.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_BARCODE.TabIndex = 89
        Me.IDC_ERR_BARCODE.Text = "0000000000"
        '
        'IDC_POWER_ON
        '
        Me.IDC_POWER_ON.AutoSize = True
        Me.IDC_POWER_ON.Location = New System.Drawing.Point(270, 333)
        Me.IDC_POWER_ON.Name = "IDC_POWER_ON"
        Me.IDC_POWER_ON.Size = New System.Drawing.Size(67, 13)
        Me.IDC_POWER_ON.TabIndex = 87
        Me.IDC_POWER_ON.Text = "0000000000"
        '
        'IDC_ERR_E13B
        '
        Me.IDC_ERR_E13B.AutoSize = True
        Me.IDC_ERR_E13B.Location = New System.Drawing.Point(270, 242)
        Me.IDC_ERR_E13B.Name = "IDC_ERR_E13B"
        Me.IDC_ERR_E13B.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_E13B.TabIndex = 86
        Me.IDC_ERR_E13B.Text = "0000000000"
        '
        'IDC_ERR_CMC7
        '
        Me.IDC_ERR_CMC7.AutoSize = True
        Me.IDC_ERR_CMC7.Location = New System.Drawing.Point(270, 211)
        Me.IDC_ERR_CMC7.Name = "IDC_ERR_CMC7"
        Me.IDC_ERR_CMC7.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_CMC7.TabIndex = 85
        Me.IDC_ERR_CMC7.Text = "0000000000"
        '
        'IDC_JAM_SCANNER
        '
        Me.IDC_JAM_SCANNER.AutoSize = True
        Me.IDC_JAM_SCANNER.Location = New System.Drawing.Point(270, 123)
        Me.IDC_JAM_SCANNER.Name = "IDC_JAM_SCANNER"
        Me.IDC_JAM_SCANNER.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_SCANNER.TabIndex = 83
        Me.IDC_JAM_SCANNER.Text = "0000000000"
        '
        'IDC_JAM_MICR
        '
        Me.IDC_JAM_MICR.AutoSize = True
        Me.IDC_JAM_MICR.Location = New System.Drawing.Point(270, 67)
        Me.IDC_JAM_MICR.Name = "IDC_JAM_MICR"
        Me.IDC_JAM_MICR.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_MICR.TabIndex = 82
        Me.IDC_JAM_MICR.Text = "0000000000"
        '
        'IDC_JAM_FEEDER
        '
        Me.IDC_JAM_FEEDER.AutoSize = True
        Me.IDC_JAM_FEEDER.Location = New System.Drawing.Point(270, 43)
        Me.IDC_JAM_FEEDER.Name = "IDC_JAM_FEEDER"
        Me.IDC_JAM_FEEDER.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_FEEDER.TabIndex = 81
        Me.IDC_JAM_FEEDER.Text = "0000000000"
        '
        'IDC_DOC_PROCESSED
        '
        Me.IDC_DOC_PROCESSED.AutoSize = True
        Me.IDC_DOC_PROCESSED.Location = New System.Drawing.Point(270, 19)
        Me.IDC_DOC_PROCESSED.Name = "IDC_DOC_PROCESSED"
        Me.IDC_DOC_PROCESSED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PROCESSED.TabIndex = 80
        Me.IDC_DOC_PROCESSED.Text = "0000000000"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(52, 386)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(180, 13)
        Me.Label11.TabIndex = 79
        Me.Label11.Text = "Total time of work (hh:mm:ss) ..........."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(33, 300)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(198, 13)
        Me.Label10.TabIndex = 78
        Me.Label10.Text = "Nr. error in read barcode codeline .........."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(36, 333)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(196, 13)
        Me.Label8.TabIndex = 76
        Me.Label8.Text = "Nr. of power ON of the peripheral .........."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(194, 13)
        Me.Label7.TabIndex = 75
        Me.Label7.Text = "Nr. error in read E13B codeline ............."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 211)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(194, 13)
        Me.Label6.TabIndex = 74
        Me.Label6.Text = "Nr. error in read CMC7 codeline ............"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 123)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(197, 13)
        Me.Label4.TabIndex = 72
        Me.Label4.Text = "Nr. jammed at the scanner photo ..........."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(197, 13)
        Me.Label3.TabIndex = 71
        Me.Label3.Text = "Nr. jammed in the read MICR photo ......."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(196, 13)
        Me.Label2.TabIndex = 70
        Me.Label2.Text = "Nr. jammed in feedering ........................."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 13)
        Me.Label1.TabIndex = 69
        Me.Label1.Text = "Nr. documents processed succefully ....."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(33, 96)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(195, 13)
        Me.Label12.TabIndex = 92
        Me.Label12.Text = "Nr. jammed in the stamp photo .............."
        '
        'IDC_JAM_STAMP
        '
        Me.IDC_JAM_STAMP.AutoSize = True
        Me.IDC_JAM_STAMP.Location = New System.Drawing.Point(270, 96)
        Me.IDC_JAM_STAMP.Name = "IDC_JAM_STAMP"
        Me.IDC_JAM_STAMP.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_STAMP.TabIndex = 93
        Me.IDC_JAM_STAMP.Text = "0000000000"
        '
        'IDC_RETAINED_FILM
        '
        Me.IDC_RETAINED_FILM.AutoSize = True
        Me.IDC_RETAINED_FILM.Location = New System.Drawing.Point(270, 149)
        Me.IDC_RETAINED_FILM.Name = "IDC_RETAINED_FILM"
        Me.IDC_RETAINED_FILM.Size = New System.Drawing.Size(67, 13)
        Me.IDC_RETAINED_FILM.TabIndex = 95
        Me.IDC_RETAINED_FILM.Text = "0000000000"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(33, 149)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(195, 13)
        Me.Label13.TabIndex = 94
        Me.Label13.Text = "Nr. documents retained after film ..........."
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(33, 179)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(195, 13)
        Me.Label14.TabIndex = 96
        Me.Label14.Text = "Nr. documents retained after read MICR"
        '
        'IDC_RETAINED_MICR
        '
        Me.IDC_RETAINED_MICR.AutoSize = True
        Me.IDC_RETAINED_MICR.Location = New System.Drawing.Point(270, 179)
        Me.IDC_RETAINED_MICR.Name = "IDC_RETAINED_MICR"
        Me.IDC_RETAINED_MICR.Size = New System.Drawing.Size(67, 13)
        Me.IDC_RETAINED_MICR.TabIndex = 97
        Me.IDC_RETAINED_MICR.Text = "0000000000"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 269)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 13)
        Me.Label5.TabIndex = 98
        Me.Label5.Text = "Nr. error in read optical codeline ............"
        '
        'IDC_ERR_OPTIC
        '
        Me.IDC_ERR_OPTIC.AutoSize = True
        Me.IDC_ERR_OPTIC.Location = New System.Drawing.Point(270, 269)
        Me.IDC_ERR_OPTIC.Name = "IDC_ERR_OPTIC"
        Me.IDC_ERR_OPTIC.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_OPTIC.TabIndex = 99
        Me.IDC_ERR_OPTIC.Text = "0000000000"
        '
        'frmHistory5xx
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(370, 466)
        Me.Controls.Add(Me.IDC_ERR_OPTIC)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.IDC_RETAINED_MICR)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.IDC_RETAINED_FILM)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.IDC_JAM_STAMP)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.IDC_TOT_TIME)
        Me.Controls.Add(Me.IDC_ERR_BARCODE)
        Me.Controls.Add(Me.IDC_POWER_ON)
        Me.Controls.Add(Me.IDC_ERR_E13B)
        Me.Controls.Add(Me.IDC_ERR_CMC7)
        Me.Controls.Add(Me.IDC_JAM_SCANNER)
        Me.Controls.Add(Me.IDC_JAM_MICR)
        Me.Controls.Add(Me.IDC_JAM_FEEDER)
        Me.Controls.Add(Me.IDC_DOC_PROCESSED)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmHistory5xx"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "History5xx"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents IDC_TOT_TIME As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_BARCODE As System.Windows.Forms.Label
    Friend WithEvents IDC_POWER_ON As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_E13B As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_CMC7 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_SCANNER As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_MICR As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_FEEDER As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PROCESSED As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_STAMP As System.Windows.Forms.Label
    Friend WithEvents IDC_RETAINED_FILM As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents IDC_RETAINED_MICR As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_OPTIC As System.Windows.Forms.Label
End Class
