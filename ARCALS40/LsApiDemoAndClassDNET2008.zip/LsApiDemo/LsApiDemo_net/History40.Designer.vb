﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistory40
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.IDC_TOT_TIME = New System.Windows.Forms.Label
        Me.IDC_DOC_STAMPED = New System.Windows.Forms.Label
        Me.IDC_DOC_PRINTED = New System.Windows.Forms.Label
        Me.IDC_POWER_ON = New System.Windows.Forms.Label
        Me.IDC_ERR_E13B = New System.Windows.Forms.Label
        Me.IDC_ERR_CMC7 = New System.Windows.Forms.Label
        Me.IDC_RETAINED_DOC = New System.Windows.Forms.Label
        Me.IDC_JAM_FEED = New System.Windows.Forms.Label
        Me.IDC_DOC_PROCESSED = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(109, 301)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 24)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "Ok"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'IDC_TOT_TIME
        '
        Me.IDC_TOT_TIME.AutoSize = True
        Me.IDC_TOT_TIME.Location = New System.Drawing.Point(234, 260)
        Me.IDC_TOT_TIME.Name = "IDC_TOT_TIME"
        Me.IDC_TOT_TIME.Size = New System.Drawing.Size(67, 13)
        Me.IDC_TOT_TIME.TabIndex = 44
        Me.IDC_TOT_TIME.Text = "0000000000"
        '
        'IDC_DOC_STAMPED
        '
        Me.IDC_DOC_STAMPED.AutoSize = True
        Me.IDC_DOC_STAMPED.Location = New System.Drawing.Point(257, 69)
        Me.IDC_DOC_STAMPED.Name = "IDC_DOC_STAMPED"
        Me.IDC_DOC_STAMPED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_STAMPED.TabIndex = 43
        Me.IDC_DOC_STAMPED.Text = "0000000000"
        '
        'IDC_DOC_PRINTED
        '
        Me.IDC_DOC_PRINTED.AutoSize = True
        Me.IDC_DOC_PRINTED.Location = New System.Drawing.Point(257, 47)
        Me.IDC_DOC_PRINTED.Name = "IDC_DOC_PRINTED"
        Me.IDC_DOC_PRINTED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PRINTED.TabIndex = 42
        Me.IDC_DOC_PRINTED.Text = "0000000000"
        '
        'IDC_POWER_ON
        '
        Me.IDC_POWER_ON.AutoSize = True
        Me.IDC_POWER_ON.Location = New System.Drawing.Point(257, 196)
        Me.IDC_POWER_ON.Name = "IDC_POWER_ON"
        Me.IDC_POWER_ON.Size = New System.Drawing.Size(67, 13)
        Me.IDC_POWER_ON.TabIndex = 41
        Me.IDC_POWER_ON.Text = "0000000000"
        '
        'IDC_ERR_E13B
        '
        Me.IDC_ERR_E13B.AutoSize = True
        Me.IDC_ERR_E13B.Location = New System.Drawing.Point(257, 173)
        Me.IDC_ERR_E13B.Name = "IDC_ERR_E13B"
        Me.IDC_ERR_E13B.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_E13B.TabIndex = 40
        Me.IDC_ERR_E13B.Text = "0000000000"
        '
        'IDC_ERR_CMC7
        '
        Me.IDC_ERR_CMC7.AutoSize = True
        Me.IDC_ERR_CMC7.Location = New System.Drawing.Point(257, 148)
        Me.IDC_ERR_CMC7.Name = "IDC_ERR_CMC7"
        Me.IDC_ERR_CMC7.Size = New System.Drawing.Size(67, 13)
        Me.IDC_ERR_CMC7.TabIndex = 39
        Me.IDC_ERR_CMC7.Text = "0000000000"
        '
        'IDC_RETAINED_DOC
        '
        Me.IDC_RETAINED_DOC.AutoSize = True
        Me.IDC_RETAINED_DOC.Location = New System.Drawing.Point(257, 121)
        Me.IDC_RETAINED_DOC.Name = "IDC_RETAINED_DOC"
        Me.IDC_RETAINED_DOC.Size = New System.Drawing.Size(67, 13)
        Me.IDC_RETAINED_DOC.TabIndex = 38
        Me.IDC_RETAINED_DOC.Text = "0000000000"
        '
        'IDC_JAM_FEED
        '
        Me.IDC_JAM_FEED.AutoSize = True
        Me.IDC_JAM_FEED.Location = New System.Drawing.Point(257, 96)
        Me.IDC_JAM_FEED.Name = "IDC_JAM_FEED"
        Me.IDC_JAM_FEED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_JAM_FEED.TabIndex = 37
        Me.IDC_JAM_FEED.Text = "0000000000"
        '
        'IDC_DOC_PROCESSED
        '
        Me.IDC_DOC_PROCESSED.AutoSize = True
        Me.IDC_DOC_PROCESSED.Location = New System.Drawing.Point(257, 21)
        Me.IDC_DOC_PROCESSED.Name = "IDC_DOC_PROCESSED"
        Me.IDC_DOC_PROCESSED.Size = New System.Drawing.Size(67, 13)
        Me.IDC_DOC_PROCESSED.TabIndex = 34
        Me.IDC_DOC_PROCESSED.Text = "0000000000"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(37, 260)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(180, 13)
        Me.Label11.TabIndex = 33
        Me.Label11.Text = "Total time of work (hh:mm:ss) ..........."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(27, 69)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(194, 13)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Nr. of documents stamped ...................."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(27, 47)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(195, 13)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Nr. of documents printed ......................."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(27, 196)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(196, 13)
        Me.Label8.TabIndex = 30
        Me.Label8.Text = "Nr. of power ON of the peripheral .........."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(27, 173)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(194, 13)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Nr. error in read E13B codeline ............."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 148)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(194, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Nr. error in read CMC7 codeline ............"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 121)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(195, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Nr. documents retained ........................."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(196, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Nr. jammed in feedering ........................."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Nr. documents processed succefully ....."
        '
        'frmHistory40
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(335, 342)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.IDC_TOT_TIME)
        Me.Controls.Add(Me.IDC_DOC_STAMPED)
        Me.Controls.Add(Me.IDC_DOC_PRINTED)
        Me.Controls.Add(Me.IDC_POWER_ON)
        Me.Controls.Add(Me.IDC_ERR_E13B)
        Me.Controls.Add(Me.IDC_ERR_CMC7)
        Me.Controls.Add(Me.IDC_RETAINED_DOC)
        Me.Controls.Add(Me.IDC_JAM_FEED)
        Me.Controls.Add(Me.IDC_DOC_PROCESSED)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmHistory40"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "History40"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents IDC_TOT_TIME As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_STAMPED As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PRINTED As System.Windows.Forms.Label
    Friend WithEvents IDC_POWER_ON As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_E13B As System.Windows.Forms.Label
    Friend WithEvents IDC_ERR_CMC7 As System.Windows.Forms.Label
    Friend WithEvents IDC_RETAINED_DOC As System.Windows.Forms.Label
    Friend WithEvents IDC_JAM_FEED As System.Windows.Forms.Label
    Friend WithEvents IDC_DOC_PROCESSED As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
