﻿Imports System.Runtime.InteropServices


Public Class frmCtsMonitor
    ' Allocco la classe LsFamily
    Dim Ls As LsFamily.LsApi

    Dim Model As String = New String(" ", 20)
    Dim Version As String = New String(" ", 20)
    Dim FwDate As String = New String(" ", 20)
    Dim UnitID As String = New String(" ", 20)
    Dim stTime As String = New String(" ", 16)
    Dim LsCfg As LsFamily.LsConfiguration
    Dim Status As LsFamily.LsUnitStatus
    Dim History As LsFamily.LsHistory


    Private Sub frmCtsMonitor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FunzioneThread()
    End Sub


    Private Function UnitConfig(ByVal Lsunit As Int16, ByRef LsCfg As LsFamily.LsConfiguration, ByRef LsStatus As LsFamily.LsUnitStatus, ByRef Model As String, ByRef Version As String, ByRef FwDate As String, ByRef S_History As LsFamily.LsHistory, ByRef stTime As String) As Int32
        Dim Ls As LsFamily.LsApi = New LsFamily.LsApi
        Dim hLs As Int16
        Dim rc As Int32

        Ls.LSDebug("----- formOptions_UnitConfig Inizio")
        rc = Ls.LSConnect(0, Lsunit, hLs, True)
        Ls.LSDebug("----- formOptions_UnitConfig 1")
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            Ls.LSDebug("----- formOptions_UnitConfig 2")
            ' rc = Ls.LSIdentify(hLs, 0, LsCfg, 0, 0, 0, 0)
            rc = Ls.LSIdentify(hLs, 0, LsCfg, Model, Version, FwDate, UnitID)
            rc = Ls.LSUnitStatus(hLs, 0, LsStatus)
            rc = Ls.LSHistory(hLs, 0, S_History, stTime)
            Ls.LSDebug("----- formOptions_UnitConfig 3")
            rc = Ls.LSDisconnect(hLs, 0)
            Ls.LSDebug("----- formOptions_UnitConfig 4")
        End If
        Ls.LSDebug("----- formOptions_UnitConfig Fine")

        Return rc
    End Function

    Private Sub FunzioneThread()

        Dim Reply As Integer
        '        Dim Connessione As Short
        Dim Periferica As Short ' LS_40_USB;
        Dim hWnd As Int32
        Dim hInst As Int32
        Dim FErrore As Boolean
        ' Dim hLs As Int16
        Dim MsgText As String = New String(" ", 2048)


        hWnd = 0
        hInst = 0
        FErrore = False
        Reply = LsFamily.LsReply.LS_OKAY

        LsCfg = New LsFamily.LsConfiguration
        Status = New LsFamily.LsUnitStatus
        History = New LsFamily.LsHistory

        'richTextBox1.Text += WriteSnapShot() SCRIVE ORA E DATA

        'Reply = LSConnect(hWnd, hInst, Periferica, ref Connessione)
        'Reply = Ls.LSConnect(hWnd, LsUnitType, hLS, True)
        'If ((Reply = LsFamily.LsReply.LS_OKAY) Or (Reply = LsFamily.LsReply.LS_ALREADY_OPEN)) Then
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_LSCONNECT) Then
            ' ls 40 connesso
            LPerif.Text = "CTS LS 40 Connected"
            LPerif.ForeColor = Color.Green
            Periferica = 40
        ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
            'ls 150 connesso
            LPerif.Text = "CTS LS 150 Connected"
            LPerif.ForeColor = Color.Green
            Periferica = 150
        ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_LSCONNECT) Then
            'ls 100 connesso
            LPerif.Text = "CTS LS 100 Connected"
            LPerif.ForeColor = Color.Green
        ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_LSCONNECT) Then
            'ls 515 connesso
            LPerif.Text = "CTS LS 515 Connected"
            LPerif.ForeColor = Color.Green
        ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB) Then
            'ls 515 connesso
            LPerif.Text = "CTS LS 520 Connected"
            LPerif.ForeColor = Color.Green
        ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            'ls 515 connesso
            LPerif.Text = "CTS LS 800 Connected"
            LPerif.ForeColor = Color.Green
        Else

            LPerif.Text = "CTS Peripheral NOT Connected"
            LPerif.ForeColor = Color.Orange
            FErrore = True
        End If

        'End If
        If ((Reply = LsFamily.LsReply.LS_OKAY) Or (Reply = LsFamily.LsReply.LS_ALREADY_OPEN)) Then
            'Reply = Ls.LSIdentify(hLs, hWnd, LsCfg, Model, Version, FwDate, UnitID)
            Reply = UnitConfig(LsUnitType, LsCfg, Status, Model, Version, FwDate, History, stTime)
            If (Reply = LsFamily.LsReply.LS_OKAY) Then

                Writeidentify(LsUnitType)
            End If

        End If

        'End
        
    End Sub


    Public Sub Writeidentify(ByVal Periferica As Short)
        'Dim SMessaggi As String = New String(" ", 200)
        Dim MsgText As String = New String(" ", 2048)


        MsgText = "//-------------------NEW SNAPSHOT-------------//" + Chr(13) + "[SNAPSHOT DATE]" + Chr(13)
        MsgText += "Date = " + DateTime.Now.ToShortDateString() + Chr(13)
        MsgText += "Hour = " + DateTime.Now.ToShortTimeString() + Chr(13)
        MsgText += Chr(13)

        MsgText += "[CONFIGURATION]" + Chr(13)

        'Select Case Periferica
        If (Model <> "") Then
            MsgText += "Device Name = " + Model + Chr(13)
        End If

        If (UnitID <> "") Then
            MsgText += "SerialNumber = " + UnitID + Chr(13)
        End If
        If (Version <> "") Then
            MsgText += "Firmware Version = " + Version + Chr(13)
        End If
        If (FwDate <> "") Then
            MsgText += "Release Date = " + FwDate + Chr(13)
        End If
        '            SMessaggi += "Endorsement Print Version = " + SInkJetVersion + "\n"
        '            If (SFeederVersion <> "") Then
        '                SMessaggi += "Feeder Version = " + SFeederVersion + "\n"
        '                If (SSorterVersion <> "") Then
        '                    SMessaggi += "Sorter Version = " + SSorterVersion + "\n"
        '                    If (SMotorVersion <> "") Then
        '                        SMessaggi += "Motor Version = " + SMotorVersion + "\n"
        'End Select

        If (LsCfg.MICR_Reader) Then
            MsgText += "Micr Reader = " + "True" + Chr(13)
        Else
            MsgText += "Micr Reader = " + "False" + Chr(13)
        End If

        'If (LsCfg.OCR_Reader) Then
        '    MsgText += "OCR reader= " + "True" + Chr(13)
        'Else
        '   MsgText += "OCR reader= " + "False" + Chr(13)
        'End If

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then

            If (LsCfg.HightSpeed) Then
                MsgText += "High Speed = " + "False" + Chr(13)
            Else
                MsgText += "High Speed =" + "True" + Chr(13)
            End If

            If (LsCfg.FeederMotorized) Then
                MsgText += "Motorized Feeder = " + "True" + Chr(13)
            Else
                MsgText += "Motorized Feeder = " + "False" + Chr(13)
            End If

            If (LsCfg.ScannerUltraViolet) Then
                MsgText += "UltraViolent = " + "True" + Chr(13)
            Else
                MsgText += "UltraViolent = " + "False" + Chr(13)
            End If

        End If

        If (LsCfg.ProcessCard) Then
            ' MsgText += "Card Processing" + Chr(13)
            MsgText += "Card Processing= " + "True" + Chr(13)
        Else
            MsgText += "Card Processing= " + "False" + Chr(13)
            ' fFound = True
        End If

        If (LsCfg.InkJet_Printer) Then
            MsgText += "Endorsement Print= " + "True" + Chr(13)
        Else
            MsgText += "Endorsement Print= " + "False" + Chr(13)
        End If

        If (LsCfg.InkJet_Printer_4_lines) Then
            MsgText += "Endorsement 4 lines Ink-jet printer= " + "True" + Chr(13)
        Else
            MsgText += "Endorsement 4 lines Ink-jet printer= " + "False" + Chr(13)
            ' fFound = True
        End If

        If (LsCfg.Feeder) Then
            MsgText += "Feeder" + Chr(13)
            ' fFound = True
        End If

        If (LsCfg.Stamp_Front) Then
            MsgText += "Voiding front stamp Present" + Chr(13)
        Else
            MsgText += "Voiding front stamp not Present" + Chr(13)
            ' fFound = True
        End If

        If (LsCfg.Scanner_Front) Then
            MsgText += "FrontScanner = " + "True" + Chr(13)
        Else
            MsgText += "FrontScanner = " + "False" + Chr(13)

        End If

        If (LsCfg.Scanner_Rear) Then
            MsgText += "RearScanner = " + "True" + Chr(13)
        Else
            MsgText += "RearScanner = " + "False" + Chr(13)
        End If



        If (LsCfg.ColorVersion) Then
            MsgText += "Color Version" + Chr(13)
            '  fFound = True
        End If

        If (LsCfg.Badge_Track123) Then
            MsgText += "MagReaderTrack123 = " + "True" + Chr(13)
        ElseIf (LsCfg.Badge_Track23) Then
            MsgText += "MagReaderTrack23 = " + "True" + Chr(13)
        ElseIf (LsCfg.Badge_Track12) Then
            MsgText += "MagReaderTrack12 = " + "True" + Chr(13)
        Else
            MsgText += "MagReader = " + "False" + Chr(13)
        End If

        MsgText += Chr(13) + "[DEVICE STATUS]" + Chr(13)

        ' Convert status to string
        Select Case Status.UnitStatus
            Case 0      'No Sense
                MsgText += "Peripheral Ok !" + Chr(13) + Chr(13)
            Case 2      'Peripheral busy
                MsgText += "Peripheral busy" + Chr(13) + Chr(13)
            Case 3      'Paper Jam
                MsgText += "Paper Jam" + Chr(13) + Chr(13)
            Case 4      'Hardware error
                MsgText += "Hardware error" + Chr(13) + Chr(13)
            Case 5      'Illegal request
                MsgText += "Illegal request" + Chr(13) + Chr(13)
            Case 6      'Feeder Empty
                MsgText += "Feeder Empty" + Chr(13) + Chr(13)
            Case 7      'Error Double Leafing
                MsgText += "Error Double Leafing" + Chr(13) + Chr(13)
            Case 9
                If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
                    MsgText += "Error Double Leafing" + Chr(13) + Chr(13)
                Else
                    MsgText += "Illegal Command" + Chr(13) + Chr(13)
                End If
            Case 11     'Aborted command
                MsgText += "Aborted command" + Chr(13) + Chr(13)
            Case 16     'Calibration Aborted
                MsgText += "Calibration Aborted" + Chr(13) + Chr(13)
            Case Else
                MsgText += "Error " + Status.UnitStatus.ToString + " not contempled !" + Chr(13) + Chr(13) + Chr(13)
        End Select


        If Status.Photo_Feeder Then
            MsgText += "Feeder sensor = Covered " + Chr(13)
        Else
            MsgText += "Feeder sensor = Not Covered " + Chr(13)
        End If

        'If Status.Photo_Sorter Then
        'MsgText += "Document present in the sorter" + Chr(13)
        'End If

        If Status.Photo_MICR Then
            'MsgText += "Document present at the MICR sensor" + Chr(13)
            MsgText += "MICR sensor =  Covered " + Chr(13)
        Else
            MsgText += "MICR sensor =  Not Covered " + Chr(13)
        End If

        If Status.Photo_Path_Ls100 Then
            MsgText += "Document in the path near the scanner" + Chr(13)
        End If

        If (LsCfg.ProcessCard) Then 'solo se e' presente la card 
            If Status.Photo_Card Then
                'MsgText += "Document present at the Card sensor" + Chr(13)
                MsgText += "Card Sensor = Covered " + Chr(13)
            Else
                MsgText += "Card Sensor = Not Covered " + Chr(13)
            End If
        End If
        If Status.Photo_Stamp Then
            MsgText += "Document present at the stamp sensor" + Chr(13)
        End If

        If Status.Photo_Scanners Then
            'MsgText += "Photo scanner covered" + Chr(13)
            MsgText += "Scanner Sensor = Covered" + Chr(13)
        Else
            MsgText += "Scanner Sensor = Not Covered" + Chr(13)
        End If

        If Status.Photo_Exit Then
            MsgText += "Document present at the exit sensor" + Chr(13)
        End If

        If (Status.Photo_Path_Module_Begin) Then
            MsgText += "Photo at begin path base module covered" + Chr(13)
        End If

        If (Status.Photo_Path_Binary_Rigth) Then
            MsgText += "Photo path binary right covered" + Chr(13)
        End If

        If (Status.Photo_Path_Binary_Left) Then
            MsgText += "Photo path binary left covered" + Chr(13)
        End If

        If (Status.Photo_Path_Module_End) Then
            MsgText += "Photo at end path base module covered" + Chr(13)
        End If

        If Status.Bins_All_Full Then
            MsgText += "Bin(s) full" + Chr(13)
        End If

        If Status.Bin_1_Full Then
            MsgText += "Bin 1 full" + Chr(13)
        End If

        If Status.Bin_2_Full Then
            MsgText += "Bin 2 full" + Chr(13)
        End If

        If Status.Unit_Just_ON Then
            MsgText += "Periferal just ON" + Chr(13)
        End If

        If (Status.Photo_Path_Feeder) Then
            MsgText += "Photo path Feeder covered" + Chr(13)
        End If

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
            If Status.Photo_Double_Leafing_Down Then
                ' MsgText += "Photo DOWN Double Leafing covered" + Chr(13)
                MsgText += "DOWN Double Leafing Sensor = Covered" + Chr(13)
            Else
                MsgText += "DOWN Double Leafing Sensor = Not Covered" + Chr(13)
            End If

            If Status.Photo_Double_Leafing_Middle Then
                ' MsgText += "Photo MIDDLE Double Leafing covered" + Chr(13)
                MsgText += "MIDDLE Double Leafing Sensor = Covered" + Chr(13)
            Else
                MsgText += "MIDDLE Double Leafing Sensor = Not Covered " + Chr(13)
            End If

            If Status.Photo_Double_Leafing_Up Then
                'MsgText += "Photo UP Double Leafing covered" + Chr(13)
                MsgText += "UP Double Leafing Sensor = Covered " + Chr(13)
            Else
                MsgText += "UP Double Leafing Sensor = Not Covered " + Chr(13)
            End If
        End If

        If Status.Sorter_1_input_pocket_1 Then
            MsgText += "Sorter 1 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_1_pocket_1_full Then
            MsgText += "Sorter 1 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_1_input_pocket_2 Then
            MsgText += "Sorter 1 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_1_pocket_2_full Then
            MsgText += "Sorter 1 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_1_input_pocket_3 Then
            MsgText += "Sorter 1 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_1_pocket_3_full Then
            MsgText += "Sorter 1 - pocket 3 full" + Chr(13)
        End If

        If Status.Sorter_2_input_pocket_1 Then
            MsgText += "Sorter 2 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_2_pocket_1_full Then
            MsgText += "Sorter 2 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_2_input_pocket_2 Then
            MsgText += "Sorter 2 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_2_pocket_2_full Then
            MsgText += "Sorter 2 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_2_input_pocket_3 Then
            MsgText += "Sorter 2 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_2_pocket_3_full Then
            MsgText += "Sorter 2 - pocket 3 full" + Chr(13)
        End If

        If Status.Sorter_3_input_pocket_1 Then
            MsgText += "Sorter 3 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_3_pocket_1_full Then
            MsgText += "Sorter 3 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_3_input_pocket_2 Then
            MsgText += "Sorter 3 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_3_pocket_2_full Then
            MsgText += "Sorter 3 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_3_input_pocket_3 Then
            MsgText += "Sorter 3 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_3_pocket_3_full Then
            MsgText += "Sorter 3 - pocket 3 full" + Chr(13)
        End If

        If Status.Sorter_4_input_pocket_1 Then
            MsgText += "Sorter 4 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_4_pocket_1_full Then
            MsgText += "Sorter 4 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_4_input_pocket_2 Then
            MsgText += "Sorter 4 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_4_pocket_2_full Then
            MsgText += "Sorter 4 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_4_input_pocket_3 Then
            MsgText += "Sorter 4 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_4_pocket_3_full Then
            MsgText += "Sorter 4 - pocket 3 full" + Chr(13)
        End If

        If Status.Sorter_5_input_pocket_1 Then
            MsgText += "Sorter 5 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_5_pocket_1_full Then
            MsgText += "Sorter 5 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_5_input_pocket_2 Then
            MsgText += "Sorter 5 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_5_pocket_2_full Then
            MsgText += "Sorter 5 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_5_input_pocket_3 Then
            MsgText += "Sorter 5 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_5_pocket_3_full Then
            MsgText += "Sorter 5 - pocket 3 full" + Chr(13)
        End If

        If Status.Sorter_6_input_pocket_1 Then
            MsgText += "Sorter 6 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_6_pocket_1_full Then
            MsgText += "Sorter 6 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_6_input_pocket_2 Then
            MsgText += "Sorter 6 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_6_pocket_2_full Then
            MsgText += "Sorter 6 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_6_input_pocket_3 Then
            MsgText += "Sorter 6 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_1_pocket_3_full Then
            MsgText += "Sorter 6 - pocket 3 full" + Chr(13)
        End If

        If Status.Sorter_7_input_pocket_1 Then
            MsgText += "Sorter 7 - photo input pocket 1 covered" + Chr(13)
        End If
        If Status.Sorter_7_pocket_1_full Then
            MsgText += "Sorter 7 - pocket 1 full" + Chr(13)
        End If
        If Status.Sorter_7_input_pocket_2 Then
            MsgText += "Sorter 7 - photo input pocket 2 covered" + Chr(13)
        End If
        If Status.Sorter_7_pocket_2_full Then
            MsgText += "Sorter 7 - pocket 2 full" + Chr(13)
        End If
        If Status.Sorter_7_input_pocket_3 Then
            MsgText += "Sorter 7 - photo input pocket 3 covered" + Chr(13)
        End If
        If Status.Sorter_7_pocket_3_full Then
            MsgText += "Sorter 7 - pocket 3 full" + Chr(13)
        End If


        'storico 
        MsgText += Chr(13) + "[DEVICE STATISTICS]" + Chr(13)
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            MsgText += "Doc Handled With Success = " + History.num_doc_handled.ToString() + Chr(13)
        Else
            MsgText += "Doc Handled With Success = " + History.doc_sorted.ToString() + Chr(13)
        End If


        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_LSCONNECT) Then
            MsgText += "Number Of Jam In Card Entry = " + History.jams_card.ToString() + Chr(13)
            MsgText += "Number Of Jam On Micr Area = " + History.jams_micr.ToString() + Chr(13)
            MsgText += "Number Of Jam On Scanner Area = " + History.jams_scanner.ToString() + Chr(13)
        End If
        MsgText += "Number Of CMC7 Errors = " + History.doc_cmc7_err.ToString() + Chr(13)
        MsgText += "Number Of E13B Errors = " + History.doc_e13b_err.ToString() + Chr(13)
        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_800_USB) Then
            MsgText += "Number Of Switch On = " + History.nr_power_on.ToString() + Chr(13)
        Else
            MsgText += "Number Of Switch On = " + History.num_turn_on.ToString() + Chr(13)
        End If
        MsgText += "Number Of Documents Endorsed = " + History.doc_ink_jet.ToString() + Chr(13)
        MsgText += "Number Of Documents Stamped = " + History.doc_stamp.ToString() + Chr(13)
        MsgText += "Total time of work (hh:mm:ss) " + stTime + Chr(13)

        richTextBox1.Text = MsgText
    End Sub

    Private Sub cmdResult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdResult.Click
        If (MessageBox.Show("Do you want clear Panel ?", "Clear monitor", MessageBoxButtons.YesNo) = DialogResult.Yes) Then

            richTextBox1.Clear()
        End If
    End Sub

    Private Sub cmdMonitor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdMonitor.Click
        FunzioneThread()
    End Sub
End Class



