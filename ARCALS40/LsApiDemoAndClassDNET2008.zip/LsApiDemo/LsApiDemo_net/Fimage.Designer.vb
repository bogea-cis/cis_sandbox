﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Fimage
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New LEAD.Windows.Forms.PictureBox
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.AutoRepaint = True
        Me.PictureBox1.AutoResetRectangles = True
        Me.PictureBox1.AutoResetScrollPosition = True
        Me.PictureBox1.AutoResetZoom = True
        Me.PictureBox1.AutoScroll = True
        Me.PictureBox1.BackErase = True
        Me.PictureBox1.BorderBottom = 0
        Me.PictureBox1.BorderLeft = 0
        Me.PictureBox1.BorderRight = 0
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.BorderTop = 0
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.DoubleBuffer = True
        Me.PictureBox1.LEADImage = Nothing
        Me.PictureBox1.LeftButtonInteractiveMode = LEAD.Windows.Forms.PictureBox.InteractiveMode.None
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.RightButtonInteractiveMode = LEAD.Windows.Forms.PictureBox.InteractiveMode.ZoomToRect
        Me.PictureBox1.Size = New System.Drawing.Size(292, 266)
        Me.PictureBox1.SizeMode = LEAD.Windows.Forms.PictureBox.PictureBoxSizeMode.Normal
        Me.PictureBox1.SourceRectangle = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.PictureBox1.SystemImage = Nothing
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.Text = "PictureBox1"
        Me.PictureBox1.Zoom = 1
        '
        'Fimage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Fimage"
        Me.Text = "A4 Image"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As LEAD.Windows.Forms.PictureBox
End Class
