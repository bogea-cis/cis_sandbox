﻿
Public Class formRetainedOption
    Enum ComboFont
        COMBO_NO_PRINT
        COMBO_FONT_NORMAL
        COMBO_FONT_BOLD
        COMBO_FONT_15_INCH
        COMBO_FONT_DOUBLE_HIGH
    End Enum

    Dim LsCfg As LsFamily.LsConfiguration
    Dim LsDefines As LsFamily.LsDefines

    Private Function UnitConfig(ByVal Lsunit As Int16, ByRef LsCfg As LsFamily.LsConfiguration, ByRef Model As String, ByRef Version As String) As Int32
        Dim Ls As LsFamily.LsApi = New LsFamily.LsApi
        Dim hLs As Int16
        Dim rc As Int32

        Ls.LSDebug("----- formOptions_UnitConfig Inizio")
        rc = Ls.LSConnect(0, Lsunit, hLs, False)
        Ls.LSDebug("----- formOptions_UnitConfig 1")
        If (rc = LsFamily.LsReply.LS_OKAY Or rc = LsFamily.LsReply.LS_ALREADY_OPEN) Then

            Ls.LSDebug("----- formOptions_UnitConfig 2")
            rc = Ls.LSIdentify(hLs, 0, LsCfg, 0, 0, 0, 0)
            Ls.LSDebug("----- formOptions_UnitConfig 3")
            rc = Ls.LSDisconnect(hLs, 0)
            Ls.LSDebug("----- formOptions_UnitConfig 4")
        End If
        Ls.LSDebug("----- formOptions_UnitConfig Fine")

        Return rc
    End Function

    Private Sub RetainedOption_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed

        cApplFunc.SaveConfiguration(cApplFunc)

    End Sub

    Private Sub RetainedOption_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim Ls As LsFamily.LsApi
        Dim Model As String = New String(" ", 20)
        Dim Version As String = New String(" ", 20)
        Dim rc As Int32
        Dim fColorHandled As Boolean = False
        Dim f300dpi As Boolean = False

        'Inizializzo i controlli della dialog
        cApplFunc.ReadConfiguration(cApplFunc, LsDefines)
        LsCfg = New LsFamily.LsConfiguration
        Ls = New LsFamily.LsApi

        rc = UnitConfig(LsUnitType, LsCfg, Model, Version)

        If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_100_USB Or _
            LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB) Then
            cmdSort.Visible = True
            Label1.Visible = True
            ckeject.Visible = True
        ElseIf (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_515_USB Or _
                LsUnitType = LsFamily.LsDefines.LsUnitType.LS_520_USB) Then
            cmdSortP1.Visible = True
            cmdSortP2.Visible = True
            Label2.Visible = True
            Label3.Visible = True
        End If


        'Ls.LSDebug("----- formOptions_Load 2")



        'If (LsUnitType = LsFamily.LsDefines.LsUnitType.LS_150_USB Or _
        '    LsUnitType = LsFamily.LsDefines.LsUnitType.LS_40_USB) Then
        'rb16g300dpi.Enabled = True
        'rb256g300dpi.Enabled = True
        'End If




        ' Side
        Select Case cApplFunc.Side
            Case LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
                rbSideAll.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
                rbSideFront.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
                rbSideRear.Checked = True
            Case LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
                rbSideNone.Checked = True
            Case Else
                rbSideFront.Checked = True
        End Select




        ' String to Print
        ' per LS520 4 linee sostituisco cbPrint con cbPrint1
        If LsCfg.InkJet_Printer_4_lines Then
            grbPrint.Enabled = True
            cbPrint.Visible = False
            cbPrint1.Visible = True
            cbPrint2.Enabled = True
            tbPrintString2.Enabled = True
            cbPrint3.Enabled = True
            tbPrintString3.Enabled = True
            cbPrint4.Enabled = True
            tbPrintString4.Enabled = True
        ElseIf LsCfg.InkJet_Printer Then
            grbPrint.Enabled = True
        End If
        cbPrint.SelectedIndex = cApplFunc.RetainedPrintValidate


        Select Case cApplFunc.RetainedPrintValidate1
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                cbPrint1.SelectedIndex = ComboFont.COMBO_FONT_NORMAL
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                cbPrint1.SelectedIndex = ComboFont.COMBO_FONT_BOLD
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                cbPrint1.SelectedIndex = ComboFont.COMBO_FONT_15_INCH
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
                cbPrint1.SelectedIndex = ComboFont.COMBO_FONT_DOUBLE_HIGH
            Case Else
                cbPrint1.SelectedIndex = ComboFont.COMBO_NO_PRINT
        End Select
        tbPrintString.Text = cApplFunc.RetainedEndorse_str

        Select Case cApplFunc.RetainedPrintValidate2
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                cbPrint2.SelectedIndex = ComboFont.COMBO_FONT_NORMAL
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                cbPrint2.SelectedIndex = ComboFont.COMBO_FONT_BOLD
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                cbPrint2.SelectedIndex = ComboFont.COMBO_FONT_15_INCH
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
                cbPrint2.SelectedIndex = ComboFont.COMBO_FONT_DOUBLE_HIGH
            Case Else
                cbPrint2.SelectedIndex = ComboFont.COMBO_NO_PRINT
        End Select
        tbPrintString2.Text = cApplFunc.RetainedEndorse_str2

        Select Case cApplFunc.RetainedPrintValidate3
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                cbPrint3.SelectedIndex = ComboFont.COMBO_FONT_NORMAL
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                cbPrint3.SelectedIndex = ComboFont.COMBO_FONT_BOLD
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                cbPrint3.SelectedIndex = ComboFont.COMBO_FONT_15_INCH
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
                cbPrint3.SelectedIndex = ComboFont.COMBO_FONT_DOUBLE_HIGH
            Case Else
                cbPrint3.SelectedIndex = ComboFont.COMBO_NO_PRINT
        End Select
        tbPrintString3.Text = cApplFunc.RetainedEndorse_str3

        Select Case cApplFunc.RetainedPrintValidate4
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                cbPrint4.SelectedIndex = ComboFont.COMBO_FONT_NORMAL
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                cbPrint4.SelectedIndex = ComboFont.COMBO_FONT_BOLD
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                cbPrint4.SelectedIndex = ComboFont.COMBO_FONT_15_INCH
            Case LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
                cbPrint4.SelectedIndex = ComboFont.COMBO_FONT_DOUBLE_HIGH
            Case Else
                cbPrint4.SelectedIndex = ComboFont.COMBO_NO_PRINT
        End Select

        tbPrintString4.Text = cApplFunc.RetainedEndorse_str4

        

        ' Front Stamp
        If (LsCfg.Stamp_Front = True) Then
            cbFrontStamp.Enabled = True
            If (cApplFunc.FrontStamp = LsFamily.LsDefines.Stamp.STAMP_FRONT) Then
                cbFrontStamp.Checked = True
                'cbFrontStamp.Visible = True
            End If
        End If

      

    End Sub

    Private Sub cmdSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSort.Click

        ' Side_Retained 
        If rbSideAll.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
        ElseIf rbSideFront.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
        ElseIf rbSideRear.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
        ElseIf rbSideNone.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
        End If

        'Sorter
        If (ckeject.Checked = True) Then
            cApplFunc.RetainedSorter = LsFamily.LsDefines.Sorter.SORTER_DOC_EJECTED
        Else
            cApplFunc.RetainedSorter = LsFamily.LsDefines.Sorter.SORTER_POCKET_1
        End If

        ' Front Stamp
        If (cbFrontStamp.Checked = True And ckeject.Checked = False) Then
            cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
        Else
            cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_NO
        End If

        ' String to Print
        cApplFunc.RetainedPrintValidate = cbPrint.SelectedIndex
        cApplFunc.RetainedEndorse_str = tbPrintString.Text
        

        Select Case cbPrint1.SelectedIndex
            Case ComboFont.COMBO_NO_PRINT
                cApplFunc.RetainedPrintValidate1 = ComboFont.COMBO_NO_PRINT
            Case ComboFont.COMBO_FONT_NORMAL
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
            Case formOptions.ComboFont.COMBO_FONT_BOLD
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
            Case formOptions.ComboFont.COMBO_FONT_15_INCH
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
            Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
        End Select

        Select Case cbPrint2.SelectedIndex
            Case ComboFont.COMBO_NO_PRINT
                cApplFunc.RetainedPrintValidate2 = ComboFont.COMBO_NO_PRINT
            Case ComboFont.COMBO_FONT_NORMAL
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
            Case formOptions.ComboFont.COMBO_FONT_BOLD
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
            Case formOptions.ComboFont.COMBO_FONT_15_INCH
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
            Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
        End Select
        cApplFunc.RetainedEndorse_str2 = tbPrintString2.Text

        If (cbPrint3.Enabled = True) Then
            Select Case cbPrint3.SelectedIndex
                Case ComboFont.COMBO_NO_PRINT
                    cApplFunc.RetainedPrintValidate3 = ComboFont.COMBO_NO_PRINT
                Case ComboFont.COMBO_FONT_NORMAL
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
            End Select
            cApplFunc.RetainedEndorse_str3 = tbPrintString3.Text
        Else
            cApplFunc.RetainedPrintValidate3 = 0
        End If
        If (cbPrint4.Enabled = True) Then
            Select Case cbPrint4.SelectedIndex
                Case ComboFont.COMBO_NO_PRINT
                    cApplFunc.RetainedPrintValidate4 = ComboFont.COMBO_NO_PRINT
                Case ComboFont.COMBO_FONT_NORMAL
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
            End Select
            cApplFunc.RetainedEndorse_str4 = tbPrintString4.Text
        Else
            cApplFunc.RetainedPrintValidate4 = 0
        End If

        Me.Close()
    End Sub

    Private Sub ckeject_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ckeject.CheckedChanged
        If (ckeject.Checked = True) Then

            rbSideNone.Checked = True
            rbSideAll.Checked = False
            rbSideFront.Checked = False
            rbSideRear.Checked = False
            GroupBox3.Enabled = False
            cbFrontStamp.Checked = False
            cbFrontStamp.Enabled = False
            grbPrint.Enabled = False

        Else

            GroupBox3.Enabled = True
            'abilito il timbro fronte
            cbFrontStamp.Enabled = True

            'se l'avevo selezionato al giro prima lo checkko
            If (cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_FRONT) Then
                cbFrontStamp.Checked = True
            End If

            If LsCfg.InkJet_Printer_4_lines Then
                grbPrint.Enabled = True
                cbPrint.Visible = False
                cbPrint1.Visible = True
                cbPrint2.Enabled = True
                tbPrintString2.Enabled = True
                cbPrint3.Enabled = True
                tbPrintString3.Enabled = True
                cbPrint4.Enabled = True
                tbPrintString4.Enabled = True
            ElseIf LsCfg.InkJet_Printer Then
                grbPrint.Enabled = True
            End If
            'grbPrint.Enabled = True
            rbSideAll.Checked = True

            End If


    End Sub

    Private Sub cmdSortP1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSortP1.Click

        ' Side_Retained 
        If rbSideAll.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
        ElseIf rbSideFront.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
        ElseIf rbSideRear.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
        ElseIf rbSideNone.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
        End If

        'Sorter
        'If (ckeject.Checked = True) Then
        'cApplFunc.RetainedSorter = LsFamily.LsDefines.Sorter.SORTER_DOC_EJECTED
        'Else
        cApplFunc.RetainedSorter = LsFamily.LsDefines.Sorter.SORTER_POCKET_1
        'End If

        ' Front Stamp
        If (cbFrontStamp.Checked = True) Then
            cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
        Else
            cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_NO
        End If

        ' String to Print
        cApplFunc.RetainedPrintValidate = cbPrint.SelectedIndex
        cApplFunc.RetainedEndorse_str = tbPrintString.Text


        Select Case cbPrint1.SelectedIndex
            Case ComboFont.COMBO_NO_PRINT
                cApplFunc.RetainedPrintValidate1 = ComboFont.COMBO_NO_PRINT
            Case ComboFont.COMBO_FONT_NORMAL
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
            Case formOptions.ComboFont.COMBO_FONT_BOLD
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
            Case formOptions.ComboFont.COMBO_FONT_15_INCH
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
            Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
        End Select

        Select Case cbPrint2.SelectedIndex
            Case ComboFont.COMBO_NO_PRINT
                cApplFunc.RetainedPrintValidate2 = ComboFont.COMBO_NO_PRINT
            Case ComboFont.COMBO_FONT_NORMAL
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
            Case formOptions.ComboFont.COMBO_FONT_BOLD
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
            Case formOptions.ComboFont.COMBO_FONT_15_INCH
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
            Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
        End Select
        cApplFunc.RetainedEndorse_str2 = tbPrintString2.Text

        If (cbPrint3.Enabled = True) Then
            Select Case cbPrint3.SelectedIndex
                Case ComboFont.COMBO_NO_PRINT
                    cApplFunc.RetainedPrintValidate3 = ComboFont.COMBO_NO_PRINT
                Case ComboFont.COMBO_FONT_NORMAL
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
            End Select
            cApplFunc.RetainedEndorse_str3 = tbPrintString3.Text
        Else
            cApplFunc.RetainedPrintValidate3 = 0
        End If
        If (cbPrint4.Enabled = True) Then
            Select Case cbPrint4.SelectedIndex
                Case ComboFont.COMBO_NO_PRINT
                    cApplFunc.RetainedPrintValidate4 = ComboFont.COMBO_NO_PRINT
                Case ComboFont.COMBO_FONT_NORMAL
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
            End Select
            cApplFunc.RetainedEndorse_str4 = tbPrintString4.Text
        Else
            cApplFunc.RetainedPrintValidate4 = 0
        End If

        Me.Close()
    End Sub

    Private Sub cmdSortP2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSortP2.Click
        ' Side_Retained 
        If rbSideAll.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_ALL_IMAGE
        ElseIf rbSideFront.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_FRONT_IMAGE
        ElseIf rbSideRear.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_BACK_IMAGE
        ElseIf rbSideNone.Checked = True Then
            cApplFunc.RetainedSide = LsFamily.LsDefines.Side.SIDE_NONE_IMAGE
        End If

        'Sorter
        'If (ckeject.Checked = True) Then
        'cApplFunc.RetainedSorter = LsFamily.LsDefines.Sorter.SORTER_DOC_EJECTED
        'Else
        cApplFunc.RetainedSorter = LsFamily.LsDefines.Sorter.SORTER_POCKET_2
        'End If

        ' Front Stamp
        If (cbFrontStamp.Checked = True) Then
            cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_FRONT
        Else
            cApplFunc.RetainedFrontStamp = LsFamily.LsDefines.Stamp.STAMP_NO
        End If

        ' String to Print
        cApplFunc.RetainedPrintValidate = cbPrint.SelectedIndex
        cApplFunc.RetainedEndorse_str = tbPrintString.Text


        Select Case cbPrint1.SelectedIndex
            Case ComboFont.COMBO_NO_PRINT
                cApplFunc.RetainedPrintValidate1 = ComboFont.COMBO_NO_PRINT
            Case ComboFont.COMBO_FONT_NORMAL
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
            Case formOptions.ComboFont.COMBO_FONT_BOLD
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
            Case formOptions.ComboFont.COMBO_FONT_15_INCH
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
            Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                cApplFunc.RetainedPrintValidate1 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
        End Select

        Select Case cbPrint2.SelectedIndex
            Case ComboFont.COMBO_NO_PRINT
                cApplFunc.RetainedPrintValidate2 = ComboFont.COMBO_NO_PRINT
            Case ComboFont.COMBO_FONT_NORMAL
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
            Case formOptions.ComboFont.COMBO_FONT_BOLD
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
            Case formOptions.ComboFont.COMBO_FONT_15_INCH
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
            Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                cApplFunc.RetainedPrintValidate2 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
        End Select
        cApplFunc.RetainedEndorse_str2 = tbPrintString2.Text

        If (cbPrint3.Enabled = True) Then
            Select Case cbPrint3.SelectedIndex
                Case ComboFont.COMBO_NO_PRINT
                    cApplFunc.RetainedPrintValidate3 = ComboFont.COMBO_NO_PRINT
                Case ComboFont.COMBO_FONT_NORMAL
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                    cApplFunc.RetainedPrintValidate3 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
            End Select
            cApplFunc.RetainedEndorse_str3 = tbPrintString3.Text
        Else
            cApplFunc.RetainedPrintValidate3 = 0
        End If
        If (cbPrint4.Enabled = True) Then
            Select Case cbPrint4.SelectedIndex
                Case ComboFont.COMBO_NO_PRINT
                    cApplFunc.RetainedPrintValidate4 = ComboFont.COMBO_NO_PRINT
                Case ComboFont.COMBO_FONT_NORMAL
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL
                Case formOptions.ComboFont.COMBO_FONT_BOLD
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_BOLD
                Case formOptions.ComboFont.COMBO_FONT_15_INCH
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_NORMAL_15
                Case formOptions.ComboFont.COMBO_FONT_DOUBLE_HIGH
                    cApplFunc.RetainedPrintValidate4 = LsFamily.LsDefines.PrintFont.PRINT_FORMAT_DOUBLE_HIGH
            End Select
            cApplFunc.RetainedEndorse_str4 = tbPrintString4.Text
        Else
            cApplFunc.RetainedPrintValidate4 = 0
        End If

        Me.Close()
    End Sub

   
End Class