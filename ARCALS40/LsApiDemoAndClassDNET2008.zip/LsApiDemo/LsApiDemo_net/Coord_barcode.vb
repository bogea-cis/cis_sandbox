Public Class formBarcode
    Inherits System.Windows.Forms.Form

    Dim bgColor As Color

#Region " Codice generato da Progettazione Windows Form "

    Public Sub New()
        MyBase.New()

        'Chiamata richiesta da Progettazione Windows Form.
        InitializeComponent()

        'Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent()

    End Sub

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue � richiesta da Progettazione Windows Form.
    'Pu� essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    Friend WithEvents cbRead As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents rbUnitInch As System.Windows.Forms.RadioButton
    Friend WithEvents rbUnitMm As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents tbHeight As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbWidth As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbY As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbX As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btOk As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cbRead = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.rbUnitInch = New System.Windows.Forms.RadioButton
        Me.rbUnitMm = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.tbHeight = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.tbWidth = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.tbY = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.tbX = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btOk = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cbRead
        '
        Me.cbRead.Items.AddRange(New Object() {"Barcode 2 of 5", "CODE 39", "CODE 128"})
        Me.cbRead.Location = New System.Drawing.Point(144, 216)
        Me.cbRead.Name = "cbRead"
        Me.cbRead.Size = New System.Drawing.Size(121, 24)
        Me.cbRead.TabIndex = 9
        Me.cbRead.Text = "ComboBox1"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(64, 216)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 23)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Read type :"
        '
        'rbUnitInch
        '
        Me.rbUnitInch.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbUnitInch.Location = New System.Drawing.Point(200, 24)
        Me.rbUnitInch.Name = "rbUnitInch"
        Me.rbUnitInch.TabIndex = 7
        Me.rbUnitInch.Text = "Inch"
        Me.rbUnitInch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rbUnitMm
        '
        Me.rbUnitMm.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbUnitMm.Location = New System.Drawing.Point(24, 24)
        Me.rbUnitMm.Name = "rbUnitMm"
        Me.rbUnitMm.TabIndex = 6
        Me.rbUnitMm.Text = "Millimeter"
        Me.rbUnitMm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tbHeight)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.tbWidth)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.tbY)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.tbX)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(24, 72)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 120)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Coordinate from RightBottom"
        '
        'tbHeight
        '
        Me.tbHeight.Location = New System.Drawing.Point(216, 80)
        Me.tbHeight.Name = "tbHeight"
        Me.tbHeight.Size = New System.Drawing.Size(40, 22)
        Me.tbHeight.TabIndex = 7
        Me.tbHeight.Text = "0"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(160, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 23)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Height :"
        '
        'tbWidth
        '
        Me.tbWidth.Location = New System.Drawing.Point(72, 80)
        Me.tbWidth.Name = "tbWidth"
        Me.tbWidth.Size = New System.Drawing.Size(40, 22)
        Me.tbWidth.TabIndex = 5
        Me.tbWidth.Text = "0"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Width :"
        '
        'tbY
        '
        Me.tbY.Location = New System.Drawing.Point(216, 32)
        Me.tbY.Name = "tbY"
        Me.tbY.Size = New System.Drawing.Size(40, 22)
        Me.tbY.TabIndex = 3
        Me.tbY.Text = "0"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(184, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Y :"
        '
        'tbX
        '
        Me.tbX.Location = New System.Drawing.Point(72, 32)
        Me.tbX.Name = "tbX"
        Me.tbX.Size = New System.Drawing.Size(40, 22)
        Me.tbX.TabIndex = 1
        Me.tbX.Text = "0"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(48, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "X :"
        '
        'btOk
        '
        Me.btOk.Location = New System.Drawing.Point(127, 264)
        Me.btOk.Name = "btOk"
        Me.btOk.TabIndex = 10
        Me.btOk.Text = "Ok"
        '
        'formBarcode
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(328, 296)
        Me.Controls.Add(Me.btOk)
        Me.Controls.Add(Me.cbRead)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.rbUnitInch)
        Me.Controls.Add(Me.rbUnitMm)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "formBarcode"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Barcode Parameter"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Coord_barcode_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        bgColor = Me.BackColor

        If (cApplFunc.Barcode_Unit = LsFamily.LsDefines.Unit.UNIT_MM) Then
            rbUnitMm.Checked = True
        Else
            rbUnitInch.Checked = True
        End If

        tbX.Text = cApplFunc.Barcode_x
        tbY.Text = cApplFunc.Barcode_y
        tbWidth.Text = cApplFunc.Barcode_w
        tbHeight.Text = cApplFunc.Barcode_h

        Select Case cApplFunc.Barcode_Type
            Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_2_OF_5
                cbRead.SelectedIndex = 0
            Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE39
                cbRead.SelectedIndex = 1
            Case LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE128
                cbRead.SelectedIndex = 2
            Case Else
                cbRead.SelectedIndex = 0
        End Select

    End Sub

    Private Sub rbUnitMm_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbUnitMm.CheckedChanged

        If rbUnitMm.Checked = True Then
            'bgColor = me.BackColor
            rbUnitMm.BackColor = Color.DarkSalmon
        Else
            rbUnitMm.BackColor = bgColor
        End If
    End Sub

    Private Sub rbUnitInch_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbUnitInch.CheckedChanged

        If rbUnitInch.Checked = True Then
            'bgColor = me.BackColor
            rbUnitInch.BackColor = Color.DarkSalmon
        Else
            rbUnitInch.BackColor = bgColor
        End If
    End Sub

    Private Sub btOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btOk.Click

        If rbUnitMm.Checked = True Then
            cApplFunc.Barcode_Unit = LsFamily.LsDefines.Unit.UNIT_MM
        ElseIf rbUnitInch.Checked = True Then
            cApplFunc.Barcode_Unit = LsFamily.LsDefines.Unit.UNIT_INCH
        End If

        cApplFunc.Barcode_x = tbX.Text
        cApplFunc.Barcode_y = tbY.Text
        cApplFunc.Barcode_w = tbWidth.Text
        cApplFunc.Barcode_h = tbHeight.Text

        Select Case cbRead.SelectedIndex
            Case 0
                cApplFunc.Barcode_Type = LsFamily.LsDefines.CodelineToRead.READ_BARCODE_2_OF_5
            Case 1
                cApplFunc.Barcode_Type = LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE39
            Case 2
                cApplFunc.Barcode_Type = LsFamily.LsDefines.CodelineToRead.READ_BARCODE_CODE128
        End Select

        Me.Close()
    End Sub
End Class
