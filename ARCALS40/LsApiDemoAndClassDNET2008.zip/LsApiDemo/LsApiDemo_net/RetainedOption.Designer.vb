﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formRetainedOption
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmdSortP2 = New System.Windows.Forms.Button
        Me.cmdSortP1 = New System.Windows.Forms.Button
        Me.cmdSort = New System.Windows.Forms.Button
        Me.ckeject = New System.Windows.Forms.CheckBox
        Me.cbFrontStamp = New System.Windows.Forms.CheckBox
        Me.grbPrint = New System.Windows.Forms.GroupBox
        Me.cbPrint1 = New System.Windows.Forms.ComboBox
        Me.cbPrint4 = New System.Windows.Forms.ComboBox
        Me.tbPrintString4 = New System.Windows.Forms.TextBox
        Me.cbPrint3 = New System.Windows.Forms.ComboBox
        Me.tbPrintString3 = New System.Windows.Forms.TextBox
        Me.cbPrint2 = New System.Windows.Forms.ComboBox
        Me.tbPrintString2 = New System.Windows.Forms.TextBox
        Me.cbPrint = New System.Windows.Forms.ComboBox
        Me.tbPrintString = New System.Windows.Forms.TextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.rbSideNone = New System.Windows.Forms.RadioButton
        Me.rbSideRear = New System.Windows.Forms.RadioButton
        Me.rbSideFront = New System.Windows.Forms.RadioButton
        Me.rbSideAll = New System.Windows.Forms.RadioButton
        Me.GroupBox1.SuspendLayout()
        Me.grbPrint.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.cmdSortP2)
        Me.GroupBox1.Controls.Add(Me.cmdSortP1)
        Me.GroupBox1.Controls.Add(Me.cmdSort)
        Me.GroupBox1.Controls.Add(Me.ckeject)
        Me.GroupBox1.Controls.Add(Me.cbFrontStamp)
        Me.GroupBox1.Controls.Add(Me.grbPrint)
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(331, 314)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Docoments Handle"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(135, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Insert document in sorter"
        Me.Label3.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(135, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(123, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Insert document in sorter"
        Me.Label2.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(135, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Sorting document"
        Me.Label1.Visible = False
        '
        'cmdSortP2
        '
        Me.cmdSortP2.Location = New System.Drawing.Point(259, 95)
        Me.cmdSortP2.Name = "cmdSortP2"
        Me.cmdSortP2.Size = New System.Drawing.Size(64, 29)
        Me.cmdSortP2.TabIndex = 8
        Me.cmdSortP2.Text = "2"
        Me.cmdSortP2.UseVisualStyleBackColor = True
        Me.cmdSortP2.Visible = False
        '
        'cmdSortP1
        '
        Me.cmdSortP1.Location = New System.Drawing.Point(259, 56)
        Me.cmdSortP1.Name = "cmdSortP1"
        Me.cmdSortP1.Size = New System.Drawing.Size(64, 29)
        Me.cmdSortP1.TabIndex = 7
        Me.cmdSortP1.Text = "1"
        Me.cmdSortP1.UseVisualStyleBackColor = True
        Me.cmdSortP1.Visible = False
        '
        'cmdSort
        '
        Me.cmdSort.Location = New System.Drawing.Point(259, 21)
        Me.cmdSort.Name = "cmdSort"
        Me.cmdSort.Size = New System.Drawing.Size(64, 29)
        Me.cmdSort.TabIndex = 6
        Me.cmdSort.Text = "Sort"
        Me.cmdSort.UseVisualStyleBackColor = True
        Me.cmdSort.Visible = False
        '
        'ckeject
        '
        Me.ckeject.Location = New System.Drawing.Point(215, 138)
        Me.ckeject.Name = "ckeject"
        Me.ckeject.Size = New System.Drawing.Size(92, 20)
        Me.ckeject.TabIndex = 5
        Me.ckeject.Text = "Eject Document"
        Me.ckeject.Visible = False
        '
        'cbFrontStamp
        '
        Me.cbFrontStamp.Enabled = False
        Me.cbFrontStamp.Location = New System.Drawing.Point(69, 138)
        Me.cbFrontStamp.Name = "cbFrontStamp"
        Me.cbFrontStamp.Size = New System.Drawing.Size(92, 20)
        Me.cbFrontStamp.TabIndex = 4
        Me.cbFrontStamp.Text = "Front Stamp"
        '
        'grbPrint
        '
        Me.grbPrint.Controls.Add(Me.cbPrint1)
        Me.grbPrint.Controls.Add(Me.cbPrint4)
        Me.grbPrint.Controls.Add(Me.tbPrintString4)
        Me.grbPrint.Controls.Add(Me.cbPrint3)
        Me.grbPrint.Controls.Add(Me.tbPrintString3)
        Me.grbPrint.Controls.Add(Me.cbPrint2)
        Me.grbPrint.Controls.Add(Me.tbPrintString2)
        Me.grbPrint.Controls.Add(Me.cbPrint)
        Me.grbPrint.Controls.Add(Me.tbPrintString)
        Me.grbPrint.Enabled = False
        Me.grbPrint.Location = New System.Drawing.Point(27, 171)
        Me.grbPrint.Name = "grbPrint"
        Me.grbPrint.Size = New System.Drawing.Size(280, 137)
        Me.grbPrint.TabIndex = 3
        Me.grbPrint.TabStop = False
        Me.grbPrint.Text = "String to Print"
        '
        'cbPrint1
        '
        Me.cbPrint1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPrint1.Items.AddRange(New Object() {"No Print", "Print 10", "Bold", "Print 15", "Double High"})
        Me.cbPrint1.Location = New System.Drawing.Point(7, 37)
        Me.cbPrint1.Name = "cbPrint1"
        Me.cbPrint1.Size = New System.Drawing.Size(80, 21)
        Me.cbPrint1.TabIndex = 11
        Me.cbPrint1.Visible = False
        '
        'cbPrint4
        '
        Me.cbPrint4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPrint4.Enabled = False
        Me.cbPrint4.Items.AddRange(New Object() {"No Print", "Print 10", "Bold", "Print 15"})
        Me.cbPrint4.Location = New System.Drawing.Point(7, 108)
        Me.cbPrint4.Name = "cbPrint4"
        Me.cbPrint4.Size = New System.Drawing.Size(80, 21)
        Me.cbPrint4.TabIndex = 9
        '
        'tbPrintString4
        '
        Me.tbPrintString4.Enabled = False
        Me.tbPrintString4.Location = New System.Drawing.Point(93, 108)
        Me.tbPrintString4.Name = "tbPrintString4"
        Me.tbPrintString4.Size = New System.Drawing.Size(180, 20)
        Me.tbPrintString4.TabIndex = 8
        Me.tbPrintString4.Text = "CTS Electronics Line 4"
        '
        'cbPrint3
        '
        Me.cbPrint3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPrint3.Enabled = False
        Me.cbPrint3.Items.AddRange(New Object() {"No Print", "Print 10", "Bold", "Print 15", "Double High"})
        Me.cbPrint3.Location = New System.Drawing.Point(7, 84)
        Me.cbPrint3.Name = "cbPrint3"
        Me.cbPrint3.Size = New System.Drawing.Size(80, 21)
        Me.cbPrint3.TabIndex = 7
        '
        'tbPrintString3
        '
        Me.tbPrintString3.Enabled = False
        Me.tbPrintString3.Location = New System.Drawing.Point(93, 84)
        Me.tbPrintString3.Name = "tbPrintString3"
        Me.tbPrintString3.Size = New System.Drawing.Size(180, 20)
        Me.tbPrintString3.TabIndex = 6
        Me.tbPrintString3.Text = "CTS Electronics Line 3"
        '
        'cbPrint2
        '
        Me.cbPrint2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPrint2.Enabled = False
        Me.cbPrint2.Items.AddRange(New Object() {"No Print", "Print 10", "Bold", "Print 15", "Double High"})
        Me.cbPrint2.Location = New System.Drawing.Point(7, 61)
        Me.cbPrint2.Name = "cbPrint2"
        Me.cbPrint2.Size = New System.Drawing.Size(80, 21)
        Me.cbPrint2.TabIndex = 5
        '
        'tbPrintString2
        '
        Me.tbPrintString2.Enabled = False
        Me.tbPrintString2.Location = New System.Drawing.Point(93, 61)
        Me.tbPrintString2.Name = "tbPrintString2"
        Me.tbPrintString2.Size = New System.Drawing.Size(180, 20)
        Me.tbPrintString2.TabIndex = 4
        Me.tbPrintString2.Text = "CTS Electronics Line 2"
        '
        'cbPrint
        '
        Me.cbPrint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPrint.Items.AddRange(New Object() {"No Print", "Print 10", "Bold", "Print 15"})
        Me.cbPrint.Location = New System.Drawing.Point(7, 37)
        Me.cbPrint.Name = "cbPrint"
        Me.cbPrint.Size = New System.Drawing.Size(80, 21)
        Me.cbPrint.TabIndex = 2
        '
        'tbPrintString
        '
        Me.tbPrintString.Location = New System.Drawing.Point(93, 38)
        Me.tbPrintString.Name = "tbPrintString"
        Me.tbPrintString.Size = New System.Drawing.Size(180, 20)
        Me.tbPrintString.TabIndex = 0
        Me.tbPrintString.Text = "CTS Electronics"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbSideNone)
        Me.GroupBox3.Controls.Add(Me.rbSideRear)
        Me.GroupBox3.Controls.Add(Me.rbSideFront)
        Me.GroupBox3.Controls.Add(Me.rbSideAll)
        Me.GroupBox3.Location = New System.Drawing.Point(27, 21)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(92, 111)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Side to Film"
        '
        'rbSideNone
        '
        Me.rbSideNone.Location = New System.Drawing.Point(13, 83)
        Me.rbSideNone.Name = "rbSideNone"
        Me.rbSideNone.Size = New System.Drawing.Size(54, 21)
        Me.rbSideNone.TabIndex = 3
        Me.rbSideNone.Text = "None"
        '
        'rbSideRear
        '
        Me.rbSideRear.Location = New System.Drawing.Point(13, 62)
        Me.rbSideRear.Name = "rbSideRear"
        Me.rbSideRear.Size = New System.Drawing.Size(54, 21)
        Me.rbSideRear.TabIndex = 2
        Me.rbSideRear.Text = "Rear"
        '
        'rbSideFront
        '
        Me.rbSideFront.Location = New System.Drawing.Point(13, 42)
        Me.rbSideFront.Name = "rbSideFront"
        Me.rbSideFront.Size = New System.Drawing.Size(54, 20)
        Me.rbSideFront.TabIndex = 1
        Me.rbSideFront.Text = "Front"
        '
        'rbSideAll
        '
        Me.rbSideAll.Location = New System.Drawing.Point(13, 21)
        Me.rbSideAll.Name = "rbSideAll"
        Me.rbSideAll.Size = New System.Drawing.Size(54, 21)
        Me.rbSideAll.TabIndex = 0
        Me.rbSideAll.Text = "All"
        '
        'formRetainedOption
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(354, 327)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.Location = New System.Drawing.Point(50, 10)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formRetainedOption"
        Me.Text = "RetainedOption"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grbPrint.ResumeLayout(False)
        Me.grbPrint.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cbFrontStamp As System.Windows.Forms.CheckBox
    Friend WithEvents grbPrint As System.Windows.Forms.GroupBox
    Friend WithEvents cbPrint1 As System.Windows.Forms.ComboBox
    Friend WithEvents cbPrint4 As System.Windows.Forms.ComboBox
    Friend WithEvents tbPrintString4 As System.Windows.Forms.TextBox
    Friend WithEvents cbPrint3 As System.Windows.Forms.ComboBox
    Friend WithEvents tbPrintString3 As System.Windows.Forms.TextBox
    Friend WithEvents cbPrint2 As System.Windows.Forms.ComboBox
    Friend WithEvents tbPrintString2 As System.Windows.Forms.TextBox
    Friend WithEvents cbPrint As System.Windows.Forms.ComboBox
    Friend WithEvents tbPrintString As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbSideNone As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideRear As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideFront As System.Windows.Forms.RadioButton
    Friend WithEvents rbSideAll As System.Windows.Forms.RadioButton
    Friend WithEvents cmdSort As System.Windows.Forms.Button
    Friend WithEvents ckeject As System.Windows.Forms.CheckBox
    Friend WithEvents cmdSortP2 As System.Windows.Forms.Button
    Friend WithEvents cmdSortP1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
