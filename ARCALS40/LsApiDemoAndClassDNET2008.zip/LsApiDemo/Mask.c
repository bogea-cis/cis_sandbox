//**************************************************************************
//  MODULE:   Mask.C
//
//  PURPOSE:  LS500 Application for Windows 
//
//  FUNCTIONS: 
// 
//	AUTHOR :  
//**************************************************************************

// --------------------------------------------------------------
//                  INCLUDES
// --------------------------------------------------------------
#include <windows.h>            // required for all Windows applications
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <ctype.h>
#include <dlgs.h>
#include <stdio.h>
#include <process.h>




#include "lsApi.h"

#include "Main.h"
#include "resource.h"



// --------------------------------------------------------------
//                  DEFINES
// --------------------------------------------------------------

// Defines calibrazione MICR
#define NR_VALORI_LETTI				512
#define OFFSET_INZIO_CALCOLO		250
#define NR_VALORI_PER_MEDIA			200
#define OFFSET_PRIMO_PICCO			60
#define UNITA_VOLT					0.0190925

#define SORTER_1_TEXT				"Sorter 1"
#define SORTER_2_TEXT				"Sorter 2"
#define SORTER_RETAINED_TEXT		"Retained Doc."
#define SORTER_AUTOMATIC_TEXT		"Auto Sorter"
#define SORTER_SWITCH				"Sorter Switch"

#define TYPE_CRITERIA				10
#define MAX_SORTER					3

#define DUMP_DEFAULT_FILE			"DumpMemory.txt"

#define TEXT_MM						"MM"
#define TEXT_INC					"INC"



// --------------------------------------------------------------
//                  EXTERNAL FUNCTION
// --------------------------------------------------------------
extern int CheckReply(HWND hwnd, int ChReply, LPSTR Requester);
extern BOOL GetFileName(HWND hwnd, LPSTR pszTitle, LPSTR pszFilter, LPSTR pszFile);
extern void ShowMICRSignal(HINSTANCE hInst, HWND hwnd, unsigned char *pd, short llDati, float Percentile);


// --------------------------------------------------------------
//                  EXTERNAL VARIABLES
// --------------------------------------------------------------
extern HINSTANCE hInst;

extern PARAUTODOCHANDLE stParDocHandle;

extern char CodelineRead[CODE_LINE_LENGTH];

extern short hLS;

extern char	IdentStr[12];
extern char	Model[64];
extern char	Version[64];
extern char	Lema[20];
extern char	InkJet[20];
extern short TypeLS;

extern HINSTANCE hOCRLibrary;
extern HINSTANCE hBarcodeLibrary;
extern HINSTANCE hPDFLibrary;

extern char CodelineRead[CODE_LINE_LENGTH];

extern char PathAppl[_MAX_PATH];


// --------------------------------------------------------------
//                  INTERNAL FUNCTION
// --------------------------------------------------------------
BOOL CALLBACK SelectSorterDlgProc500(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

void EnableChoices(HWND hDlg, BOOL fDo);
void EnableChoice1(HWND hDlg, BOOL fDo);
void EnableChoice2(HWND hDlg, BOOL fDo);
void EnableChoice3(HWND hDlg, BOOL fDo);
void EnableChoice4(HWND hDlg, BOOL fDo);
void EnableChoice5(HWND hDlg, BOOL fDo);
void EnableOpticMainBarcode500(HWND hwnd, BOOL Flag);

void EnableOpticMainOcr500(HWND hwnd, BOOL Flag);

void SorterReadSelection500(HWND hDlg);
void SetObjOpticParameterMainBarcode500(HWND hDlg);
void SetObjOpticParameterMainOcr500(HWND hDlg);


BOOL CALLBACK DlgProcDecoSwParBarcode500(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);


// --------------------------------------------------------------
//                  INTERNAL VARIABLES
// --------------------------------------------------------------



//***************************************************************************
// FUNCTION  : EnableChoiceOptic
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
void EnableChoiceOptic(HWND hwnd, BOOL Flag)
{
	long CurrItem;


	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);

	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_CHARTYPE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_COMBOPTICAL), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_UNIT_MM), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_UNIT_INC), Flag);

	if( Flag )
	{
		switch( stParDocHandle.CodelineOptType )
		{
		case READ_CODELINE_SW_OCRA:
			CurrItem = 1;
			break;
		case READ_CODELINE_SW_OCRB_NUM:
			CurrItem = 2;
			break;
		case READ_CODELINE_SW_OCRB_ALFANUM:
			CurrItem = 3;
			break;
		case READ_CODELINE_SW_E13B:
			CurrItem = 4;
			break;
		case READ_CODELINE_SW_E13B_X_OCRB:
			CurrItem = 5;
			break;
		case READ_CODELINE_SW_MULTI_READ:
			CurrItem = 0;
			break;
		default:
			CurrItem = 2;
			break;
		}
		SendMessage(GetDlgItem(hwnd, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);

	} // end if
} // End EnableChoiceOptic


BOOL CALLBACK DlgProcDecoSwParOCR(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HWND hCombo;
	int CurrItem;
	char str[10];
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	
	
	switch( msg )
	{
		case WM_INITDIALOG:
			SetWindowText(hDlg, "Parametrer for Ocr Window");

			hCombo = GetDlgItem(hDlg, IDC_COMBOPTICAL);		
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_MUTILREAD);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_OCRA);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_OCRB);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_OCRB_ALPHA);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_E13B);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_E13BOPT);
			
			EnableChoiceOptic(hDlg,TRUE);

			if(stParDocHandle.Unit_measure == UNIT_MM)
			{
				SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Codeline_Sw_x,TRUE);
				SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Codeline_Sw_y,TRUE);
				SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Codeline_Sw_w,TRUE);
				CheckDlgButton(hDlg,IDC_UNIT_MM,TRUE);
			}
			else
			{
				sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_w);
				SetDlgItemText(hDlg, IDC_W, str);
				sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_x);
				SetDlgItemText(hDlg, IDC_X, str);
				sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_y);
				SetDlgItemText(hDlg, IDC_Y, str);
				CheckDlgButton(hDlg,IDC_UNIT_INC,TRUE);
			}
			sprintf(str, "%.2f", OCR_VALUE_IN_MM);
			SetDlgItemText(hDlg, IDC_H, str);
			switch( stParDocHandle.CodelineOptType )
			{
			case READ_CODELINE_SW_OCRA:
				CurrItem = 1;
				break;
			case READ_CODELINE_SW_OCRB_NUM:
				CurrItem = 2;
				break;
			case READ_CODELINE_SW_OCRB_ALFANUM:
				CurrItem = 3;
				break;
			case READ_CODELINE_SW_E13B:
				CurrItem = 4;
				break;
			case READ_CODELINE_SW_E13B_X_OCRB:
				CurrItem = 5;
				break;
			case READ_CODELINE_SW_MULTI_READ:
				CurrItem = 0;
				break;
			default:
				CurrItem = 2;
				break;
			}

			SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);
		return TRUE;


		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
			case IDC_UNIT_INC:
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_INC) == BST_CHECKED)
				{
					SetButtonInc(hDlg);
				}
				break;

			case IDC_UNIT_MM:
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_MM) == BST_CHECKED)
				{
					SetButtonMM(hDlg);
				}
				break;

			case IDOK:
				// read codeline type
				CurrItem = SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_GETCURSEL, 0, 0);
				switch( CurrItem )
				{
				case 0:
					stParDocHandle.CodelineOptType = READ_CODELINE_SW_MULTI_READ;
					break;
				case 1:
					stParDocHandle.CodelineOptType = READ_CODELINE_SW_OCRA;
					break;
				case 2:
					stParDocHandle.CodelineOptType = READ_CODELINE_SW_OCRB_NUM;
					break;
				case 3:
					stParDocHandle.CodelineOptType = READ_CODELINE_SW_OCRB_ALFANUM;
					break;
				case 4:
					stParDocHandle.CodelineOptType = READ_CODELINE_SW_E13B;
					break;
				case 5:
					stParDocHandle.CodelineOptType = READ_CODELINE_SW_E13B_X_OCRB;
					break;
				}
				if( IsDlgButtonChecked(hDlg, IDC_UNIT_MM) == BST_CHECKED )
					stParDocHandle.Unit_measure = UNIT_MM;
				else if( IsDlgButtonChecked(hDlg, IDC_UNIT_INC) == BST_CHECKED )
					stParDocHandle.Unit_measure = UNIT_INCH;
			
				// Reads the coordinate
				if( stParDocHandle.Unit_measure == UNIT_MM)
				{
					GetDlgItemText(hDlg,IDC_X,str,8);
					if (str[0] =='-')
						stParDocHandle.Codeline_Sw_x = 0 - (float)atoi(&str[1]);
					else
						stParDocHandle.Codeline_Sw_x = (float)GetDlgItemInt(hDlg, IDC_X, NULL, FALSE);

					stParDocHandle.Codeline_Sw_y = (float)GetDlgItemInt(hDlg, IDC_Y, NULL, FALSE);
					GetDlgItemText(hDlg,IDC_W,str,8);
					if (str[0] =='-')
						stParDocHandle.Codeline_Sw_w = 0 - (float)atoi(&str[1]);
					else
						stParDocHandle.Codeline_Sw_w = (float)GetDlgItemInt(hDlg, IDC_W, NULL, FALSE);
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));
					stParDocHandle.Codeline_Sw_h = (float)atof(Sw_h);
				}
				else 
				{
					GetDlgItemText(hDlg, IDC_X, Sw_x, sizeof(Sw_x));
					GetDlgItemText(hDlg, IDC_Y, Sw_y, sizeof(Sw_y));
					GetDlgItemText(hDlg, IDC_W, Sw_w, sizeof(Sw_w));
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));

					stParDocHandle.Codeline_Sw_x = (float)atof(Sw_x);
					stParDocHandle.Codeline_Sw_y = (float)atof(Sw_y);
					stParDocHandle.Codeline_Sw_w = (float)atof(Sw_w);
					stParDocHandle.Codeline_Sw_h = (float)atof(Sw_h);
				}
				
				EndDialog(hDlg, IDOK);

				return TRUE;	
		}
		return TRUE;	
	}

	return FALSE;
} // DlgProcDecoSwParOCR



void SetButtonInc(HWND hDlg)
{
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	int Sw_Value;
	if( IsDlgButtonChecked(hDlg, IDC_UNIT_INC) == BST_CHECKED )
	{
		Sw_Value = GetDlgItemInt(hDlg, IDC_X, NULL, FALSE);
		sprintf(Sw_x, "%.2f", (Sw_Value / 25.4));
		SetDlgItemText(hDlg, IDC_X, Sw_x);

		Sw_Value = GetDlgItemInt(hDlg, IDC_Y, NULL, FALSE);
		sprintf(Sw_y, "%.2f", (Sw_Value / 25.4));
		SetDlgItemText(hDlg, IDC_Y, Sw_y);

		Sw_Value = GetDlgItemInt(hDlg, IDC_W, NULL, FALSE);
		sprintf(Sw_w, "%.2f", (Sw_Value / 25.4));
		SetDlgItemText(hDlg, IDC_W, Sw_w);

		Sw_Value = GetDlgItemInt(hDlg, IDC_H, NULL, FALSE);
		sprintf(Sw_h, "%.2f", (Sw_Value / 25.4));
		SetDlgItemText(hDlg, IDC_H, Sw_h);

	}
} // SetButtonInc


void SetButtonMM(HWND hDlg)
{
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	float Sw_Value_inc;
	if( IsDlgButtonChecked(hDlg, IDC_UNIT_MM) == BST_CHECKED )
	{
		GetDlgItemText(hDlg, IDC_X, Sw_x, sizeof(Sw_x));
		Sw_Value_inc = (float)atof(Sw_x);
		SetDlgItemInt(hDlg, IDC_X, (int)(Sw_Value_inc * 25.4), FALSE);

		GetDlgItemText(hDlg, IDC_Y, Sw_y, sizeof(Sw_y));
		Sw_Value_inc = (float)atof(Sw_y);
		SetDlgItemInt(hDlg, IDC_Y, (int)(Sw_Value_inc * 25.4), FALSE);

		GetDlgItemText(hDlg, IDC_W, Sw_w, sizeof(Sw_w));
		Sw_Value_inc = (float)atof(Sw_w);
		SetDlgItemInt(hDlg, IDC_W, (int)(Sw_Value_inc * 25.4), FALSE);


		GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));
		Sw_Value_inc = (float)atof(Sw_h);
		SetDlgItemInt(hDlg, IDC_H, (int)(Sw_Value_inc * 25.4), FALSE);

	}
} // SetButtonMM


BOOL CALLBACK DlgProcDecoSwParPdf(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	char str[10];
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	
	
	switch( msg )
	{
		case WM_INITDIALOG:
			SetWindowText(hDlg, "Parametrer for PDF417 Window");

			EnableWindow(GetDlgItem(hDlg, IDC_COMBOPTICAL), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_UNIT_INC), FALSE);

			if(stParDocHandle.Unit_measure == UNIT_MM)
			{
				SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Pdf417_Sw_x,TRUE);
				SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Pdf417_Sw_y,TRUE);
				SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Pdf417_Sw_w,TRUE);
				SetDlgItemInt(hDlg,IDC_H,(int)stParDocHandle.Pdf417_Sw_h,TRUE);
				CheckDlgButton(hDlg,IDC_UNIT_MM,TRUE);
			}
			else
			{
				sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_w);
				SetDlgItemText(hDlg, IDC_W, str);
				sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_x);
				SetDlgItemText(hDlg, IDC_X, str);
				sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_y);
				SetDlgItemText(hDlg, IDC_Y, str);
				sprintf(str, "%.2f", OCR_VALUE_IN_MM);
				SetDlgItemText(hDlg, IDC_H, str);
				CheckDlgButton(hDlg,IDC_UNIT_INC,TRUE);
			}

		return TRUE;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
			case IDC_UNIT_INC:
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_INC) == BST_CHECKED)
				{
					SetButtonInc(hDlg);
				}
				break;

			case IDC_UNIT_MM:
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_MM) == BST_CHECKED)
				{
					SetButtonMM(hDlg);
				}
				break;

			case IDOK:
				if( IsDlgButtonChecked(hDlg, IDC_UNIT_MM) == BST_CHECKED )
					stParDocHandle.Unit_measure = UNIT_MM;
				else if( IsDlgButtonChecked(hDlg, IDC_UNIT_INC) == BST_CHECKED )
					stParDocHandle.Unit_measure = UNIT_INCH;

				// Reads the coordinate
				if( stParDocHandle.Unit_measure == UNIT_MM)
				{
					GetDlgItemText(hDlg,IDC_X,str,8);
					if (str[0] =='-')
						stParDocHandle.Pdf417_Sw_x = 0 - (float)atoi(&str[1]);
					else
						stParDocHandle.Pdf417_Sw_x = (float)GetDlgItemInt(hDlg, IDC_X, NULL, FALSE);

					stParDocHandle.Pdf417_Sw_y = (float)GetDlgItemInt(hDlg, IDC_Y, NULL, FALSE);
					GetDlgItemText(hDlg,IDC_W,str,8);
					if (str[0] =='-')
						stParDocHandle.Pdf417_Sw_w = 0 - (float)atoi(&str[1]);
					else
						stParDocHandle.Pdf417_Sw_w = (float)GetDlgItemInt(hDlg, IDC_W, NULL, FALSE);
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));
					stParDocHandle.Pdf417_Sw_h = (float)atof(Sw_h);
				}
				else 
				{
					GetDlgItemText(hDlg, IDC_X, Sw_x, sizeof(Sw_x));
					GetDlgItemText(hDlg, IDC_Y, Sw_y, sizeof(Sw_y));
					GetDlgItemText(hDlg, IDC_W, Sw_w, sizeof(Sw_w));
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));

					stParDocHandle.Pdf417_Sw_x = (float)atof(Sw_x);
					stParDocHandle.Pdf417_Sw_y = (float)atof(Sw_y);
					stParDocHandle.Pdf417_Sw_w = (float)atof(Sw_w);
					stParDocHandle.Pdf417_Sw_h = (float)atof(Sw_h);
				}
				
				EndDialog(hDlg, IDOK);

				return TRUE;
		}
		return TRUE;	
	}

	return FALSE;
} // DlgProcDecoSwParPdf


//void SetObjOpticParameterMainOcr
//
//
void SetObjOpticParameterMainOcr(HWND hDlg)
{
	char str[16];

	if(stParDocHandle.Unit_measure == UNIT_MM)
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Codeline_Sw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Codeline_Sw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Codeline_Sw_w,TRUE);
	}
	else 
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_INC);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_w);
		SetDlgItemText(hDlg, IDC_W, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_x);
		SetDlgItemText(hDlg, IDC_X, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_y);
		SetDlgItemText(hDlg, IDC_Y, str);

	}
	sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_h);
	SetDlgItemText(hDlg, IDC_H, str);

	switch( stParDocHandle.CodelineOptType )
		{
		case READ_CODELINE_SW_OCRA:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRA);
			break;
		case READ_CODELINE_SW_OCRB_NUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB);
			break;
		case READ_CODELINE_SW_OCRB_ALFANUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB_ALPHA);
			break;
		case READ_CODELINE_SW_OCRB_ITALY:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB_ITALY);
			break;
		case READ_CODELINE_SW_E13B:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13B);
			break;
		case READ_CODELINE_SW_E13B_X_OCRB:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13BOPT);
			break;
		case READ_CODELINE_SW_MULTI_READ:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_MUTILREAD);
			break;
		}
} // SetObjOpticParameterMainOcr


void SetObjOpticParameterMainOcrHw(HWND hDlg)
{
	char str[16];

	if(stParDocHandle.Codeline_Hw_Unit_measure == UNIT_MM)
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Codeline_Hw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Codeline_Hw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Codeline_Hw_w,TRUE);
	}
	else 
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_INC);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_w);
		SetDlgItemText(hDlg, IDC_W, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_x);
		SetDlgItemText(hDlg, IDC_X, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_y);
		SetDlgItemText(hDlg, IDC_Y, str);

	}
	sprintf(str, "%.2f", stParDocHandle.Codeline_Hw_h);
	SetDlgItemText(hDlg, IDC_H, str);

	switch( stParDocHandle.Codeline_Hw_Type )
		{
		case READ_CODELINE_SW_OCRA:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRA);
			break;
		case READ_CODELINE_SW_OCRB_NUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB);
			break;
		case READ_CODELINE_SW_OCRB_ALFANUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB_ALPHA);
			break;
		case READ_CODELINE_SW_E13B:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13B);
			break;
		case READ_CODELINE_SW_E13B_X_OCRB:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13BOPT);
			break;
		case READ_CODELINE_SW_MULTI_READ:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_MUTILREAD);
			break;
		}
} // SetObjOpticParameterMainOcrHw


//void SetObjOpticParameterMainPdf
//
//
void SetObjOpticParameterMainPdf(HWND hDlg)
{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Pdf417_Sw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Pdf417_Sw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Pdf417_Sw_w,TRUE);
		SetDlgItemInt(hDlg,IDC_H,(int)stParDocHandle.Pdf417_Sw_h,TRUE);

} // SetObjOpticParameterMainOcr


//***************************************************************************
// FUNCTION  : EnableOpticMainOcr
//
// PURPOSE   : // 
//
// PARAMETER : 
//***************************************************************************
void EnableOpticMainOcr(HWND hwnd, BOOL Flag)
{

	SetDlgItemText(hwnd,IDC_STATIC1,"OCR Decode Information");
	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);

	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TYPE_OPT), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_U_MEASURE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_S_MEASURE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_S_TYPE_OPT), Flag);

} // End EnableOpticMainOcr


//***************************************************************************
// FUNCTION  : EnableOpticMainOcrHw
//
// PURPOSE   : // 
//
// PARAMETER : 
//***************************************************************************
void EnableOpticMainOcrHw(HWND hwnd, BOOL Flag)
{

	SetDlgItemText(hwnd,IDC_STATIC1,"OCR Hw Decode Information");
	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);

	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TYPE_OPT), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_U_MEASURE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_S_MEASURE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_S_TYPE_OPT), Flag);

} // End EnableOpticMainOcrHw


//***************************************************************************
// FUNCTION  : EnableOpticMainPdf
//
// PURPOSE   : // 
//
// PARAMETER : 
//***************************************************************************
void EnableOpticMainPdf(HWND hwnd, BOOL Flag)
{

	SetDlgItemText(hwnd,IDC_STATIC1,"OCR Decode Information");
	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);

	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);

} // End EnableOpticMainPdf
