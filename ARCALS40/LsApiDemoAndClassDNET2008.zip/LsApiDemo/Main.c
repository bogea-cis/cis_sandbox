//**************************************************************************
//  MODULE:   MAIN.C
//
//  PURPOSE:  Main application
//
//  FUNCTIONS: 
//
//	AUTHOR :  
//**************************************************************************

// --------------------------------------------------------------
//                  INCLUDES
// --------------------------------------------------------------
#include <windows.h>
#include <stdio.h>

#include "resource.h"

#include "LsApi.h"
#include "Main.h"



// --------------------------------------------------------------
//                  FUNCTIONS
// --------------------------------------------------------------
extern BOOL CALLBACK DocumentHandleDlgProc500 (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
extern BOOL CheckDocRetained(void);
extern int CheckReply(HWND hwnd, int ChReply, LPSTR Requester);
extern int CALLBACK SorterDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
extern int GetTypeLS(char *Config_Ls, char *Model, char *Version);


BOOL APIENTRY DlgProcMain(HWND hDlg, UINT message, UINT wParam, LONG lParam);

int DoAutoDocHandle(HWND hWnd);
int DoSingleDocHandle(HWND hWnd);

void Ls100Dialog(HWND hwnd);
void Ls200Dialog(HWND hwnd);
void Ls500Dialog(HWND hwnd);
void Ls800Dialog(HWND hwnd);



// --------------------------------------------------------------
//                  EXTERNAL VARIABLES
// --------------------------------------------------------------
extern unsigned short	NrCheque;
extern BOOL fDocRetained;
extern PARAUTODOCHANDLE stParDocHandle;
extern short hLS;


// --------------------------------------------------------------
//                  VARIABLES
// --------------------------------------------------------------
HINSTANCE hInst;
HWND hDlgMain;

char PathAppl[_MAX_PATH];
char FullFName[_MAX_PATH];

FILE *fh;
DWORD eee;
short Reply;
unsigned long NrDocToRead;

PARAUTODOCHANDLE stParDocHandle;

HINSTANCE hOCRLibrary;
HINSTANCE hBarcodeLibrary;
HINSTANCE hPDFLibrary;

char szTextMsg[1024];
char szBitmapFile[_MAX_PATH] = "";
char szStampFile[_MAX_PATH] = "";
char PathAppl[_MAX_PATH];
char FullFName[_MAX_PATH];

BOOL fViewOCRRectangle = FALSE;
BOOL fImageCorrection = FALSE;

char szCurDir[MAX_PATH];
char szTmp[MAX_PATH];

unsigned char SenseKey;
unsigned char StatusByte[4];

short	hLS;

char	IdentStr[12];
char	Model[64];
char	Version[64];
char	Lema[20];
char	InkJet[20];
short	TypeLS;

long	*BufFrontImage;
long	*BufFrontNettoImage;
long	*BufBackImage;
long	*BufBackNettoImage;
char	*Save_BufFrontImage;
char	*Save_BufFrontNettoImage;
char	*Save_BufBackImage;
char	*Save_BufBackNettoImage;

char CodelineRead[CODE_LINE_LENGTH];

unsigned short	NrCheque;

char	SaveFile[_MAX_PATH];
short	NrFileJPEG = 0;
short	NrFileBMP = 0;
short	NrFileTIFF = 0;
HWND	hCombo;

BOOL	fDocRetained;
BOOL	fImagePresent;




//***************************************************************************
// FUNCTION  : DefaultParDocumentHandle
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
void DefaultParDocumentHandle(void)
{
	register ii;

	stParDocHandle.Stamp				= NO_STAMP;
	stParDocHandle.Validate				= NO_PRINT_VALIDATE;
    stParDocHandle.PrintBold			= FALSE;
    stParDocHandle.szValidateText[0]	= '\0';
	stParDocHandle.CodelineType			= NO_READ_CODELINE;   
	stParDocHandle.Sorter				= SORTER_BAY1;
	stParDocHandle.ScanMode				= SCAN_MODE_16GR200;
	stParDocHandle.NumDoc				= 0;
	stParDocHandle.ClearBlack			= CLEAR_ALL_BLACK;
	stParDocHandle.Side					= SIDE_FRONT_IMAGE;
	stParDocHandle.ReadMode				= READMODE_BRUTTO;
	stParDocHandle.SaveCodeline			= FALSE;
	stParDocHandle.ResetFileCodeline	= TRUE;
    stParDocHandle.Qual					= 128;
	stParDocHandle.SaveImage			= IMAGE_SAVE_HANDLE;
	stParDocHandle.BeepOnError			= BEEP;
	stParDocHandle.WaitTimeout			= WAIT_NO;
	stParDocHandle.BadgeTrack			= FORMAT_ABA_MINTS;
	stParDocHandle.LinearEntry			= FALSE;
	stParDocHandle.PercentSpeedMeno		= 5;
	stParDocHandle.PercentSpeedPiu		= 5;
	for( ii = 0; ii < MAX_CRITERIA; ii ++ )
	{
		memset(&stParDocHandle.DataSorter[ii], 0, sizeof(DATASORTERSELECT));
		stParDocHandle.DataSorter[ii].CharToStart = 1;
		stParDocHandle.DataSorter[ii].Bin = SORTER_BAY2;
	}

	stParDocHandle.SorterStamp				= NO_STAMP;
	stParDocHandle.SorterValidate			= NO_PRINT_VALIDATE;
    stParDocHandle.SorterPrintBold			= FALSE;
    stParDocHandle.SorterszValidateText[0]	= '\0';
	stParDocHandle.SorterSide				= SIDE_FRONT_IMAGE;
	stParDocHandle.DoubleLeafingBlock		= FALSE;
	stParDocHandle.DoubleLeafingLevel		= DOUBLE_LEAFING_DEFAULT;

	stParDocHandle.ValueImageCalibration	= 0;
	stParDocHandle.StampPosition			= 0;

	stParDocHandle.Peripheral				= LS_100_USB;
}  // End DefaultParDocumentHandle


//*********************************************************************
//	LeggiConfigurazione
//
//	open .Cfg configuration file
//	If it does not exist, fill the structure with zeros
//*********************************************************************
void LeggiConfigurazione(char *FullFName)
{
	FILE *fh;
	char *PtrTmp;


	// build path name
	GetModuleFileName(hInst, (char *)PathAppl, sizeof(PathAppl));
	PtrTmp = strrchr((const char *)PathAppl, '\\');
	*(++PtrTmp) = '\0';

	strcpy(FullFName, PathAppl);
	strcat(FullFName, FILE_CONF);

	if( (fh = fopen(FullFName, "rb")) != NULL )
	{		// file exixts
		fread(&stParDocHandle, sizeof(stParDocHandle), 1, fh);
		fclose( fh );
	}
	else
	{
		// Load default
		DefaultParDocumentHandle();
	}

	// load OCR libraries if present
	hOCRLibrary = LoadLibrary("CtsDecod.DLL");
	hBarcodeLibrary = LoadLibrary("BarDecode.DLL");
	hPDFLibrary = LoadLibrary("CtsPdf.DLL");
}


//*********************************************************************
//	SalvaConfigurazione
//*********************************************************************
void SalvaConfigurazione(char *FullFName)
{
	FILE *fh;


	strcpy(FullFName, PathAppl);
	strcat(FullFName, FILE_CONF);

	// open configuration file
	if( (fh = fopen(FullFName, "wb")) != NULL )
	{
		fwrite(&stParDocHandle, sizeof(stParDocHandle), 1, fh);
		fclose( fh );
	}

	if( hOCRLibrary )
		FreeLibrary( hOCRLibrary );

	if( hBarcodeLibrary )
		FreeLibrary( hBarcodeLibrary );

	if( hPDFLibrary )
		FreeLibrary(hPDFLibrary );
}



/******************************************************************************
 * -------- WinMain -----------------------------------------------------------
 ******************************************************************************/
//
//	Params:
//              hInstance          - instance Handle
//              hPrevInstance      - Handle of previous instance
//              lpCmdLine          - pointer to command line
//              nCmdShow           - Window's state
//
//

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	char *PtrTmp;


	hInst = hInstance;

	// check for image directory
	if( GetFileAttributes(SAVE_DIRECTORY_IMAGE) == 0xFFFFFFFF)
	{
		if (CreateDirectory(SAVE_DIRECTORY_IMAGE, NULL) == FALSE)
			return FALSE;
	}

	// build path name
	GetModuleFileName(hInst, (char *)PathAppl, sizeof(PathAppl));
	PtrTmp = strrchr((const char *)PathAppl, '\\');
	*(++PtrTmp) = '\0';

	strcpy(FullFName, PathAppl);
	strcat(FullFName, FILE_CONF);

	LeggiConfigurazione(FullFName);

	if( !DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DlgProcMain) )
		MessageBox(NULL, "", APP_TITLE, MB_OK | MB_ICONERROR);

	SalvaConfigurazione(FullFName);

	return FALSE;

}	// End WinMain




void EnableButtons(HWND hDlg, BOOL fDo)
{
	EnableWindow(GetDlgItem(hDlg, IDOK), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_RESET), fDo);
	EnableWindow(GetDlgItem(hDlg, IDCONFIG), fDo);

} // EnableButtons


/******************************************************************************
 * ----- DlgProcMain ----------------------------------------------------------
 ******************************************************************************/
//
//	Params:
//              hDlg               - window Handle
//              message            - message type
//              wParam             - Windows word parameter
//              lParam             - Windows long parameter
//
//
BOOL APIENTRY DlgProcMain(HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
	HWND hDlgRect;
	RECT rtWnd;
	PAINTSTRUCT ps;
	HDC hdc;
	int ImageY, ImageX;
	int ImageWidth, ImageHeight;
	unsigned char *pdati;
	long BitCount;
	BOOL ret;
	BITMAPINFO *ShowImage;


	switch( message )
	{
	case WM_INITDIALOG:

		hDlgMain = hDlg;

		// title
		SetWindowText(hDlg, APP_TITLE);
		if (stParDocHandle.Peripheral == LS_100_USB)
		{
			CheckDlgButton(hDlg, IDC_LS100, BST_CHECKED); 
		}
		else if (stParDocHandle.Peripheral == LS_515_USB)
		{
			CheckDlgButton(hDlg, IDC_LS500, BST_CHECKED); 
		}
		else if (stParDocHandle.Peripheral == LS_800_USB)
		{
			CheckDlgButton(hDlg, IDC_LS800, BST_CHECKED); 
		}


		return TRUE;


    case WM_COMMAND: 
	{
 		switch (LOWORD(wParam))
		{
		case IDOK:
			{
				EnableButtons(hDlg, FALSE);
				// Get peripheral selected
				if(IsDlgButtonChecked(hDlg, IDC_LS100) == BST_CHECKED)
				{
					TypeLS = TYPE_LS100_1;	// Default

					stParDocHandle.Peripheral = LS_100_USB;

				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS200) == BST_CHECKED)
				{
					stParDocHandle.Peripheral = LS_200_USB;
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS500) == BST_CHECKED)
				{
					TypeLS = TYPE_LS515S;	// Default

					stParDocHandle.Peripheral = LS_515_USB;
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS800) == BST_CHECKED)
				{
					stParDocHandle.Peripheral = LS_800_USB;
				}

				//-----------Open--------------------------------------------
				Reply = LSConnect(hDlg, hInst, stParDocHandle.Peripheral, &hLS);
				if( Reply != LS_OKAY)
				{
					CheckReply(hDlg, Reply, "LSConnect");
					EnableButtons(hDlg, TRUE);
					return TRUE;
				}

				//-----------Identify-----------------------------------
				Reply = LSIdentify(hLS, hDlg, IdentStr, Model, Version, Lema, InkJet, NULL, NULL);
				if( Reply == LS_OKAY)
				{
					TypeLS = GetTypeLS(IdentStr, Model, Version);
				}


				if(IsDlgButtonChecked(hDlg, IDC_LS100) == BST_CHECKED)
				{
					Ls100Dialog(hDlg);
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS200) == BST_CHECKED)
				{
					Ls200Dialog(hDlg);
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS500) == BST_CHECKED)
				{
					Ls500Dialog(hDlg);
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS800) == BST_CHECKED)
				{
					Ls800Dialog(hDlg);
				}

				LSDisconnect(hLS, hDlg);
				EnableButtons(hDlg, TRUE);

				return TRUE;
			}

		case IDCONFIG:
			{
				EnableButtons(hDlg, FALSE);
				// Get peripheral selected
				if(IsDlgButtonChecked(hDlg, IDC_LS100) == BST_CHECKED)
				{
					TypeLS = TYPE_LS100_1;	// Default

					stParDocHandle.Peripheral = LS_100_USB;
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS200) == BST_CHECKED)
				{
					stParDocHandle.Peripheral = LS_200_USB;
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS500) == BST_CHECKED)
				{
					TypeLS = TYPE_LS515S;	// Default

					stParDocHandle.Peripheral = LS_515_USB;
				}
				else if(IsDlgButtonChecked(hDlg, IDC_LS800) == BST_CHECKED)
				{
					stParDocHandle.Peripheral = LS_800_USB;
				}

				//-----------Open--------------------------------------------
				Reply = LSConnect(hDlg, hInst, stParDocHandle.Peripheral, &hLS);
				if( Reply != LS_OKAY)
				{
					CheckReply(hDlg, Reply, "LSConnect");
					EnableButtons(hDlg, TRUE);
					return TRUE;
				}

				//-----------Identify-----------------------------------
				Reply = LSIdentify(hLS, hDlg, IdentStr, Model, Version, Lema, InkJet, NULL, NULL);
				if( Reply == LS_OKAY)
				{
					TypeLS = GetTypeLS(IdentStr, Model, Version);
					SaveConfiguration(IdentStr);
					DisplayIdentify(hDlg, IdentStr, Model,Version,  Lema,  InkJet);
				}
				

				LSDisconnect(hLS, hDlg);
				EnableButtons(hDlg, TRUE);

				return TRUE;		
			}

		case IDC_RESET:
			// Get peripheral selected
			if(IsDlgButtonChecked(hDlg, IDC_LS100) == BST_CHECKED)
				stParDocHandle.Peripheral = LS_100_USB;
			else if(IsDlgButtonChecked(hDlg, IDC_LS200) == BST_CHECKED)
				stParDocHandle.Peripheral = LS_200_USB;
			else if(IsDlgButtonChecked(hDlg, IDC_LS500) == BST_CHECKED)
				stParDocHandle.Peripheral = LS_515_USB;
			else if(IsDlgButtonChecked(hDlg, IDC_LS800) == BST_CHECKED)
				stParDocHandle.Peripheral = LS_800_USB;

			DoLSReset(hDlg, stParDocHandle.Peripheral);
			return TRUE;


        case IDCANCEL:
			SendMessage(hDlg, WM_CLOSE, 0, 0);
			return TRUE;
		
		} // End switch (LOWORD(wParam))

		return FALSE;
	} // End case WM_COMMAND


	case WM_PAINT:

		ret = FALSE;
		// Check if image ready to show
		if( fImagePresent )
		{
			hDlgRect = hDlg;

			if( Save_BufFrontImage )
				ShowImage = (BITMAPINFO *)Save_BufFrontImage;
			else if( Save_BufBackImage )
				ShowImage = (BITMAPINFO *)Save_BufBackImage;
			else
				ShowImage = 0;

			if( ShowImage )
			{
				GetClientRect(hDlgRect, &rtWnd);
				hdc = BeginPaint(hDlgRect,&ps);

				ps.rcPaint.right = rtWnd.right;
				ps.rcPaint.bottom = rtWnd.bottom;

				ImageX = rtWnd.right / 6;
				ImageY = rtWnd.bottom / 3;

				if( ((((BITMAPINFOHEADER *)ShowImage)->biWidth) + ImageX) <= rtWnd.right )
					ImageWidth = (((BITMAPINFOHEADER *)ShowImage)->biWidth);
				else
					ImageWidth = rtWnd.right - ImageX - (rtWnd.right / 10);

				if( ((((BITMAPINFOHEADER *)ShowImage)->biHeight) + ImageY) <= rtWnd.bottom )
					ImageHeight = (((BITMAPINFOHEADER *)ShowImage)->biHeight);
				else
					ImageHeight = rtWnd.bottom - ImageY - (rtWnd.bottom / 10 );

				if( ((BITMAPINFOHEADER *)ShowImage)->biBitCount )
					BitCount = 1 << ((BITMAPINFOHEADER *)ShowImage)->biBitCount;
				else
					BitCount = 0;

				pdati = (unsigned char *)ShowImage + sizeof(BITMAPINFOHEADER) + (BitCount * sizeof(RGBQUAD));

				StretchDIBits(hdc,
								ImageX,
								ImageY,
								ImageWidth,
								ImageHeight,
								0, 0,
								(((BITMAPINFOHEADER *)ShowImage)->biWidth),
								(((BITMAPINFOHEADER *)ShowImage)->biHeight),
								pdati,
								ShowImage,
								DIB_RGB_COLORS,
								SRCCOPY);

				EndPaint(hDlgRect, &ps) ;

				ret = TRUE;
			}
		}
		return ret;


	case WM_CLOSE:
		// close the dialog
		EndDialog(hDlg, TRUE);

		return TRUE;

	} //switch( message )

	return FALSE;
} // DlgProcMain




// *******************************************************************
// *    CheckReply()
// *******************************************************************
int CheckReply(HWND hwnd, int ChReply, LPSTR Requester)
{
	int  RcError = 0;


	strcpy(szTextMsg, Requester);
	strcat(szTextMsg, "\n\n");

	switch (ChReply)
	{
		case LS_OKAY:
			break;

		// --- ERRORS -----------------------------------------------------------
		case LS_SYSTEM_ERROR:
			strcat(szTextMsg, "The module was unable to execute command due to a system error.\n\nPossible reasons: memory allocation error.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_USB_ERROR:
			strcat(szTextMsg, "The module was unable to execute command due to a USB error.\n\nPossible reasons: error condition coming from SCSI Manager or SCSI Adapter.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_PERIPHERAL_NOT_FOUND:
			strcat(szTextMsg, "Peripheral not found.\n\nPossible reasons: peripheral is switched off or not connected to the SCSI bus.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_HARDWARE_ERROR:
			strcat(szTextMsg, "Peripheral hardware error.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_PERIPHERAL_OFF_ON:
			strcat(szTextMsg, "Peripheral has been switched off and on again.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_RESERVED_ERROR:
			strcat(szTextMsg, "Peripheral reservation error.\n\nPossible reasons: another program is using the peripheral.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_BOURRAGE:
			strcat(szTextMsg, "Document jammed.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_DOUBLE_LEAFING_ERROR:
			strcat(szTextMsg, "Document double leafing error.");
            MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_INVALID_COMMAND:
			strcat(szTextMsg, "Invalid command.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_IMAGE_OVERWRITE:
			strcat(szTextMsg, "Image Overwrite.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_DATA_LOST:
			strcat(szTextMsg, "Error during SCSI data transfer.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_COMMAND_IN_EXECUTION_YET:
			strcat(szTextMsg, "A command is already in execution.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_JPEG_ERROR:
			strcat(szTextMsg, "JPEG image not created.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_COMMAND_SEQUENCE_ERROR:
			strcat(szTextMsg, "Command sequence error.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_ALREADY_OPEN:
			strcat(szTextMsg, "Peripheral already connected.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_IMAGE_NOT_PRESENT:
			strcat(szTextMsg, "Image not present or returned nr. byte zero.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_SCAN_NETTO_IMAGE_NOT_SUPPORTED:
			strcat(szTextMsg, "The peripheral don't read NETTO image.");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
		case LS_256_GRAY_NOT_SUPPORTED:
			strcat(szTextMsg, "The periphearal don't read image at 256 gray");
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;

		// --- WARNINGS -------------------------------------------------------
		case LS_FEEDER_EMPTY:
			strcat(szTextMsg, "LS_FEEDER_EMPTY");
			MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 1;
			break;
		case LS_LOOP_INTERRUPTED:
			strcat(szTextMsg, "LS_LOOP_INTERRUPTED");
			MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 1;
			break;
		case LS_DOUBLE_LEAFING_WARNING:
			strcat(szTextMsg, "Document double leafing warning.");
            MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 0;
			break;
		case LS_SORTER1_FULL:
			strcat(szTextMsg, "SORTER 1 FULL");
			MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 1;
			break;
		case LS_SORTER2_FULL:
			strcat(szTextMsg, "SORTER 2 FULL");
			MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 1;
			break;
		case LS_SORTERS_BOTH_FULL:
			strcat(szTextMsg, "SORTER BOTH FULL");
			MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 1;
			break;
		case LS_KEEP_DOC_ON_CODELINE_ERROR:
			strcat(szTextMsg, "STOP FOR ERROR READ CODELINE");
			MessageBox(hwnd, szTextMsg, TITLE_POPUP, MB_OK);
			RcError = 1;
			break;

		default:       
			sprintf(szTextMsg, "%s\n\nUNKNOWN REPLY CODE NUMBER %d", Requester, ChReply);
			MessageBox(hwnd, szTextMsg, TITLE_ERROR, MB_OK);
			RcError = 1;
			break;
	}

	return RcError;
} // end CheckReply


//***************************************************************************
// FUNCTION  : GetTypeLS
//
// PURPOSE   : Return the type of peripheral connected
//
// PARAMETER : 
//***************************************************************************
int GetTypeLS(char *Config_Ls, char *Model, char *Version)
{
	int TypeLS;


	//  peripheral identify, if LS100 USB only or USB/RS232
	if( strncmp(Version, MODEL_LS100_1, strlen(MODEL_LS100_1)) == 0 )
		TypeLS = TYPE_LS100_1;
	else if( strncmp(Version, MODEL_LS100_2, strlen(MODEL_LS100_2)) == 0 )
		TypeLS = TYPE_LS100_2;
	else if( strncmp(Version, MODEL_LS100_3, strlen(MODEL_LS100_3)) == 0 )
		TypeLS = TYPE_LS100_3;
	else if( strncmp(Version, MODEL_LS100_4, strlen(MODEL_LS100_4)) == 0 )
		TypeLS = TYPE_LS100_4;
	else if( strncmp(Version, MODEL_LS100_5, strlen(MODEL_LS100_5)) == 0 )
		TypeLS = TYPE_LS100_5;


	//Identify the type of peripheral LS500 LS505, LS510 or LS515
	if( strncmp(Model, MODEL_LS515, strlen(MODEL_LS515)) == 0 )
	{
		TypeLS = TYPE_LS515S;
		if( (Config_Ls[2] & MASK_LS515D) == MASK_LS515D )
			TypeLS = TYPE_LS515D;
		if( (Config_Ls[2] & MASK_LS515C) == MASK_LS515C )
			TypeLS = TYPE_LS515C;
	}
	else if( strncmp(Model, MODEL_LS510S, strlen(MODEL_LS510S)) == 0 )
		TypeLS = TYPE_LS510S;
	else if( strncmp(Model, MODEL_LS510D, strlen(MODEL_LS510D)) == 0 )
		TypeLS = TYPE_LS510D;
	else if( strncmp(Model, MODEL_LS505, strlen(MODEL_LS505)) == 0 )
		TypeLS = TYPE_LS505;
	else if( strncmp(Model, MODEL_LS500, strlen(MODEL_LS500)) == 0 )
	{
		if( strncmp(Version, "5.33", 4) == 0 )
			TypeLS = TYPE_LS510S;
		else
			TypeLS = TYPE_LS500;
	}

	return TypeLS;
} // GetTypeLS



//***************************************************************************
// FUNCTION  : DoAutoDocHandle
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
int DoAutoDocHandle(HWND hWnd)
{
	int		Reply;
	char	dirBase[_MAX_DIR];
	char	Filename[_MAX_FNAME];

	char	BufFrontFile[_MAX_PATH];
	char	BufFrontNettoFile[_MAX_PATH];
	char	BufBackFile[_MAX_PATH];
	char	BufBackNettoFile[_MAX_PATH];

	char	BufCodelineSW[CODE_LINE_LENGTH];
	char	BufCodelineHW[CODE_LINE_LENGTH];
	char	BufBarcode[CODE_LINE_LENGTH];
	char	BufOptical[CODE_LINE_LENGTH];
	READOPTIONS ro;
	short	len_codeline, len_barcode = CODE_LINE_LENGTH;
	MSG		msg;
	short	NumDocRemain;
	short	NrDocToProcess;
	int		ReplyFunz = 0;

	short	CodelineType;
	char	SideToFilm;
	char    TypeOfDecod;
	char	nOutGrade;
	char    CodelineOptType[3];

	FILE	*fhCodeline = NULL;
	float	C_x,C_y,C_w,C_h;


	fImagePresent = FALSE;
	if( stParDocHandle.NumDoc )
		NrDocToProcess = stParDocHandle.NumDoc;
	else
		NrDocToProcess = -1;

	if(( stParDocHandle.TypeOfDecod & DECODE_OCR )&& (stParDocHandle.Side == SIDE_NONE_IMAGE ))
		SideToFilm =  SIDE_FRONT_IMAGE;

	//-----------LoadString--------------------------------------
	if( (stParDocHandle.Validate == PRINT_VALIDATE) && (strlen(stParDocHandle.szValidateText)))
	{
		if( strstr(stParDocHandle.szValidateText, "%d") )
			Reply = LSLoadStringWithCounter(hLS,
											hWnd, 
											(char)(stParDocHandle.PrintBold ? FORMAT_BOLD : FORMAT_NORMAL),
											stParDocHandle.szValidateText,
											8,
											3);
		else
			Reply = LSLoadString(hLS,
								 hWnd,
								 (char)(stParDocHandle.PrintBold ? FORMAT_BOLD : FORMAT_NORMAL),
								 (short)strlen(stParDocHandle.szValidateText),
							     stParDocHandle.szValidateText);
		if (Reply != LS_OKAY)
		{
			if (CheckReply(hWnd, Reply, "LSLoadString"))
			{
				return 0;
			}
		}
	}


	// Send the command of draw red rectangle
	LSViewOCRRectangle(hWnd, fViewOCRRectangle);



	if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
		TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
	{
		//----------- Change stamp position -----------
		Reply = LSChangeStampPosition(hLS, hWnd, stParDocHandle.StampPosition, 0);
	}

	if( TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
		TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
	{
//		Reply = LSDisableWaitDocument(hWnd, SUSPENSIVE_MODE, TRUE);
//		if (Reply != LS_OKAY)
//		{
//			if (CheckReply(hWnd, Reply, "LSDisableWaitDocument"))
//			{
//				return 0;
//			}
//		}

		//----------- Set double leafing sensibility -----------
		Reply = LSDoubleLeafingSensibility(hLS, hWnd, 0, stParDocHandle.DoubleLeafingLevel);
		if (Reply != LS_OKAY)
		{
			if (CheckReply(hWnd, Reply, "LSDoubleLeafingSensibility"))
			{
				return 0;
			}
		}

		//----------- Set Block Document if double leafing -----------
		Reply = LSConfigDoubleLeafing(hLS, hWnd, (short)(stParDocHandle.DoubleLeafingBlock ? DOUBLE_LEAFING_ERROR : DOUBLE_LEAFING_WARNING));
		if (Reply != LS_OKAY)
		{
			if( CheckReply(hWnd, Reply, "LSConfigDoubleLeafing"))
			{
				return 0;
			}
		}

		//----------- Set sorter criteria
		if( stParDocHandle.Sorter == SORTER_AUTOMATIC )
		{
			Reply = LSSetSorterCriteria(hLS,
										hWnd,
										stParDocHandle.DataSorter,
										MAX_CRITERIA);
			if( Reply != LS_OKAY )
			{
				if( CheckReply(hWnd, Reply, "LSSetSorterCriteria") )
				{
					return 0;
				}
			}
		}
	}

	
	// set fixed params for LsAutoDocHandle and LSExtAutoDocHandle
	sprintf(dirBase, "%s%s", PathAppl, SAVE_DIRECTORY_IMAGE);
	strcpy(Filename, NAME_IMAGE);
	
	TypeOfDecod = stParDocHandle.TypeOfDecod;
	CodelineType = NO_READ_CODELINE;
	if( stParDocHandle.TypeOfDecod & DECODE_MICR )
	{
		CodelineType = READ_CODELINE_MICR;
		TypeOfDecod -= DECODE_MICR;
	}
	else if( stParDocHandle.TypeOfDecod & DECODE_OCR )
	{
		CodelineType = NO_READ_CODELINE;
		
		// set  default  coordinates for ocr
		C_x = stParDocHandle.Codeline_Sw_x;
		C_y = stParDocHandle.Codeline_Sw_y;
		C_w = stParDocHandle.Codeline_Sw_w;
		C_h = stParDocHandle.Codeline_Sw_h;

		TypeOfDecod -= DECODE_OCR;
	}
	else if( stParDocHandle.TypeOfDecod & DECODE_BARCODE )
	{
		CodelineType = NO_READ_CODELINE;
		// set  coordinates for barcode
		C_x = stParDocHandle.Barcode_Sw_x;
		C_y = stParDocHandle.Barcode_Sw_y;
		C_w = stParDocHandle.Barcode_Sw_w;
		C_h = stParDocHandle.Barcode_Sw_h;
		
		TypeOfDecod -= DECODE_BARCODE;
	}
	else if( stParDocHandle.TypeOfDecod & DECODE_PDF417 )
	{
		CodelineType = NO_READ_CODELINE;

		TypeOfDecod -= DECODE_PDF417;
	}

	if( (stParDocHandle.DoCheckCodeline) &&
		(stParDocHandle.Side == SIDE_NONE_IMAGE) )
		SideToFilm = SIDE_FRONT_IMAGE;
	else
		SideToFilm = stParDocHandle.Side;


	//-----------AutoDocHandle-----------------------------------
	Reply = LSAutoDocHandle(hLS,
							hWnd,
							stParDocHandle.Stamp,
							stParDocHandle.Validate,
							CodelineType,
							stParDocHandle.ScanMode,
						    AUTO_FEED,	
							stParDocHandle.Sorter,
							stParDocHandle.NumDoc,
							stParDocHandle.ClearBlack,
							SideToFilm,
							stParDocHandle.ReadMode,
							stParDocHandle.SaveImage,
							dirBase,
							Filename,
							(float)stParDocHandle.Codeline_Sw_x,
							(float)stParDocHandle.Codeline_Sw_y,
							(float)stParDocHandle.Codeline_Sw_w,
							0,
							0,
							OCR_FRONT_IMAGE,
							stParDocHandle.SaveFormat,
							stParDocHandle.Qual,
							SAVE_OVERWRITE,	// 0,
							1,	// 0,
							stParDocHandle.WaitTimeout,
							stParDocHandle.BeepOnError,
							NULL,
							NULL,
							NULL);

	if (Reply != LS_OKAY)
	{
		if( (Reply != LS_FEEDER_EMPTY) && (Reply != LS_DOUBLE_LEAFING_WARNING) )
		{
			if (CheckReply(hWnd, Reply, "LSExtAutoDocHandle"))
			{
				return 0;
			}
		}
		else
			Reply = LS_OKAY;		//  l'OK
	}


	// open codeline file
	if( stParDocHandle.SaveCodeline )
	{
		strcpy(FullFName, PathAppl);
		strcat(FullFName, FILE_CODELINE);

		if( stParDocHandle.ResetFileCodeline )
			fhCodeline = fopen(FullFName, "w+t");
		else
			fhCodeline = fopen(FullFName, "a+t");
	}


	if( Save_BufBackNettoImage )
	{
		GlobalFree( Save_BufBackNettoImage );
		Save_BufBackNettoImage = 0;
	}

	if( Save_BufBackImage )
	{
		GlobalFree( Save_BufBackImage );
		Save_BufBackImage = 0;
	}

	if( Save_BufFrontNettoImage )
	{
		GlobalFree( Save_BufFrontNettoImage );
		Save_BufFrontNettoImage = 0;
	}

	if( Save_BufFrontImage )
	{
		GlobalFree( Save_BufFrontImage );
		Save_BufFrontImage = 0;
	}


	//-----------GetDocData--------------------------------------
    if( Reply == LS_OKAY )
	{
		while( NrCheque != NrDocToProcess )
		{
			memset(BufFrontFile,	  0, sizeof(BufFrontFile));
			memset(BufFrontNettoFile, 0, sizeof(BufFrontNettoFile));
			memset(BufBackFile,		  0, sizeof(BufBackFile));
			memset(BufBackNettoFile,  0, sizeof(BufBackNettoFile));

			// free bitmap areas from DoSingleDocHandle
			if( BufBackNettoImage )
			{
				GlobalFree( BufBackNettoImage );
				BufBackNettoImage = 0;
			}
			if( BufBackImage )
			{
				GlobalFree( BufBackImage );
				BufBackImage = 0;
			}
			if( BufFrontNettoImage )
			{
				GlobalFree( BufFrontNettoImage );
				BufFrontNettoImage = 0;
			}
			if( BufFrontImage )
			{
				GlobalFree( BufFrontImage );
				BufFrontImage = 0;
			}

			memset(BufCodelineSW,	0, sizeof(BufCodelineSW));
			memset(BufCodelineHW,	0, sizeof(BufCodelineHW));
			memset(BufBarcode,		0, sizeof(BufBarcode));
			memset(BufOptical,		0, sizeof(BufOptical));

			Reply = LSGetDocData(hLS,
								 hWnd,
								 NULL,
								 BufFrontFile,
								 BufBackFile,
								 BufFrontNettoFile,
								 BufBackNettoFile,
								 &(LPHANDLE)BufFrontImage,
								 &(LPHANDLE)BufBackImage,
								 &(LPHANDLE)BufFrontNettoImage,
								 &(LPHANDLE)BufBackNettoImage,
								 BufCodelineSW,
								 BufCodelineHW,
								 BufBarcode,
								 BufOptical,
								 &NumDocRemain,
								 0,
								 NULL,
								 NULL);

			if( (Reply != LS_OKAY) && (Reply != LS_DOUBLE_LEAFING_WARNING) &&
				(Reply != LS_LOOP_INTERRUPTED) &&
				(Reply != LS_SORTER1_FULL) && (Reply != LS_SORTER2_FULL) &&
				(Reply != LS_SORTERS_BOTH_FULL))
			{
				if( CheckReply(hWnd, Reply, "LSGetDocData") )
				{
					break;
				}
			}


			NrCheque ++;

			if( stParDocHandle.TypeOfDecod & DECODE_OCR )
			{
				ro.PutBlanks = TRUE;
				if(stParDocHandle.CodelineOptType == READ_CODELINE_SW_E13B_X_OCRB )
					{
					ro.TypeRead  = READ_CODELINE_SW_E13B_X_OCRB ;
					CodelineOptType[0] = READ_CODELINE_SW_E13B;
					CodelineOptType[1] = READ_CODELINE_SW_OCRB_NUM;
					CodelineOptType[2] = '\0';
					}
				else
					{
					ro.TypeRead = 'N';
					CodelineOptType[0] = stParDocHandle.CodelineOptType;
					CodelineOptType[1] = '\0';
					}



				Reply = LSCodelineReadFromBitmap(hWnd,
												 (HANDLE)BufFrontImage,
												 CodelineOptType,
												 stParDocHandle.Unit_measure,
												 stParDocHandle.Codeline_Sw_x,
												 stParDocHandle.Codeline_Sw_y,
												 stParDocHandle.Codeline_Sw_w,
												 stParDocHandle.Codeline_Sw_h,
												 &ro,
												 BufCodelineSW,
												 (UINT *)&len_codeline);

				if (Reply != LS_OKAY)
				{
					CheckReply(hWnd, Reply, "LSCodelineReadFromBitmap");
				}
			}

			if( stParDocHandle.TypeOfDecod & DECODE_BARCODE )
			{
				Reply = LSReadBarcodeFromBitmap(hWnd,
												BufFrontImage,
												stParDocHandle.Barcodetype,
												(int)stParDocHandle.Barcode_Sw_x,
												(int)stParDocHandle.Barcode_Sw_y,
												(int)stParDocHandle.Barcode_Sw_w,
												(int)stParDocHandle.Barcode_Sw_h,
												BufBarcode,
												(UINT *)&len_barcode);

				if (Reply != LS_OKAY)
				{
					CheckReply(hWnd, Reply, "LS500_ReadBarcodeFromBitmap");
				}
			}

			if( stParDocHandle.TypeOfDecod & DECODE_PDF417 )
			{
				Reply = LSReadPdf417FromBitmap(hWnd,
											   BufFrontImage,
											   BufBarcode,
											   (UINT *)&len_codeline,
											   &nOutGrade,
											   0, 0, 0, 0);

				if (Reply != LS_OKAY)
				{
					CheckReply(hWnd, Reply, "LS500_ReadPdf417FromBitmap");
				}
			}



			// save codeline 
			if( BufCodelineSW[0] )
				strcpy(CodelineRead, BufCodelineSW);
			else if( BufCodelineHW[0] )
				strcpy(CodelineRead, BufCodelineHW);
			else if( BufBarcode[0] )
				strcpy(CodelineRead, BufBarcode);

			// Show codeline and/or Images
			if( BufCodelineHW[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufCodelineHW);
			else if( BufCodelineSW[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufCodelineSW);
			else if( BufBarcode[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufBarcode);
			else if( BufOptical[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufOptical);
			else
				SetDlgItemText(hWnd, IDC_CODELINE, "");


			// For change the image set the flag to FALSE
			fImagePresent = FALSE;

			// Libero le aree bitmap ritornate
			if( Save_BufBackNettoImage )
				GlobalFree( Save_BufBackNettoImage );
			Save_BufBackNettoImage = (char *)BufBackNettoImage;
			BufBackNettoImage = 0;

			if( Save_BufBackImage )
				GlobalFree( Save_BufBackImage );
			Save_BufBackImage = (char *)BufBackImage;
			BufBackImage = 0;

			if( Save_BufFrontNettoImage )
				GlobalFree( Save_BufFrontNettoImage );
			Save_BufFrontNettoImage = (char *)BufFrontNettoImage;
			BufFrontNettoImage = 0;

			if( Save_BufFrontImage )
				GlobalFree( Save_BufFrontImage );
			Save_BufFrontImage = (char *)BufFrontImage;
			BufFrontImage = 0;

			// Set the flag to TRUE
			fImagePresent = TRUE;
			InvalidateRect(hWnd, NULL, TRUE);


			// save codeline on file
			if( stParDocHandle.SaveCodeline )
			{
				if( BufCodelineHW[0] != '\0' )
				{
					strcat(BufCodelineHW, "\n");
					fputs(BufCodelineHW, fhCodeline);
				}

				if( BufBarcode[0] != '\0' )
				{
					strcat(BufBarcode, "\n");
					fputs(BufBarcode, fhCodeline);
				}

				if( BufCodelineSW[0] != '\0' )
				{
					strcat(BufCodelineSW, "\n");
					fputs(BufCodelineSW, fhCodeline);
				}
			}


			// show image
			while( PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) )
			{
				TranslateMessage( &msg );
				DispatchMessage( &msg );
			}


			if( ((Reply != LS_OKAY) && (Reply != LS_DOUBLE_LEAFING_WARNING)) &&
				(Reply > LS_DECODE_FONT_NOT_PRESENT))
			{
				CheckReply(hWnd, Reply, "LSGetDocData");
				break;
			}

		} // End while(1)
	}


	// close  Codeline file
	if( stParDocHandle.SaveCodeline )
		fclose( fhCodeline );

	return ReplyFunz;
}  // End DoAutoDocHandle


//***************************************************************************
// FUNCTION  : DoSingleDocHandle
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
int DoSingleDocHandle(HWND hWnd)
{
	int		Reply, ReplyDH;
	short	X;
	short	Y;
	short	Size;
	char	dirBase[_MAX_DIR];
	char	Filename[_MAX_FNAME];

	char  BufCodelineHW[CODE_LINE_LENGTH];
	char  BufBarcode[CODE_LINE_LENGTH];
	char  BufCodelineSW[CODE_LINE_LENGTH];
	short llCodeline;
	short len_barcode;

	char	CodelineType;
	short	Sorter;
	short   StopAfterCodeline;

	READOPTIONS ro;

	unsigned char SenseKey;
	unsigned char StatusByte[4];

	char  SideToFilm;


	NrCheque ++;


	fImagePresent = FALSE;
	//-----------LoadString--------------------------------------
	if( (stParDocHandle.Validate == PRINT_VALIDATE) && (strlen(stParDocHandle.szValidateText)) )
	{
		if( strstr(stParDocHandle.szValidateText, "%d") )
			Reply = LSLoadStringWithCounter(hLS,
											hWnd,
											(char)(stParDocHandle.PrintBold ? FORMAT_BOLD : FORMAT_NORMAL),
											stParDocHandle.szValidateText,
											8,
											3);
		else
			Reply = LSLoadString(hLS,
								 hWnd,
								 (char)(stParDocHandle.PrintBold ? FORMAT_BOLD : FORMAT_NORMAL),
								 (short)strlen(stParDocHandle.szValidateText),
								 stParDocHandle.szValidateText);
		if (Reply != LS_OKAY)
		{
			if (CheckReply(hWnd, Reply, "LSLoadString"))
			{
				return Reply;
			}
		}
	}


	// Send the command of draw red rectangle
	LSViewOCRRectangle(hWnd, fViewOCRRectangle);


	// Send the command for handle the image
//	LSEnableImageCorrection(hLS, hWnd, fImageCorrection);


	if( TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
		TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
	{
		//----------- Set sorter criteria
		if( stParDocHandle.Sorter == SORTER_AUTOMATIC )
		{
			Reply = LSSetSorterCriteria(hLS,
										hWnd,
										stParDocHandle.DataSorter,
										MAX_CRITERIA);
			if( Reply != LS_OKAY )
			{
				if( CheckReply(hWnd, Reply, "LSSetSorterCriteria") )
				{
					return 0;
				}
			}
		}

		//----------- Set double leafing sensibility -----------
		Reply = LSDoubleLeafingSensibility(hLS, hWnd, 0, stParDocHandle.DoubleLeafingLevel);
		if (Reply != LS_OKAY)
		{
			if (CheckReply(hWnd, Reply, "LSDuobleLeafingSensibility"))
			{
				return 0;
			}
		}

		//----------- Set Block Document if double leafing -----------
		Reply = LSConfigDoubleLeafing(hLS, hWnd, (short)(stParDocHandle.DoubleLeafingBlock ? DOUBLE_LEAFING_ERROR : DOUBLE_LEAFING_WARNING));
		if (Reply != LS_OKAY)
		{
			if( CheckReply(hWnd, Reply, "LSConfigDoubleLeafing"))
			{
				return 0;
			}
		}
	}


	// set fixed params for LS500_DocHandle
	sprintf(dirBase, "%s%s", PathAppl, SAVE_DIRECTORY_IMAGE);
	strcpy(Filename, NAME_IMAGE);
	if( (stParDocHandle.CodelineType == READ_CODELINE_SW_OCRA) ||
		(stParDocHandle.CodelineType == READ_CODELINE_SW_OCRB_NUM) )
	{
		CodelineType = NO_READ_CODELINE;

		X    = 16;
		Y    = 16;
		Size = -1; 

		if( stParDocHandle.ScanMode == SCAN_MODE_16GR200 )
		{
			X *= 2;
			Y *= 2;
		}
	}
	else
		CodelineType = stParDocHandle.CodelineType;


	if( (stParDocHandle.DoCheckCodeline) &&
		(stParDocHandle.Side == SIDE_NONE_IMAGE) )
		SideToFilm = SIDE_FRONT_IMAGE;
	else
		SideToFilm = stParDocHandle.Side;


	//-----------DocHandle-----------------------------------
	ReplyDH = LSDocHandle(hLS,
						  hWnd,
						  stParDocHandle.Stamp,
						  stParDocHandle.Validate,
						  CodelineType,
						  SideToFilm,
						  stParDocHandle.ScanMode,
						  (short)(stParDocHandle.LinearEntry == TRUE ? PATH_FEED : AUTO_FEED),
						  stParDocHandle.Sorter,
						  stParDocHandle.WaitTimeout,
						  stParDocHandle.BeepOnError,
						  NULL,
						  0,
						  0);

	if( ReplyDH != LS_OKAY && ReplyDH != LS_KEEP_DOC_ON_CODELINE_ERROR )
	{
		if( ReplyDH != LS_DOUBLE_LEAFING_WARNING )
			if( CheckReply(hWnd, ReplyDH, "LSDocHandle"))
			{
				return ReplyDH;
			}
	}


	//
	// Read the codeline and the images
	//

	// free bitmap areas
	if( BufBackNettoImage )
	{
		GlobalFree( BufBackNettoImage );
		BufBackNettoImage = 0;
	}
	if( BufBackImage )
	{
		GlobalFree( BufBackImage );
		BufBackImage = 0;
	}
	if( BufFrontNettoImage )
	{
		GlobalFree( BufFrontNettoImage );
		BufFrontNettoImage = 0;
	}
	if( BufFrontImage )
	{
		GlobalFree( BufFrontImage );
		BufFrontImage = 0;
	}

	memset((char *)BufCodelineHW,	0, sizeof(BufCodelineHW));
	memset((char *)BufBarcode,		0, sizeof(BufBarcode));
	memset((char *)BufCodelineSW,	0, sizeof(BufCodelineSW));

	llCodeline = CODE_LINE_LENGTH;
	len_barcode = CODE_LINE_LENGTH;

	//------------Read Codeline hardware---------------------------
	if( (!stParDocHandle.LinearEntry) &&
		(stParDocHandle.CodelineType == READ_CODELINE_MICR ||
		 stParDocHandle.CodelineType == READ_BARCODE_HW ||
		 stParDocHandle.CodelineType == READ_MICR_AND_BARCODE_HW) )
	{
		Reply = LSReadCodeline(hLS,
							   hWnd,
							   BufCodelineHW,
							   &llCodeline,
							   BufBarcode,
							   &len_barcode,
							   NULL,
							   NULL);

		if( Reply != LS_OKAY)
		{
			if( CheckReply(hWnd, Reply, "LSReadCodeline"))
			{
				return Reply;
			}
		}
	}

	StopAfterCodeline = FALSE;

	// Read images if DocHandle = OK
	if( ((ReplyDH == LS_OKAY) || (ReplyDH == LS_DOUBLE_LEAFING_WARNING)) &&
		(Reply == LS_OKAY) )
	{
		//-----------ReadImage-------------------------------------
		if( SideToFilm != SIDE_NONE_IMAGE )
		{
			Reply = LSReadImage(hLS,
								hWnd,
								stParDocHandle.ClearBlack,
								SideToFilm,
								stParDocHandle.ReadMode,
								0,
								&BufFrontImage,
								&BufBackImage,
								&BufFrontNettoImage,
								&BufBackNettoImage);

			if (Reply != LS_OKAY)
			{
				if((Reply == LS_IMAGE_NOT_PRESENT ) &&
					(stParDocHandle.Sorter == SORTER_AUTOMATIC))
				{
					// I suppose that the document was retained after MICR
				
					StopAfterCodeline = TRUE;
				}
				else
				{
					if( CheckReply(hWnd, Reply, "LSReadImage"))
					{
						return Reply;
					}
				}
			}
	
			if( stParDocHandle.TypeOfDecod & DECODE_BARCODE )
			{
				Reply = LSReadBarcodeFromBitmap(hWnd,
												BufFrontImage,
												stParDocHandle.Barcodetype,
												(int)stParDocHandle.Barcode_Sw_x,
												(int)stParDocHandle.Barcode_Sw_y,
												(int)stParDocHandle.Barcode_Sw_w,
												(int)stParDocHandle.Barcode_Sw_h,
												BufBarcode,
												(UINT *)&len_barcode);
				if (Reply != LS_OKAY)
				{
					CheckReply(hWnd, Reply, "LS500_ReadBarcodeFromBitmap");
				}
			}
		}

		if( (StopAfterCodeline == FALSE) &&
			((stParDocHandle.Side == SIDE_ALL_IMAGE) ||
			(stParDocHandle.Side == SIDE_FRONT_IMAGE)) )
		{
			if( ((stParDocHandle.CodelineType == READ_CODELINE_SW_OCRA) ||
				 (stParDocHandle.CodelineType == READ_CODELINE_SW_OCRB_NUM))
				 && (hOCRLibrary) )
			{
				ro.PutBlanks = TRUE;
				ro.TypeRead = 'N';

				Reply = LSReadCodelineFromBitmap(hWnd,
												 BufFrontImage,
												 (char *)&stParDocHandle.CodelineType,
												 X,
												 Y,
												 Size,
												 MAX_PIXEL_HEIGHT,
												 &ro,
												 BufCodelineSW,
												 (UINT *)&llCodeline);
				if (Reply != LS_OKAY)
				{
					if( CheckReply(hWnd, Reply, "LSReadCodelineFromBitmapEx"))
					{
						return Reply;
					}
				}
			}
		}


		// Save the image if required
		if(stParDocHandle.SaveImage == IMAGE_SAVE_BOTH)
		{
			// Type image format
			switch(stParDocHandle.SaveFormat)
			{
			case SAVE_JPEG:
				if( BufBackImage )
				{
					// build complete filename
					sprintf(SaveFile, "%s\\%s%dBB.jpg", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileJPEG);
					Reply = LSSaveJPEG(hWnd, BufBackImage, stParDocHandle.Qual, SaveFile );
				}

				if( BufFrontImage )
				{
					// build complete filename
					sprintf(SaveFile, "%s\\%s%dFF.jpg", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileJPEG);
					Reply = LSSaveJPEG(hWnd, BufFrontImage, stParDocHandle.Qual, SaveFile );
				}

				NrFileJPEG ++;
				break;

			case SAVE_BMP:
				if( BufBackImage )
				{
					// build complete filename
					sprintf(SaveFile, "%s\\%s%dBB.bmp", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileBMP);
					Reply = LSSaveDIB(hWnd, BufBackImage, SaveFile );
				}

				if( BufFrontImage )
				{
					// build complete filename
					sprintf(SaveFile, "%s\\%s%dFF.bmp", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileBMP);
					Reply = LSSaveDIB(hWnd, BufFrontImage, SaveFile );
				}

				NrFileBMP ++;
				break;

			case FILE_TIF:
			case FILE_CCITT:
			case FILE_CCITT_GROUP3_1DIM:
			case FILE_CCITT_GROUP3_2DIM:
			case FILE_CCITT_GROUP4:

				if( BufBackImage )
				{
					// build complete filename
					sprintf(SaveFile, "%s\\%s%dBB.tiff", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileTIFF);
					Reply = LSSaveTIFF(hWnd, BufBackImage, SaveFile, stParDocHandle.SaveFormat,SAVE_OVERWRITE,1);
				}

				if( BufFrontImage )
				{
					// build complete filename
					sprintf(SaveFile, "%s\\%s%dFF.tiff", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileTIFF);
					Reply = LSSaveTIFF(hWnd, BufFrontImage, SaveFile, stParDocHandle.SaveFormat,SAVE_OVERWRITE, 1);
				}

				NrFileTIFF ++;
				break;
			}
		}


		// Show codeline and/or Images
		if( BufCodelineHW[0] )
			SetDlgItemText(hWnd, IDC_CODELINE, BufCodelineHW);
		else if( BufCodelineSW[0] )
			SetDlgItemText(hWnd, IDC_CODELINE, BufCodelineSW);
		else if( BufBarcode[0] )
			SetDlgItemText(hWnd, IDC_CODELINE, BufBarcode);
		else
			SetDlgItemText(hWnd, IDC_CODELINE, "");


		// For change the image set the flag to FALSE
		fImagePresent = FALSE;

		// free areas
		if( Save_BufBackNettoImage )
			GlobalFree( Save_BufBackNettoImage );
		Save_BufBackNettoImage = (char *)BufBackNettoImage;
		BufBackNettoImage = 0;

		if( Save_BufBackImage )
			GlobalFree( Save_BufBackImage );
		Save_BufBackImage = (char *)BufBackImage;
		BufBackImage = 0;

		if( Save_BufFrontNettoImage )
			GlobalFree( Save_BufFrontNettoImage );
		Save_BufFrontNettoImage = (char *)BufFrontNettoImage;
		BufFrontNettoImage = 0;

		if( Save_BufFrontImage )
			GlobalFree( Save_BufFrontImage );
		Save_BufFrontImage = (char *)BufFrontImage;
		BufFrontImage = 0;

		// Set the flag to TRUE
		fImagePresent = TRUE;
		InvalidateRect(hWnd, NULL, TRUE);
	}

		memset(CodelineRead, 0, sizeof(CodelineRead));
		if( BufCodelineHW[0] )
			strcpy(CodelineRead, BufCodelineHW);
		else if( BufBarcode[0] )
			strcpy(CodelineRead, BufBarcode);
		else if( BufCodelineSW[0] )
			strcpy(CodelineRead, BufCodelineSW);


	// If doc retained show a dialog
	if( (stParDocHandle.Sorter == HOLD_DOCUMENT) ||
		(fDocRetained && (ReplyDH == LS_KEEP_DOC_ON_CODELINE_ERROR)) ||
		(StopAfterCodeline) )
	{
		Sorter = (short)DialogBox(hInst, MAKEINTRESOURCE(IDD_SORTER), hWnd, SorterDlgProc);

		//-----------LoadString--------------------------------------
		if( (stParDocHandle.SorterValidate == PRINT_VALIDATE) && (strlen(stParDocHandle.SorterszValidateText)) )
		{
			Reply = LSLoadString(hLS,
								 hWnd,
								 (char)(stParDocHandle.SorterPrintBold ? FORMAT_BOLD : FORMAT_NORMAL),
								 (short)strlen(stParDocHandle.SorterszValidateText),
								 stParDocHandle.SorterszValidateText);
			if( Reply != LS_OKAY) //&& (Reply != LS_KEEP_DOC_ON_CODELINE_ERROR) )
			{
				if (CheckReply(hWnd, Reply, "LSLoadString"))
				{
					return Reply;
				}
			}
		}

		//-----------DocHandle-----------------------------------
		Reply = LSDocHandle(hLS,
							hWnd,
							stParDocHandle.SorterStamp,
							stParDocHandle.SorterValidate,
							NO_READ_CODELINE,
							stParDocHandle.SorterSide,
							stParDocHandle.ScanMode,
							PATH_FEED,
							Sorter,
							stParDocHandle.WaitTimeout,
							stParDocHandle.BeepOnError,
							NULL,
							0,
							0);
		if( Reply != LS_OKAY )
		{
			if( CheckReply(hWnd, Reply, "LSDocHandle") )
			{
				return Reply;
			}
		}


		if( Reply == LS_OKAY )
		{
			//-----------ReadImage-------------------------------------
			if( stParDocHandle.SorterSide != SIDE_NONE_IMAGE )
			{
				Reply = LSReadImage(hLS,
									hWnd,
									stParDocHandle.ClearBlack,
									stParDocHandle.SorterSide,
									stParDocHandle.ReadMode,
									0,
									&BufFrontImage,
									&BufBackImage,
									&BufFrontNettoImage,
									&BufBackNettoImage);

				if (Reply != LS_OKAY)
				{
					if( CheckReply(hWnd, Reply, "LSReadImage"))
					{
						return Reply;
					}
				}
			}

			if( (stParDocHandle.SorterSide == SIDE_ALL_IMAGE) ||
				(stParDocHandle.SorterSide == SIDE_FRONT_IMAGE) )
			{
				if( ((stParDocHandle.CodelineType == READ_CODELINE_SW_OCRA) ||
					 (stParDocHandle.CodelineType == READ_CODELINE_SW_OCRB_NUM))
					 && (hOCRLibrary) )
				{
					ro.PutBlanks = TRUE;
					ro.TypeRead = 'N';

					LSReadCodelineFromBitmap(hWnd,
											 BufFrontImage,
											 (char *)&stParDocHandle.CodelineType,
											 X,
											 Y,
											 Size,
											 MAX_PIXEL_HEIGHT,
											 &ro,
											 BufCodelineSW,
											 (UINT *)&llCodeline);
					if (Reply != LS_OKAY)
					{
						if( CheckReply(hWnd, Reply, "LSReadCodelineFromBitmapEx"))
						{
							return Reply;
						}
					}
				}
			}


			// Save the image if required
			if(stParDocHandle.SaveImage == IMAGE_SAVE_BOTH)
			{
				// Type image format
				switch(stParDocHandle.SaveFormat)
				{
				case SAVE_JPEG:
					if( BufBackImage )
					{
						// build complete filename
						sprintf(SaveFile, "%s\\%s%dBB.jpg", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileJPEG);
						Reply = LSSaveJPEG(hWnd, BufBackImage, stParDocHandle.Qual, SaveFile );
					}

					if( BufFrontImage )
					{
						// build complete filename
						sprintf(SaveFile, "%s\\%s%dFF.jpg", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileJPEG);
						Reply = LSSaveJPEG(hWnd, BufFrontImage, stParDocHandle.Qual, SaveFile );
					}

					NrFileJPEG ++;
					break;

				case SAVE_BMP:
					if( BufBackImage )
					{
						// build complete filename
						sprintf(SaveFile, "%s\\%s%dBB.bmp", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileBMP);
						Reply = LSSaveDIB(hWnd, BufBackImage, SaveFile );
					}

					if( BufFrontImage )
					{
						// build complete filename
						sprintf(SaveFile, "%s\\%s%dFF.bmp", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileBMP);
						Reply = LSSaveDIB(hWnd, BufFrontImage, SaveFile );
					}

					NrFileBMP ++;
					break;

				case FILE_TIF:
				case FILE_CCITT:
				case FILE_CCITT_GROUP3_1DIM:
				case FILE_CCITT_GROUP3_2DIM:
				case FILE_CCITT_GROUP4:

					if( BufBackImage )
					{
						// build complete filename
						sprintf(SaveFile, "%s\\%s%dBB.tiff", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileTIFF);
						Reply = LSSaveTIFF(hWnd, BufBackImage, SaveFile, stParDocHandle.SaveFormat,SAVE_OVERWRITE,1);
					}

					if( BufFrontImage )
					{
						// build complete filename
						sprintf(SaveFile, "%s\\%s%dFF.tiff", SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrFileTIFF);
						Reply = LSSaveTIFF(hWnd, BufFrontImage, SaveFile, stParDocHandle.SaveFormat,SAVE_OVERWRITE, 1);
					}

					NrFileTIFF ++;
					break;
				}
			}


			// Show codeline and/or Images
			if( BufCodelineHW[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufCodelineHW);
			else if( BufCodelineSW[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufCodelineSW);
			else if( BufBarcode[0] )
				SetDlgItemText(hWnd, IDC_CODELINE, BufBarcode);
			else
				SetDlgItemText(hWnd, IDC_CODELINE, "");


			// For change the image set the flag to FALSE
			fImagePresent = FALSE;

			if( Save_BufBackNettoImage )
				GlobalFree( Save_BufBackNettoImage );
			Save_BufBackNettoImage = (char *)BufBackNettoImage;
			BufBackNettoImage = 0;

			if( Save_BufBackImage )
				GlobalFree( Save_BufBackImage );
			Save_BufBackImage = (char *)BufBackImage;
			BufBackImage = 0;

			if( Save_BufFrontNettoImage )
				GlobalFree( Save_BufFrontNettoImage );
			Save_BufFrontNettoImage = (char *)BufFrontNettoImage;
			BufFrontNettoImage = 0;

			if( Save_BufFrontImage )
				GlobalFree( Save_BufFrontImage );
			Save_BufFrontImage = (char *)BufFrontImage;
			BufFrontImage = 0;

			// Set the flag to TRUE
			fImagePresent = TRUE;
			InvalidateRect(hWnd, NULL, TRUE);
		} // if( Reply == LS_OKAY )
	}

	// more documents in the feeder?
	if( Reply == LS_OKAY )
	{
		if( LSPeripheralStatus(hLS, hWnd, &SenseKey, StatusByte) == LS_OKAY )
		{
			if( !(StatusByte[0] & MASK_FEEDER_EMPTY) )
				Reply = LS_FEEDER_EMPTY;
		}
	}

	return Reply;
}  // End DoSingleDocHandle


//********************************************************************
// FUNCTION  : thShowCodeline
//
// PURPOSE   : Show the codeline read in overlapped mode
//
// PARAMETER : 
//
//********************************************************************
void thShowCodeline(unsigned long NrDocCodeline)
{

	// Show codeline
	if( CodelineRead[0] )
		SetDlgItemText(hDlgMain, IDC_CODELINE, CodelineRead);
	else
		SetDlgItemText(hDlgMain, IDC_CODELINE, "");


} // thShowCodeline


//********************************************************************
// FUNCTION  : thShowImageFront
//
// PURPOSE   : Show the image read in overlapped mode
//
// PARAMETER : 
//
//********************************************************************
void thShowImageFront(unsigned long NrDocImage)
{
	char fName[_MAX_PATH];


	// Save the image if required
	if( BufFrontImage && (stParDocHandle.SaveImage == IMAGE_SAVE_BOTH) )
	{
		if( stParDocHandle.SaveFormat == SAVE_JPEG )
		{
			sprintf(fName, "%s%s\\%s%04dF.jpg", PathAppl, SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrDocImage);
			LSSaveJPEG(NULL, BufFrontImage, stParDocHandle.Qual, fName);
		}
		else if( stParDocHandle.SaveFormat == SAVE_BMP )
		{
			sprintf(fName, "%s%s\\%s%04dF.bmp", PathAppl, SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrDocImage);
			LSSaveDIB(NULL, BufFrontImage, fName);
		}
		else // if( stParDocHandle.FileFormat == SAVE_TIFF )
		{
			sprintf(fName, "%s%s\\%s%04dF.tif", PathAppl, SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrDocImage);
			LSSaveTIFF(NULL, BufFrontImage, fName, stParDocHandle.SaveFormat, SAVE_OVERWRITE, 1);
		}
	}


	// For change the image set the flag to FALSE
	fImagePresent = FALSE;

	// Show Image
	if( BufFrontImage )
	{
		if( Save_BufFrontImage )
			GlobalFree( Save_BufFrontImage );
		Save_BufFrontImage = (char *)BufFrontImage;
		BufFrontImage = 0;
	}

	// Set the flag to TRUE
	fImagePresent = TRUE;
	InvalidateRect(hDlgMain, NULL, TRUE);

} // thShowImageFront


//********************************************************************
// FUNCTION  : thShowImageBack
//
// PURPOSE   : Show the back image read in overlapped mode
//
// PARAMETER : 
//
//********************************************************************
void thShowImageBack(unsigned long NrDocImage)
{
	char fName[_MAX_PATH];


	// Save the image if required
	if( BufBackImage && (stParDocHandle.SaveImage == IMAGE_SAVE_BOTH) )
	{
		if( stParDocHandle.SaveFormat == SAVE_JPEG )
		{
			sprintf(fName, "%s%s\\%s%04dB.jpg", PathAppl, SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrDocImage);
			LSSaveJPEG(NULL, BufBackImage, stParDocHandle.Qual, fName);
		}
		else if( stParDocHandle.SaveFormat == SAVE_BMP )
		{
			sprintf(fName, "%s%s\\%s%04dB.bmp", PathAppl, SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrDocImage);
			LSSaveDIB(NULL, BufBackImage, fName);
		}
		else // if( stParDocHandle.FileFormat == SAVE_TIFF )
		{
			sprintf(fName, "%s%s\\%s%04dB.tif", PathAppl, SAVE_DIRECTORY_IMAGE, NAME_IMAGE, NrDocImage);
			LSSaveTIFF(NULL, BufBackImage, fName, stParDocHandle.SaveFormat, SAVE_OVERWRITE, 1);
		}
	}

	// Show Image
	// For change the image set the flag to FALSE
	fImagePresent = FALSE;

	if( BufBackImage )
	{
		if( Save_BufBackImage )
			GlobalFree( Save_BufBackImage );
		Save_BufBackImage = (char *)BufBackImage;
		BufBackImage = 0;
	}

	// Set the flag to TRUE
	fImagePresent = TRUE;
	InvalidateRect(hDlgMain, NULL, TRUE);

} // thShowImage


// Try of callback routine
int OnCodelineRead(S_CODELINE_INFO_LS100 *CodelineInfo)
{
	DWORD IdThread;
	HANDLE hThread;
	unsigned long NrDoc;


	// save the codeline ...
	memset(CodelineRead, 0, sizeof(CodelineRead));
	memcpy(CodelineRead, CodelineInfo->CodelineRead, CodelineInfo->NrBytes);
	NrDoc = CodelineInfo->NrDoc;

	// ... and I start a thread which displays 
	hThread = CreateThread(NULL, 16384, (LPTHREAD_START_ROUTINE)thShowCodeline, (LPVOID)NrDoc, 0, &IdThread);

	return 0;
} // OnCodelineRead


// Try of callback routine
int OnImageFrontReady(S_IMAGE_INFO_LS100 *ImgInfo)
{
	DWORD IdThread;
	HANDLE hThread;
	unsigned long NrDoc;


	// save the image ...
	BufFrontImage = ImgInfo->hImage;
	NrDoc = ImgInfo->NrDoc;

	// ... and I start a thread which displays 
	hThread = CreateThread(NULL, 16384, (LPTHREAD_START_ROUTINE)thShowImageFront, (LPVOID)NrDoc, 0, &IdThread);

	return 0;
} // OnImageFrontReady


// Try of callback routine
int OnImageBackReady(S_IMAGE_INFO_LS100 *ImgInfo)
{
	DWORD IdThread;
	HANDLE hThread;
	unsigned long NrDoc;


	// save the image...
	BufBackImage = ImgInfo->hImage;
	NrDoc = ImgInfo->NrDoc;

	// ... and I start a thread which displays 
	hThread = CreateThread(NULL, 16384, (LPTHREAD_START_ROUTINE)thShowImageBack, (LPVOID)NrDoc, 0, &IdThread);

	return 0;
} // OnImageBackReady


//***************************************************************************
// FUNCTION  : DoOverlappedMode
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
int DoOverlappedMode(HWND hWnd, short hLS, unsigned short NrDocToRead)
{
	int		Reply;
	short	CodelineType;


	//-----------LoadString--------------------------------------
	if( stParDocHandle.Validate == PRINT_VALIDATE )
	{
		if( IdentStr[1] & 0x08 )
		{
			Reply = LSLoadString(hLS,
								 hWnd,
								 (char)(stParDocHandle.PrintBold ? FORMAT_BOLD : FORMAT_NORMAL),
								 (short)strlen(stParDocHandle.Endorse_str),
								 stParDocHandle.Endorse_str);
			if (Reply != LS_OKAY)
			{
				if (CheckReply(hWnd, Reply, "LSLoadString"))
				{
					return 0;
				}
			}
		}
		if( IdentStr[1] & 0x04 )
		{
			Reply = LSLoadMultiString(hLS,
									  hWnd,
									  stParDocHandle.Invalidation_Offset1, 0,
									  stParDocHandle.Invalidation_str1,
									  (short)strlen(stParDocHandle.Invalidation_str1),
									  stParDocHandle.Invalidation_Offset2, 0,
									  stParDocHandle.Invalidation_str2,
									  (short)strlen(stParDocHandle.Invalidation_str2),
									  stParDocHandle.Invalidation_Offset3, 0,
									  stParDocHandle.Invalidation_str3,
									  (short)strlen(stParDocHandle.Invalidation_str3));
			if (Reply != LS_OKAY)
			{
				if (CheckReply(hWnd, Reply, "LSLoadMultiString"))
				{
					return 0;
				}
			}
		}
	}


	CodelineType = NO_READ_CODELINE;
	if( stParDocHandle.TypeOfDecod & DECODE_MICR )
	{
		CodelineType = READ_CODELINE_MICR;
	}
	else if( stParDocHandle.TypeOfDecod & DECODE_OCR )
	{
		if( stParDocHandle.CodelineOptType == READ_CODELINE_SW_OCRA ||
			stParDocHandle.CodelineOptType == READ_CODELINE_SW_OCRB_NUM ||
			stParDocHandle.CodelineOptType == READ_CODELINE_SW_OCRB_ALFANUM ||
			stParDocHandle.CodelineOptType == READ_CODELINE_SW_E13B ||
			stParDocHandle.CodelineOptType == READ_CODELINE_SW_E13B_X_OCRB ||
			stParDocHandle.CodelineOptType == READ_CODELINE_SW_MULTI_READ )
		{
			CodelineType = stParDocHandle.CodelineOptType;
		}
	}
	else if( stParDocHandle.TypeOfDecod & DECODE_PDF417 )
	{
		CodelineType = READ_BARCODE_PDF417;
	}
	else if( stParDocHandle.TypeOfDecod & DECODE_BARCODE )
	{
		CodelineType = READ_BARCODE_2_OF_5;
	}


	// Faccio partire la lettura
	Reply = LSDocHandleOverlapped(hLS,
								  hWnd,
								  stParDocHandle.FrontStamp,
								  stParDocHandle.Validate,
								  CodelineType,
								  stParDocHandle.Side,
								  stParDocHandle.ScanMode,
								  stParDocHandle.ClearBlack,
								  stParDocHandle.WaitTimeout,
								  stParDocHandle.BeepOnError,
								  stParDocHandle.NumDoc,
								  0,
								  0,
								  OnCodelineRead,
								  OnImageFrontReady,
								  OnImageBackReady,
								  NULL);

	if( Reply != LS_OKAY )
	{
		if( CheckReply(hWnd, Reply, "LSDocHandleOverlapped") )
		{
			return Reply;
		}
	}

	return Reply;
}  // End DoOverlappedMode


BOOL CheckDocRetained()
{
	register ii;
	BOOL Rc;


	// reply ok
	Rc = FALSE;

	if( stParDocHandle.Sorter == SORTER_AUTOMATIC )
		for( ii = 0; ii < MAX_CRITERIA; ii++)
			if( (stParDocHandle.DataSorter[ii].TypeCriteria != CRITERIA_NO ) &&
				(stParDocHandle.DataSorter[ii].Bin == HOLD_DOCUMENT))
				Rc = TRUE;

	return Rc;
} // CheckDocRetained


void Ls100Dialog(HWND hwnd)
{
	unsigned short NrDocToRead;


	if (DialogBox(hInst, MAKEINTRESOURCE (IDD_DOCUMENT_HANDLE_100), hwnd, DlgProcDocumentHandle100))
	{
		NrCheque = 0;

		// work out the num. of documents to read
		if( stParDocHandle.NumDoc )
			NrDocToRead = stParDocHandle.NumDoc;
		else
			NrDocToRead = 65535;

		if( stParDocHandle.OverlappedMode )
		{
			DoOverlappedMode(hwnd, hLS, NrDocToRead);
		}
		else if( stParDocHandle.Sorter == HOLD_DOCUMENT )
		{
			do
				Reply = DoSingleDocHandle(hwnd);
			while( (--NrDocToRead) && (Reply == LS_OKAY) );
		}
		else
		{
			Reply = DoAutoDocHandle(hwnd);
		}
	}
} // Ls100Dialog


void Ls200Dialog(HWND hwnd)
{
} // Ls200Dialog


void Ls500Dialog(HWND hwnd)
{

	if( DialogBox(hInst, MAKEINTRESOURCE (IDD_DOCUMENTHANDLE500), hwnd, DocumentHandleDlgProc500))
	{
		NrCheque = 0;

		fDocRetained = CheckDocRetained();

		//  check Codeline or Linear Entry
		if( (stParDocHandle.LinearEntry) ||
			(stParDocHandle.Sorter == HOLD_DOCUMENT) ||
			(fDocRetained) ||
			((stParDocHandle.DoCheckCodeline ) &&
			(stParDocHandle.CodelineType != NO_READ_CODELINE)) )
		{
			if( stParDocHandle.NumDoc )
				NrDocToRead = stParDocHandle.NumDoc;
			else
				NrDocToRead = 65535;

			do
				Reply = DoSingleDocHandle(hwnd);
			while( (--NrDocToRead) && (Reply == LS_OKAY) );

		}
		else
		{
			Reply = DoAutoDocHandle(hwnd);
		}
	}
} // Ls500Dialog


void Ls800Dialog(HWND hwnd)
{
} // Ls800Dialog


// --------------------------------------------------------------------
//
//	Parametri:
//
//	Descrizione:
//               Routines di reset
//
void DoLSReset(HWND hDlg, short TypePeripheral)
{
	int Reply;
	short hLS;


	//-----------Open--------------------------------------------
	Reply = LSConnectDiagnostica(hDlg, hInst, TypePeripheral, &hLS);
	if( Reply != LS_OKAY )
	{
		CheckReply(hDlg, Reply, "LSConnect");
		return;
	}

	Reply = LSReset(hLS, hDlg, (char)(TypePeripheral == LS_200_USB ? RESET_ERROR : RESET_FREE_PATH));
	if(Reply != LS_OKAY) 
		CheckReply(hDlg, Reply, "Reset");
	else

		MessageBox(hDlg, "RESET completed successfully !", TITLE_ERROR, MB_OK);

	LSDisconnect(hLS, hDlg);

} // DoLSReset

//*******************************************************************
//*    SaveConfiguration()
//*******************************************************************
void SaveConfiguration(unsigned char *IdentStr)
{

	PeriphFeatures.Micr				= FALSE;
	PeriphFeatures.InkjetPrinter	= FALSE;
	PeriphFeatures.VoidingStamp		= FALSE;
	PeriphFeatures.ScannerFront		= FALSE;
	PeriphFeatures.ScannerBack		= FALSE;
	PeriphFeatures.BadgeReader		= FALSE;


	if( IdentStr[1] & 0x01 )						// 00000001
		PeriphFeatures.Micr = TRUE;

	if( IdentStr[1] & 0x08 )						// 00001000
		PeriphFeatures.InkjetPrinter = TRUE;

	if( IdentStr[1] & 0x20 )						// 00100000
		PeriphFeatures.VoidingStamp = TRUE;

	if( IdentStr[2] & 0x01 )						// 00000001
		PeriphFeatures.ScannerFront = TRUE;

	if( IdentStr[2] & 0x02 )						// 00000010
		PeriphFeatures.ScannerBack = TRUE;

	if( IdentStr[2] & 0x04 )
		if( IdentStr[2] & 0x08 )
			PeriphFeatures.BadgeReader = BADGE_TRACKS_1_2;
		else
			PeriphFeatures.BadgeReader = BADGE_TRACKS_2_3;

} // SaveConfiguration


// *******************************************************************
// *    DisplayIdentify()
// *
// *******************************************************************
int DisplayIdentify(HWND hWnd, char *IdentStr, LPSTR VendorMod,
					LPSTR ProductVer, LPSTR Lema, LPSTR InkJet)
{
	char MsgText[1024];
	int  fFound = FALSE;


	memset(MsgText, 0, sizeof(MsgText));
	sprintf(MsgText, "Firmware Version : %s\nRelease Date : %s\n\n", ProductVer, Lema);


	if( (InkJet[0] != ' ') && (InkJet[0] != '\0') )
	{
		strcat(MsgText, "Expansion Board Printer Firmware Version : ");
		strncat(MsgText, InkJet, 7);
		strcat(MsgText, "\n\n");
	}

	if( PeriphFeatures.Micr )						// 00000001
	{
		strcat(MsgText, "MICR reader present\n");
		fFound = TRUE;
	}

	if( PeriphFeatures.InkjetPrinter )				// 00001000
	{
		strcat(MsgText, "Ink-jet printer\n");
		fFound = TRUE;
	}

	if( PeriphFeatures.VoidingStamp )				// 00100000
	{
		strcat(MsgText, "Voiding front stamp\n");
		fFound = TRUE;
	}

	if( PeriphFeatures.ScannerFront )				// 00000001
	{
		strcat(MsgText, "Scanner FRONT present\n");
		fFound = TRUE;
	}

	if( PeriphFeatures.ScannerBack )				// 00000010
	{
		strcat(MsgText, "Scanner BACK present\n");
		fFound = TRUE;
	}

	if( PeriphFeatures.BadgeReader )
	{
		if( PeriphFeatures.BadgeReader == BADGE_TRACKS_1_2 )
			strcat(MsgText, "Badge reader tracks 1/2 present\n");
		else
			strcat(MsgText, "Badge reader tracks 2/3 present\n");
		fFound = TRUE;
	}

	if( fFound == FALSE )
		strcat(MsgText, "None\n"); 

	MessageBox(hWnd, MsgText, "Peripheral identify", MB_OK | MB_ICONINFORMATION);

	return 0;
} // DisplayIdentify
