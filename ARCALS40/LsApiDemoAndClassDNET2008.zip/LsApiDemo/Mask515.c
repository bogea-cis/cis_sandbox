//**************************************************************************
//  MODULE:   Mask.C
//
//  PURPOSE:  LS500 Application to Windows 
//
//  FUNCTIONS: 
// 
//	AUTHOR :  
//**************************************************************************

// --------------------------------------------------------------
//                  INCLUDES
// --------------------------------------------------------------
#include <windows.h>            // required for all Windows applications
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <ctype.h>
#include <dlgs.h>
#include <stdio.h>
#include <process.h>




#include "lsApi.h"

#include "Main.h"
#include "resource.h"



// --------------------------------------------------------------
//                  DEFINES
// --------------------------------------------------------------

// Defines calibrazione MICR
#define NR_VALORI_LETTI				512
#define OFFSET_INZIO_CALCOLO		250
#define NR_VALORI_PER_MEDIA			200
#define OFFSET_PRIMO_PICCO			60
#define UNITA_VOLT					0.0190925

#define SORTER_1_TEXT				"Sorter 1"
#define SORTER_2_TEXT				"Sorter 2"
#define SORTER_RETAINED_TEXT		"Retained Doc."
#define SORTER_AUTOMATIC_TEXT		"Auto Sorter"
#define SORTER_SWITCH				"Sorter Switch"

#define TYPE_CRITERIA				10
#define MAX_SORTER					3

#define DUMP_DEFAULT_FILE			"DumpMemory.txt"

#define TEXT_MM						"MM"
#define TEXT_INC					"INC"



// --------------------------------------------------------------
//                  EXTERNAL FUNCTION
// --------------------------------------------------------------
extern BOOL GetFileName(HWND hwnd, LPSTR pszTitle, LPSTR pszFilter, LPSTR pszFile);
extern void ShowMICRSignal(HINSTANCE hInst, HWND hwnd, unsigned char *pd, short llDati, float Percentile);


// --------------------------------------------------------------
//                  EXTERNAL VARIABLES
// --------------------------------------------------------------
extern HINSTANCE hInst;

extern PARAUTODOCHANDLE stParDocHandle;

extern char CodelineRead[CODE_LINE_LENGTH];

extern short hLS;

extern char	IdentStr[12];
extern char	Model[64];
extern char	Version[64];
extern char	Lema[20];
extern char	InkJet[20];
extern short TypeLS;

extern HINSTANCE hOCRLibrary;
extern HINSTANCE hBarcodeLibrary;
extern HINSTANCE hPDFLibrary;

extern char CodelineRead[CODE_LINE_LENGTH];

extern char PathAppl[_MAX_PATH];


// --------------------------------------------------------------
//                  INTERNAL FUNCTION
// --------------------------------------------------------------
BOOL CALLBACK SelectSorterDlgProc500(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

//void SetButtonOcr(HWND hDlg);

void EnableChoices(HWND hDlg, BOOL fDo);
void EnableChoice1(HWND hDlg, BOOL fDo);
void EnableChoice2(HWND hDlg, BOOL fDo);
void EnableChoice3(HWND hDlg, BOOL fDo);
void EnableChoice4(HWND hDlg, BOOL fDo);
void EnableChoice5(HWND hDlg, BOOL fDo);
void EnableOpticMainBarcode500(HWND hwnd, BOOL Flag);

void EnableOpticMainOcr500(HWND hwnd, BOOL Flag);

void SorterReadSelection500(HWND hDlg);
void SetObjOpticParameterMainBarcode500(HWND hDlg);
void SetObjOpticParameterMainOcr500(HWND hDlg);

BOOL CALLBACK DlgProcDecoSwParBarcode500(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);



// --------------------------------------------------------------
//                  INTERNAL VARIABLES
// --------------------------------------------------------------
HWND hWndSlider1;

UCHAR TableCriteria[TYPE_CRITERIA][48] = {"No Selection", "Error in Codeline", "Codeline = Str1", "Codeline != Str1", "Codeline > Str1", "Codeline < Str1", "Codeline between Str1 AND Str2", "Codeline Out of range Str1 AND Str2", "Codeline = Str1 OR Str2", "Codeline != Str1 AND Str2"};
UCHAR TableSorter[MAX_SORTER][48] = {"Retained", "Sorter 1", "Sorter 2"};
char SorterTable[] = {HOLD_DOCUMENT, SORTER_BAY1, SORTER_BAY2};

WORD iTic;




//***************************************************************************
// FUNCTION  : DocumentHandleDlgProc500
//
// PURPOSE   : 
//
// PARAMETER : 
//***************************************************************************
BOOL CALLBACK DocumentHandleDlgProc500 (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND hHScroll;
	int Quality;


	switch (message)
	{
		case WM_INITDIALOG:

			// Timeout
			if(stParDocHandle.WaitTimeout == WAIT_YES)
				CheckDlgButton(hDlg, IDC_WAIT_TIMEOUT, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_WAIT_TIMEOUT, BST_UNCHECKED); 

			// Beep
			if(stParDocHandle.BeepOnError == BEEP)
				CheckDlgButton(hDlg, IDC_BEEP, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_BEEP, BST_UNCHECKED); 

			// Front Stamp
			if( stParDocHandle.Stamp == FRONT_STAMP ||
				stParDocHandle.Stamp == FRONT_AND_BACK_STAMP )
				CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_UNCHECKED); 

			// Back Stamp
			if( stParDocHandle.Stamp == BACK_STAMP ||
				stParDocHandle.Stamp == FRONT_AND_BACK_STAMP )
				CheckDlgButton(hDlg, IDC_BACKSTAMP, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_BACKSTAMP, BST_UNCHECKED); 

			// Stamp Position
			SetDlgItemInt(hDlg, IDC_POSITION_STAMP, stParDocHandle.StampPosition, TRUE);

			// Validate
			if( stParDocHandle.Validate == PRINT_VALIDATE )
				CheckDlgButton(hDlg, IDC_PRINT_ENDORSE, BST_CHECKED);
			if( stParDocHandle.PrintBold )
				CheckDlgButton(hDlg, IDC_BOLD, BST_CHECKED);
			SetDlgItemText(hDlg, IDC_VALIDATE, stParDocHandle.szValidateText);

			// CodeLineType
			if( TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
				TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
			{
				// if LS510 take out cmc7 and e13b and insert micr
				SetDlgItemText(hDlg, IDC_CODELINECMC7, "MICR");

				// disable E13B and enable buttons 2
				ShowWindow(GetDlgItem(hDlg, IDC_CODELINEE13B), SW_HIDE);
				ShowWindow(GetDlgItem(hDlg, IDC_CODELINEOCR2), SW_HIDE);
				ShowWindow(GetDlgItem(hDlg, IDC_CODELINEOCR), SW_SHOW);
			}

			if( hOCRLibrary != NULL )	//enable OCR Sw.
			{
				EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR2), TRUE);
			}

			// enable codeline types
			if( stParDocHandle.TypeOfDecod & DECODE_MICR )
			{
				if( stParDocHandle.CodelineType == READ_CODELINE_MICR )
					CheckDlgButton(hDlg, IDC_CODELINECMC7, BST_CHECKED);
//				else
//					CheckDlgButton(hDlg, IDC_CODELINEE13B, BST_CHECKED);
			}

			if( stParDocHandle.TypeOfDecod & DECODE_OCR )
			{
				if( hOCRLibrary != NULL )	//enable OCR Sw.
				{
					CheckDlgButton(hDlg, IDC_CODELINEOCR, BST_CHECKED);
					CheckDlgButton(hDlg, IDC_CODELINEOCR2, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), TRUE);
				}
			}

			if( stParDocHandle.TypeOfDecod & DECODE_BARCODE )
			{
					CheckDlgButton(hDlg, IDC_BARCODESW, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), TRUE);
			}

			if( stParDocHandle.TypeOfDecod & DECODE_PDF417 )
			{
				if( hPDFLibrary != NULL )	//enable PDF decoding
				{
					CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_CHECKED);
				}
			}


			// Save on file
			if( stParDocHandle.SaveImage == IMAGE_SAVE_BOTH )
			{
				// Save Image on file
				switch (stParDocHandle.SaveFormat)
				{
				case SAVE_JPEG:
					CheckDlgButton(hDlg, IDC_SAVE_JPG, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), TRUE);
					break;
				case FILE_TIF:
					CheckDlgButton(hDlg, IDC_SAVE_TIFF, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				case FILE_CCITT:
					CheckDlgButton(hDlg, IDC_SAVE_CCITT, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				case FILE_CCITT_GROUP3_1DIM:
					CheckDlgButton(hDlg, IDC_SAVE_CCITTGR3D1, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				case FILE_CCITT_GROUP3_2DIM:
					CheckDlgButton(hDlg, IDC_SAVE_CCITTGR3D2, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				case FILE_CCITT_GROUP4:
					CheckDlgButton(hDlg, IDC_SAVE_CCITTGR4, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				case SAVE_BMP:
					CheckDlgButton(hDlg, IDC_SAVE_BMP, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				default:
					CheckDlgButton(hDlg, IDC_SAVE_NONE, BST_CHECKED);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;
				}
			}
			else
			{
				// No save file
				CheckDlgButton(hDlg, IDC_SAVE_NONE, BST_CHECKED); 
				EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
			}

			// ScanMode
			if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
				TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
			{
				EnableWindow(GetDlgItem(hDlg, IDC_SCANMODE256GR100), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_SCANMODE256GR200), TRUE);
			}
			switch (stParDocHandle.ScanMode)
			{
			case SCAN_MODE_16GR100:
				
				CheckRadioButton(hDlg, IDC_SCANMODE16GR100, IDC_SCANMODE256GR200, IDC_SCANMODE16GR100);
				break;

			case SCAN_MODE_16GR200:
				
				CheckRadioButton(hDlg, IDC_SCANMODE16GR100, IDC_SCANMODE256GR200, IDC_SCANMODE16GR200);

				EnableWindow(GetDlgItem(hDlg, IDC_BARCODESW), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), TRUE);

				break;

			case SCAN_MODE_256GR100:

				if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
					TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
					CheckRadioButton(hDlg, IDC_SCANMODE16GR100, IDC_SCANMODE256GR200, IDC_SCANMODE256GR100);
				else
					CheckRadioButton(hDlg, IDC_SCANMODE16GR100, IDC_SCANMODE256GR200, IDC_SCANMODE16GR100);
				break;

			case SCAN_MODE_256GR200:
				
				if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
					TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
					CheckRadioButton(hDlg, IDC_SCANMODE16GR100, IDC_SCANMODE256GR200, IDC_SCANMODE256GR200);
				else
					CheckRadioButton(hDlg, IDC_SCANMODE16GR100, IDC_SCANMODE256GR200, IDC_SCANMODE16GR200);

				EnableWindow(GetDlgItem(hDlg, IDC_BARCODESW), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), TRUE);

				break;
			}

			// NumDoc
			if(stParDocHandle.NumDoc == 0)
			{
				CheckRadioButton(hDlg, IDC_ALLNUMDOC, IDC_FIXEDNUMDOC, IDC_ALLNUMDOC);
				EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), FALSE);
			}
			else
			{
				CheckRadioButton(hDlg, IDC_ALLNUMDOC, IDC_FIXEDNUMDOC, IDC_FIXEDNUMDOC);
				SetDlgItemInt (hDlg, IDC_NUMDOC, stParDocHandle.NumDoc, TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), TRUE);
			}

			// Linear Entrance
			if(stParDocHandle.LinearEntry == TRUE)
			{
				// disable codeline
				CheckDlgButton(hDlg, IDC_CODELINECMC7,	BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_CODELINECMC7), FALSE);
				CheckDlgButton(hDlg, IDC_CODELINEE13B,	BST_UNCHECKED);
				EnableWindow(GetDlgItem(hDlg, IDC_CODELINEE13B), FALSE);

				CheckDlgButton(hDlg, IDC_LINEAR_ENTRANCE, BST_CHECKED); 
			}
			else
				CheckDlgButton(hDlg, IDC_LINEAR_ENTRANCE, BST_UNCHECKED); 

			// ClearBlack
			if(stParDocHandle.ClearBlack == CLEAR_ALL_BLACK)
				CheckDlgButton(hDlg, IDC_CLEARIMAGE, BST_CHECKED); 
			else
				CheckDlgButton(hDlg, IDC_CLEARIMAGE, BST_UNCHECKED); 

			CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODEBRUTTO); // 24.10.98

			// ReadMode Brutto and/or Netto
			if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510D || TypeLS == TYPE_LS515D )
			{
				EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), TRUE);
			}
			switch( stParDocHandle.ReadMode )
			{
				case READMODE_ALL:
					if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510D || TypeLS == TYPE_LS515D )
						CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODEALL);
					else
						CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODEBRUTTO);
					break;

				case READMODE_BRUTTO:
					CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODEBRUTTO);
					break;

				case READMODE_NETTO:
					if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510D || TypeLS == TYPE_LS515D )
						CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODENETTO);
					else
						CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODEBRUTTO);
					break;
			}

			// Side
			switch( stParDocHandle.Side )
			{
				case SIDE_FRONT_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEFRONT);
				break;

				case SIDE_BACK_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEBACK);
					if( TypeLS == TYPE_LS510D || TypeLS == TYPE_LS515D )
					{
						EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), FALSE);
						EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), FALSE);
						CheckRadioButton(hDlg, IDC_READMODEALL, IDC_READMODENETTO, IDC_READMODEBRUTTO);
					}
				break;

				case SIDE_ALL_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEALL);
				break;

				case SIDE_NONE_IMAGE:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDENONE);
					EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_READMODEBRUTTO), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), FALSE);
				break;
			}

			// Save Codeline on file
			if( stParDocHandle.SaveCodeline )
			{
				CheckDlgButton(hDlg, IDC_SAVE_CODELINE, BST_CHECKED);

				EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), TRUE);

				if( stParDocHandle.ResetFileCodeline )
					CheckDlgButton(hDlg, IDC_RESET_FILE, BST_CHECKED);
			}

			// Quality
			SetDlgItemInt (hDlg, IDC_QUALITY, stParDocHandle.Qual, TRUE);

			// Sorter
			if( stParDocHandle.Sorter == SORTER_BAY1 )
				SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_1_TEXT);
			else if( stParDocHandle.Sorter == SORTER_BAY2 )
				SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_2_TEXT);
			else if( stParDocHandle.Sorter == HOLD_DOCUMENT )
				SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_RETAINED_TEXT);
			else if( stParDocHandle.Sorter == SORTER_AUTOMATIC )
				SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_AUTOMATIC_TEXT);
			else if( stParDocHandle.Sorter == SORTER_SWITCH_1_TO_2 )
				SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_SWITCH);

			// Only Last Image
			if( stParDocHandle.ViewOnlyLastImage )
				CheckDlgButton(hDlg, IDC_LAST_IMAGE, BST_CHECKED);

			// Double Leafing Sensibility and Block
			if( TypeLS == TYPE_LS510S || TypeLS == TYPE_LS510D ||
				TypeLS == TYPE_LS515S || TypeLS == TYPE_LS515D )
			{
				switch( stParDocHandle.DoubleLeafingLevel )
				{
				case DOUBLE_LEAFING_LEVEL1:
					iTic = 0;
					break;
				case DOUBLE_LEAFING_LEVEL2:
					iTic = 20;
					break;
				case DOUBLE_LEAFING_LEVEL3:
					iTic = 40;
					break;
				case DOUBLE_LEAFING_DEFAULT:
					iTic = 60;
					break;
				case DOUBLE_LEAFING_LEVEL4:
					iTic = 80;
					break;
				case DOUBLE_LEAFING_LEVEL5:
					iTic = 100;
					break;
				}
				hHScroll = GetDlgItem(hDlg, IDC_SCROLLBAR1);
				SetScrollRange(hHScroll, SB_CTL, HSCROLLMIN, HSCROLLMAX, TRUE);
				SetScrollPos(hHScroll, SB_CTL, iTic, TRUE);

				if( stParDocHandle.DoubleLeafingBlock )
					CheckDlgButton(hDlg, IDC_DOUBLELEAFINGBLOCK, BST_CHECKED);
				else
					CheckDlgButton(hDlg, IDC_DOUBLELEAFINGBLOCK, BST_UNCHECKED);
			}
			else
			{
				EnableWindow(GetDlgItem(hDlg, IDC_STATIC_DL1), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_STATIC_DL2), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_STATIC_DL3), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_DOUBLELEAFINGBLOCK), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_SCROLLBAR1), FALSE);
			}

			// Check Codeline
			if( stParDocHandle.DoCheckCodeline )
				CheckDlgButton(hDlg, IDC_DO_CHECK, BST_CHECKED);
			if( stParDocHandle.CodelineBase[0] )
				SetDlgItemText(hDlg, IDC_CHECK_CODELINE, stParDocHandle.CodelineBase);

			return TRUE;


		case WM_HSCROLL:
		{
			short nScrollInc;
			short nPos;
			WORD  hScrollPos;
			short Diff;

			nPos = (short int) HIWORD(wParam);   // scroll box position 
			hScrollPos = iTic;				
			nScrollInc = 0;

			switch( LOWORD(wParam) )		// Scroll bar Value
			{
			case SB_LEFT:
				nScrollInc = -hScrollPos;
				break;
			case SB_RIGHT:
				nScrollInc = HSCROLLMAX - hScrollPos;
				break;
			case SB_LINELEFT:
				if( hScrollPos > HSCROLLMIN )
					if( (iTic - SCROLLSTEP) < HSCROLLMIN )
						nScrollInc = HSCROLLMIN - iTic;
					else
						nScrollInc = -SCROLLSTEP;
				break;
			case SB_LINERIGHT:
				if( hScrollPos < HSCROLLMAX )
					if( (iTic + SCROLLSTEP) > HSCROLLMAX )
						nScrollInc = HSCROLLMAX - iTic;
					else
						nScrollInc = SCROLLSTEP;
				break;
			case SB_PAGELEFT:
				nScrollInc = HSCROLLMIN - hScrollPos;
				break;
			case SB_PAGERIGHT:
				nScrollInc = HSCROLLMAX - hScrollPos;
				break;
			case SB_THUMBTRACK:
				break;
			case SB_THUMBPOSITION:
				nScrollInc = nPos - hScrollPos;
				Diff = nScrollInc % SCROLLSTEP;
				if( Diff )
				{
					nPos -= Diff;
					nScrollInc = nPos - hScrollPos;
				}
				break;
			default:
				nScrollInc = 0;
				break;
			}

			if(nScrollInc)
			{
				iTic = hScrollPos + nScrollInc;
				hHScroll = GetDlgItem(hDlg, IDC_SCROLLBAR1);
				SetScrollPos(hHScroll, SB_CTL, iTic, TRUE);
			}
		}
		return TRUE;


		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
				case IDC_SET_OCR:
					DialogBox(hInst, MAKEINTRESOURCE (IDD_DECO_PAR_SW), hDlg, DlgProcDecoSwParOCR);
					SendMessage(hDlg, WM_COMMAND, IDC_VIEW_OCR, 0);
					return TRUE;

				case IDC_VIEW_OCR:
					// pressed the button for OCR data
					EnableOpticMainOcr500(hDlg, TRUE);
					SetObjOpticParameterMainOcr500(hDlg);
					return TRUE;

				case IDC_SET_BARCODE:
					DialogBox(hInst, MAKEINTRESOURCE (IDD_DECO_PAR_SW), hDlg, DlgProcDecoSwParBarcode500);
					SendMessage(hDlg, WM_COMMAND, IDC_VIEW_BARCODE, 0);
					return TRUE;
				
				case IDC_VIEW_BARCODE:
					// pressed the button for barcode data
					EnableOpticMainBarcode500(hDlg,TRUE);
					SetObjOpticParameterMainBarcode500(hDlg);				
					return TRUE;

				case IDC_CODELINECMC7:
					if(IsDlgButtonChecked(hDlg, IDC_CODELINECMC7) == BST_CHECKED)
						CheckDlgButton(hDlg, IDC_CODELINECMC7, BST_UNCHECKED);
					else
						CheckDlgButton(hDlg, IDC_CODELINECMC7, BST_CHECKED);
					return TRUE;

				case IDC_CODELINEE13B:
					if(IsDlgButtonChecked(hDlg, IDC_CODELINEE13B) == BST_CHECKED)
						CheckDlgButton(hDlg, IDC_CODELINEE13B, BST_UNCHECKED);
					else
						CheckDlgButton(hDlg, IDC_CODELINEE13B, BST_CHECKED);
					return TRUE;

				case IDC_BARCODEHW:
					if(IsDlgButtonChecked(hDlg, IDC_BARCODEHW) == BST_CHECKED)
						CheckDlgButton(hDlg, IDC_BARCODEHW, BST_UNCHECKED);
					else
						CheckDlgButton(hDlg, IDC_BARCODEHW, BST_CHECKED);
					return TRUE;

				case IDC_BARCODESW:
					if(IsDlgButtonChecked(hDlg, IDC_BARCODESW) == BST_CHECKED)
					{
						CheckDlgButton(hDlg, IDC_BARCODESW, BST_UNCHECKED); 
						EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), FALSE);
						EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), FALSE);
						EnableOpticMainBarcode500(hDlg,FALSE);
					}
					else
					{
						CheckDlgButton(hDlg, IDC_BARCODESW,BST_CHECKED);
						EnableWindow(GetDlgItem(hDlg, IDC_SET_BARCODE), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_VIEW_BARCODE), TRUE);

						EnableOpticMainBarcode500(hDlg,TRUE);
					}
					if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
					{
						CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED); 
						CheckDlgButton(hDlg, IDC_SIDENONE, BST_UNCHECKED); 
					}
				break;

				case IDC_BARCODE_PDF417:
					if(IsDlgButtonChecked(hDlg, IDC_BARCODE_PDF417) == BST_CHECKED)
					{
						CheckDlgButton(hDlg, IDC_BARCODE_PDF417, BST_UNCHECKED); 
					}
					else
					{
						CheckDlgButton(hDlg, IDC_BARCODE_PDF417,	BST_CHECKED);
					}

					if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
					{
						CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED); 
						CheckDlgButton(hDlg, IDC_SIDENONE, BST_UNCHECKED); 
					}
					break;

				case IDC_CODELINEOCR:
					if(IsDlgButtonChecked(hDlg, IDC_CODELINEOCR) == BST_CHECKED)
					{
						CheckDlgButton(hDlg, IDC_CODELINEOCR, BST_UNCHECKED); 
						EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), FALSE);
						EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), FALSE);
						EnableOpticMainOcr500(hDlg,FALSE);
					}
					else
					{
						CheckDlgButton(hDlg, IDC_CODELINEOCR, BST_CHECKED); 
						EnableOpticMainOcr500(hDlg,TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_SET_OCR), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_VIEW_OCR), TRUE);
						SetObjOpticParameterMainOcr500(hDlg);
					}
					if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
					{
						CheckDlgButton(hDlg, IDC_SIDEFRONT, BST_CHECKED); 
						CheckDlgButton(hDlg, IDC_SIDENONE, BST_UNCHECKED); 
					}
					break;
				
				case IDC_SAVE_NONE:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_SAVE_BMP:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_SAVE_JPG:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), TRUE);
					break;

				case IDC_SAVE_TIFF:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_SAVE_CCITT:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_SAVE_CCITTGR3D1:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_SAVE_CCITTGR3D2:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_SAVE_CCITTGR4:
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_QUALITY_TEXT), FALSE);
					break;

				case IDC_QUALITY:
					Quality = GetDlgItemInt(hDlg, IDC_QUALITY, NULL, FALSE);
					if ((Quality > 255) || (Quality < 2))
					{
						MessageBeep(MB_ICONEXCLAMATION);
						if (Quality > 126)
						{
							Quality = 255;
							SetDlgItemText(hDlg, IDC_QUALITY, "255");
						}
						else
						{
							Quality = 2;
							SetDlgItemText(hDlg, IDC_QUALITY, "2");
						}
					}
					break;

				case IDC_SCANMODE16GR100:
				case IDC_SCANMODE16GR200:
				case IDC_SCANMODE256GR100:
				case IDC_SCANMODE256GR200:
					

					switch( HIWORD(wParam) )
					{
						case BN_CLICKED:
							if(IsDlgButtonChecked(hDlg, IDC_LINEAR_ENTRANCE) == BST_UNCHECKED)
							{
								if( hOCRLibrary )
								{
									EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR), TRUE);
									EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR2), TRUE);
								}
							}
							break;
					}
	
					if(IsDlgButtonChecked(hDlg, IDC_SCANMODE16GR200) == BST_CHECKED)
					{
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODESW), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), TRUE);
					}
					if(IsDlgButtonChecked(hDlg, IDC_SCANMODE256GR200) == BST_CHECKED)
					{
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODESW), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), TRUE);
					}
					if(IsDlgButtonChecked(hDlg, IDC_SCANMODE16GR100) == BST_CHECKED)
					{
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODESW), FALSE);
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
					}
					if(IsDlgButtonChecked(hDlg, IDC_SCANMODE256GR100) == BST_CHECKED)
					{
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODESW), FALSE);
						EnableWindow(GetDlgItem(hDlg, IDC_BARCODE_PDF417), FALSE);
					}

					return TRUE;

				case IDC_SIDEBACK:
					switch( HIWORD(wParam) )
					{
						case BN_CLICKED:
							EnableWindow(GetDlgItem(hDlg, IDC_READMODEBRUTTO), TRUE);
							if( TypeLS == TYPE_LS510D || TypeLS == TYPE_LS515D )
							{
								EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), TRUE);
								EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), TRUE);
							}
							else
							{
								EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), FALSE);
								EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), FALSE);
							}
							break;
					}
					return (TRUE);

				case IDC_SIDEALL:
				case IDC_SIDEFRONT:
					switch( HIWORD(wParam) )
					{
						case BN_CLICKED:
							EnableWindow(GetDlgItem(hDlg, IDC_READMODEBRUTTO), TRUE);
							if( TypeLS == TYPE_LS505 || TypeLS == TYPE_LS510D || TypeLS == TYPE_LS515D )
							{
								EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), TRUE);
								EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), TRUE);
							}
							break;
					}
					return (TRUE);

				case IDC_SIDENONE:
					switch( HIWORD(wParam) )
					{
						case BN_CLICKED:
							EnableWindow(GetDlgItem(hDlg, IDC_READMODEBRUTTO), FALSE);
							EnableWindow(GetDlgItem(hDlg, IDC_READMODENETTO), FALSE);
							EnableWindow(GetDlgItem(hDlg, IDC_READMODEALL), FALSE);
							break;
					}
					return (TRUE);

				case IDC_ALLNUMDOC:
					EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), FALSE);
					break;

				case IDC_FIXEDNUMDOC:
					EnableWindow(GetDlgItem(hDlg, IDC_NUMDOC), TRUE);
					if (stParDocHandle.NumDoc == 0)
						SetDlgItemInt (hDlg, IDC_NUMDOC, 1, TRUE);
					else
						SetDlgItemInt (hDlg, IDC_NUMDOC, stParDocHandle.NumDoc, TRUE);
					break;

				case IDC_NUMDOC:
					if (GetDlgItemInt(hDlg, IDC_NUMDOC, NULL, FALSE) == 0)
						SetDlgItemInt (hDlg, IDC_NUMDOC, 1, TRUE);
					break;

				case IDC_LINEAR_ENTRANCE:
					if(IsDlgButtonChecked(hDlg, IDC_LINEAR_ENTRANCE) == BST_CHECKED)
					{
						// disable the codeline
						CheckDlgButton(hDlg, IDC_CODELINECMC7,	BST_UNCHECKED);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINECMC7), FALSE);
						CheckDlgButton(hDlg, IDC_CODELINEE13B,	BST_UNCHECKED);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINEE13B), FALSE);
						CheckDlgButton(hDlg, IDC_CODELINEOCR,	BST_UNCHECKED);
						CheckDlgButton(hDlg, IDC_CODELINEOCR2,	BST_UNCHECKED);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR), FALSE);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR2), FALSE);

					}
					else
					{
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINECMC7), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINEE13B), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_CODELINEOCR2), TRUE);
						EnableWindow(GetDlgItem(hDlg, IDC_ALLNUMDOC), TRUE);
					}
					break;

				case IDC_SAVE_CODELINE:
					if(IsDlgButtonChecked(hDlg, IDC_SAVE_CODELINE) == BST_CHECKED)
					{
						stParDocHandle.SaveCodeline = TRUE;

						EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), TRUE);

						if( stParDocHandle.ResetFileCodeline )
							CheckDlgButton(hDlg, IDC_RESET_FILE, BST_CHECKED);
					}
					else
					{
						stParDocHandle.SaveCodeline = FALSE;

						EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), FALSE);
					}
					break;

				case IDC_RESET_FILE:
					if(IsDlgButtonChecked(hDlg, IDC_RESET_FILE) == BST_CHECKED)
						stParDocHandle.ResetFileCodeline = TRUE;
					else
						stParDocHandle.ResetFileCodeline = FALSE;
					break;


				case IDC_SELECT_SORTER:
					// Dialog box for param selection and sortre selection
					if (DialogBox(hInst, MAKEINTRESOURCE(IDD_SELECT_SORTER), hDlg, SelectSorterDlgProc500))
					{
						if( stParDocHandle.Sorter == SORTER_BAY1 )
							SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_1_TEXT);
						else if( stParDocHandle.Sorter == SORTER_BAY2 )
							SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_2_TEXT);
						else if( stParDocHandle.Sorter == HOLD_DOCUMENT )
							SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_RETAINED_TEXT);
						else if( stParDocHandle.Sorter == SORTER_AUTOMATIC )
							SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_AUTOMATIC_TEXT);
						else if( stParDocHandle.Sorter == SORTER_SWITCH_1_TO_2 )
							SetDlgItemText(hDlg, IDC_ACTIVE_CHOICE, SORTER_SWITCH);
					}
					return TRUE;

				case IDC_AGG_CODELINE:
					SetDlgItemText(hDlg, IDC_CHECK_CODELINE, CodelineRead);
					return TRUE;


				case IDC_DO_CHECK:
					CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDENONE);
					SendMessage(hDlg, WM_COMMAND, IDC_SIDENONE, 0);
					return TRUE;



				case IDOK:
					// Timeout
					if(IsDlgButtonChecked(hDlg, IDC_WAIT_TIMEOUT) == BST_CHECKED)
						stParDocHandle.WaitTimeout = WAIT_YES;
					else
						stParDocHandle.WaitTimeout = WAIT_NO;

					// Beep
					if(IsDlgButtonChecked(hDlg, IDC_BEEP) == BST_CHECKED)
						stParDocHandle.BeepOnError = BEEP;
					else
						stParDocHandle.BeepOnError = NO_BEEP;

					// Linear Entrance
					if(IsDlgButtonChecked(hDlg, IDC_LINEAR_ENTRANCE) == BST_CHECKED)
						stParDocHandle.LinearEntry = TRUE;
					else
						stParDocHandle.LinearEntry = FALSE;

					// Front Stamp
					if( IsDlgButtonChecked(hDlg, IDC_FRONTSTAMP) == BST_CHECKED )
					{
						// Back Stamp
						if(IsDlgButtonChecked(hDlg, IDC_BACKSTAMP) == BST_CHECKED)
							stParDocHandle.Stamp = FRONT_AND_BACK_STAMP;
						else
							stParDocHandle.Stamp = FRONT_STAMP;
					}
					else
					{
						// Back Stamp
						if(IsDlgButtonChecked(hDlg, IDC_BACKSTAMP) == BST_CHECKED)
							stParDocHandle.Stamp = BACK_STAMP;
						else
							stParDocHandle.Stamp = NO_STAMP;
					}

					// Stamp Position
					stParDocHandle.StampPosition = GetDlgItemInt(hDlg, IDC_POSITION_STAMP, NULL, FALSE);

					// Validate
					if( IsDlgButtonChecked(hDlg, IDC_PRINT_ENDORSE) == BST_CHECKED )
						stParDocHandle.Validate = PRINT_VALIDATE;
					else
						stParDocHandle.Validate = NO_PRINT_VALIDATE;
					if( IsDlgButtonChecked(hDlg, IDC_BOLD) == BST_CHECKED )
						stParDocHandle.PrintBold = TRUE;
					else
						stParDocHandle.PrintBold = FALSE;
					GetDlgItemText(hDlg,IDC_VALIDATE, stParDocHandle.szValidateText, sizeof(stParDocHandle.szValidateText));


					// CodeLineType
					stParDocHandle.CodelineType = NO_READ_CODELINE;
					stParDocHandle.TypeOfDecod = DECODE_NONE;

					if(IsDlgButtonChecked(hDlg, IDC_CODELINECMC7) == BST_CHECKED)
					{
						stParDocHandle.CodelineType = READ_CODELINE_MICR;
						stParDocHandle.TypeOfDecod |= DECODE_MICR;
					}

					if( IsDlgButtonChecked(hDlg, IDC_BARCODEHW) == BST_CHECKED )
					{
						stParDocHandle.CodelineType = READ_BARCODE_HW;
						stParDocHandle.TypeOfDecod |= DECODE_BARCODE_HW;
					}

					if(IsDlgButtonChecked(hDlg, IDC_CODELINEOCR) == BST_CHECKED)
					{
						stParDocHandle.TypeOfDecod |= DECODE_OCR;
					}

					if(IsDlgButtonChecked(hDlg, IDC_BARCODESW) == BST_CHECKED)
					{
						stParDocHandle.TypeOfDecod |= DECODE_BARCODE;
					}

					if(IsDlgButtonChecked(hDlg, IDC_BARCODE_PDF417) == BST_CHECKED)
					{
						stParDocHandle.TypeOfDecod |= DECODE_PDF417;
					}

					// ScanMode
					if(IsDlgButtonChecked(hDlg, IDC_SCANMODE16GR100) == BST_CHECKED)
						stParDocHandle.ScanMode = SCAN_MODE_16GR100;
					else if(IsDlgButtonChecked(hDlg, IDC_SCANMODE16GR200) == BST_CHECKED)
						stParDocHandle.ScanMode = SCAN_MODE_16GR200;
					else if(IsDlgButtonChecked(hDlg, IDC_SCANMODE256GR100) == BST_CHECKED)
						stParDocHandle.ScanMode = SCAN_MODE_256GR100;
					else if(IsDlgButtonChecked(hDlg, IDC_SCANMODE256GR200) == BST_CHECKED)
						stParDocHandle.ScanMode = SCAN_MODE_256GR200;

					// NumDoc
					if(IsDlgButtonChecked(hDlg, IDC_ALLNUMDOC) == BST_CHECKED)
						stParDocHandle.NumDoc = 0;
					else
						stParDocHandle.NumDoc = GetDlgItemInt(hDlg, IDC_NUMDOC, NULL, FALSE);

					// ClearBlack
					if(IsDlgButtonChecked(hDlg, IDC_CLEARIMAGE) == BST_CHECKED)
						stParDocHandle.ClearBlack = CLEAR_ALL_BLACK;
					else
						stParDocHandle.ClearBlack = NO_CLEAR_BLACK;

					// Side
					if(IsDlgButtonChecked(hDlg, IDC_SIDEFRONT) == BST_CHECKED)
						stParDocHandle.Side = SIDE_FRONT_IMAGE;
					else if(IsDlgButtonChecked(hDlg, IDC_SIDEBACK) == BST_CHECKED)
						stParDocHandle.Side = SIDE_BACK_IMAGE;
					else if(IsDlgButtonChecked(hDlg, IDC_SIDEALL) == BST_CHECKED)
						stParDocHandle.Side = SIDE_ALL_IMAGE;
					else if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
						stParDocHandle.Side = SIDE_NONE_IMAGE;

					// ReadMode to 256 Gray
					if(IsDlgButtonChecked(hDlg, IDC_READMODEBRUTTO) == BST_CHECKED)
						stParDocHandle.ReadMode = READMODE_BRUTTO;
					else if(IsDlgButtonChecked(hDlg, IDC_READMODENETTO) == BST_CHECKED)
						stParDocHandle.ReadMode = READMODE_NETTO;
					else if(IsDlgButtonChecked(hDlg, IDC_READMODEALL) == BST_CHECKED)
						stParDocHandle.ReadMode = READMODE_ALL;

					// Save Codeline on file
					if( stParDocHandle.SaveCodeline )
					{
						CheckDlgButton(hDlg, IDC_SAVE_CODELINE, BST_CHECKED);

						EnableWindow(GetDlgItem(hDlg, IDC_RESET_FILE), TRUE);

						if( stParDocHandle.ResetFileCodeline )
							CheckDlgButton(hDlg, IDC_RESET_FILE, BST_CHECKED);
					}

					// Double Leafing Sensibility and Block
					switch( iTic )
					{
					case 0:
						stParDocHandle.DoubleLeafingLevel = DOUBLE_LEAFING_LEVEL1;
						break;
					case 20:
						stParDocHandle.DoubleLeafingLevel = DOUBLE_LEAFING_LEVEL2;
						break;
					case 40:
						stParDocHandle.DoubleLeafingLevel = DOUBLE_LEAFING_LEVEL3;
						break;
					case 60:
					default:
						stParDocHandle.DoubleLeafingLevel = DOUBLE_LEAFING_DEFAULT;
						break;
					case 80:
						stParDocHandle.DoubleLeafingLevel = DOUBLE_LEAFING_LEVEL4;
						break;
					case 100:
						stParDocHandle.DoubleLeafingLevel = DOUBLE_LEAFING_LEVEL5;
						break;
					}

					// Double Leafing
					if(IsDlgButtonChecked(hDlg, IDC_DOUBLELEAFINGBLOCK) == BST_CHECKED)
						stParDocHandle.DoubleLeafingBlock = TRUE;
					else
						stParDocHandle.DoubleLeafingBlock = FALSE;

					// save on FILE
					// handle always saved, it is used to show the image
					if(stParDocHandle.Side != SIDE_NONE_IMAGE &&
					  ((IsDlgButtonChecked(hDlg, IDC_SAVE_JPG) == BST_CHECKED) ||
					   (IsDlgButtonChecked(hDlg, IDC_SAVE_BMP) == BST_CHECKED) ||
					   (IsDlgButtonChecked(hDlg, IDC_SAVE_TIFF) == BST_CHECKED) ||
					   (IsDlgButtonChecked(hDlg, IDC_SAVE_CCITT) == BST_CHECKED) ||
					   (IsDlgButtonChecked(hDlg, IDC_SAVE_CCITTGR3D1) == BST_CHECKED)||
					   (IsDlgButtonChecked(hDlg, IDC_SAVE_CCITTGR3D2) == BST_CHECKED) ||
					   (IsDlgButtonChecked(hDlg, IDC_SAVE_CCITTGR4) == BST_CHECKED)) )
					{

						stParDocHandle.SaveImage = IMAGE_SAVE_BOTH;
						
						if(IsDlgButtonChecked(hDlg, IDC_SAVE_JPG) == BST_CHECKED)
							stParDocHandle.SaveFormat =  SAVE_JPEG;
						else if(IsDlgButtonChecked(hDlg, IDC_SAVE_BMP) == BST_CHECKED)
							stParDocHandle.SaveFormat =  SAVE_BMP;
						else if(IsDlgButtonChecked(hDlg, IDC_SAVE_TIFF) == BST_CHECKED)
							stParDocHandle.SaveFormat =  FILE_TIF;
						else if(IsDlgButtonChecked(hDlg, IDC_SAVE_CCITT) == BST_CHECKED)
							stParDocHandle.SaveFormat =  FILE_CCITT;
						else if(IsDlgButtonChecked(hDlg, IDC_SAVE_CCITTGR3D1) == BST_CHECKED)
							stParDocHandle.SaveFormat =  FILE_CCITT_GROUP3_1DIM;
						else if(IsDlgButtonChecked(hDlg, IDC_SAVE_CCITTGR3D2) == BST_CHECKED)
							stParDocHandle.SaveFormat =  FILE_CCITT_GROUP3_2DIM;
						else
							stParDocHandle.SaveFormat =  FILE_CCITT_GROUP4;
					}
					else
					{
						stParDocHandle.SaveImage = IMAGE_SAVE_HANDLE;
						stParDocHandle.SaveFormat =  SAVE_JPEG;
					}

					//Quality
					stParDocHandle.Qual = GetDlgItemInt(hDlg, IDC_QUALITY, NULL, FALSE);

					// Only Last Image
					if(IsDlgButtonChecked(hDlg, IDC_LAST_IMAGE) == BST_CHECKED)
						stParDocHandle.ViewOnlyLastImage = TRUE;
					else
						stParDocHandle.ViewOnlyLastImage = FALSE;

					// Check Codeline
					if( IsDlgButtonChecked(hDlg, IDC_DO_CHECK) == BST_CHECKED)
						stParDocHandle.DoCheckCodeline = TRUE;
					else
						stParDocHandle.DoCheckCodeline = FALSE;
					GetDlgItemText(hDlg, IDC_CHECK_CODELINE, stParDocHandle.CodelineBase, CODE_LINE_LENGTH);


					EndDialog (hDlg, 1);
					return TRUE;


				case IDCANCEL:
					EndDialog (hDlg, 0);
					return TRUE;
			} // WM_COMMAND
	} // End switch

	return FALSE;
}  // End DocumentHandleDlgProc500



// Dialog of ouput document holder
int CALLBACK SorterDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch( message )
	{
	case WM_INITDIALOG:

		// show last codeline read
		SetDlgItemText(hDlg, IDC_READ_CODELINE, CodelineRead);

		// Front Stamp
		if( stParDocHandle.SorterStamp == FRONT_STAMP ||
			stParDocHandle.SorterStamp == FRONT_AND_BACK_STAMP )
			CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_CHECKED); 
		else
			CheckDlgButton(hDlg, IDC_FRONTSTAMP, BST_UNCHECKED); 

		// Back Stamp
		if( stParDocHandle.SorterStamp == BACK_STAMP ||
			stParDocHandle.SorterStamp == FRONT_AND_BACK_STAMP )
			CheckDlgButton(hDlg, IDC_BACKSTAMP, BST_CHECKED); 
		else
			CheckDlgButton(hDlg, IDC_BACKSTAMP, BST_UNCHECKED); 

		// Validate
		if( stParDocHandle.SorterValidate == PRINT_VALIDATE )
			CheckDlgButton(hDlg, IDC_PRINT_ENDORSE, BST_CHECKED);
		if( stParDocHandle.SorterPrintBold )
			CheckDlgButton(hDlg, IDC_BOLD, BST_CHECKED);
		SetDlgItemText(hDlg, IDC_VALIDATE, stParDocHandle.SorterszValidateText);

		// Side
		switch (stParDocHandle.SorterSide)
		{
			case SIDE_FRONT_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEFRONT);
			break;

			case SIDE_BACK_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEBACK);
			break;

			case SIDE_ALL_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDEALL);
			break;

			case SIDE_NONE_IMAGE:
				CheckRadioButton(hDlg, IDC_SIDEALL, IDC_SIDENONE, IDC_SIDENONE);
			break;
		}

		return TRUE;

	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDOK:
			SorterReadSelection500( hDlg );
			EndDialog(hDlg, 1);
			break;

		case IDCANCEL:
			SorterReadSelection500( hDlg );
			EndDialog(hDlg, 2);
			break;
		}
		return TRUE;
	}

    return FALSE;
}	// SorterDlgProc


void SorterReadSelection500(HWND hDlg)
{
	// Front Stamp
	if( IsDlgButtonChecked(hDlg, IDC_FRONTSTAMP) == BST_CHECKED )
	{
		// Back Stamp
		if(IsDlgButtonChecked(hDlg, IDC_BACKSTAMP) == BST_CHECKED)
			stParDocHandle.SorterStamp = FRONT_AND_BACK_STAMP;
		else
			stParDocHandle.SorterStamp = FRONT_STAMP;
	}
	else
	{
		// Back Stamp
		if(IsDlgButtonChecked(hDlg, IDC_BACKSTAMP) == BST_CHECKED)
			stParDocHandle.SorterStamp = BACK_STAMP;
		else
			stParDocHandle.SorterStamp = NO_STAMP;
	}

	// Validate
	if( IsDlgButtonChecked(hDlg, IDC_PRINT_ENDORSE) == BST_CHECKED )
		stParDocHandle.SorterValidate = PRINT_VALIDATE;
	else
		stParDocHandle.SorterValidate = NO_PRINT_VALIDATE;
	if( IsDlgButtonChecked(hDlg, IDC_BOLD) == BST_CHECKED )
		stParDocHandle.SorterPrintBold = TRUE;
	else
		stParDocHandle.SorterPrintBold = FALSE;
	GetDlgItemText(hDlg,IDC_VALIDATE, stParDocHandle.SorterszValidateText, sizeof(stParDocHandle.SorterszValidateText));

	// Side
	if(IsDlgButtonChecked(hDlg, IDC_SIDEFRONT) == BST_CHECKED)
		stParDocHandle.SorterSide = SIDE_FRONT_IMAGE;
	else if(IsDlgButtonChecked(hDlg, IDC_SIDEBACK) == BST_CHECKED)
		stParDocHandle.SorterSide = SIDE_BACK_IMAGE;
	else if(IsDlgButtonChecked(hDlg, IDC_SIDEALL) == BST_CHECKED)
		stParDocHandle.SorterSide = SIDE_ALL_IMAGE;
	else if(IsDlgButtonChecked(hDlg, IDC_SIDENONE) == BST_CHECKED)
		stParDocHandle.SorterSide = SIDE_NONE_IMAGE;
}


// Dialog for sorter criteria
BOOL CALLBACK SelectSorterDlgProc500(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	register ii;
	short Lenght;
	static int OldNrChar1;
	static int OldNrChar2;
	static int OldNrChar3;
	static int OldNrChar4;
	static int OldNrChar5;


	switch( message )
	{
	case WM_INITDIALOG:
		// combo box initialization
		for( ii = 0; ii < TYPE_CRITERIA; ii ++)
		{
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_1), CB_ADDSTRING, 0L, (LPARAM)TableCriteria[ii]);
			if( ii < MAX_SORTER )
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_1), CB_ADDSTRING, 0L, (LPARAM)TableSorter[ii]);
		}
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_1), CB_SETCURSEL, (WPARAM)(int)stParDocHandle.DataSorter[0].TypeCriteria, 0L);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_1), CB_SETCURSEL, (WPARAM)(int)(stParDocHandle.DataSorter[0].Bin), 0L);

		for( ii = 0; ii < TYPE_CRITERIA; ii ++)
		{
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_2), CB_ADDSTRING, 0L, (LPARAM)TableCriteria[ii]);
			if( ii < MAX_SORTER )
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_2), CB_ADDSTRING, 0L, (LPARAM)TableSorter[ii]);
		}
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_2), CB_SETCURSEL, (WPARAM)(int)stParDocHandle.DataSorter[1].TypeCriteria, 0L);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_2), CB_SETCURSEL, (WPARAM)(int)(stParDocHandle.DataSorter[1].Bin), 0L);

		for( ii = 0; ii < TYPE_CRITERIA; ii ++)
		{
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_3), CB_ADDSTRING, 0L, (LPARAM)TableCriteria[ii]);
			if( ii < MAX_SORTER )
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_3), CB_ADDSTRING, 0L, (LPARAM)TableSorter[ii]);
		}
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_3), CB_SETCURSEL, (WPARAM)(int)stParDocHandle.DataSorter[2].TypeCriteria, 0L);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_3), CB_SETCURSEL, (WPARAM)(int)(stParDocHandle.DataSorter[2].Bin), 0L);

		for( ii = 0; ii < TYPE_CRITERIA; ii ++)
		{
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_4), CB_ADDSTRING, 0L, (LPARAM)TableCriteria[ii]);
			if( ii < MAX_SORTER )
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_4), CB_ADDSTRING, 0L, (LPARAM)TableSorter[ii]);
		}
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_4), CB_SETCURSEL, (WPARAM)(int)stParDocHandle.DataSorter[3].TypeCriteria, 0L);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_4), CB_SETCURSEL, (WPARAM)(int)(stParDocHandle.DataSorter[3].Bin), 0L);

		for( ii = 0; ii < TYPE_CRITERIA; ii ++)
		{
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_5), CB_ADDSTRING, 0L, (LPARAM)TableCriteria[ii]);
			if( ii < MAX_SORTER )
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_5), CB_ADDSTRING, 0L, (LPARAM)TableSorter[ii]);
		}
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_5), CB_SETCURSEL, (WPARAM)(int)stParDocHandle.DataSorter[4].TypeCriteria, 0L);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_5), CB_SETCURSEL, (WPARAM)(int)(stParDocHandle.DataSorter[4].Bin), 0L);

		SetDlgItemText(hDlg, IDC_STRING_11, stParDocHandle.DataSorter[0].String1);
		SetDlgItemText(hDlg, IDC_STRING_12, stParDocHandle.DataSorter[0].String2);
		SetDlgItemText(hDlg, IDC_STRING_21, stParDocHandle.DataSorter[1].String1);
		SetDlgItemText(hDlg, IDC_STRING_22, stParDocHandle.DataSorter[1].String2);
		SetDlgItemText(hDlg, IDC_STRING_31, stParDocHandle.DataSorter[2].String1);
		SetDlgItemText(hDlg, IDC_STRING_32, stParDocHandle.DataSorter[2].String2);
		SetDlgItemText(hDlg, IDC_STRING_41, stParDocHandle.DataSorter[3].String1);
		SetDlgItemText(hDlg, IDC_STRING_42, stParDocHandle.DataSorter[3].String2);
		SetDlgItemText(hDlg, IDC_STRING_51, stParDocHandle.DataSorter[4].String1);
		SetDlgItemText(hDlg, IDC_STRING_52, stParDocHandle.DataSorter[4].String2);


		// Set type of sorter
		if( stParDocHandle.Sorter == SORTER_BAY1 )
			CheckDlgButton(hDlg, IDC_SORTER1, BST_CHECKED);
		else if(stParDocHandle.Sorter == SORTER_BAY2)
			CheckDlgButton(hDlg, IDC_SORTER2, BST_CHECKED);
		else if(stParDocHandle.Sorter == HOLD_DOCUMENT)
			CheckDlgButton(hDlg, IDC_RETAINED, BST_CHECKED);
		else if(stParDocHandle.Sorter == SORTER_AUTOMATIC)
		{
			CheckDlgButton(hDlg, IDC_SORTERAUTOMATIC, BST_CHECKED);
			EnableChoices(hDlg, TRUE);

			for( ii = 0; ii < MAX_CRITERIA; ii ++)
			{
				if( stParDocHandle.DataSorter[ii].TypeCriteria != CRITERIA_NO )
				switch( ii )
				{
				case 0:
					EnableChoice1(hDlg, TRUE);
					break;
				case 1:
					EnableChoice2(hDlg, TRUE);
					break;
				case 2:
					EnableChoice3(hDlg, TRUE);
					break;
				case 3:
					EnableChoice4(hDlg, TRUE);
					break;
				case 4:
					EnableChoice5(hDlg, TRUE);
					break;
				}
			}
		}
		else if(stParDocHandle.Sorter == SORTER_SWITCH_1_TO_2)
			CheckDlgButton(hDlg, IDC_SWITCH_SORTER, BST_CHECKED);
		return TRUE;


	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDC_SORTER1:
			if(IsDlgButtonChecked(hDlg, IDC_SORTER1) == BST_CHECKED)
			{
				EnableChoices(hDlg, FALSE);
				EnableChoice1(hDlg, FALSE);
				EnableChoice2(hDlg, FALSE);
				EnableChoice3(hDlg, FALSE);
				EnableChoice4(hDlg, FALSE);
				EnableChoice5(hDlg, FALSE);
			}
			return TRUE;

		case IDC_SORTER2:
			if(IsDlgButtonChecked(hDlg, IDC_SORTER2) == BST_CHECKED)
			{
				EnableChoices(hDlg, FALSE);
				EnableChoice1(hDlg, FALSE);
				EnableChoice2(hDlg, FALSE);
				EnableChoice3(hDlg, FALSE);
				EnableChoice4(hDlg, FALSE);
				EnableChoice5(hDlg, FALSE);
			}
			return TRUE;

		case IDC_RETAINED:
			if(IsDlgButtonChecked(hDlg, IDC_RETAINED) == BST_CHECKED)
			{
				EnableChoices(hDlg, FALSE);
				EnableChoice1(hDlg, FALSE);
				EnableChoice2(hDlg, FALSE);
				EnableChoice3(hDlg, FALSE);
				EnableChoice4(hDlg, FALSE);
				EnableChoice5(hDlg, FALSE);
			}
			return TRUE;

		case IDC_SORTERAUTOMATIC:
			if(IsDlgButtonChecked(hDlg, IDC_SORTERAUTOMATIC) == BST_CHECKED)
			{
				EnableChoices(hDlg, TRUE);
				for( ii = 0; ii < MAX_CRITERIA; ii ++)
					if( stParDocHandle.DataSorter[ii].TypeCriteria != CRITERIA_NO )
						switch( ii )
						{
						case 0:
							EnableChoice1(hDlg, TRUE);
							break;
						case 1:
							EnableChoice2(hDlg, TRUE);
							break;
						case 2:
							EnableChoice3(hDlg, TRUE);
							break;
						case 3:
							EnableChoice4(hDlg, TRUE);
							break;
						case 4:
							EnableChoice5(hDlg, TRUE);
							break;
						}
			}
			return TRUE;

		case IDC_SWITCH_SORTER:
			if(IsDlgButtonChecked(hDlg, IDC_SWITCH_SORTER) == BST_CHECKED)
			{
				EnableChoices(hDlg, FALSE);
				EnableChoice1(hDlg, FALSE);
				EnableChoice2(hDlg, FALSE);
				EnableChoice3(hDlg, FALSE);
				EnableChoice4(hDlg, FALSE);
				EnableChoice5(hDlg, FALSE);
			}
			return TRUE;

		case IDC_COMBO_CHOICE_1:
		{
			int index;

			if( HIWORD(wParam) == CBS_SIMPLE )
			{
				index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_1), CB_GETCURSEL, 0L, 0L);

				EnableChoice1(hDlg, (index == CRITERIA_NO ? FALSE : TRUE));
			}
			return TRUE;
		}

		case IDC_COMBO_CHOICE_2:
		{
			int index;

			if( HIWORD(wParam) == CBS_SIMPLE )
			{
				index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_2), CB_GETCURSEL, 0L, 0L);

				EnableChoice2(hDlg, (index == CRITERIA_NO ? FALSE : TRUE));
			}
			return TRUE;
		}

		case IDC_COMBO_CHOICE_3:
		{
			int index;

			if( HIWORD(wParam) == CBS_SIMPLE )
			{
				index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_3), CB_GETCURSEL, 0L, 0L);

				EnableChoice3(hDlg, (index == CRITERIA_NO ? FALSE : TRUE));
			}
			return TRUE;
		}

		case IDC_COMBO_CHOICE_4:
		{
			int index;

			if( HIWORD(wParam) == CBS_SIMPLE )
			{
				index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_4), CB_GETCURSEL, 0L, 0L);

				EnableChoice4(hDlg, (index == CRITERIA_NO ? FALSE : TRUE));
			}
			return TRUE;
		}

		case IDC_COMBO_CHOICE_5:
		{
			int index;

			if( HIWORD(wParam) == CBS_SIMPLE )
			{
				index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_5), CB_GETCURSEL, 0L, 0L);

				EnableChoice5(hDlg, (index == CRITERIA_NO ? FALSE : TRUE));
			}
			return TRUE;
		}

		case IDC_CHAR_CHECK_1:
		{
			int iSet;

			iSet = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_1, FALSE, FALSE);

			if( iSet > 255 || iSet == 0 )
				SetDlgItemInt(hDlg, IDC_CHAR_CHECK_1, OldNrChar1, FALSE);
			else
				OldNrChar1 = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_1, FALSE, FALSE);

			return TRUE;
		}

		case IDC_CHAR_CHECK_2:
		{
			int iSet;

			iSet = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_2, FALSE, FALSE);

			if( iSet > 255 || iSet == 0 )
				SetDlgItemInt(hDlg, IDC_CHAR_CHECK_2, OldNrChar2, FALSE);
			else
				OldNrChar2 = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_2, FALSE, FALSE);

			return TRUE;
		}

		case IDC_CHAR_CHECK_3:
		{
			int iSet;

			iSet = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_3, FALSE, FALSE);

			if( iSet > 255 || iSet == 0 )
				SetDlgItemInt(hDlg, IDC_CHAR_CHECK_3, OldNrChar3, FALSE);
			else
				OldNrChar3 = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_3, FALSE, FALSE);

			return TRUE;
		}

		case IDC_CHAR_CHECK_4:
		{
			int iSet;

			iSet = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_4, FALSE, FALSE);

			if( iSet > 255 || iSet == 0 )
				SetDlgItemInt(hDlg, IDC_CHAR_CHECK_4, OldNrChar4, FALSE);
			else
				OldNrChar4 = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_4, FALSE, FALSE);

			return TRUE;
		}

		case IDC_CHAR_CHECK_5:
		{
			int iSet;

			iSet = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_5, FALSE, FALSE);

			if( iSet > 255 || iSet == 0 )
				SetDlgItemInt(hDlg, IDC_CHAR_CHECK_5, OldNrChar5, FALSE);
			else
				OldNrChar5 = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_5, FALSE, FALSE);

			return TRUE;
		}


		case IDOK:
		{
			if(IsDlgButtonChecked(hDlg, IDC_SORTER1) == BST_CHECKED)
				stParDocHandle.Sorter = SORTER_BAY1;
			else if(IsDlgButtonChecked(hDlg, IDC_SORTER2) == BST_CHECKED)
				stParDocHandle.Sorter = SORTER_BAY2;
			else if(IsDlgButtonChecked(hDlg, IDC_RETAINED) == BST_CHECKED)
				stParDocHandle.Sorter = HOLD_DOCUMENT;
			else if(IsDlgButtonChecked(hDlg, IDC_SORTERAUTOMATIC) == BST_CHECKED)
				stParDocHandle.Sorter = SORTER_AUTOMATIC;
			else if(IsDlgButtonChecked(hDlg, IDC_SWITCH_SORTER) == BST_CHECKED)
				stParDocHandle.Sorter = SORTER_SWITCH_1_TO_2;

			//Read Choice 1 param
			stParDocHandle.DataSorter[0].TypeCriteria = (char)SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_1), CB_GETCURSEL, 0L, 0L);
			GetDlgItemText(hDlg, IDC_STRING_11, stParDocHandle.DataSorter[0].String1, MAX_CHAR_CHECK+1);
			GetDlgItemText(hDlg, IDC_STRING_12, stParDocHandle.DataSorter[0].String2, MAX_CHAR_CHECK+1);
			stParDocHandle.DataSorter[0].CharToStart = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_1, FALSE, FALSE);
			stParDocHandle.DataSorter[0].NrCharCheck = strlen(stParDocHandle.DataSorter[0].String1);
			if( (Lenght = strlen(stParDocHandle.DataSorter[0].String2)) > stParDocHandle.DataSorter[0].NrCharCheck )
				stParDocHandle.DataSorter[0].NrCharCheck = (char)Lenght;
			stParDocHandle.DataSorter[0].Bin = SorterTable[SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_1), CB_GETCURSEL, 0L, 0L)];

			//Read Choice 2 param
			stParDocHandle.DataSorter[1].TypeCriteria = (char)SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_2), CB_GETCURSEL, 0L, 0L);
			GetDlgItemText(hDlg, IDC_STRING_21, stParDocHandle.DataSorter[1].String1, MAX_CHAR_CHECK+1);
			GetDlgItemText(hDlg, IDC_STRING_22, stParDocHandle.DataSorter[1].String2, MAX_CHAR_CHECK+1);
			stParDocHandle.DataSorter[1].CharToStart = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_2, FALSE, FALSE);
			stParDocHandle.DataSorter[1].NrCharCheck = strlen(stParDocHandle.DataSorter[1].String1);
			if( (Lenght = strlen(stParDocHandle.DataSorter[1].String2)) > stParDocHandle.DataSorter[1].NrCharCheck )
				stParDocHandle.DataSorter[1].NrCharCheck = (char)Lenght;
			stParDocHandle.DataSorter[1].Bin = SorterTable[SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_2), CB_GETCURSEL, 0L, 0L)];

			//Read Choice 3 param
			stParDocHandle.DataSorter[2].TypeCriteria = (char)SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_3), CB_GETCURSEL, 0L, 0L);
			GetDlgItemText(hDlg, IDC_STRING_31, stParDocHandle.DataSorter[2].String1, MAX_CHAR_CHECK+1);
			GetDlgItemText(hDlg, IDC_STRING_32, stParDocHandle.DataSorter[2].String2, MAX_CHAR_CHECK+1);
			stParDocHandle.DataSorter[2].CharToStart = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_3, FALSE, FALSE);
			stParDocHandle.DataSorter[2].NrCharCheck = strlen(stParDocHandle.DataSorter[2].String1);
			if( (Lenght = strlen(stParDocHandle.DataSorter[2].String2)) > stParDocHandle.DataSorter[2].NrCharCheck )
				stParDocHandle.DataSorter[2].NrCharCheck = (char)Lenght;
			stParDocHandle.DataSorter[2].Bin = SorterTable[SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_3), CB_GETCURSEL, 0L, 0L)];

			//Read Choice 4 param
			stParDocHandle.DataSorter[3].TypeCriteria = (char)SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_4), CB_GETCURSEL, 0L, 0L);
			GetDlgItemText(hDlg, IDC_STRING_41, stParDocHandle.DataSorter[3].String1, MAX_CHAR_CHECK+1);
			GetDlgItemText(hDlg, IDC_STRING_42, stParDocHandle.DataSorter[3].String2, MAX_CHAR_CHECK+1);
			stParDocHandle.DataSorter[3].CharToStart = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_4, FALSE, FALSE);
			stParDocHandle.DataSorter[3].NrCharCheck = strlen(stParDocHandle.DataSorter[3].String1);
			if( (Lenght = strlen(stParDocHandle.DataSorter[3].String2)) > stParDocHandle.DataSorter[3].NrCharCheck )
				stParDocHandle.DataSorter[3].NrCharCheck = (char)Lenght;
			stParDocHandle.DataSorter[3].Bin = SorterTable[SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_4), CB_GETCURSEL, 0L, 0L)];

			//Read Choice 5 param
			stParDocHandle.DataSorter[4].TypeCriteria = (char)SendMessage(GetDlgItem(hDlg, IDC_COMBO_CHOICE_5), CB_GETCURSEL, 0L, 0L);
			GetDlgItemText(hDlg, IDC_STRING_51, stParDocHandle.DataSorter[4].String1, MAX_CHAR_CHECK+1);
			GetDlgItemText(hDlg, IDC_STRING_52, stParDocHandle.DataSorter[4].String2, MAX_CHAR_CHECK+1);
			stParDocHandle.DataSorter[4].CharToStart = GetDlgItemInt(hDlg, IDC_CHAR_CHECK_5, FALSE, FALSE);
			stParDocHandle.DataSorter[4].NrCharCheck = strlen(stParDocHandle.DataSorter[4].String1);
			if( (Lenght = strlen(stParDocHandle.DataSorter[4].String2)) > stParDocHandle.DataSorter[4].NrCharCheck )
				stParDocHandle.DataSorter[4].NrCharCheck = (char)Lenght;
			stParDocHandle.DataSorter[4].Bin = SorterTable[SendMessage(GetDlgItem(hDlg, IDC_COMBO_SORTER_5), CB_GETCURSEL, 0L, 0L)];

			EndDialog(hDlg, TRUE);
			return TRUE;
		}

		case IDCANCEL:
			EndDialog(hDlg, FALSE);
			return TRUE;
		}
	}

    return FALSE;
}	// SelectSorterDlgProc500


//
// ------- EnableChoices
//
void EnableChoices(HWND hDlg, BOOL fDo)
{
	//Choice 1
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC1), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC11), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_CHOICE_1), fDo);
	//Choice 2
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC2), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC21), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_CHOICE_2), fDo);
	//Choice 3
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC3), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC31), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_CHOICE_3), fDo);
	//Choice 4
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC4), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC41), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_CHOICE_4), fDo);
	//Choice 5
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC5), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC51), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_CHOICE_5), fDo);
}

void EnableChoice1(HWND hDlg, BOOL fDo)
{
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC12), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_11), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC13), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_12), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC14), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_CHAR_CHECK_1), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC15), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_SORTER_1), fDo);
}

void EnableChoice2(HWND hDlg, BOOL fDo)
{
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC22), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_21), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC23), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_22), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC24), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_CHAR_CHECK_2), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC25), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_SORTER_2), fDo);
}

void EnableChoice3(HWND hDlg, BOOL fDo)
{
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC32), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_31), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC33), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_32), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC34), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_CHAR_CHECK_3), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC35), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_SORTER_3), fDo);
}

void EnableChoice4(HWND hDlg, BOOL fDo)
{
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC42), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_41), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC43), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_42), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC44), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_CHAR_CHECK_4), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC45), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_SORTER_4), fDo);
}

void EnableChoice5(HWND hDlg, BOOL fDo)
{
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC52), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_51), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC53), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STRING_52), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC54), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_CHAR_CHECK_5), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_STATIC55), fDo);
	EnableWindow(GetDlgItem(hDlg, IDC_COMBO_SORTER_5), fDo);
}
//
// ------- end EnableChoices
//



BOOL CALLBACK DlgProcDecoSwParBarcode500(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	char str[10];
	char Sw_x[16],Sw_y[16],Sw_h[16],Sw_w[16];
	HWND hCombo;
	int CurrItem;


	switch( msg )
	{
		case WM_INITDIALOG:
			SetWindowText(hDlg, "Parametrer for Barcode Window");
			
			if(stParDocHandle.Barcode_Unit_measure == UNIT_MM)
			{
				SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Barcode_Sw_x,TRUE);
				SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Barcode_Sw_y,TRUE);
				SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Barcode_Sw_w,TRUE);
				SetDlgItemInt(hDlg,IDC_H,(int)stParDocHandle.Barcode_Sw_h,TRUE);
				CheckDlgButton(hDlg,IDC_UNIT_MM,TRUE);
			}
			else
			{
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_w);
				SetDlgItemText(hDlg, IDC_W, str);
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_x);
				SetDlgItemText(hDlg, IDC_X, str);
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_y);
				SetDlgItemText(hDlg, IDC_Y, str);
				sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_h);
				SetDlgItemText(hDlg, IDC_H, str);
				CheckDlgButton(hDlg,IDC_UNIT_INC,TRUE);
			}
			
			EnableWindow(GetDlgItem(hDlg, IDC_UNIT_INC), FALSE);

			//set barcode type
			hCombo = GetDlgItem(hDlg, IDC_COMBOPTICAL);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_BARCODE_2_OF_5);
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)STR_BARCODE_CODE39);
			switch( stParDocHandle.Barcodetype )
			{
			case READ_BARCODE_2_OF_5:
				CurrItem = 0;
				break;
			case READ_BARCODE_CODE39:
				CurrItem = 1;
				break;
			}

			SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);
			
			return TRUE;


		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
			
			case IDC_UNIT_INC:
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_INC) == BST_CHECKED)
					SetButtonInc(hDlg);
				break;

			case IDC_UNIT_MM:
				if( IsDlgButtonChecked(hDlg,IDC_UNIT_MM) == BST_CHECKED)
					SetButtonMM(hDlg);
				break;

			case IDOK:
				if( IsDlgButtonChecked(hDlg, IDC_UNIT_MM) == BST_CHECKED )
					stParDocHandle.Barcode_Unit_measure = UNIT_MM;
				else if( IsDlgButtonChecked(hDlg, IDC_UNIT_INC) == BST_CHECKED )
					stParDocHandle.Barcode_Unit_measure = UNIT_INCH;
			
				// Reads the coordinate
				if( stParDocHandle.Barcode_Unit_measure == UNIT_MM)
				{
					stParDocHandle.Barcode_Sw_x = (float)GetDlgItemInt(hDlg, IDC_X, NULL, FALSE);
					stParDocHandle.Barcode_Sw_y = (float)GetDlgItemInt(hDlg, IDC_Y, NULL, FALSE);
					stParDocHandle.Barcode_Sw_w = (float)GetDlgItemInt(hDlg, IDC_W, NULL, FALSE);
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));
					stParDocHandle.Barcode_Sw_h = (float)atof(Sw_h);
				}
				else 
				{
					GetDlgItemText(hDlg, IDC_X, Sw_x, sizeof(Sw_x));
					GetDlgItemText(hDlg, IDC_Y, Sw_y, sizeof(Sw_y));
					GetDlgItemText(hDlg, IDC_W, Sw_w, sizeof(Sw_w));
					GetDlgItemText(hDlg, IDC_H, Sw_h, sizeof(Sw_h));

					stParDocHandle.Barcode_Sw_x = (float)atof(Sw_x);
					stParDocHandle.Barcode_Sw_y = (float)atof(Sw_y);
					stParDocHandle.Barcode_Sw_w = (float)atof(Sw_w);
					stParDocHandle.Barcode_Sw_h = (float)atof(Sw_h);
				}

				switch( SendMessage(GetDlgItem(hDlg, IDC_COMBOPTICAL), CB_GETCURSEL, 0, 0) )
				{
				case 0:
					stParDocHandle.Barcodetype = READ_BARCODE_2_OF_5;
					break;
				case 1:
					stParDocHandle.Barcodetype = READ_BARCODE_CODE39;
					break;
				}

				EndDialog(hDlg, IDOK);
				return TRUE;
			}
			return TRUE;
	}

	return FALSE;
} // DlgProcDecoSwParBarcode500




//void SetObjOpticParameterMainOcr500
//
// set the params in the optical functions (in doc handle window)
//
void SetObjOpticParameterMainOcr500(HWND hDlg)
{
	char str[16];

	if(stParDocHandle.Unit_measure == UNIT_MM)
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Codeline_Sw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Codeline_Sw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Codeline_Sw_w,TRUE);
	}
	else 
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_INC);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_w);
		SetDlgItemText(hDlg, IDC_W, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_x);
		SetDlgItemText(hDlg, IDC_X, str);
		sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_y);
		SetDlgItemText(hDlg, IDC_Y, str);

	}
	sprintf(str, "%.2f", stParDocHandle.Codeline_Sw_h);
	SetDlgItemText(hDlg, IDC_H, str);

	switch( stParDocHandle.CodelineOptType )
		{
		case READ_CODELINE_SW_OCRA:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRA);
			break;
		case READ_CODELINE_SW_OCRB_NUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB);
			break;
		case READ_CODELINE_SW_OCRB_ALFANUM:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_OCRB_ALPHA);
			break;
		case READ_CODELINE_SW_E13B:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13B);
			break;
		case READ_CODELINE_SW_E13B_X_OCRB:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_E13BOPT);
			break;
		case READ_CODELINE_SW_MULTI_READ:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_MUTILREAD);
			break;
		}
} // SetObjOpticParameterMainOcr500


//void SetObjOpticParameterMainBarcode500
//
//set the params in the optical functions (in doc handle window)
//
void SetObjOpticParameterMainBarcode500(HWND hDlg)
{
	char str[16];

	if(stParDocHandle.Barcode_Unit_measure == UNIT_MM)
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_MM);
		SetDlgItemInt(hDlg,IDC_X,(int)stParDocHandle.Barcode_Sw_x,TRUE);
		SetDlgItemInt(hDlg,IDC_Y,(int)stParDocHandle.Barcode_Sw_y,TRUE);
		SetDlgItemInt(hDlg,IDC_W,(int)stParDocHandle.Barcode_Sw_w,TRUE);
		SetDlgItemInt(hDlg,IDC_H,(int)stParDocHandle.Barcode_Sw_h,TRUE);
		switch( stParDocHandle.Barcodetype )
		{
		case READ_BARCODE_2_OF_5:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_BARCODE_2_OF_5);
			break;
		case READ_BARCODE_CODE39:
			SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_BARCODE_2_OF_5);
			break;
		}
	}
	else 
	{
		SetDlgItemText(hDlg,IDC_U_MEASURE,TEXT_INC);
		sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_w);
		SetDlgItemText(hDlg, IDC_W, str);
		sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_x);
		SetDlgItemText(hDlg, IDC_X, str);
		sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_y);
		SetDlgItemText(hDlg, IDC_Y, str);

	}
	sprintf(str, "%.2f", stParDocHandle.Barcode_Sw_h);
	SetDlgItemText(hDlg, IDC_H, str);

	switch( stParDocHandle.Barcodetype )
	{
	case READ_BARCODE_2_OF_5:
		SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_BARCODE_2_OF_5);
		break;
	case READ_BARCODE_CODE39:
		SetDlgItemText(hDlg, IDC_TYPE_OPT, STR_BARCODE_CODE39);
		break;
	}

} // SetObjOpticParameterMainBarcode500




//***************************************************************************
// FUNCTION  : EnableOpticMainBarcode500
//
// PURPOSE   : enable/dis the window portion where there are the coordinates
//
// PARAMETER : 
//***************************************************************************
void EnableOpticMainBarcode500(HWND hwnd, BOOL Flag)
{
	long CurrItem;

	
	SetDlgItemText(hwnd,IDC_STATIC1,"Barcode Decode Information");
	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TYPE_OPT), FALSE);
	EnableWindow(GetDlgItem(hwnd, IDC_U_MEASURE), FALSE);
	EnableWindow(GetDlgItem(hwnd, IDC_S_MEASURE), FALSE);
	EnableWindow(GetDlgItem(hwnd, IDC_S_TYPE_OPT), FALSE);
	if( Flag )
	{
		switch( stParDocHandle.Barcodetype )
		{
		case READ_BARCODE_2_OF_5:
			CurrItem = 6;
			break;
		default:
			CurrItem = 1;
			break;
		}
		SendMessage(GetDlgItem(hwnd, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);

	} // end if
} // End EnableOpticMainBarcode500


//***************************************************************************
// FUNCTION  : EnableOpticMainOcr500
//
// PURPOSE   : // 
//
// PARAMETER : 
//***************************************************************************
void EnableOpticMainOcr500(HWND hwnd, BOOL Flag)
{
	long CurrItem;

	SetDlgItemText(hwnd,IDC_STATIC1,"OCR Decode Information");
	EnableWindow(GetDlgItem(hwnd, IDC_STATIC1), Flag);

	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL1), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_LABELOPTICAL2), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_X), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_Y), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_W), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_H), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_TYPE_OPT), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_U_MEASURE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_S_MEASURE), Flag);
	EnableWindow(GetDlgItem(hwnd, IDC_S_TYPE_OPT), Flag);
	if( Flag )
	{
		switch( stParDocHandle.CodelineOptType )
		{
		case READ_CODELINE_SW_OCRA:
			CurrItem = 1;
			break;
		case READ_CODELINE_SW_OCRB_NUM:
			CurrItem = 2;
			break;
		case READ_CODELINE_SW_OCRB_ALFANUM:
			CurrItem = 3;
			break;
		case READ_CODELINE_SW_E13B:
			CurrItem = 4;
			break;
		case READ_CODELINE_SW_E13B_X_OCRB:
			CurrItem = 5;
			break;
		case READ_CODELINE_SW_MULTI_READ:
			CurrItem = 0;
			break;
		default:
			CurrItem = 2;
			break;
		}
		SendMessage(GetDlgItem(hwnd, IDC_COMBOPTICAL), CB_SETCURSEL, CurrItem, 0);

	} // end if
} // End EnableOpticMainOcr500
