////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>
#include <fcntl.h>
#include <stdio.h>
#include <io.h>
#include <string.h>
#include <direct.h>


////////////////////////
//Includes espec�ficos//
////////////////////////

#include "CFileUtils.h"


//////////////
//Namespaces//
//////////////


////////////////////////////////////////
//Inicializa��es ( membros est�ticos )//
////////////////////////////////////////

const int CFileUtils::MAX_PATH_SIZE= MAX_PATH;


//////////////////////////////
//Implementa��es dos m�todos//
//////////////////////////////


//////////////////
//Static Methods//
//////////////////


////////////////////////////
//Construtores & Destrutor//
////////////////////////////

CFileUtils::CFileUtils()
{

	//Construtor Dummy

}


bool CFileUtils::getFilePath(const char* fullFileName, char* filePath)
{

	bool result = false;
	char fileName[CFileUtils::MAX_PATH_SIZE] = {0};
	char fileExtension[CFileUtils::MAX_PATH_SIZE] = {0};

	//calling method that evaluates the file path and split its parts.
	result = breakFileName(fullFileName, filePath, fileName, fileExtension);

	return(result);

}


bool CFileUtils::getFileName(const char* fullFileName, char* fileName)
{

	bool result = false;
	char filePath[CFileUtils::MAX_PATH_SIZE] = {0};
	char fileExtension[CFileUtils::MAX_PATH_SIZE] = {0};

	//calling method that evaluates the file path and split its parts.
	if((result = breakFileName(fullFileName, filePath, fileName, fileExtension)) == true)
	{
		strcat(fileName, ".");
		strcat(fileName, fileExtension);
	}
	
	return(result);

}

bool CFileUtils::getFileExtension(const char* fullFileName, char* fileExtension)
{

	bool result = false;
	char filePath[CFileUtils::MAX_PATH_SIZE] = {0};
	char fileName[CFileUtils::MAX_PATH_SIZE] = {0};

	//calling method that evaluates the file path and split its parts.
	result = breakFileName(fullFileName, filePath, fileName, fileExtension);

	return(result);

}

bool CFileUtils::breakFileName(const char* fullFileName, char* filePath, char* fileName, char* fileExtension)
{

	char* token = NULL;
	char* lastToken = NULL;

	token = strpbrk(fullFileName, "\\");
	if(token != NULL)
	{
		do
		{
			lastToken = token + 1;
			token = strpbrk(token + 1, "\\");
		} while(token != NULL);
		strncpy(filePath, fullFileName , (lastToken - fullFileName));

		int len = (lastToken - fullFileName);
		if (len > 0)
		{
			filePath[ len - 1 ]= '\0';
		}
		else
		{
			filePath[ 0 ]= '\0';
		}

		strcpy(fileName, lastToken);

		token = strpbrk(fileName, ".");
		if(token != NULL)
		{
			do
			{
				lastToken = token;
				token = strpbrk(token + 1, ".");
			}while(token != NULL);

			if (lastToken)
			{
				strcpy(fileExtension, lastToken + 1);
				*lastToken = '\0';
			}
			else
			{
				fileExtension[ 0 ] = '\0';
			}
		}
	}
	else
	{
		return false;
	}
	
	return true;

}


//his method extract one level of directory of the Path provided
///Ex : path   = "c:\test\dir1\abc"
///     return = "c:\test\dir1"
///It returns false if couldnot extract the dir
bool CFileUtils::extractDirectory(const char* path, char* truncatedPath)
{

	char* token = NULL;

	token = strrchr(path, '\\');

	memset( truncatedPath, '\0', sizeof( truncatedPath ) );

	//If the ocurrence was found....
	if( token != NULL ){

		strncpy( truncatedPath, path , (token-path) );

		return true;

	}else{

		return false;

	}


}


//Create the directorty specified by "path", and all the directories needed
///in the path, if they do not exist
void CFileUtils::createDirectoryRecursive( const char* path )
{

	//Hold the path, minus the last directory
	char truncatedPath[MAX_PATH_SIZE]= {'\0'};

	//Locate the first ocurrence of "\" ( should be in c:\\dir.... )
	char* idx= strchr( path, '\\' );


	//Verify if the directory exist�s
	///zero     = exists
	///non zero = does�t exists
	if( access( path, 0 ) != 0 ){

		//Extract the last level of the directory tree
		CFileUtils::extractDirectory( path, truncatedPath );

		//Call recursively this method, in order to create
		///the deeper directories first
		CFileUtils::createDirectoryRecursive( truncatedPath );

		//Finally create the directory
		CreateDirectory( path, NULL );

	};//if( access( path, 0 ) != 0 )

}

bool CFileUtils::fileExists (const char* path)
{
	///zero     = exists
	///non zero = does�t exists
	return (access( path , 0 ) == 0); 
}

bool CFileUtils::isDirectory (const char* path)
{
	bool ret = false;
	WIN32_FIND_DATA findFileData;
	HANDLE hFind = INVALID_HANDLE_VALUE;

	if (path != NULL)
	{
		//carrega a estrutura com informa��es do arquivo
		hFind = FindFirstFile(path , &findFileData);

		if (hFind != INVALID_HANDLE_VALUE)
		{
			//verificamos se � ou nao um diretorio
			ret = isDirectory(&findFileData);
		}
		FindClose(hFind);
	}
	return ret;
}

bool CFileUtils::isDirectory (WIN32_FIND_DATA* findFileData)
{
	bool ret = false;

	if (findFileData != NULL)
	{
		if ((findFileData->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{
			ret = true;
		}
	}
	return ret;
}

bool CFileUtils::deleteFile (const char* path)
{
	///zero     = Ok
	///non zero = Error
	return (remove(path) == 0);
}

void CFileUtils::deleteDirectory (const char* path)
{
	CBasicStringList allFiles;
	listFileNames (path, "*", true, allFiles, EFOAll);
	const char* pStr = NULL;

	int len = allFiles.count();

	for (int i = len - 1 ; i >= 0  ; i--)
	{
		pStr = allFiles.elmtAt(i);

		if (isDirectory(pStr))
		{
			rmdir(pStr);
		}
		else
		{
			deleteFile(pStr);
		}
	}
	rmdir(path);
}

bool CFileUtils::copyFile (const char* path, const char* toPath)
{
	///non zero	= Ok
	///zero		= Error

	///For�amos para n�o falhar se o arquivo existir
	return (::CopyFile(path, toPath, FALSE) != 0);
}

bool CFileUtils::moveFile (const char* fromPath, const char* toPath, bool overwrite)
{

	//verifica se eh para sobrescrever
	if (overwrite)
	{
		deleteFile(toPath);
	}

	///non zero	= Error
	///zero		= OK
	return (rename(fromPath, toPath) == 0);
}

unsigned int CFileUtils::getFileSize (const char* path)
{
	unsigned int ret = 0;

	//vamos abrir o arquivo para verificar o tamanho
	FILE* fp = fopen (path, "r");
	if (fp)
	{
		//vamos para o final
		fseek ( fp, 0, SEEK_END );
		//pegamos a posi��o atual que � o mesmo que o tamanho
		ret = ftell( fp );

		fclose (fp);
	}

	return ret;
}

void CFileUtils::listFileNames ( const char* basePath, const char* searchCriterion,  bool recursive, CBasicStringList& filesList, EFindOptions findOptions)
{
	WIN32_FIND_DATA findFileData;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	char path[MAX_PATH_SIZE] = {0};
	int basePathLen;

	basePathLen = strlen (basePath);

	//monta o criterio de busca, se nao tem '\' entao coloca
	if (basePath[basePathLen - 1] == '\\')
		sprintf (path, "%s%s", basePath, searchCriterion);
	else
		sprintf (path, "%s\\%s", basePath, searchCriterion);

	//carrega estrutura com informa��es do arquivo
	hFind = FindFirstFile(path , &findFileData);

	if (hFind != INVALID_HANDLE_VALUE)
	{
		do
		{
			//verifica se � recursivo, se for, entao verificamos se � um diretorio
			if (recursive && isDirectory(&findFileData))
			{
				//se for recursivo e � um diret�rio, ainda temos que ver se n�o eh .
				if(strncmp(findFileData.cFileName, ".", 1))
				{
					//concatena no nome do diretorio no basePath
					if (basePath[basePathLen - 1] == '\\')
						sprintf (path, "%s%s", basePath, findFileData.cFileName);
					else
						sprintf (path, "%s\\%s", basePath, findFileData.cFileName);

					if (findOptions == EFOAll || findOptions == EFOOnlyDirectories)
					{
						filesList.add(path);
					}

					listFileNames (path, searchCriterion, true, filesList, findOptions);
				}
			}
			else
			{
				if (isDirectory(&findFileData))
				{
					//nao � recursivo e � diretorio

					//se for diretorio e for "." nao inserimos na lista
					if(strncmp(findFileData.cFileName, ".", 1))
					{
						//nao � ".", eh nome de diretorio
						if (findOptions == EFOAll || findOptions == EFOOnlyDirectories)
						{
							sprintf(path, "%s\\%s", basePath, findFileData.cFileName);
							filesList.add(path);
						}
					}					
				}
				else
				{
					//n�o � recursivo e � arquivo

					//� arquivo
					if (findOptions == EFOAll || findOptions == EFOOnlyFiles)
					{
						sprintf(path, "%s\\%s", basePath, findFileData.cFileName);
						filesList.add(path);
					}
				}
			}

		}while (FindNextFile(hFind, &findFileData) != 0);

		FindClose(hFind);
	}
}

char* CFileUtils::getCurrentDirectory (char* path, int pathLength)
{
	if (path)
	{
		::GetCurrentDirectory (pathLength, path);
	}

	return path;
}

void CFileUtils::getFileAttributes (const char* path, CFileAttributes* fAttributes)
{
	if (path)
	{
		DWORD attr = 0;
		attr =  GetFileAttributes (path);

		if (attr >= 0)
		{
			fAttributes->archive		= (attr & FILE_ATTRIBUTE_ARCHIVE) == FILE_ATTRIBUTE_ARCHIVE;
			fAttributes->compressed		= (attr & FILE_ATTRIBUTE_COMPRESSED) == FILE_ATTRIBUTE_COMPRESSED;
			fAttributes->directory		= (attr & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY;
			fAttributes->encripted		= (attr & FILE_ATTRIBUTE_ENCRYPTED) == FILE_ATTRIBUTE_ENCRYPTED;
			fAttributes->hidden			= (attr & FILE_ATTRIBUTE_HIDDEN) == FILE_ATTRIBUTE_HIDDEN;
			fAttributes->normal			= (attr & FILE_ATTRIBUTE_NORMAL) == FILE_ATTRIBUTE_NORMAL;
			fAttributes->readOnly		= (attr & FILE_ATTRIBUTE_READONLY) == FILE_ATTRIBUTE_READONLY;
			fAttributes->system			= (attr & FILE_ATTRIBUTE_SYSTEM) == FILE_ATTRIBUTE_SYSTEM;
			fAttributes->temporary		= (attr & FILE_ATTRIBUTE_TEMPORARY) == FILE_ATTRIBUTE_TEMPORARY;

		}
	}
}

void CFileUtils::setFileAttributes (const char* path, CFileAttributes* fAttributes)
{
	if (path)
	{
		DWORD attr = 0;

		if(fAttributes->archive)
			attr |= FILE_ATTRIBUTE_ARCHIVE;
		if(fAttributes->compressed)
			attr |= FILE_ATTRIBUTE_COMPRESSED;
		if(fAttributes->directory)
			attr |= FILE_ATTRIBUTE_DIRECTORY;
		if(fAttributes->encripted)
			attr |= FILE_ATTRIBUTE_ENCRYPTED;
		if(fAttributes->hidden)
			attr |= FILE_ATTRIBUTE_HIDDEN;
		if(fAttributes->normal)
			attr |= FILE_ATTRIBUTE_HIDDEN;
		if(fAttributes->readOnly)
			attr |= FILE_ATTRIBUTE_NORMAL;
		if(fAttributes->system)
			attr |= FILE_ATTRIBUTE_READONLY;
		if(fAttributes->temporary)
			attr |= FILE_ATTRIBUTE_SYSTEM;

		::SetFileAttributes (path, attr);
	}
}

bool CFileUtils::createBlankFile (const char* path)
{
	bool ret = false;
	char truncatedPath[MAX_PATH_SIZE]= {'\0'};

	//extrai o diretorio do arquivo
	extractDirectory (path, truncatedPath);

	//verifica se o diretorio existe
	if (!fileExists(truncatedPath))
	{
		//se nao existe entao criamos
		createDirectoryRecursive(truncatedPath);
	}

	//agora que ja existe o diretorio vamos criar o arquvo em branco
	FILE* fp = fopen (path, "w");
	if (fp)
	{
		ret = true;
		fclose (fp);
	}

	return ret;
}

bool CFileUtils::waitUntilFileExist (const char* file, int timeout)
{
	bool ret = false;

	int start = GetTickCount();

	while (timeout == INFINITE ||
			(GetTickCount() - start) < (unsigned int)timeout)
	{
		if (CFileUtils::fileExists(file))
		{
			ret = true;
			break;
		}
		Sleep (100);
	}

	return ret;
}

bool CFileUtils::safeCopy (const char* sourceFile, const char* destFile)
{
    bool ret = false;
    FILE* fpSource = fopen (sourceFile, "rb");

    if (fpSource)
    {
        //seta modo para binario
        _setmode (_fileno(fpSource), _O_BINARY);

        //abre arquivo destino
        FILE* fpDest = fopen (destFile, "wb");

        if (fpDest)
        {
            //seta modo para binario
            _setmode (_fileno(fpDest), _O_BINARY);

            //obtem o handle para o arquivo
            HANDLE hfile = (HANDLE) _get_osfhandle (_fileno (fpDest));


            fseek (fpSource, 0L, SEEK_END);
            unsigned int fileLen = ftell (fpSource);
            fseek (fpSource, 0L, SEEK_SET);

            unsigned char* buffer = new unsigned char[fileLen];

            memset (buffer, '\0', fileLen);

            fread (buffer, fileLen, 1, fpSource);
            fwrite (buffer, fileLen, 1, fpDest);


            delete[] buffer;

            fflush(fpDest);

            //descarrega buffer da memoria para o disco
            if (!FlushFileBuffers (hfile))
            {
				ret = false;
            }
			else
			{
				ret = true;
			}

            fclose (fpDest);
        }

        fclose (fpSource);
    }

    return ret;
}

bool CFileUtils::readAllFile (const char* file, CBuffer& fileContent)
{
	bool ret = false;
    FILE* fpSource = fopen (file, "rb");

	fileContent.clear();
    if (fpSource)
    {
        fseek (fpSource, 0L, SEEK_END);
        unsigned int fileLen = ftell (fpSource);
        fseek (fpSource, 0L, SEEK_SET);

        unsigned char* buffer = new unsigned char[fileLen];
        memset (buffer, '\0', fileLen);

		for (unsigned int i = 0; i < fileLen; i++)
		{
			fread (&buffer[i], 1, 1, fpSource);
		}
		fclose (fpSource);

		fileContent.setBuffer(buffer, fileLen);

		delete[] buffer;
		ret = true;
	}

	return ret;
}

bool CFileUtils::readAllFile (const char* file, CBasicString& fileContent)
{
	bool ret;
	CBuffer buff;

	fileContent.clear();
	ret = readAllFile (file, buff);

	if (ret)
	{
		fileContent.append((const char*)buff.getBuffer());
	}

	return ret;
}

bool CFileUtils::readAllFile (const char* file, CBasicStringList& fileContent, const char* separators)
{
	bool ret;
	CBuffer buff;

	fileContent.clear();
	ret = readAllFile (file, buff);

	if (ret)
	{
		fileContent.deserialize((const char*)buff.getBuffer(), separators);
	}
	
	return ret;
}

bool CFileUtils::appendDataInFile (const char* file, const void* buffer, unsigned int len)
{
	bool ret = false;
	FILE* fp;

	fp = fopen (file, "ab");

	if (fp)
	{
		if (len > 0)
		{
			fwrite (buffer, len, 1, fp);
		}
		fclose (fp);
		ret = true;
	}

	return ret;
}

bool CFileUtils::appendDataInFile (const char* file, CBasicStringList& data)
{
	bool ret = false;
	FILE* fp;

	fp = fopen (file, "ab");

	if (fp)
	{
		int listLen = data.count();

		for (int i = 0; i < listLen; i++)
		{
			fprintf(fp, "%s\n", data[i]);
		}

		fclose (fp);
		ret = true;
	}

	return ret;
}

bool CFileUtils::appendFileInFile (const char* fileFrom, const char* fileTo)
{
	bool ret = false;
	
	CBuffer content;
	if (CFileUtils::readAllFile (fileFrom, content))
	{
		ret = CFileUtils::appendDataInFile (fileTo, (const void*)content.getBuffer(), content.length());
	}
	
	return ret;
}
