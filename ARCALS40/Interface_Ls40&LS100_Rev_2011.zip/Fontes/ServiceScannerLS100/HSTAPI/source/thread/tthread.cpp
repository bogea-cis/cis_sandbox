////////////////////////////////////////////////////////////////////////////
// arquivo      :  thread.cpp
// autor        : Marlon Silva Amorim
// empresa      : HST 
// modificacoes : 08/11//99; 
// Descricao    : Definicao da classe thread
//                > colocar getlasterror para o tratamento de erro em cada chamada
//                > colocar enabled em cada metodo
//                > colocar closehandle e/ou exit thread
/*                > rever o campo suspended
**** A seguir as constantes do windows para prioridade *******

THREAD_PRIORITY_ABOVE_NORMAL  
Indicates 1 point above normal priority for the priority class. 
THREAD_PRIORITY_BELOW_NORMAL 
Indicates 1 point below normal priority for the priority class. 
THREAD_PRIORITY_HIGHEST 
Indicates 2 points above normal priority for the priority class. 
THREAD_PRIORITY_IDLE 
Indicates a base-priority level of 1 for IDLE_PRIORITY_CLASS, 
                                          NORMAL_PRIORITY_CLASS, or 
                                          HIGH_PRIORITY_CLASS processes, 
                                          and a base-priority level of 16 for 
                                          REALTIME_PRIORITY_CLASS processes. 
THREAD_PRIORITY_LOWEST 
Indicates 2 points below normal priority for the priority class. 
THREAD_PRIORITY_NORMAL 
Indicates normal priority for the priority class. 
THREAD_PRIORITY_TIME_CRITICAL 
Indicates a base-priority level of 15 for IDLE_PRIORITY_CLASS, 
                                          NORMAL_PRIORITY_CLASS, or 
                                          HIGH_PRIORITY_CLASS processes, and 
                                          a base-priority level of 31 for 
                                          REALTIME_PRIORITY_CLASS processes. 
*/ 
////////////////////////////////////////////////////////////////////////////
#include "tthread.h"

////////////////////////////////////////////////////////////////////////////
// CONSTANTES DEFAULT LOCAIS
////////////////////////////////////////////////////////////////////////////
#define  THREAD_DEFAULT_PRIORITY      THREAD_PRIORITY_NORMAL                  // prioridade normal
#define  THREAD_DEFAULT_STACK         0                                       // indica mesmo stack do processo pai             

////////////////////////////////////////////////////////////////////////////
// CONSTRUCTOR TThread
// creation flag indica se thread exeeutara imediatamente ou se iniciar�
// suspensa;
// Cria objeto TThread mas nao inicia thread. Vide TThread.start
////////////////////////////////////////////////////////////////////////////
TThread::TThread (   void  *thread_function_, 
                     void *thread_parameter_)
{
   // _________________________________________________   
   // inicia estado da thread com os valores  default
   handle_OK         = FALSE;    // handle para thread inicia inv�lido
   enabled           = TRUE;     // inicia abilitada
   suspended         = FALSE;      
   priority          = THREAD_DEFAULT_PRIORITY;
   stack_size        = THREAD_DEFAULT_STACK;
   thread_handle     = NULL;           
   thread_ID         = 0;
   suspend_counter   = 0; 
   
   // _________________________________________________
   // repassa parametros de criacao
   thread_function   = thread_function_;
   thread_parameter  = thread_parameter_;

}

////////////////////////////////////////////////////////////////////////////
// DESTRUTOR TThread
// Fecha handle da thread 
////////////////////////////////////////////////////////////////////////////
TThread::~TThread (void)
{
	int error_code=0; //mod warning
	TerminateThread(thread_handle, error_code);
  CloseHandle(thread_handle);
}

////////////////////////////////////////////////////////////////////////////
// TThread START
// creation_flag_ sao flags adicionais para a criacao da 
// thread (ex: CREATE_SUSPENDED) O valor 0 indica executar imediatamente
// Inicia efetivamente a thread.
////////////////////////////////////////////////////////////////////////////
BOOL TThread::Start (int creation_flag_)
{
	
   // _________________________________________________
   // tenta criar thread
   thread_handle = CreateThread( NULL,                                        // security
                                 stack_size,                                  // tamanho da pilha da thread 
                                 (LPTHREAD_START_ROUTINE ) thread_function,   // fun��o a ser  executada pela thread
                                 thread_parameter,                            // parametro para a thread
                                 creation_flag_,                              // thread inicia imediatamente
                                 (LPDWORD) &thread_ID );                      // variavel que recebe o ID da thread
                  

   // _________________________________________________    
   // caso a thread nao foi criada
   if (thread_handle == INVALID_HANDLE_VALUE) 
   {
      // handle para o erro
      handle_OK   = FALSE;   
      return FALSE;
   }

   // _________________________________________________
   // caso conseguiu criar o handle 
   else
   {
      handle_OK         = TRUE;
      suspended         = FALSE; // ????????????
      if (creation_flag_ == CREATE_SUSPENDED)
         suspended = TRUE;
      return TRUE;
   }
}


////////////////////////////////////////////////////////////////////////////
// TThread SetPriority
// 
// Seta a Prioridade da thread
////////////////////////////////////////////////////////////////////////////
BOOL TThread::SetPriority (int priority_)
{ 
   // _________________________________________________
   // se a mudanca de prioridade der certo
   if (SetThreadPriority( thread_handle,
                            priority_)) 
   {
      priority = priority_;
      return TRUE;
   }
   // _________________________________________________
   // se a mudanca de prioridade der errrado
   else 
   {
      // usar getlasterror aqui
      return FALSE;
   }
}

////////////////////////////////////////////////////////////////////////////
// TThread Suspend
// 
// Suspende thread
////////////////////////////////////////////////////////////////////////////
BOOL TThread::Suspend (void)
{
   int   result;                                      // retorno de funcoes

   //_________________________________________________
   // tenta suspender thread
   result = SuspendThread(thread_handle);
   //_________________________________________________
   // nao conseguiu suspender thread
   if (result == 0xFFFFFFFF)
   {
      // handle para erro
      return FALSE;
   }
   //_________________________________________________
   // thread foi suspensa
   else 
   {
      suspended         = TRUE;
      suspend_counter++;
      return TRUE;
   }
}
            
////////////////////////////////////////////////////////////////////////////
// TThread Resume
// 
// Resume thread
////////////////////////////////////////////////////////////////////////////
BOOL TThread::Resume (void)
{
   int   result;                                      // retorno de funcoes

   // se a tread estiver suspensa 
   if (suspended)
   {
      //_________________________________________________
      // tenta resumir thread
      result = ResumeThread(thread_handle);
      //_________________________________________________
      // nao conseguiu resumir thread
      if (result == 0xFFFFFFFF)
      {
         // handle para erro
         return FALSE;
      }
      //_________________________________________________
      // thread foi resumida
      else 
      {
         suspended         = FALSE;
         suspend_counter--;   
         return TRUE;
      }
   }
   // thread nao estava suspensa 
   else
   {
      return TRUE;
   }
}      


HANDLE TThread::getHandle ()
{
	return thread_handle;
}