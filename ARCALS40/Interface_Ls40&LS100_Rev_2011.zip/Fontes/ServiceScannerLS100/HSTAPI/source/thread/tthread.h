///////////////////////////////////////////////////////////////////////////////
// thread.hpp 
// autor : Marlon Silva Amorim
// 
// Descricao : Este arquivo declara a classe thread que encapsula todas as
// funcoes para iniciar e manipular uma thread.
///////////////////////////////////////////////////////////////////////////////

#ifndef _TTHREAD
#define _TTHREAD

#include <windows.h>
#include <winbase.h>
#include "CImpExpRules.h"

class CLASS_MODIFIER TThread
{
protected:
	BOOL  enabled;                         // indica se objeto pode ser usado (read_only)
	BOOL  handle_OK;                       // indica se possui valid handle
	BOOL  suspended;                       // se thread est� suspensa ou ativa
	int   priority;                        // prioridade da thread
	int   stack_size;							   // tamanho da pilha na criacao da thread
	void  *thread_function;	               // ponteio para a funcao da thread
	void  *thread_parameter;               // parametro para a thread (dentro de thread_function pode usar thread_parameter)
	HANDLE thread_handle;                  // handle para thread criada
	int    thread_ID;                      // thread ID
	unsigned int suspend_counter;          // contador de numero de vezes que thread foi suspensa
public:
	   // constructor da thread
	TThread (   void  *thread_function_, 
		void  *thread_parameter_);
	// destructor
	~TThread (); 
	// inicia thread
	BOOL Start (int creation_flag_);
	// seta a prioridade da thread
	BOOL SetPriority (int priority_);
	// suspende a thread
	BOOL Suspend (void);
	// resume a thread
	BOOL Resume (void);
	
	HANDLE getHandle ();

};

#endif