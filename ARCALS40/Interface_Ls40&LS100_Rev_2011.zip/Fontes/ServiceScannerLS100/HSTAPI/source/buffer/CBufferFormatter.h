// CBufferFormatter.h: interface for the CBufferFormatter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CBUFFERFORMATTER_H__A182FEE2_9E7A_4FEB_85F3_ADCD5DE191CB__INCLUDED_)
#define AFX_CBUFFERFORMATTER_H__A182FEE2_9E7A_4FEB_85F3_ADCD5DE191CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"

#include "CList.h"
#include "CFieldBuffer.h"
#include "CCriticalSection.h"

const char DEFAULT_BUFFER_FORMATTER_LOG_FILE_NAME[] = "BufferFormatter.log";


#pragma warning(disable: 4251)


class CLASS_MODIFIER CBufferFormatter  
{
public:
	CBufferFormatter(const char* bufferName);
	virtual ~CBufferFormatter();

	void add (const char* fieldName, int fieldLen, CFieldBuffer::EFieldType type);
	void add (const char* fieldName, int fieldLen, CFieldBuffer::EFieldType type, CFieldBuffer::EFieldAligment aligment);

	void remove (int idx);
	void remove (const char* fieldName);

	CFieldBuffer* elmtAt(int idx);
	CFieldBuffer* elmtAt(const char* fieldName);

	int count ();

	void resetAllFields ();

	void serialize (CBuffer& output);
	void deserialize (CBuffer& input);

	int getAllSize ();

	const char* getBufferName();

	void log (const char* filePath = DEFAULT_BUFFER_FORMATTER_LOG_FILE_NAME);

	CFieldBuffer* operator[] (int idx);
	CFieldBuffer* operator[] (const char* fieldName);

private:
	static void deleteField (CFieldBuffer** obj);
	int indexOf (const char* fieldName);


private:

	CList<CFieldBuffer*> m_fieldList;
	
	static CCriticalSection m_cs;

	char m_bufferName[64];

};



#endif // !defined(AFX_CBUFFERFORMATTER_H__A182FEE2_9E7A_4FEB_85F3_ADCD5DE191CB__INCLUDED_)
