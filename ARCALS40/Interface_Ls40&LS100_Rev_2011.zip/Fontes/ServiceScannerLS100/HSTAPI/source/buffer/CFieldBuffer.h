// CFieldBuffer.h: interface for the CFieldBuffer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CFIELDBUFFER_H__1F475AB2_34EA_4459_9C22_17DCB1CA5A84__INCLUDED_)
#define AFX_CFIELDBUFFER_H__1F475AB2_34EA_4459_9C22_17DCB1CA5A84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"

#include "CBuffer.h"


const unsigned char DEFAULT_FIELD_BUFFER_BINARY_BYTE = 0x00;
const unsigned char DEFAULT_FIELD_BUFFER_NUMERIC_BYTE = 0x30;
const unsigned char DEFAULT_FIELD_BUFFER_ALPHA_BYTE = 0x20;

class CLASS_MODIFIER CFieldBuffer
{
public:
	enum EFieldType
	{
		EFT_Binary,
		EFT_Numeric,
		EFT_AlphaNumeric
	};

	enum EFieldAligment
	{
		EFA_Left,
		EFA_Rigth
	};


public:
	CFieldBuffer(const char* fieldName, int fieldLen, EFieldType type);
	CFieldBuffer(const char* fieldName, int fieldLen, EFieldType type, EFieldAligment aligment);
	virtual ~CFieldBuffer();
	
	const char* getFieldName ();
	int getFieldConfiguredLen ();
	int getFieldRealLen ();

	void fill ();
	void fill (const unsigned char value);

	EFieldType getType ();
	EFieldAligment getAligment ();

	bool isOverflow ();

	void setType (EFieldType type);
	void setAligment (EFieldAligment aligment);

	void setValue (const char* value);
	void setValue (const unsigned char* value, int len);
	void setValue (CBuffer& value);

	CBuffer* getValue ();

private:
	void initialize (const char* fieldName, int fieldLen, EFieldType type, EFieldAligment aligment);

private:
	char m_fieldName[32];
	int m_fieldLen;
	CBuffer m_value;
	EFieldType m_type;
	EFieldAligment m_aligment;
	bool m_overflow;

};

#endif // !defined(AFX_CFIELDBUFFER_H__1F475AB2_34EA_4459_9C22_17DCB1CA5A84__INCLUDED_)
