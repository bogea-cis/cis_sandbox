// CBufferFormatter.cpp: implementation of the CBufferFormatter class.
//
//////////////////////////////////////////////////////////////////////

#include "CBufferFormatter.h"

#include <string.h>
#include <stdio.h>
#include <time.h>

CCriticalSection CBufferFormatter::m_cs;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBufferFormatter::CBufferFormatter(const char* bufferName) : m_fieldList(deleteField)
{
	strcpy (m_bufferName, bufferName);
}

CBufferFormatter::~CBufferFormatter()
{

}


void CBufferFormatter::add (const char* fieldName, int fieldLen, CFieldBuffer::EFieldType type)
{
	m_fieldList.add(new CFieldBuffer(fieldName, fieldLen, type));
}

void CBufferFormatter::add (const char* fieldName, int fieldLen, CFieldBuffer::EFieldType type, CFieldBuffer::EFieldAligment aligment)
{
	m_fieldList.add(new CFieldBuffer(fieldName, fieldLen, type, aligment));
}

void CBufferFormatter::remove (int idx)
{
	if (idx >= m_fieldList.count() ||
		idx < 0)
	{
		return ;
	}

	m_fieldList.remove(idx);
}

void CBufferFormatter::remove (const char* fieldName)
{
	int idx = indexOf(fieldName);

	if (idx >= 0)
	{
		m_fieldList.remove(idx);
	}
}

CFieldBuffer* CBufferFormatter::elmtAt(int idx)
{
	if (idx >= m_fieldList.count() ||
		idx < 0)
	{
		return NULL;
	}
	else
	{
		return m_fieldList[idx];
	}
}

CFieldBuffer* CBufferFormatter::elmtAt(const char* fieldName)
{
	int idx = indexOf(fieldName);

	if (idx >= 0)
	{
		return m_fieldList[idx];
	}

	return NULL;
}

int CBufferFormatter::count ()
{
	return m_fieldList.count();
}

void CBufferFormatter::serialize (CBuffer& output)
{
	output.clear();

	int count = m_fieldList.count();

	CBuffer* pBuffer;
	for (int i = 0; i < count; i++)
	{
		pBuffer = m_fieldList[i]->getValue();
		output.append(*pBuffer);
	}
}

void CBufferFormatter::deserialize (CBuffer& input)
{
	int count = m_fieldList.count();


	if (input.length() >= this->getAllSize())
	{
		const unsigned char* pInput = input.getBuffer();
		CFieldBuffer* pField;
		int idx = 0;

		for (int i = 0; i < count; i++)
		{
			pField = m_fieldList[i];
			pField->setValue(&pInput[idx], pField->getFieldConfiguredLen());
		}
	}
}

void CBufferFormatter::resetAllFields ()
{
	int count = m_fieldList.count();

	CFieldBuffer* pField;

	for (int i = 0; i < count; i++)
	{
		pField = m_fieldList[i];
		pField->fill();
	}
}

int CBufferFormatter::getAllSize ()
{
	int ret = 0;
	int count = m_fieldList.count();

	CFieldBuffer* pField;

	for (int i = 0; i < count; i++)
	{
		pField = m_fieldList[i];
		ret += pField->getFieldConfiguredLen();
	}
	
	return ret;
}

const char* CBufferFormatter::getBufferName()
{
	return m_bufferName;
}

void CBufferFormatter::log (const char* filePath)
{
	FILE* fp;

	m_cs.enter();

	fp = fopen (filePath, "ab");

	if (fp)
	{
		CBuffer rawData;
		char dateHour[64] = {0};
		time_t now;
		time(&now);
		strftime(dateHour, sizeof(dateHour), "DATE: %d/%m/%Y\t%H:%M:%S", localtime(&now));

		fprintf (fp, "%s\tNAME: %s\n", dateHour, this->getBufferName());

		fprintf (fp, "FIELDS:\n");

		int listLen = m_fieldList.count();

		CFieldBuffer* pField;
		for (int i = 0; i < listLen; i++)
		{
			pField = m_fieldList[i];

			
			if (pField->isOverflow())
			{
				fprintf (fp, "! ->");
			}
			else
			{
				fprintf (fp, "\t");
			}
			
			switch (pField->getType())
			{
				case CFieldBuffer::EFT_Binary:
				{
					fprintf (fp, "%04d    %-25s[", pField->getFieldRealLen(), pField->getFieldName());
					CBuffer* pBuffer = pField->getValue();

					CBuffer unpacked;
					pBuffer->unpack(unpacked);
					fprintf (fp, "%s]\n", (char*)unpacked.getBuffer());
				}
				break;

				case CFieldBuffer::EFT_Numeric:
				case CFieldBuffer::EFT_AlphaNumeric:
				{
					fprintf (fp, "%04d    %-25s[%s]\n", pField->getFieldRealLen(), pField->getFieldName(), (char*)pField->getValue()->getBuffer());
				}
				break;
			}

			rawData.append(*pField->getValue());
		}
		
		
		fprintf (fp, "RAW DATA: [");

		int bufferLen = rawData.length();

		for (int j = 0; j < bufferLen; j++)
		{
			fprintf (fp, "%c", (char) rawData.at(j));
		}
		fprintf (fp, "]\n");
		fprintf (fp, "--------------------------------------------------------------------------------\n");

		fclose (fp);
	}

	m_cs.leave();
}

int CBufferFormatter::indexOf (const char* fieldName)
{
	int ret = -1;

	int count = m_fieldList.count();

	for (int i = 0; i < count; i++)
	{
		if (!stricmp (fieldName, m_fieldList[i]->getFieldName()))
		{
			ret = i;
			break;
		}
	}

	return ret;
}


CFieldBuffer* CBufferFormatter::operator[] (int idx)
{
	return elmtAt(idx);
}

CFieldBuffer* CBufferFormatter::operator[] (const char* fieldName)
{
	return elmtAt(fieldName);
}

void CBufferFormatter::deleteField (CFieldBuffer** obj)
{
	delete *obj;
}

