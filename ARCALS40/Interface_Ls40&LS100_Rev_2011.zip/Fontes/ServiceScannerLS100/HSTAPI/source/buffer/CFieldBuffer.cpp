// CFieldBuffer.cpp: implementation of the CFieldBuffer class.
//
//////////////////////////////////////////////////////////////////////

#include "CFieldBuffer.h"
#include <string.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFieldBuffer::CFieldBuffer(const char* fieldName, int fieldLen, EFieldType type)
{
	EFieldAligment aligment;

	switch (type)
	{
		case CFieldBuffer::EFT_Binary:
		{
			aligment = CFieldBuffer::EFA_Left;
		}
		break;
		case CFieldBuffer::EFT_Numeric:
		{
			aligment = CFieldBuffer::EFA_Rigth;
		}
		break;
		case CFieldBuffer::EFT_AlphaNumeric:
		{
			aligment = CFieldBuffer::EFA_Left;
		}
		break;
	}
	initialize (fieldName, fieldLen, type, aligment);
}

CFieldBuffer::CFieldBuffer(const char* fieldName, int fieldLen, EFieldType type, EFieldAligment aligment)
{
	initialize (fieldName, fieldLen, type, aligment);
}

void CFieldBuffer::initialize (const char* fieldName, int fieldLen, EFieldType type, EFieldAligment aligment)
{
	memcpy (m_fieldName, fieldName, sizeof(m_fieldName));
	m_fieldLen = fieldLen;
	m_type = type;
	m_aligment = aligment;
	m_overflow = false;

	this->fill();
}

CFieldBuffer::~CFieldBuffer()
{
}

const char* CFieldBuffer::getFieldName ()
{
	return m_fieldName;
}

int CFieldBuffer::getFieldConfiguredLen ()
{
	return m_fieldLen;
}

int CFieldBuffer::getFieldRealLen ()
{
	return m_value.length();
}

void CFieldBuffer::fill ()
{
	switch (m_type)
	{
		case CFieldBuffer::EFT_Binary:
		{
			fill (DEFAULT_FIELD_BUFFER_BINARY_BYTE);
		}
		break;
		case CFieldBuffer::EFT_Numeric:
		{
			fill (DEFAULT_FIELD_BUFFER_NUMERIC_BYTE);
		}
		break;
		case CFieldBuffer::EFT_AlphaNumeric:
		{
			fill (DEFAULT_FIELD_BUFFER_ALPHA_BYTE);
		}
		break;
	}
}

void CFieldBuffer::fill (const unsigned char value)
{
	m_value.setBuffer (value, m_fieldLen);
}

CFieldBuffer::EFieldType CFieldBuffer::getType ()
{
	return m_type;
}

CFieldBuffer::EFieldAligment CFieldBuffer::getAligment ()
{
	return m_aligment;
}

bool CFieldBuffer::isOverflow ()
{
	return m_overflow;
}

void CFieldBuffer::setType (CFieldBuffer::EFieldType type)
{
	m_type = type;
}

void CFieldBuffer::setAligment (CFieldBuffer::EFieldAligment aligment)
{
	m_aligment = aligment;
}

void CFieldBuffer::setValue (const char* value)
{
	setValue((const unsigned char*)value, strlen (value));
}

void CFieldBuffer::setValue (const unsigned char* value, int len)
{
	if (len > m_fieldLen)
	{
		//buffer overflow
		m_overflow = true;
	}
	else
	{
		m_overflow = false;
	}

	switch (m_aligment)
	{
		case CFieldBuffer::EFA_Left:
		{
			m_value.updateBuffer(0, value, len);
		}
		break;

		case CFieldBuffer::EFA_Rigth:
		{
			int start = m_fieldLen - len;

			if(start < 0)
			{
				start = 0;
			}
			
			m_value.updateBuffer(start, value, len);
		}
		break;
	}
}

void CFieldBuffer::setValue (CBuffer& value)
{
	setValue (value.getBuffer(), value.length());
}

CBuffer* CFieldBuffer::getValue ()
{
	return  &m_value;
}



