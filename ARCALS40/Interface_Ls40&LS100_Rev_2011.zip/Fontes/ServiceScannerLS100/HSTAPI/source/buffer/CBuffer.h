// CBuffer.h: interface for the CBuffer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CBUFFER_H__59F36CBC_9E2F_4948_AD80_ECB036DC37EE__INCLUDED_)
#define AFX_CBUFFER_H__59F36CBC_9E2F_4948_AD80_ECB036DC37EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"

const int DEFAULT_BUFFER_MEMORY_BLOCK_SIZE = 2048;

class CLASS_MODIFIER CBuffer  
{
public:
	CBuffer();
	CBuffer(const CBuffer& buffer);
	CBuffer(const unsigned char* buffer, int len);
	virtual ~CBuffer();

	void updateBuffer (int startIndex, const unsigned char* buffer, int len);

	void setBuffer (const unsigned char* buffer, int len);
	void setBuffer (const unsigned char fillByte, int len);
	void setBuffer (CBuffer& buffer);

	const unsigned char* getBuffer ();

	int length ();

	int compare (const CBuffer& buffer);
	int compare (const CBuffer& buffer, int len);
	int compare (const unsigned char* buffer, int len);

	void append (const CBuffer& buffer);
	void append (const unsigned char* buffer, int len);
	void append (const char* buffer);
	void append (unsigned long value);
	void append (long value);
	void append (unsigned int value);
	void append (int value);
	void append (unsigned short value);
	void append (short value);
	void append (unsigned char value);
	void append (char value);
	void append (bool value);

	void clear ();

	void setDefaultMemoryBlockLength (int len);
	int getDefaultMemoryBlockLength ();

	unsigned char at (int index);

	void subBuffer (int startIndex, CBuffer& output);
	void subBuffer (int startIndex, int len, CBuffer& output);
	void subBuffer (int startIndex, int len, unsigned char* output, int allocatedLen);

	void subBuffer (int startIndex, unsigned long& output);
	void subBuffer (int startIndex, long& output);

	void subBuffer (int startIndex, unsigned int& output);
	void subBuffer (int startIndex, int& output);

	void subBuffer (int startIndex, unsigned short& output);
	void subBuffer (int startIndex, short& output);

	void subBuffer (int startIndex, unsigned char& output);
	void subBuffer (int startIndex, char& output);

	void subBuffer (int startIndex, bool& output);


	void setInteratorIndex (int index);

	void getNext (CBuffer& output);
	void getNext (int len, CBuffer& output);
	void getNext (int len, unsigned char* output, int allocatedLen);
	void getNext (unsigned long& output);
	void getNext (long& output);
	void getNext (unsigned int& output);
	void getNext (int& output);
	void getNext (unsigned short& output);
	void getNext (short& output);
	void getNext (unsigned char& output);
	void getNext (char& output);
	void getNext (bool& output);

	int indexOf (int startIndex, const unsigned char* buffer, int bufferLen);

	void pack (CBuffer& packedBuffer);
	void unpack (CBuffer& unpackedBuffer);

	void resetIterator ();

	unsigned char operator[] (int index);

private:
	void adjustInternalAllocation (int size);
	void freeInternalAllocation ();

private:
	unsigned char* m_buffer;
	int m_bufferLen;
	int m_memoryBlockLen;
	int m_allocatedLen;
	int m_interatorIdx;

};

#endif // !defined(AFX_CBUFFER_H__59F36CBC_9E2F_4948_AD80_ECB036DC37EE__INCLUDED_)
