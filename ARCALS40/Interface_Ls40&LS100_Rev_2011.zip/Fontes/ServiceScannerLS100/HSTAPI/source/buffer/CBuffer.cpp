// CBuffer.cpp: implementation of the CBuffer class.
//
//////////////////////////////////////////////////////////////////////

#include "CBuffer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBuffer::CBuffer()
{
	resetIterator();
	m_memoryBlockLen = DEFAULT_BUFFER_MEMORY_BLOCK_SIZE;
	m_buffer = NULL;
	m_bufferLen = 0;
	m_allocatedLen = 0;
	adjustInternalAllocation(1);
}

CBuffer::CBuffer(const CBuffer& buffer)
{
	resetIterator();
	m_memoryBlockLen = buffer.m_memoryBlockLen;
	m_buffer = NULL;
	m_bufferLen = 0;
	m_allocatedLen = 0;

	setBuffer (buffer.m_buffer, buffer.m_bufferLen);
}

CBuffer::CBuffer(const unsigned char* buffer, int len)
{
	resetIterator();
	m_memoryBlockLen = DEFAULT_BUFFER_MEMORY_BLOCK_SIZE;
	m_buffer = NULL;
	m_bufferLen = 0;
	m_allocatedLen = 0;

	setBuffer (buffer, len);
}

CBuffer::~CBuffer()
{
	if (m_buffer)
	{
		delete[] m_buffer;
		m_buffer = NULL;
	}
}


unsigned char CBuffer::at (int index)
{
	return m_buffer[index];
}

unsigned char CBuffer::operator[] (int index)
{
	return at(index);
}

int CBuffer::indexOf (int startIndex, const unsigned char* buffer, int bufferLen)
{
	int ret = -1;

	//verifica se nao ultrapassa os limites
	if (startIndex + bufferLen <= m_bufferLen)
	{
		for (int i = startIndex; i <= m_bufferLen - bufferLen; i++)
		{
			if (memcmp(&m_buffer[i], buffer, bufferLen) == 0)
			{
				ret = i;
				break;
			}
		}
	}

	return ret;
}

void CBuffer::updateBuffer (int startIndex, const unsigned char* buffer, int len)
{
	if (startIndex + len > m_bufferLen)
	{
		adjustInternalAllocation((startIndex + len) - m_bufferLen);
		m_bufferLen = startIndex + len;
	}
	memcpy (&m_buffer[startIndex], buffer, len);
}


void CBuffer::setBuffer (const unsigned char* buffer, int len)
{
	clear();

	if (len > m_bufferLen)
	{
		adjustInternalAllocation(len);
	}

	memcpy (m_buffer, buffer, len);
	m_bufferLen = len;
	m_buffer[m_bufferLen] = '\0';
}

void CBuffer::setBuffer (const unsigned char fillByte, int len)
{
	clear();
	adjustInternalAllocation(len);
	memset (m_buffer, fillByte, len);
	m_bufferLen = len;
	m_buffer[m_bufferLen] = '\0';
}

void CBuffer::setBuffer (CBuffer& buffer)
{
	setBuffer(buffer.m_buffer, buffer.m_bufferLen);
}

const unsigned char* CBuffer::getBuffer ()
{
	return m_buffer;
}

int CBuffer::length ()
{
	return m_bufferLen;
}

int CBuffer::compare (const CBuffer& buffer)
{
	return compare (buffer.m_buffer, buffer.m_bufferLen);
}

int CBuffer::compare (const CBuffer& buffer, int len)
{
	return compare (buffer.m_buffer, len);
}

int CBuffer::compare (const unsigned char* buffer, int len)
{
	return memcmp(m_buffer, buffer, len);
}

void CBuffer::append (const CBuffer& buffer)
{
	append(buffer.m_buffer, buffer.m_bufferLen);
}

void CBuffer::append (const unsigned char* buffer, int len)
{
	//verifica se precisa alocar mais memoria
	adjustInternalAllocation(len);
	
	memcpy (&m_buffer[m_bufferLen], buffer, len);
	m_bufferLen += len;
	m_buffer[m_bufferLen] = '\0';
}

void CBuffer::append (const char* buffer)
{
	append( (const unsigned char*)buffer, strlen(buffer) );
}


void CBuffer::append (unsigned long value)
{
	append ((unsigned char*)&value, sizeof (unsigned long));
}

void CBuffer::append (long value)
{
	append ((unsigned char*)&value, sizeof (unsigned long));
}

void CBuffer::append (unsigned int value)
{
	append ((unsigned char*)&value, sizeof (unsigned int));
}

void CBuffer::append (int value)
{
	append ((unsigned char*)&value, sizeof (int));
}

void CBuffer::append (unsigned short value)
{
	append ((unsigned char*)&value, sizeof (unsigned short));
}

void CBuffer::append (short value)
{
	append ((unsigned char*)&value, sizeof (short));
}

void CBuffer::append (unsigned char value)
{
	append ((unsigned char*)&value, sizeof (unsigned char));
}

void CBuffer::append (char value)
{
	append ((unsigned char*)&value, sizeof (char));
}

void CBuffer::append (bool value)
{
	append ((unsigned char*)&value, sizeof (bool));
}

void CBuffer::clear ()
{
	m_bufferLen = 0;
}

void CBuffer::setInteratorIndex (int index)
{
	if (index >=0 &&
		index < m_bufferLen)
	{
		m_interatorIdx = index;
	}
}

void CBuffer::getNext (CBuffer& output)
{
	int len = m_bufferLen - m_interatorIdx;
	subBuffer(m_interatorIdx, len, output);
	m_interatorIdx += len;
}

void CBuffer::getNext (int len, CBuffer& output)
{
	subBuffer(m_interatorIdx, len, output);
	m_interatorIdx += len;
}

void CBuffer::getNext (int len, unsigned char* output, int allocatedLen)
{
	subBuffer (m_interatorIdx, len, output, allocatedLen);
	m_interatorIdx += len;
}

void CBuffer::getNext (unsigned long& output)
{
	getNext (sizeof(unsigned long), (unsigned char*)&output, sizeof(unsigned long));
}

void CBuffer::getNext (long& output)
{
	getNext (sizeof(long), (unsigned char*)&output, sizeof(long));
}

void CBuffer::getNext (unsigned int& output)
{
	getNext (sizeof(unsigned int), (unsigned char*)&output, sizeof(unsigned int));
}

void CBuffer::getNext (int& output)
{
	getNext (sizeof(int), (unsigned char*)&output, sizeof(int));
}

void CBuffer::getNext (unsigned short& output)
{
	getNext (sizeof(unsigned short), (unsigned char*)&output, sizeof(unsigned short));
}

void CBuffer::getNext (short& output)
{
	getNext (sizeof(short), (unsigned char*)&output, sizeof(short));
}

void CBuffer::getNext (unsigned char& output)
{
	getNext (sizeof(unsigned char), (unsigned char*)&output, sizeof(unsigned char));
}

void CBuffer::getNext (char& output)
{
	getNext (sizeof(char), (unsigned char*)&output, sizeof(char));
}

void CBuffer::getNext (bool& output)
{
	getNext (sizeof(bool), (unsigned char*)&output, sizeof(bool));
}

void CBuffer::adjustInternalAllocation (int aditionalSize)
{
	//verifica se o tamanho atual + o que vai ser 
	//adicionado eh maior que o alocado
	if (m_bufferLen + aditionalSize >= m_allocatedLen)
	{
		//precisa alocar mais
		
		//aloca aux
		unsigned char* aux = NULL;
		if (m_bufferLen > 0)
		{
			aux = new unsigned char[m_bufferLen];

			//copia conteudo para aux
			memcpy (aux, m_buffer, m_bufferLen);
		}

		//limpa buffer atual
		freeInternalAllocation ();

		//aloca mais um bloco de memoria
		m_allocatedLen = (m_memoryBlockLen * ((m_bufferLen + aditionalSize) / m_memoryBlockLen + 1));
		m_buffer = new unsigned char [m_allocatedLen + 1];
		memset (m_buffer, '\0', m_allocatedLen + 1);

		//copia de aux
		if (aux)
		{
			memcpy (m_buffer, aux, m_bufferLen);

			//destroi aux
			delete[] aux;
			aux = NULL;
		}
	}
}

void CBuffer::freeInternalAllocation ()
{
	if (m_buffer)
	{
		delete[] m_buffer;
		m_buffer = NULL;
		m_allocatedLen = 0;
	}
}

void CBuffer::setDefaultMemoryBlockLength (int len)
{
	m_memoryBlockLen = len;
}

int CBuffer::getDefaultMemoryBlockLength ()
{
	return m_memoryBlockLen;
}


void CBuffer::subBuffer (int startIndex, CBuffer& output)
{
	subBuffer (startIndex, m_bufferLen - startIndex, output);
}

void CBuffer::subBuffer (int startIndex, int len, CBuffer& output)
{
	output.clear();

	if (startIndex + len <= m_bufferLen)
	{
		output.setBuffer(&m_buffer[startIndex], len);
	}
}

void CBuffer::subBuffer (int startIndex, int len, unsigned char* output, int allocatedLen)
{
	if (startIndex + len <= m_bufferLen)
	{
		if (output &&
			allocatedLen >= len)
		{
			memcpy (output, &m_buffer[startIndex], len);
		}
	}
}

void CBuffer::subBuffer (int startIndex, unsigned long& output)
{
	subBuffer (startIndex,  sizeof (unsigned long), (unsigned char*)&output, sizeof (unsigned long));
}

void CBuffer::subBuffer (int startIndex, long& output)
{
	subBuffer (startIndex,  sizeof (long), (unsigned char*)&output, sizeof (long));
}

void CBuffer::subBuffer (int startIndex, unsigned int& output)
{
	subBuffer (startIndex,  sizeof (unsigned int), (unsigned char*)&output, sizeof (unsigned int));
}

void CBuffer::subBuffer (int startIndex, int& output)
{
	subBuffer (startIndex,  sizeof (int), (unsigned char*)&output, sizeof (int));
}

void CBuffer::subBuffer (int startIndex, unsigned short& output)
{
	subBuffer (startIndex,  sizeof (unsigned short), (unsigned char*)&output, sizeof (unsigned short));
}

void CBuffer::subBuffer (int startIndex, short& output)
{
	subBuffer (startIndex,  sizeof (short), (unsigned char*)&output, sizeof (short));
}

void CBuffer::subBuffer (int startIndex, unsigned char& output)
{
	subBuffer (startIndex, sizeof (unsigned char), (unsigned char*)&output, sizeof (unsigned char));
}

void CBuffer::subBuffer (int startIndex, char& output)
{
	subBuffer (startIndex, sizeof (char), (unsigned char*)&output, sizeof (char));
}

void CBuffer::subBuffer (int startIndex, bool& output)
{
	subBuffer (startIndex, sizeof (bool), (unsigned char*)&output, sizeof (bool));
}


void CBuffer::pack (CBuffer& packedBuffer)
{
    unsigned char packed;

	packedBuffer.clear();
	

	//Percorre o vetor de dados de entrada, para comprim�-los
	for( int i = 0; i < m_bufferLen; i+=2)
	{

		//Ex: 0011 1010 (A)
		int byteA = m_buffer[ i ];
		//Ex: 0011 1011 (B)
		int byteB= m_buffer[ i + 1 ];


		if (byteA >= 0x41)
		{
			byteA = 0x0A + (byteA - 0x41);
		}
		else
		{
			//Ex: 0000 1010 (A)
			byteA= byteA & 0x0F;
		}

		if (byteB >= 0x41)
		{
			byteB = 0x0A + (byteB - 0x41);
		}
		else
		{
			//Ex: 0000 1011 (B)
			byteB= byteB & 0x0F;
		}

		//Ex: 1010 0000 (A)
		byteA= byteA << 4;

		packed = 0;
		packed |= byteA;
		packed |= byteB;

		packedBuffer.append (packed);
	}
}

void CBuffer::unpack (CBuffer& unpackedBuffer)
{
    unsigned char al;
    unsigned char ba;

	unpackedBuffer.clear();
   
    for (int i = 0; i < m_bufferLen; i++ )
    { 	
        al = (m_buffer[i] & 0xf0); 
        al = (al >> 4);
        if ( al <= 9)
            al = al + 0x30;
        else
            al = al + 0x37;	
        
        ba = (m_buffer[i] & 0x0f); 
        if ( ba <= 9)
            ba = ba + 0x30;
        else
            ba = ba + 0x37;
        
		unpackedBuffer.append((unsigned char*)&al, 1);
		unpackedBuffer.append((unsigned char*)&ba, 1);
    }
}

void CBuffer::resetIterator ()
{
	m_interatorIdx = 0;
}

