// CKernelModeParallel.h: interface for the CKernelModeParallel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CKERNELMODEPARALLEL_H__F71CA72E_65F2_4DF5_9D01_43BC7FC59B40__INCLUDED_)
#define AFX_CKERNELMODEPARALLEL_H__F71CA72E_65F2_4DF5_9D01_43BC7FC59B40__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdlib.h>
#include "CInpOut32.h"
#include "CImpExpRules.h"
#include <windows.h>

const char GIVEIO_DEVICE_NAME[] = "\\\\.\\giveio";

const int DEFAULT_AVAILABITY_TIMEOUT = 10000;

class CLASS_MODIFIER CKernelModeParallel  
{
	public:

		CKernelModeParallel(const char* portName);

		CKernelModeParallel(int parallelDataAddr, 
					int parallelStatusAddr, 
					int parallelCommandAddr);

		virtual ~CKernelModeParallel();

		//abre comunica��o com a porta atravez do giveio
		bool open ();

		//fecha comunica��o com a porta
		void close ();

		//leitura de dados da porta
		//TODO, por equato nao tenho com testar esta fun��o pois a impressora
		//que estou desenvolvendo (e a maioria delas), n�o necessitam receber dados
		//int read (void* pData, size_t iLen, DWORD* pdwRead = NULL, DWORD dwTimeout = 0);

		//escrita de dados na porta
		//int write (const void* pData, unsigned int iLen, unsigned int* pdwWritten = NULL, unsigned int dwTimeout = 0);
		int writeByte (unsigned char byte);
		int writeByteArray (const unsigned char* byteArray, unsigned int byteArrayLen);


		//Status Register 0x309 (LPT1)

		//obtem byte de status da impressora
		unsigned char getStatusByte ();

		//verifica o estado o pino busy
		bool busyPin (unsigned char statusByte);

		//verifica o estado o pino ack
		bool ackPin (unsigned char statusByte);

		//verifica o estado o pino paper
		bool paperPin (unsigned char statusByte);

		//verifica o estado o pino select
		bool selectPin (unsigned char statusByte);

		//verifica o estado o pino error
		bool errorPin (unsigned char statusByte);


		//Command register 0x30A (LPT1)

		//obtem byte de status da impressora
		unsigned char getCommandByte ();

		//seta valor do pino enable interruption
		void setEnableIntPin (bool value);

		//seta valor do pino select
		void setSelectPin (bool value);

		//seta valor do pino init
		void setInitPin (bool value);

		//seta valor do pino autoFeed
		void setAutoFeedPin (bool value);

		//seta valor do pino strobe
		void setStrobePin (bool value);

		//seta commandPins
		void setCommandPinsByte (unsigned char value);

	private:

		//aguarda pino busy ser setado para 0
		bool waitAvailability (int miliseconds);

	private:
		HANDLE m_handle;
		CInpOut32* m_data;
		CInpOut32* m_status;
		CInpOut32* m_command;
};
#endif // !defined(AFX_CKERNELMODEPARALLEL_H__F71CA72E_65F2_4DF5_9D01_43BC7FC59B40__INCLUDED_)
