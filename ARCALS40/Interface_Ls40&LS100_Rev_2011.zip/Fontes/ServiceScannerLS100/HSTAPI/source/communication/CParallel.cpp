// CParallel.cpp: implementation of the CParallel class.
//Luis Gustavo de Brito
//////////////////////////////////////////////////////////////////////

#include "CParallel.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CParallel::CParallel()
{
	m_handle = NULL;
	m_writeSyncEvent = NULL;
	m_readSyncEvent = NULL;

}


CParallel::~CParallel()
{
	if (m_handle)
	{
		CloseHandle(m_handle);
		m_handle = NULL;
	}
	if (m_writeSyncEvent)
	{
		CloseHandle(m_writeSyncEvent);
		m_writeSyncEvent = NULL;
	}
	if (m_readSyncEvent)
	{
		CloseHandle(m_readSyncEvent);
		m_readSyncEvent = NULL;
	}
}


CParallel::EPort CParallel::checkPort (const char* portName)
{
	HANDLE hFile = ::CreateFile(portName, 
						   GENERIC_READ|GENERIC_WRITE, 
						   0, 
						   0, 
						   OPEN_EXISTING, 
						   0,
						   0);

	// Check if we could open the device
	if (hFile == INVALID_HANDLE_VALUE)
	{
		// Display error
		switch (::GetLastError())
		{
			case ERROR_FILE_NOT_FOUND:
			{
				// The specified COM-port does not exist
				return EPortNotAvailable;
			}

			case ERROR_ACCESS_DENIED:
			{
				// The specified COM-port is in use
				return EPortInUse;
			}

			default:
			{
				// Something else is wrong
				return EPortUnknownError;
			}
		}
	}

	// Close handle
	::CloseHandle(hFile);

	// Port is available
	return EPortAvailable;


}


int CParallel::open (const char* portName, bool overlapped)
{
	m_lastError = ERROR_SUCCESS;
	
	strcpy (m_portName, portName);

	m_writeSyncEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	m_readSyncEvent  = CreateEvent(NULL, TRUE, FALSE, NULL);


	m_overlapped = overlapped;
	m_handle = ::CreateFile(portName,
						   GENERIC_READ|GENERIC_WRITE, 
						   0,
						   0,
						   OPEN_EXISTING,
						   overlapped ? FILE_FLAG_OVERLAPPED : 0,
						   0);

	if (m_handle == INVALID_HANDLE_VALUE)
	{
		m_lastError = ::GetLastError();
	}

	return m_lastError;
}


int CParallel::close ()
{
	m_lastError = ERROR_SUCCESS;

	if (m_handle)
	{
		CloseHandle(m_handle);
		m_handle = NULL;
	}
	if (m_writeSyncEvent)
	{
		CloseHandle(m_writeSyncEvent);
		m_writeSyncEvent = NULL;
	}
	if (m_readSyncEvent)
	{
		CloseHandle(m_readSyncEvent);
		m_readSyncEvent = NULL;
	}
	return m_lastError;
}


int CParallel::read (void* pData, size_t iLen, DWORD* pdwRead/* = NULL*/, DWORD dwTimeout/* = 0*/)
{
	DWORD dwRead = 0;
	m_lastError = ERROR_SUCCESS;

	if (!pdwRead)
	{
		pdwRead = &dwRead;
	}

	*pdwRead = 0;

	// Wait for the event to happen
	LPOVERLAPPED lpOvInternal = NULL;
	OVERLAPPED ovInternal;
	if (m_overlapped)
	{
		// Setup our own overlapped structure
		memset(&ovInternal,0,sizeof(ovInternal));
		ovInternal.hEvent = m_writeSyncEvent;

		// Use our internal overlapped structure
		lpOvInternal = &ovInternal;
	}


	if (! ::ReadFile(m_handle, pData, iLen, pdwRead, lpOvInternal))
	{
		long lastError = ::GetLastError();

		if (lastError != ERROR_IO_PENDING)
		{
			// Save the error
			m_lastError = lastError;
			return m_lastError;
		}

		// Wait for the overlapped operation to complete
		switch (::WaitForSingleObject(lpOvInternal->hEvent ,dwTimeout))
		{
			case WAIT_OBJECT_0:
			{
				// The overlapped operation has completed
				if (!::GetOverlappedResult(m_handle,lpOvInternal,pdwRead,FALSE))
				{
					// Set the internal error code
					m_lastError = ::GetLastError();
					return m_lastError;
				}
				break;
			}

			case WAIT_TIMEOUT:
			{
				// Cancel the I/O operation
				::CancelIo(m_handle);

				// The operation timed out. Set the internal error code and quit
				m_lastError = ERROR_TIMEOUT;
				return m_lastError;
			}

			default:
			{
				// Set the internal error code
				m_lastError = ::GetLastError();
				return m_lastError;
			}
		}
	}

	return m_lastError;
}


int CParallel::write (const void* pData, size_t iLen, DWORD* pdwWritten/* = NULL*/, DWORD dwTimeout/* = 0*/)
{
	DWORD dwWritten = 0;
	m_lastError = ERROR_SUCCESS;
	
	if (!pdwWritten)
	{
		pdwWritten = &dwWritten;
	}

	*pdwWritten = 0;

	// Wait for the event to happen
	LPOVERLAPPED lpOvInternal = NULL;
	OVERLAPPED ovInternal;
	if (m_overlapped)
	{
		// Setup our own overlapped structure
		memset(&ovInternal,0,sizeof(ovInternal));
		ovInternal.hEvent = m_writeSyncEvent;

		// Use our internal overlapped structure
		lpOvInternal = &ovInternal;
	}

	if (! ::WriteFile(m_handle, pData, iLen, pdwWritten, lpOvInternal))
	{
		m_lastError = ::GetLastError();

		long lastError = ::GetLastError();

		if (lastError != ERROR_IO_PENDING)
		{
			// Save the error
			m_lastError = lastError;
			return m_lastError;
		}

		// Wait for the overlapped operation to complete
		switch (::WaitForSingleObject(lpOvInternal->hEvent ,dwTimeout))
		{
			case WAIT_OBJECT_0:
			{
				// The overlapped operation has completed
				if (!::GetOverlappedResult(m_handle,lpOvInternal,pdwWritten, FALSE))
				{
					// Set the internal error code
					m_lastError = ::GetLastError();
					return m_lastError;
				}
				break;
			}

			case WAIT_TIMEOUT:
			{
				// Cancel the I/O operation
				::CancelIo(m_handle);

				// The operation timed out. Set the internal error code and quit
				m_lastError = ERROR_TIMEOUT;
				return m_lastError;
			}

			default:
			{
				// Set the internal error code
				m_lastError = ::GetLastError();
				return m_lastError;
			}
		}

	}

	return m_lastError;
}


int CParallel::purge ()
{
	m_lastError = ERROR_SUCCESS;

	//if (!::PurgeComm(m_handle, PURGE_TXCLEAR | PURGE_RXCLEAR))
	//{
		// Set the internal error code
	//	m_lastError = ::GetLastError();
	//-		_RPTF0(_CRT_WARN,"CSerial::Purge - Overlapped completed without result\n");
	//}
	return 	m_lastError;
}


BYTE CParallel::getStatus ()
{
	PAR_QUERY_INFORMATION inf;
	DWORD bytesReturned;
	BOOL rc;


	rc = DeviceIoControl (m_handle,
						IOCTL_PAR_QUERY_INFORMATION,
						NULL,
						0,
						(LPVOID)&inf,
						sizeof (PAR_QUERY_INFORMATION),
						&bytesReturned,
						NULL);

	if( !rc ){

		//TODO
		//Verificar se "status = 0" pode ser considerado erro
		inf.Status= 0;

	}//if( !rc )

	return inf.Status;

}


void CParallel::setStatus ()
{
	PAR_SET_INFORMATION inf;
	DWORD bytesReturned;
	BOOL rc;

	inf.Init = PARALLEL_INIT;


	rc = DeviceIoControl (m_handle,
						IOCTL_PAR_QUERY_INFORMATION,
						(LPVOID)&inf,
						sizeof (PAR_QUERY_INFORMATION),
						NULL,
						0,
						&bytesReturned,
						NULL);

	if( !rc ){

		//TODO
		//logar

	}

}


const char* CParallel::getPortName ()
{
	return m_portName;
}

