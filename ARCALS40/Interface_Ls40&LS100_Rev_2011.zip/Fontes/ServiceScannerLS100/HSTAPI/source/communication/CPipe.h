///////////
//Defines//
///////////

#ifndef HST_COMMUNICATION_CPIPE_H
#define HST_COMMUNICATION_CPIPE_H


//Verifica qual o modo de declara��o da classe deve ser utilizado
///HST_DLL_LIB_IMPORT : A classe est� contida em uma DLL, e seu s�mbolo ser� importado.
///                     Este define deve ser utilizado quando o projeto deseja utilizar uma classe contida em uma DLL ( que seja exportada ).
///HST_DLL_LIB_EXPORT : A classe est� contida em uma DLL, e seu s�mbolo ser� exportado.
///                     Este define deve ser utilizado quando o projeto ( DLL ) deseja torna a classe acess�vel para uso.
///"ELSE"             : A classe ser� utilizada atrav�s da inclus�o de seu c�digo fonte.
#ifdef HST_DLL_LIB_IMPORT
	#define CLASS_MODIFIER __declspec(dllimport)
#elif HST_DLL_LIB_EXPORT
	#define CLASS_MODIFIER __declspec(dllexport)
#else 
	#define CLASS_MODIFIER 
#endif


////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>
#include "CImpExpRules.h"


////////////////////////
//Includes espec�ficos//
////////////////////////


///////////////////
//Namespaces(Uso)//
///////////////////


//////////////////////////
//Namespaces(Declara��o)//
//////////////////////////



//////////////
//Enumerados//
//////////////

	enum EPipeRole	{
					prUnknown	/**TODO - Descri��o*/,
					prClient	/**TODO - Descri��o*/,
					prServer	/**TODO - Descri��o*/
					};

	enum EPipeType	{
					ptUnknown	/**TODO - Descri��o*/,
					ptNammed	/**TODO - Descri��o*/,
					ptUnnamed	/**TODO - Descri��o*/
					};

	enum EPipeInitializationState	{
									pisUnknown	/**TODO - Descri��o*/,
									pisInvalid	/**TODO - Descri��o*/,
									pisOpened	/**TODO - Descri��o*/,
									pisCreated	/**TODO - Descri��o*/
									};


//////////
//Classe//
//////////

/**
\class CPipe
\brief Breve descri��o sobre CPipe.

Descri��o detalhada sobre as funcionalidades e caracter�sticas de CPipe.

\author Diego Felipe Lassa
\version 1.0.0.0
\date 30/04/2008
\bug
\warning
*/
class CLASS_MODIFIER CPipe{

	private:

		///////////
		//Membros//
		///////////

		/***/
		char* m_name;

		/**Handle para o pipe utilizado*/
		HANDLE m_handle;

		/***/
		int m_access;

		/**Variable that receives the read handle for the pipe.*/
		HANDLE m_readHandle;

		/**Variable that receives the write handle for the pipe.*/
		HANDLE m_writeHandle;

		/***/
		int m_suggestedSize;

		/***/
		int m_maxInstances;

		/***/
		int m_outBufferSize;

		/***/
		int m_inBufferSize;

		/***/
		LPSECURITY_ATTRIBUTES m_securityAttributes;

		/***/
		LPOVERLAPPED m_overlapped;

		/**Armazena o status de inicializa��o do Pipe*/
		EPipeInitializationState m_initializationState;

		/***/
		EPipeRole m_pipeRole;


		/**
		\brief
		\param
		\param
		\param
		\param
		\return
		*/
		bool createUnnamedPipe( PHANDLE readPipe, PHANDLE writePipe, LPSECURITY_ATTRIBUTES securityAttributes, int suggestedSize );

		/**
		\brief
		\param
		\param
		\param
		\param
		\param
		\param
		\param
		\param
		\return
		*/
		HANDLE createNamedPipe( const char*  name, int openMode, int pipeMode, int maxInstances, int outBufferSize, int inBufferSize, int defaultTimeOut, LPSECURITY_ATTRIBUTES securityAttributes );

	protected:


		/**
		\brief
		\return
		*/
		const char* getName();

		/**
		\brief
		\param
		*/
		void setName( const char* name );


		/**
		\brief
		\return
		*/
		HANDLE getReadHandle();

		/**
		\brief
		\param
		*/
		void setReadHandle( HANDLE value );


		/**
		\brief
		\return
		*/
		HANDLE getWriteHandle();

		/**
		\brief
		\param
		*/
		void setWriteHandle( HANDLE value );


		/**
		\brief
		\param
		*/
		void setPipeRole( EPipeRole value );

	public:

		////////////////////////////
		//Construtores & Destrutor//
		////////////////////////////

		/**
		\brief
		*/
		CPipe();

		/**
		\brief
		\param
		*/
		CPipe( const char* pipeName );

		/**
		\brief
		\param
		\param
		*/
		CPipe( const char* pipeName, int access );

		/**
		\brief
		*/
		~CPipe();


		/**
		\brief
		*/
		void initialization();

		/**
		\brief
		*/
		void finalization();


		///////////
		//M�todos//
		///////////

		/**
		\brief
		\param
		\param
		\return
		*/
		virtual int write( const void* buffer, const unsigned int bufferSize );

		/**
		\brief
		\param
		\param
		\return
		*/
		virtual int write( const char* buffer, const unsigned int bufferSize );

		/**
		\brief
		\return
		*/
		virtual int read();

		/**
		\brief
		\param
		\param
		\return
		*/
		virtual int read( char* buffer, const unsigned int bufferSize );


		/**
		\brief
		\param
		\param
		\param
		\return
		*/
		virtual int peek( char* buffer, const unsigned int bufferSize, unsigned int *bytesAvailable, unsigned int *bytesLeft );

		/**
		\brief
		\param
		\param
		\return
		*/
		virtual int peek( char* buffer, const unsigned int bufferSize );


		/**
		\brief
		\return
		*/
		int getMaxInstances();

		/**
		\brief
		\param
		*/
		void setMaxInstances( int value );

		/**
		\brief
		\return
		*/
		int getOutBufferSize();

		/**
		\brief
		\param
		*/
		void setOutBufferSize( int value );

		/**
		\brief
		\return
		*/
		int getInBufferSize();

		/**
		\brief
		\param
		*/
		void setInBufferSize( int value );

	
		/**
		\brief
		\return
		*/
		LPSECURITY_ATTRIBUTES getSecurityAttributes();

		/**
		\brief
		\param
		*/
		void setSecurityAttributes( LPSECURITY_ATTRIBUTES value );


		/**
		\brief
		\return
		*/
		LPOVERLAPPED getOverlapped();

		/**
		\brief
		\param
		*/
		void setOverlapped( LPOVERLAPPED value );

		/**
		\brief
		\return
		*/
		EPipeRole getPipeRole();


		//////////////
		//Constantes//
		//////////////

		/***/
		static const int ACCESS_INBOUND;
		/***/
		static const int ACCESS_OUTBOUND;
		/***/
		static const int ACCESS_DUPLEX;

		/***/
		////TODO - Verificar: N�o encontrado nos Headers
		//static const int ACCESS_FLAG_FIRST_PIPE_INSTANCE;
		/***/
		static const int ACCESS_FLAG_WRITE_THROUGH;
		/***/
		static const int ACCESS_FLAG_OVERLAPPED;

		/***/
		static const int ACCESS_SECURITY_WRITE_DAC;
		/***/
		static const int ACCESS_SECURITY_WRITE_OWNER;
		/***/
		static const int ACCESS_SECURITY_SYSTEM;

		/***/
		static const int UNLIMITED_INSTANCES;


		////////
		//Mode//
		////////
		
		/***/
		static const int TYPE_BYTE;
		/***/
		static const int TYPE_MESSAGE;

		/***/
		static const int READMODE_BYTE;
		/***/
		static const int READMODE_MESSAGE;

		/***/
		static const int WAIT;
		/***/
		static const int NOWAIT;

};//CPipe



#endif//#ifndef HST_COMMUNICATION_CPIPE_H
