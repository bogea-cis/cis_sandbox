// CInpOut32.cpp: implementation of the CInpOut32 class.
//
//////////////////////////////////////////////////////////////////////

#include <conio.h>
#include "CInpOut32.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInpOut32::CInpOut32(int addr)
{
	m_addr = addr;
}

CInpOut32::~CInpOut32()
{

}

bool CInpOut32::putByte (int b)
{
	return _outp(m_addr, b) == b ? true : false;
}

unsigned char CInpOut32::getByte ()
{
	return _inp(m_addr);
}

int CInpOut32::getAddr()
{
	return m_addr;
}
