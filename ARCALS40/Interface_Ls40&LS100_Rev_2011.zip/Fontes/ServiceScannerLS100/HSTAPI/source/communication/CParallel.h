// CParallel.h: interface for the CParallel class.
//Luis Gustavo de Brito
//////////////////////////////////////////////////////////////////////

#ifndef HST_COMMUNICATION_CPARALLEL_H
#define HST_COMMUNICATION_CPARALLEL_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include <winioctl.h>
#include "CImpExpRules.h"
#include "ntddpar.h"


class CLASS_MODIFIER CParallel  
{
	public:
		// Port availability
		typedef enum
		{
			EPortUnknownError = -1/**Unknown error occurred*/,
			EPortAvailable    =  0/**Port is available*/,
			EPortNotAvailable =  1/**Port is not present*/,
			EPortInUse        =  2/**Port is in use*/
		} 
		EPort;

	public:
		CParallel();
		virtual ~CParallel();

		static EPort checkPort (const char* portName);

		int open (const char* portName, bool overlapped = true);
		int close ();

		int read (void* pData, size_t iLen, DWORD* pdwRead = NULL, DWORD dwTimeout = 0);
		int write (const void* pData, size_t iLen, DWORD* pdwWritten = NULL, DWORD dwTimeout = 0);

		int purge ();

		BYTE getStatus ();
		void setStatus ();

		const char* getPortName ();

	private:
		HANDLE m_handle;
		HANDLE m_writeSyncEvent;
		HANDLE m_readSyncEvent;

		char m_portName[16];
		int m_lastError;
		bool m_overlapped;

};//CParallel


#endif//HST_COMMUNICATION_CPARALLEL_H
