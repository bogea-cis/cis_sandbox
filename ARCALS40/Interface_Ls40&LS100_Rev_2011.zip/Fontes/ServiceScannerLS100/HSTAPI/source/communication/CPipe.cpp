////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////


////////////////////////
//Includes espec�ficos//
////////////////////////

#include "CPipe.h"


//////////////
//Namespaces//
//////////////


////////////////////////////////////////
//Inicializa��es ( membros est�ticos )//
////////////////////////////////////////

//Access Modes
//////////////
const int CPipe::ACCESS_INBOUND	= PIPE_ACCESS_INBOUND;
const int CPipe::ACCESS_OUTBOUND= PIPE_ACCESS_OUTBOUND;
const int CPipe::ACCESS_DUPLEX	= PIPE_ACCESS_DUPLEX;

//Access Flags
//////////////
////TODO - Verificar: N�o encontrado nos Headers
//const int CPipe::ACCESS_FLAG_FIRST_PIPE_INSTANCE= FILE_FLAG_FIRST_PIPE_INSTANCE;
const int CPipe::ACCESS_FLAG_WRITE_THROUGH		= FILE_FLAG_WRITE_THROUGH;
const int CPipe::ACCESS_FLAG_OVERLAPPED			= FILE_FLAG_OVERLAPPED;

//Security Access Modes
///////////////////////
const int CPipe::ACCESS_SECURITY_WRITE_DAC	= WRITE_DAC;
const int CPipe::ACCESS_SECURITY_WRITE_OWNER= WRITE_OWNER;
const int CPipe::ACCESS_SECURITY_SYSTEM		= ACCESS_SYSTEM_SECURITY;

//Mode
//////
const int CPipe::TYPE_BYTE		= PIPE_TYPE_BYTE;
const int CPipe::TYPE_MESSAGE	= PIPE_TYPE_MESSAGE;

const int CPipe::READMODE_BYTE		=PIPE_READMODE_BYTE;
const int CPipe::READMODE_MESSAGE	=PIPE_READMODE_MESSAGE;

const int CPipe::WAIT	=PIPE_WAIT;
const int CPipe::NOWAIT	=PIPE_NOWAIT;


//N�mero m�ximo de instancias que podem ser criadas para um dado Pipe
/////////////////////////////////////////////////////////////////////
const int CPipe::UNLIMITED_INSTANCES		= PIPE_UNLIMITED_INSTANCES;


//////////////////////////////
//Implementa��es dos m�todos//
//////////////////////////////


////////////////////////////
//Construtores & Destrutor//
////////////////////////////

CPipe::CPipe()
{

	this->initialization();

	bool pipeCreated= this->createUnnamedPipe( &this->m_readHandle, &this->m_writeHandle, NULL, 0 );

	//Verifica se foi poss�vel criar o Pipe
	if( ! pipeCreated ){

		//Obt�m o c�digo do erro
		DWORD errorCode= GetLastError();

	}//if( ! pipeCreated )

}


CPipe::CPipe( const char* pipeName )
{

	this->initialization();

	HANDLE pipeHandle= NULL; 

	pipeHandle= this->createNamedPipe( pipeName, CPipe::ACCESS_DUPLEX, CPipe::TYPE_BYTE, this->getMaxInstances(), this->getOutBufferSize(), this->getInBufferSize(), 0, this->getSecurityAttributes() );

	//Verifica se foi poss�vel criar o Pipe
	if( pipeHandle == NULL ){

		//Obt�m o c�digo do erro
		DWORD errorCode= GetLastError();

	}//if( pipeHandle == NULL )

}


CPipe::~CPipe()
{

	this->finalization();

}


void CPipe::initialization()
{

	this->m_name= NULL;

	this->setReadHandle( NULL );

	this->setWriteHandle( NULL );
	
	this->m_handle= NULL;

	this->setMaxInstances( CPipe::UNLIMITED_INSTANCES );

	this->setOutBufferSize( 1024 );

	this->setInBufferSize( 1024 );

	this->m_securityAttributes= NULL;

	this->m_overlapped= NULL;

	this->setPipeRole( prUnknown );

}


void CPipe::finalization()
{
}


///////////////////////
//Setter�s & Getter�s//
///////////////////////

const char* CPipe::getName()
{

	return const_cast< const char* >( this->m_name );

}

void CPipe::setName( const char* name )
{

	if( this->m_name != NULL ){

		free( this->m_name );

	}//if( this->m_name != NULL )

	//Obs: Tamanho m�ximo para o nome do pipe = 256 caracteres
	if( strlen( name ) <= 256 ){

		this->m_name= strdup( name );

	}else{//if( strlen( name ) <= 256 )

		this->m_name= (char*)malloc( 256 + 1 );
		memset( this->m_name, '\0', 256+1 );

		strncpy( this->m_name, name, 256 );

	}//else if( strlen( name ) <= 256 )

}


HANDLE CPipe::getReadHandle()
{

	return this->m_readHandle;

}

void CPipe::setReadHandle( HANDLE value )
{

	this->m_readHandle= value;

}

HANDLE CPipe::getWriteHandle()
{

	return this->m_writeHandle;

}

void CPipe::setWriteHandle( HANDLE value )
{

	this->m_writeHandle= value;

}


int CPipe::getMaxInstances()
{

	return this->m_maxInstances;

}

void CPipe::setMaxInstances( int value )
{

	if( value >= 0 ){

		this->m_maxInstances= value;

	}else{//if( value >= 0 )

		this->m_maxInstances= 0;

	}//else if( value >= 0 )

}


int CPipe::getOutBufferSize()
{

	return this->m_outBufferSize;

}

void CPipe::setOutBufferSize( int value )
{

	if( value >= 0 ){

		this->m_outBufferSize= value;

	}else{//if( value >= 0 )

		this->m_outBufferSize= 0;

	}//else if( value >= 0 )

}


int CPipe::getInBufferSize()
{

	return this->m_outBufferSize;

}

void CPipe::setInBufferSize( int value )
{

	if( value >= 0 ){

		this->m_inBufferSize= value;

	}else{//if( value >= 0 )

		this->m_inBufferSize= 0;

	}//else if( value >= 0 )

}


LPSECURITY_ATTRIBUTES CPipe::getSecurityAttributes()
{

	return this->m_securityAttributes;

}

void CPipe::setSecurityAttributes( LPSECURITY_ATTRIBUTES value )
{

	if( this->m_securityAttributes != NULL ){

		delete this->m_securityAttributes;

	}//if( this->m_securityAttributes != NULL )

	this->m_securityAttributes= value;

}


LPOVERLAPPED CPipe::getOverlapped()
{

	return this->m_overlapped;

}

void CPipe::setOverlapped( LPOVERLAPPED value )
{

	if( this->m_overlapped != NULL ){

		delete this->m_overlapped;

	}//if( this->m_overlapped != NULL )

	this->m_overlapped= value;

}

//////////////////
//Demais M�todos//
//////////////////

bool CPipe::createUnnamedPipe( PHANDLE readPipe, PHANDLE writePipe, LPSECURITY_ATTRIBUTES securityAttributes, int suggestedSize )
{

	return ( CreatePipe( readPipe, writePipe, securityAttributes, suggestedSize ) != 0 );

}

HANDLE CPipe::createNamedPipe( const char* name, int openMode, int pipeMode, int maxInstances, int outBufferSize, int inBufferSize, int defaultTimeOut, LPSECURITY_ATTRIBUTES securityAttributes )
{

	return CreateNamedPipe( name, openMode, pipeMode, maxInstances, outBufferSize, inBufferSize, defaultTimeOut, securityAttributes );

}

int CPipe::write( const void* buffer, const unsigned int bufferSize )
{

	//Stub
	return 0;

}

int CPipe::write( const char* buffer, const unsigned int bufferSize )
{

	BOOL writeSuccessful = false;

	unsigned int bytesWritten= 0;

	writeSuccessful= WriteFile(
								this->getWriteHandle(),
								(LPCVOID)buffer,
								(DWORD)bufferSize,
								(LPDWORD)&bytesWritten,
								this->getOverlapped()
								);


	return bytesWritten;

}


int CPipe::read()
{

	//Stub!

	return 0;

}

int CPipe::read( char* buffer, const unsigned int bufferSize )
{

	BOOL readSuccessful = false;

	unsigned int bytesRead= 0;

	readSuccessful= ReadFile(
							this->getWriteHandle(),
							(LPVOID)buffer,
							(DWORD)bufferSize,
							(LPDWORD)&bytesRead,
							this->getOverlapped()
							);


	return bytesRead;

}


int CPipe::peek( char* buffer, const unsigned int bufferSize, unsigned int *bytesAvailable, unsigned int *bytesLeft )
{

	BOOL readSuccessful = false;

	unsigned int bytesRead= 0;

	readSuccessful= PeekNamedPipe(
								this->getWriteHandle(),
								(LPVOID)buffer,
								(DWORD)bufferSize,
								(LPDWORD)&bytesRead,
								(LPDWORD)bytesAvailable,
								(LPDWORD)bytesLeft
								);


	return bytesRead;

}

int CPipe::peek( char* buffer, const unsigned int bufferSize )
{

	unsigned int bytesRead= 0;
	unsigned int bytesAvailable= 0;
	unsigned int bytesLeft= 0;

	bytesRead= this->peek( buffer, bufferSize, &bytesAvailable, &bytesLeft );

	return bytesRead;

}


EPipeRole CPipe::getPipeRole()
{

	return this->m_pipeRole;

}

void CPipe::setPipeRole( EPipeRole value )
{

	this->m_pipeRole= value;

}