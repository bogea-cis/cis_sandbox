// CInpOut32.h: interface for the CInpOut32 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CINPOUT32_H__5B1B51D7_5047_4FAE_8DA5_24110E57E5F3__INCLUDED_)
#define AFX_CINPOUT32_H__5B1B51D7_5047_4FAE_8DA5_24110E57E5F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"

class CLASS_MODIFIER CInpOut32  
{
public:
	CInpOut32(int addr);
	virtual ~CInpOut32();

	bool putByte (int b);

	unsigned char getByte ();

	int getAddr();
private:
	int m_addr;
};

#endif // !defined(AFX_CINPOUT32_H__5B1B51D7_5047_4FAE_8DA5_24110E57E5F3__INCLUDED_)
