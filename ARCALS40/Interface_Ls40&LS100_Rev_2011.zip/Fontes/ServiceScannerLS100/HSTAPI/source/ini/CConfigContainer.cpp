///////////////////////////////////////////////////////////////////////////////
// Descricao:
// Autor: Amadeu Vilar Filho / Luis Gustavo de Brito
// Data de criacao: 11/12/2007
//
// Alteracoes:
//
///////////////////////////////////////////////////////////////////////////////

#include "CConfigContainer.h"
#include "CConfigSerializer.h"


CConfigContainer::CConfigContainer(const char* fileName) 
{
	strcpy (m_fileName, fileName);
	m_section = new CList<CSectionContainer*>(CConfigContainer::onDelete, NULL);
	m_sectionNames.clear();
	m_section->clear();
}

CConfigContainer::~CConfigContainer() {
	this->clearSections();

	delete m_section;
}

void CConfigContainer::clearSections() {
	m_sectionNames.clear();
	m_section->clear();
}

void CConfigContainer::setSection(CSectionContainer* section) {
	
	int idx = m_sectionNames.indexOf(section->getName());

	//so adiciona se nao existir
	if (idx < 0)
	{
		m_sectionNames.add(section->getName());
		m_section->add(section);
	}
	//m_sectionContainer[section->getName()] = section;
}

CSectionContainer* CConfigContainer::getSection(const char* name) {

	CSectionContainer* ret = NULL;
	int idx;

	idx = m_sectionNames.indexOf(name);

	if (idx >= 0)
	{
		ret = m_section->at(idx);
	}

	return ret;
}

CSectionContainer* CConfigContainer::getFirstSection() {
	m_containerIndex = 0;

	if(m_sectionNames.count() <= 0) {
		return NULL;
	}
	else {
		return m_section->at(0);
	}
}

CSectionContainer* CConfigContainer::getNextSection() {
	m_containerIndex++;
	if(m_containerIndex >= m_sectionNames.count()) {
		return NULL;
	}
	else {
		return m_section->at(m_containerIndex);
	}
}

bool CConfigContainer::saveToFile() {
	return this->saveToFile(m_fileName);
}

bool CConfigContainer::loadFromFile() {
	return this->loadFromFile(m_fileName);
}

//implementin ISerializable interface
bool CConfigContainer::saveToFile(const char* fileName) {
	CConfigSerializer serializer(this, fileName);
	return serializer.serialize();
}

bool CConfigContainer::loadFromFile(const char* fileName) {
	CConfigSerializer serializer(this, fileName);
	this->clearSections();
	return serializer.deserialize();
}


//apaga elementos de sessao
void CConfigContainer::onDelete(CSectionContainer** obj) {
	delete *obj;
}


//Retorna o valor da chave, na sessao no formato string
const char* CConfigContainer::getValueStr(const char* section, const char* key)
{
	const char* ret = NULL;

	CSectionContainer* pSection = this->getSection(section);
	if (pSection)
	{
		ret = pSection->getKeyValue(key);
	}
	return ret;
}

bool CConfigContainer::getValueStr(const char* section, const char* key, char* output, int outputLen)
{
	bool ret = false;
	CSectionContainer* pSection = this->getSection(section);
	if (pSection)
	{
		const char* pValue = pSection->getKeyValue(key);
		if (pValue)
		{
			int pValueLen = strlen (pValue);
			if (pValueLen  < outputLen)
			{
				strcpy (output, pValue);
				ret = true;
			}
		}
	}
	return ret;
}

//Retorna o valor da chave, na sessao, no formato inteiro
bool CConfigContainer::getValueInt(const char* section, const char* key, int& out)
{
	bool ret = false;

	CSectionContainer* pSection = this->getSection(section);
	if (pSection)
	{
		const char* pValue = pSection->getKeyValue(key);
		if (pValue)
		{
			out = atoi(pValue);
			ret = true;
		}
	}	
	return ret;
}


//Retorna o valor da chave, na sessao, no formato binario
bool CConfigContainer::getValueBin(const char* section, const char* key, unsigned char* output,
								   int allocdLen, int& outputLen)
{
	bool ret = false;
	CSectionContainer* pSection = this->getSection(section);
	if (pSection)
	{
		const char* keyValue = pSection->getKeyValue(key);
		if (keyValue)
		{
			this->convertAsciiToBin(keyValue, output, allocdLen, outputLen);
			ret = true;
		}
	}

	return ret;
}


//Armazena o valor da chave, na sessao, no formato string
bool CConfigContainer::setValueStr(const char* section, const char* key, const char* value)
{
	bool ret = false;
	CSectionContainer* pSection = this->getSection(section);
	if (pSection)
	{
		if (pSection->updateValue(key, value))
		{
			ret = true;
		}
	}
	return ret;
}


//Armazena o valor da chave, na sessao, no formato inteiro convertido para string
bool CConfigContainer::setValueInt(const char* section, const char* key, int value)
{
	char szValue[32] = {0};
	sprintf (szValue, "%d", value);
	return setValueStr(section, key, szValue);
}


//Armazena o valor da chave, na sessao, no formato binario convertido para string
bool CConfigContainer::setValueBin(const char* section, const char* key, unsigned char* input, int inputLen)
{
	unsigned char ascii[1000] = {0};
	this->convertBinToAscii(input, ascii, inputLen);
	return setValueStr(section, key, (const char*)ascii);
}

//Converte a string em ascii para bin�rio
void CConfigContainer::convertAsciiToBin(const char* str, unsigned char* output, 
										 int allocdLen, int& outputLen)
{
	int iStrLen = 0;
	int i = 0;
	int j = 0;

	//verifica se a string alocada tem tamanho compativel para receber string binaria
	if (((iStrLen = strlen(str)) / 2) > allocdLen)
	{
		return;	//caso n�o tenha, retorna.
	}
	
	for (i=0, j=0; i<iStrLen; i+=2, j++)
	{
		sscanf((const char*)&str[i], "%2x", (const char*)&output[j]);
	}

	outputLen = j;	
}

void CConfigContainer::convertBinToAscii(unsigned char* bin, unsigned char* ascii, 
										 int tamanho)
{
	int i,  k = 0;	
	unsigned char al;
	unsigned char ba;

	for (i = 0; i < tamanho; i++ )
	{ 	
		al = (bin[i] & 0xf0); 
		al = (al >> 4);
		if ( al <= 9)
		al = al + '30';
		else
		al = al + '37';	

		ba = (bin[i] & 0x0f); 
		if ( ba <= 9)
		ba = ba + '30';
		else
		ba = ba + '37';

		memcpy(&ascii[k], &al, 1);
		memcpy(&ascii[k+1], &ba, 1);
		k+=2;
	}

	ascii[tamanho*2] = 0;	
}