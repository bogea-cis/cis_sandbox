///////////////////////////////////////////////////////////////////////////////
// Descricao:
// Autor: Amadeu Vilar Filho / Luis Gustavo de Brito
// Data de criacao: 11/12/2007
//
// Alteracoes:
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __C_CONFIG_CONTAINER_H__
#define __C_CONFIG_CONTAINER_H__

#ifdef WIN32
#pragma warning(disable : 4786)
#endif

#include "CSectionContainer.h"
#include "ISerializable.h"

#ifdef WIN32
#include "CList.h"
#include "CBasicStringList.h"
#else
#include "../queues/CList.h"
#include "../queues/CBasicStringList.h"
#endif

#include "CImpExpRules.h"


class CLASS_MODIFIER CConfigContainer: public ISerializable 
{
	public:
		//static CConfigContainer* getInstance();
		CConfigContainer(const char* fileName);
		virtual ~CConfigContainer();
		
		void clearSections();
		void setSection(CSectionContainer* section);
		CSectionContainer* getSection(const char* name);
		
		CSectionContainer* getFirstSection();
		CSectionContainer* getNextSection();
		
		//implementin ISerializable interface
		virtual bool saveToFile(const char* fileName);
		virtual bool loadFromFile(const char* fileName);

		virtual bool saveToFile();
		virtual bool loadFromFile();

		const char* getValueStr(const char* section, const char* key);

		bool getValueStr(const char* section, const char* key, char* output, int outputLen);

		bool getValueInt(const char* section, const char* key, int& ret);

		bool getValueBin(const char* section, const char* key, unsigned char* output,
						 int allocdLen, int& outputLen);

		bool setValueStr(const char* section, const char* key, const char* value);

		bool setValueInt(const char* section, const char* key, int value);

		bool setValueBin(const char* section, const char* key, unsigned char* input,
						 int inputLen);

	private:
			
		static void onDelete(CSectionContainer** obj); 

		void convertAsciiToBin(const char* str, unsigned char* output,
							   int allocdLen, int& outputLen);

		void convertBinToAscii(unsigned char* bin, unsigned char* ascii, 
							   int tamanho);

		//static CConfigContainer* m_instance;
		CBasicStringList m_sectionNames;
		CList<CSectionContainer*>* m_section;
		char m_fileName[256];
		int m_containerIndex;
				
};

#endif //__C_CONFIG_CONTAINER_H__