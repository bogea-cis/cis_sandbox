//////////////////////////////////////////////////////////////////////////////
// Descricao:
// Autor: Amadeu Vilar Filho / Luis Gustavo de Brito
// Data de criacao: 11/12/2007
//
// Alteracoes:
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __C_SECTION_CONTAINER_H__
#define __C_SECTION_CONTAINER_H__

#include <string.h>

#ifdef WIN32
#include "CBasicStringList.h"
#include "CMutex.h"
#else
#include "../queues/CBasicStringList.h"
#endif
#include "CImpExpRules.h"


#pragma warning(disable:4786)
        
//define some useful types
struct CKeyNameComparer {
	bool operator()(const char* key1, const char* key2 ) const {
		return(strcmp( key1, key2 ) < 0);
	}
};

class CLASS_MODIFIER CSectionContainer {
    public:
        CSectionContainer(char* name);
        virtual ~CSectionContainer();
        
        void insertKey(const char* name, const char* value);
        const char* getKeyValue(const char* name);
        void clearKeys();
        bool getFirstKeyPair(char* name, char* value);
        bool getNextKeyPair(char* name, char* value);
        char* getName();

		bool updateValue(const char* key, const char* value);
		
		void lock ();
		void unlock ();

	private:
		CBasicStringList m_key;
		CBasicStringList m_value;
		int m_containerIndex;
		CMutex* m_sem;

        char m_name[100];
};

#endif //__C_SECTION_CONTAINER_H__