// CResponseProtocol.cpp: implementation of the CResponseProtocol class.
//
//////////////////////////////////////////////////////////////////////

#include "CResponseProtocol.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CResponseProtocol::CResponseProtocol(CSocket& acceptedSocket)
{
	m_connected = true;
	m_acceptedSocket = &acceptedSocket;
}

CResponseProtocol::~CResponseProtocol()
{
}


/*
Central to Terminal:

TT II ZZ EE XXXX...XXX
\/ \/ \/ \/ \________/
|  |  |  |      \
|  |  |  \       ----------------- DADOS EXTRAS
|  |  \   ------------------------ CODIGO DE ERRO
|  \   --------------------------- ID COMANDO		
\  ------------------------------- CRACHA
 --------------------------------- TAMANHO MSG
*/
bool CResponseProtocol::send (CBuffer& extraData, unsigned short ticket, short commandId, short errorCode)
{
	bool ret = false;
	

	short fullBufferLenHostOrder = RESPONSE_PROTOCOL_SEND_HEADER_SIZE - 2 + extraData.length();
	short fullBufferLenNetworkOrder = htons (fullBufferLenHostOrder);
	
	CBuffer bufferToSend;
	
	bufferToSend.clear();

	//adiciona tamanho total da mensagem
	bufferToSend.append((unsigned char*)&fullBufferLenNetworkOrder, sizeof (fullBufferLenNetworkOrder));

	//adiciona numero sequencial (ticket)
	bufferToSend.append((unsigned char*)&ticket, sizeof (unsigned short));

	//adiciona id do comando
	bufferToSend.append((unsigned char*)&commandId, sizeof (short));

	//adiciona error code
	bufferToSend.append((unsigned char*)&errorCode, sizeof (short));

	if (extraData.length() > 0)
	{
		//adiciona dados extras
		bufferToSend.append(extraData);
	}


	int wrote = 0;
	int toWrite = fullBufferLenHostOrder + 2;

	const unsigned char* fullBuffer = bufferToSend.getBuffer();

	while (toWrite > 0)
	{
		wrote = m_acceptedSocket->send(&fullBuffer[wrote], toWrite);

		if (wrote > 0)
		{
			toWrite -= wrote;
		}
		else
		{
			//erro
			m_connected = false;
			break;
		}
	}

	//sucesso
	if (toWrite == 0)
	{
		ret = true;
	}


	return ret;
}



/*
TT II ZZ XXXX...XXX
\/ \/ \/ \________/
|  |  |      |
|  |  |      \
|  |  \       ---- DADOS EXTRAS
|  \   ----------- ID COMANDO
\  --------------- CRACHA
 ----------------- TAMANHO MSG
*/
bool CResponseProtocol::recv (short& commandId, short& ticket, CBuffer& extraData)
{
	bool ret = false;
	CBuffer allData;
	unsigned char buffer[256] = {0};
	int read = 0;
	short hostLen = 0;


	extraData.clear();
	allData.clear();
	ticket = commandId = 0;

	read = m_acceptedSocket->recv((char*)&hostLen, 2);

	if (read > 0)
	{
		//pega o tamanho do restante dos dados
		hostLen = ntohs(hostLen);

		int toRead = hostLen;

		while (toRead > 0)
		{
			if (toRead > sizeof(buffer))
			{
				read = m_acceptedSocket->recv(buffer, sizeof(buffer));
			}
			else
			{
				read = m_acceptedSocket->recv(buffer, toRead);
			}

			if (read > 0)
			{
				toRead -= read;
				allData.append(buffer, read);
			}
			else
			{
				//erro 
				m_connected = false;
				break;
			}
		}


		if (toRead == 0)
		{
			CBuffer subBuff;
			
			allData.resetIterator();
			allData.getNext(ticket);
			allData.getNext(commandId);

			//verifica se tem dados extras
			if (allData.length() > RESPONSE_PROTOCOL_RECV_HEADER_SIZE - 2)
			{
				allData.subBuffer(RESPONSE_PROTOCOL_RECV_HEADER_SIZE - 2, extraData);
			}
			ret = true;
		}
	}
	else
	{
		m_connected = false;
	}
		

	return ret;
}

bool CResponseProtocol::connected ()
{
	return m_connected;
}

