// CResponseProtocol.h: interface for the CBasicProtocol class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CResponseProtocol_H__75FE4206_F3A0_4787_99ED_68F91E59073A__INCLUDED_)
#define AFX_CBASICPROTOCOL_H__75FE4206_F3A0_4787_99ED_68F91E59073A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"
#include "CBuffer.h"
#include "CSocket.h"

const int RESPONSE_PROTOCOL_SEND_HEADER_SIZE = 8;
const int RESPONSE_PROTOCOL_RECV_HEADER_SIZE = 6;


class CLASS_MODIFIER CResponseProtocol  
{
public:

	CResponseProtocol(CSocket& acceptedSocket);
	virtual ~CResponseProtocol();

	bool send (CBuffer& extraData, unsigned short ticket, short commandId, short errorCode);
	bool recv (short& commandId, short& ticket, CBuffer& extraData);

	bool connected ();
private:
	CSocket* m_acceptedSocket;
	bool m_connected;
};

#endif // !defined(AFX_CResponseProtocol_H__75FE4206_F3A0_4787_99ED_68F91E59073A__INCLUDED_)
