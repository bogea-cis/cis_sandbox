///////////////////////////////////////////////////////////////////////////////
// Descricao:
// Autor: Amadeu Vilar Filho / Luis Gustavo de Brito
// Data de criacao: 11/12/2007
//
// Alteracoes:
//
///////////////////////////////////////////////////////////////////////////////

#ifndef CSOCKET_H
#define CSOCKET_H

#ifdef WIN32
#include <winsock2.h>
#else
#ifdef __linux__
#include "sys/socket.h"
#else
#error Wrong OS!!
#endif
#endif

#include "CImpExpRules.h"


class CLASS_MODIFIER CSocket
{
public:
	enum ESocketShutdown
	{
		ESSRecv = 0,
		ESSSend,
		ESSSendAndRecv
	};
	
	enum ESocketType
	{
		ESTSockStream = SOCK_STREAM,
		ESTSockDGram = SOCK_DGRAM
	};
	
	enum ESocketProtocol
	{
		ESP_TCP = 0,
		ESP_UDP
	};
	
	enum ESelectMode
	{
		ESMError,
		ESMRead,
		ESMWrite
	};
	
public:
	
	
/**
* Construtor da classe
* @param  protocol Determina o protocolo
* @param  type Determina o tipo de socket
	*/
	CSocket (ESocketProtocol protocol, ESocketType type );
	
	
	/**
	* Destrutor da classe
	*/
	virtual ~CSocket ( );
	
	
	/**
	* Retorna o handle do socket
	* @return int
	*/
	int getHandle ( );
	
	/**
	* faz conexão com maquina remota
	* @return bool
	* @param  ip Determina o IP do servidor que se deseja conectar
	* @param  port Determina a porta do servidor remoto
	*/
	bool connect (const char* ip, unsigned short port );
	
	
	/**
	* Reserva endereço (ip + porta)
	* @return bool
	* @param  ip Determina o endereço que vamos dar bind
	* @param  port Determina a porta que vamos dar bind
	*/
	bool bind (const char* ip, unsigned short port );
	
	
	/**
	* Coloca socket em estado de listinig
	* @return bool
	* @param  backlog Numero maximo de conexões que podem ficar esperando na fila
	*/
	bool listen (unsigned int backlog );
	
	
	/**
	* Aceita socket que quer conectar-se
	* @return CSocket*
	*/
	CSocket* accept ( );
	
	
	/**
	* Evia mensagem  em um  strem socket
	* @return int
	* @param  buffer Mensagem que deve ser enviada
	* @param  bufferLen Tamanho da mensagem
	*/
	int send (const void* buffer, unsigned int bufferLen );
	
	
	/**
	* Recebe mensagem em um strem socket
	* @return retorno > 0 -> numero de bytes lidos
	*		   retorno = 0 -> host fechou a conexao
	*         retorno < 0 -> algum erro aconteceu verificar com getlasterror
	* @param  buffer Buffer de saida com o dado lido
	* @param  bufferLen Indica o tamanho do buffer.
	*/
	int recv (void* buffer, unsigned int bufferLen );
	
	
	/**
	* Envia mensagem  em um datagram socket
	* @return int
	* @param  buffer Mensagem que deve ser enviada pelo socket datagram
	* @param  bufferLen Tamanho da mensagem
	* @param  ip Determina o endereço do host
	* @param  port Determina a porta do host
	*/
	int sendTo (const void* buffer, unsigned int bufferLen, const char* ip, unsigned int port );
	
	
	/**
	* Reebe mensagem em um datagram socket
	* @return int
	* @param  buffer Buffer de saida com o dado lido
	* @param  bufferLen Tamanho do buffer
	* @param  fromIp Endereço IP de onde vamos ler
	* @param  fromPort Porta de onde vamos ler
	*/
	int recvFrom (void* buffer, unsigned int bufferLen, const char* fromIp, unsigned int fromPort );
	
	
	/**
	* Desabilita Envio e recebimento de mensagens (shutdown) e destroi socket.
	* @return bool
	*/
	bool close ( );
	
	
	/**
	* Desabilita Envio e/ou recebimento de mensagens
	* @return bool
	* @param  mode Determina o que devemos fazer shutdown, send, recv ou os dois
	*/
	bool shutdown (ESocketShutdown mode );
	
	
	/**
	* Verifica evento de leitura no socket
	* @return int
	*         -1 = erro
	*          0 = timeout
	*          1 = tem dado para ser lido
	* @param  timeout tempo em microsegundos
	*/
	int peek (int timeout);
	
	/**
	* Retorna o ultimo erro
	* @return int
	*/
	int getLastError ();
	
	/**
	* Retorna IP de um host
	* @return bool
	* @param ipOrName Nome do host que se deseja encontrar o IP
	* @param outName parametr de saida com o IP
	*/ 
	static bool getHostByName (const char* ipOrName, char* outName);
	
protected:
/**
* Construtor 
	*/
	CSocket (int sFD);
	
private:
	
	void initAttributes ( ) ;
	
private:
	
	// File descriptor (handle) do socket
	unsigned int m_socketFD;
	//Ultimo erro
	int m_lastError;
	
};

#endif // CSOCKET_H

