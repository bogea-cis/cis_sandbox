// CRequestProtocol.h: interface for the CBasicProtocol class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CRequestProtocol_H__75FE4206_F3A0_4787_99ED_68F91E59073A__INCLUDED_)
#define AFX_CBASICPROTOCOL_H__75FE4206_F3A0_4787_99ED_68F91E59073A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"
#include "CBuffer.h"
#include "CSocket.h"

const int REQUEST_PROTOCOL_SEND_HEADER_SIZE = 6;
const int REQUEST_PROTOCOL_RECV_HEADER_SIZE = 8;


class CLASS_MODIFIER CRequestProtocol  
{
public:

	CRequestProtocol(const char* ip, int port);
	virtual ~CRequestProtocol();

	bool send (short commandId, CBuffer& extraData, short& ticket);
	bool recv (CBuffer& extraData, short& ticket, short& commandId, short& errorCode);

	bool connected ();

	void resetConnection ();

private:
	bool initialize ();
	bool finalize ();

private:
	char m_ip[16];
	int m_port;
	bool m_connected;
	static unsigned short m_ticket;
	CSocket* m_clientSocket;
};

#endif // !defined(AFX_CRequestProtocol_H__75FE4206_F3A0_4787_99ED_68F91E59073A__INCLUDED_)
