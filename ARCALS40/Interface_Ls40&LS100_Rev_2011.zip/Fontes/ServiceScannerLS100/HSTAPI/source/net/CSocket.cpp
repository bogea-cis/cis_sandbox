///////////////////////////////////////////////////////////////////////////////
// Descricao:
// Autor: Amadeu Vilar Filho / Luis Gustavo de Brito
// Data de criacao: 11/12/2007
//
// Alteracoes:
//
///////////////////////////////////////////////////////////////////////////////

#include "CSocket.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#ifdef WIN32
#include <winsock2.h>
#else
#include <unistd.h>
#include "sys/types.h"
#include "sys/socket.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include "sys/wait.h"
#include <signal.h>
#include <netdb.h>
#endif


/**
* Construtor da classe
* @param  protocol Determina o protocolo
*/
CSocket::CSocket (ESocketProtocol protocol, ESocketType type ) 
{
	static bool startupSocketInterfaceFlag = false;
	
	if (!startupSocketInterfaceFlag)
	{
		startupSocketInterfaceFlag = true;
#ifdef WIN32
		WSADATA wsaData;
		WSAStartup(MAKEWORD(1, 1), &wsaData);
#endif
	}
	
	//seta valores defaults
	this->initAttributes();
	
	//vamos criar um socket file descriptor (FD)
	m_socketFD = socket (PF_INET, (int) type, (int) protocol);
	
	// set SO_REUSEADDR on a socket to true (1):
#ifdef WIN32
	char optval = '1';
	::setsockopt(m_socketFD, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof (optval));
#else
	int optval = 1;
	::setsockopt(m_socketFD, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof (optval));
#endif
}

/**
* Construtor 
*/
CSocket ::CSocket (int sFD)
{
	//seta valores defaults
	this->initAttributes();
	m_socketFD = sFD;
}

/**
* Destrutor da classe
*/
CSocket::~CSocket ( ) 
{ 
	if (m_socketFD != 0)
	{
		//destroi handle do socket
		close();
	}
}


/**
* Retorna o handle do socket
* @return int
*/
int CSocket::getHandle ( ) 
{
	return this->m_socketFD;
}


/**
* faz conexão com maquina remota
* @return bool
* @param  ip Determina o IP do servidor que se deseja conectar
* @param  port Determina a porta do servidor remoto
*/
bool CSocket::connect (const char* ip, unsigned short port ) 
{
	bool ret = false;
	char remoteIP[15 + 1] = {0};
	
	//vamos pegar o IP do host remoto
	if (getHostByName (ip, remoteIP))
	{
		struct sockaddr_in dest_addr; // will hold the destination addr
		
		dest_addr.sin_family = AF_INET;        // host byte order
		dest_addr.sin_port = htons(port);	 // short, network byte order
		dest_addr.sin_addr.s_addr = inet_addr (remoteIP);
		
		memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
		
		//vamos tentar nos conectar
		if (::connect (m_socketFD, (struct sockaddr *)&dest_addr, sizeof (sockaddr_in)) == 0)
		{
			//sucesso
			ret = true;
		}
	}
	
	return ret;
}


/**
* Reserva endereço (ip + porta)
* @return bool
* @param  ip Determina o endereço que vamos dar bind
* @param  port Determina a porta que vamos dar bind
*/
bool CSocket::bind (const char* ip, unsigned short port ) 
{
	bool ret = false;
	
	char bindIP[15 + 1] = {0};
	
	//vamos pegar o IP do host remoto
	if (getHostByName (ip, bindIP))
	{
		struct sockaddr_in addr; // will hold the destination addr
		
		addr.sin_family = AF_INET;        // host byte order
		addr.sin_port = htons(port);	 // short, network byte order
		addr.sin_addr.s_addr = inet_addr (bindIP);
		
		memset(addr.sin_zero, '\0', sizeof addr.sin_zero);
		
		//vamos tentar fazer o bind
		if (::bind (m_socketFD, (struct sockaddr *)&addr, sizeof (sockaddr_in)) == 0)
		{
			//sucesso
			ret = true;
		}
	}
	
	
	return ret;
}


/**
* Coloca socket em estado de listinig
* @return bool
* @param  backlog Numero maximo de conexões que podem ficar esperando na fila
*/
bool CSocket::listen (unsigned int backlog ) 
{
	bool ret = false;
	
	if (::listen(m_socketFD, backlog) == 0)
	{
		//sucesso
		ret = true;
	}
	
	return ret;
}


/**
* Aceita socket que quer conectar-se
* @return CSocket*
*/
CSocket* CSocket::accept ( ) 
{
	CSocket* ret = NULL;
	struct sockaddr_in their_addr; // connector's address information
	int sin_size;
	int newFD = 0;
	
	sin_size = sizeof (sockaddr_in);
	
#ifdef WIN32
	newFD = ::accept(m_socketFD, (sockaddr*)&their_addr, &sin_size);
#else
	newFD = ::accept(m_socketFD, (sockaddr*)&their_addr, (socklen_t*)&sin_size);
#endif               
	
	if (newFD > 0)
	{
		//sucesso
		ret = new CSocket (newFD);		
	}
	
	return ret;
}


/**
* Evia mensagem  em um  strem socket
* @return int
* @param  buffer Mensagem que deve ser enviada
* @param  bufferLen Tamanho da mensagem
*/
int CSocket::send (const void* buffer, unsigned int bufferLen ) 
{	
	unsigned int totalBytesSent = 0;
	const char* pBuffer = reinterpret_cast<const char*>(buffer);
	while(bufferLen != totalBytesSent)
	{
		int bytesSent = ::send(m_socketFD, &pBuffer[totalBytesSent], (bufferLen - totalBytesSent), 0);
		if(bytesSent > 0)
		{
			totalBytesSent += bytesSent;
		}
		else
		{
			return bytesSent;
		}
		
	}
	return static_cast<int>(totalBytesSent);
}


/**
* Recebe mensagem em um strem socket
* @return retorno > 0 -> numero de bytes lidos
*		  retorno = 0 -> host fechou a conexao
*         retorno < 0 -> algum erro aconteceu verificar com getlasterror
* @param  buffer Buffer de saida com o dado lido
* @param  bufferLen Indica o tamanho do buffer.
*/
int CSocket::recv (void* buffer, unsigned int bufferLen ) 
{
	return ::recv(m_socketFD, (char*)buffer, bufferLen, 0);
}


/**
* Envia mensagem  em um datagram socket
* @return int
* @param  buffer Mensagem que deve ser enviada pelo socket datagram
* @param  bufferLen Tamanho da mensagem
* @param  ip Determina o endereço do host
* @param  port Determina a porta do host
*/
int CSocket::sendTo (const void* buffer, unsigned int bufferLen, const char* ip, unsigned int port ) 
{
	int ret = -1;
	
	//not implemented
	
	return ret;
}


/**
* Reebe mensagem em um datagram socket
* @return int
* @param  buffer Buffer de saida com o dado lido
* @param  bufferLen Tamanho do buffer
* @param  fromIp Endereco IP de onde vamos ler
* @param  fromPort Porta de onde vamos ler
*/
int CSocket::recvFrom (void* buffer, unsigned int bufferLen, const char* fromIp, unsigned int fromPort ) 
{
	int ret = -1;
	
	//not implemented
	
	return ret;
}


/**
* Desabilita Envio e recebimento de mensagens (shutdown) e destroi socket.
* @return bool
*/
bool CSocket::close ( ) 
{
	bool ret = false;
	
#ifdef WIN32
	ret = ::closesocket(m_socketFD) == 0;
#else
	ret = ::close (m_socketFD) == 0;
#endif
	
	return ret;
}


/**
* Desabilita Envio e/ou recebimento de mensagens
* @return bool
* @param  mode Determina o que devemos fazer shutdown, send, recv ou os dois
*/
bool CSocket::shutdown (ESocketShutdown mode ) 
{
	bool ret = false;
	
	ret = ::shutdown(m_socketFD, (int)mode) == 0;
	
	return ret;
}


/**
* Verifica evento de leitura no socket
* @return int
*         -1 = erro
*          0 = timeout
*          1 = tem dado para ser lido
* @param  timeout tempo em microsegundos
*/
int CSocket::peek (int timeout) 
{
	int ret = -1;
	
	fd_set readfds;
	struct timeval tv;
	
	// clear the set ahead of time
	FD_ZERO(&readfds);
	
	// add our descriptors to the set
	FD_SET(m_socketFD, &readfds);
	
	// wait until either socket has data ready to be recv()d (timeout 10.5 secs)
	tv.tv_sec = timeout / 1000;
	tv.tv_usec = (timeout % 1000) * 1000;
	
	ret = select(m_socketFD + 1, &readfds, NULL, NULL, &tv);
	
	return ret;
}


/**
* Retorna o ultimo erro
* @return int
*/
int CSocket::getLastError ()
{
#ifdef WIN32
	return WSAGetLastError();
#else
	return errno;
#endif
}


/**
* Retorna IP de um host
* @return bool
* @param ipOrName Nome do host que se deseja encontrar o IP
* @param outName parametr de saida com o IP
*/ 
bool CSocket::getHostByName (const char* ipOrName, char* outName)
{
	bool ret = false;
	
	struct hostent *he;
	he = ::gethostbyname(ipOrName);
	
	if (he)
	{
		strcpy (outName, he->h_name);
		ret = true;
	}
	
	return ret;
}


void CSocket::initAttributes ( ) {
	m_socketFD = 0;
}

