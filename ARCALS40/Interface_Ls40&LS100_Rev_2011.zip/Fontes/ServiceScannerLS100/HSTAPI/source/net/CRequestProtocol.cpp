// CRequestProtocol.cpp: implementation of the CRequestProtocol class.
//
//////////////////////////////////////////////////////////////////////

#include "CRequestProtocol.h"

unsigned short CRequestProtocol::m_ticket = 0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CRequestProtocol::CRequestProtocol(const char* ip, int port)
{
	strcpy (m_ip, ip);
	m_port = port;
	m_clientSocket = NULL;
	m_connected = false;

	initialize ();
}

CRequestProtocol::~CRequestProtocol()
{
	finalize();
}

bool CRequestProtocol::initialize ()
{
	bool ret = false;

	if (m_clientSocket)
	{
		finalize();
	}

	m_clientSocket = new CSocket (CSocket::ESP_TCP, CSocket::ESTSockStream);
	ret = m_clientSocket->connect(m_ip, m_port);

	if (ret)
	{
		m_connected = true;
	}

	return ret;
}

bool CRequestProtocol::finalize ()
{
	m_clientSocket->shutdown(CSocket::ESSSendAndRecv);
	m_clientSocket->close();
	delete m_clientSocket;
	m_clientSocket = NULL;
	m_connected = false;
	return true;
}


/*
TT II ZZ XXXX...XXX
\/ \/ \/ \________/
|  |  |      |
|  |  |      \
|  |  \       ---- DADOS EXTRAS
|  \   ----------- ID COMANDO
\  --------------- CRACHA
 ----------------- TAMANHO MSG
*/
bool CRequestProtocol::send (short commandId, CBuffer& extraData, short& ticket)
{
	bool ret = false;
	

	short fullBufferLenHostOrder = REQUEST_PROTOCOL_SEND_HEADER_SIZE - 2 + extraData.length();
	short fullBufferLenNetworkOrder = htons (fullBufferLenHostOrder);
	
	CBuffer bufferToSend;
	

	//soma numero sequencial
	m_ticket++;

	bufferToSend.clear();

	//adiciona tamanho total da mensagem
	bufferToSend.append((unsigned char*)&fullBufferLenNetworkOrder, sizeof (fullBufferLenNetworkOrder));

	//adiciona numero sequencial (ticket)
	bufferToSend.append((unsigned char*)&m_ticket, sizeof (m_ticket));

	//adiciona id do comando
	bufferToSend.append((unsigned char*)&commandId, sizeof (commandId));

	if (extraData.length() > 0)
	{
		//adiciona dados extras
		bufferToSend.append(extraData);
	}


	int wrote = 0;
	int toWrite = fullBufferLenHostOrder + 2;

	const unsigned char* fullBuffer = bufferToSend.getBuffer();

	while (toWrite > 0)
	{
		wrote = m_clientSocket->send(&fullBuffer[wrote], toWrite);

		if (wrote > 0)
		{
			toWrite -= wrote;
		}
		else
		{
			//erro
			m_connected = false;
			break;
		}
	}

	//sucesso
	if (toWrite == 0)
	{
		ret = true;
	}


	return ret;

}


/*
Central to Terminal:

TT II ZZ EE XXXX...XXX
\/ \/ \/ \/ \________/
|  |  |  |      \
|  |  |  \       ----------------- DADOS EXTRAS
|  |  \   ------------------------ CODIGO DE ERRO
|  \   --------------------------- ID COMANDO		
\  ------------------------------- CRACHA
 --------------------------------- TAMANHO MSG
*/
bool CRequestProtocol::recv (CBuffer& extraData, short& ticket, short& commandId, short& errorCode)
{
	bool ret = false;
	CBuffer allData;
	unsigned char buffer[256] = {0};
	int read = 0;
	short hostLen = 0;


	allData.clear();
	ticket = commandId = errorCode = 0;


	read = m_clientSocket->recv((char*)&hostLen, 2);

	if (read > 0)
	{
		//pega o tamanho do restante dos dados
		hostLen = ntohs(hostLen);

		int toRead = hostLen;


		while (toRead > 0)
		{
			if (toRead > sizeof(buffer))
			{
				read = m_clientSocket->recv(buffer, sizeof(buffer));
			}
			else
			{
				read = m_clientSocket->recv(buffer, toRead);
			}

			if (read > 0)
			{
				toRead -= read;
				allData.append(buffer, read);
			}
			else
			{
				//erro
				m_connected = false;
				break;
			}
		}


		if (toRead == 0)
		{
			CBuffer subBuff;
			
			allData.resetIterator();
			allData.getNext(ticket);
			allData.getNext(commandId);
			allData.getNext(errorCode);

			//verifica se tem dados extras
			if (allData.length() > REQUEST_PROTOCOL_RECV_HEADER_SIZE - 2)
			{
				const unsigned char* pBuffer = allData.getBuffer();
				int headerLen = REQUEST_PROTOCOL_RECV_HEADER_SIZE - 2;
				extraData.append(&pBuffer[headerLen], allData.length() - headerLen);
			}
			ret = true;
		}
	}
	else
	{
		m_connected = false;
	}
		

	return ret;
}

void CRequestProtocol::resetConnection ()
{
	finalize();
	initialize();
}


bool CRequestProtocol::connected ()
{
	return m_connected;
}


