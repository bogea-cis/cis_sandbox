// CObjectContainer.h: interface for the CObjectContainer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COBJECTCONTAINER_H__E8CD239A_5995_4D30_A232_0C713543DF06__INCLUDED_)
#define AFX_COBJECTCONTAINER_H__E8CD239A_5995_4D30_A232_0C713543DF06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "CLogger.h"


class CObjectContainer  
{
public:
	static CLogger* getTraceInstance ();

private:
	static CLogger* m_trace;

};

#endif // !defined(AFX_COBJECTCONTAINER_H__E8CD239A_5995_4D30_A232_0C713543DF06__INCLUDED_)
