// CObjectContainer.cpp: implementation of the CObjectContainer class.
//
//////////////////////////////////////////////////////////////////////

#include "CObjectContainer.h"

CLogger* CObjectContainer::m_trace = NULL;


CLogger* CObjectContainer::getTraceInstance ()
{
	if (CObjectContainer::m_trace == NULL)
	{
		CObjectContainer::m_trace = new CLogger ("HSTAPI.log", LOW_PRIORITY);
	}

	return CObjectContainer::m_trace;
}

