// CMenu.h: interface for the CMenu class.
//
//////////////////////////////////////////////////////////////////////
#ifndef _CMENU_H_
#define _CMENU_H_

#include "CImpExpRules.h"
#include "..\queue\CList.h"


class CLASS_MODIFIER CConsoleMenu  
{
public:
	CConsoleMenu();
	virtual ~CConsoleMenu();

	virtual void execute ();
	
	virtual void setClearScreen(bool clearScreen);
	
	virtual bool getClearScreen();

	
protected:
	virtual const char* getMenuItemName () = 0;
	virtual void setExitMenuOption (int option);
	virtual void printInvalidOption ();
	virtual bool getConsoleInt(int& option);
	virtual int getConsoleString(char* data, int dataLen);
	virtual bool isNumber (const char* data);

private:
	virtual void printMenu ();
	virtual void printExitOption ();
	virtual void printInfoString (const char* str);
	virtual int getIntOption ();
	static void deleteMenu (CConsoleMenu** menu);

protected:
	CList<CConsoleMenu*>* m_menuOptions;
	
private:
	char m_menuItemName[64];
	int m_exitMenuOption;
	bool m_clearScreen;
};

#endif
