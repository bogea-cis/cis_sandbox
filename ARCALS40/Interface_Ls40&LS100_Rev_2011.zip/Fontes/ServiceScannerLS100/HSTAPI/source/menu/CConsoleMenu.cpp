// CConsoleMenu.cpp: implementation of the CConsoleMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "CConsoleMenu.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CConsoleMenu::CConsoleMenu()
{
	m_menuOptions = new CList<CConsoleMenu*>(CConsoleMenu::deleteMenu);

	m_exitMenuOption = 0;
	
	m_clearScreen = false;
}

CConsoleMenu::~CConsoleMenu()
{
	m_menuOptions->clear();
}

void CConsoleMenu::execute ()
{
	bool exit = false;
	static bool firstTime = true;
	int option = 0;


	while (!exit)
	{
		if (firstTime)
		{
			firstTime = false;
		}
		else
		{
			if(m_clearScreen)
			{
				printInfoString("\033[H\033[J");
			}
			else
			{
				printInfoString ("--------------------------------------------------------------------------------\n");
			}
		}
		printMenu ();
		printExitOption();
		printInfoString ("Option: ");

		option = getIntOption ();
		printInfoString ("\n");
		if (m_exitMenuOption == option)
		{
			exit = true;
		}
		else
		{
			if ((option - 1) >= 0 && (option - 1) < m_menuOptions->count())
			{
				m_menuOptions->at(option - 1)->execute();
				printInfoString ("\n");
			}
			else
			{
				printInvalidOption();
			}
		}
	}
}

const char* CConsoleMenu::getMenuItemName ()
{
	return m_menuItemName;
}

void CConsoleMenu::printMenu ()
{
	CConsoleMenu* pMenu = NULL;

	for (int i = 0; i < m_menuOptions->count(); i++)
	{
		pMenu = m_menuOptions->at(i);

		if (pMenu)
		{
			printf ("%2d - %s\n", i + 1, pMenu->getMenuItemName());
		}
	}
}

void CConsoleMenu::printExitOption ()
{
	printf ("%2d - Exit\n", m_exitMenuOption);
}

void CConsoleMenu::printInvalidOption ()
{
	printf ("Invalid option\n\n");
}

void CConsoleMenu::printInfoString (const char* str)
{
	printf (str);
}

int CConsoleMenu::getIntOption ()
{
	int opt = 0;
	if(getConsoleInt(opt) == false)
	{
		opt = -1;
	}
	return opt;
}

void CConsoleMenu::setExitMenuOption (int option)
{
	m_exitMenuOption = option;
}

void CConsoleMenu::deleteMenu (CConsoleMenu** menu)
{
	delete (*menu);
}

void CConsoleMenu::setClearScreen(bool clearScreen)
{
	m_clearScreen = clearScreen;
}
	
bool CConsoleMenu::getClearScreen()
{
	return m_clearScreen;
}

bool CConsoleMenu::getConsoleInt(int& option)
{
	bool res = false;
	char aux[100] = {0};
	char cOpt[100] = {0};
	fflush(stdin);
	fgets(aux, 100, stdin);
	if(sscanf(aux, "%s", cOpt) == 1)
	{
		int factor = 1;
		char* number = cOpt;
		if(number[0] == '-')
		{
			number++;
			factor = -1;
		}
		if(isNumber(number))
		{
			option = atoi(number);
			res = true;
		}
		option *= factor;
	}
	return res;
}

int CConsoleMenu::getConsoleString(char* data, int dataLen)
{
	fflush(stdin);
	memset(data, 0, dataLen);
	fgets(data, dataLen, stdin);
	int len = strlen(data);
	
	if(data[len -1] == '\n' || data[len -1] == '\r')
	{
		data[len -1] = '\0';
		len--;
	}
	
	return len;
}

bool CConsoleMenu::isNumber (const char* data)
{
	bool ret = true;
	int len = strlen (data);
	for (int i = 0; i < len; i++)
	{
		if (!isdigit (data[i]))
		{
			ret = false;
			break;
		}
	}
	return ret;
}

