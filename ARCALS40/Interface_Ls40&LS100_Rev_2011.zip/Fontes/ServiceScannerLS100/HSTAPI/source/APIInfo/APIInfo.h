#ifndef _API_INFO_H_
#define _API_INFO_H_


#include "CImpExpRules.h"

const char API_VERSION[] = "0.1";
const char AUTHORS[] =	"Amadeu Vilar Filho\n" 
						"Diego Felipe Lassa\n" 
						"Jose Ramos\n"
						"Luis Gustavo de Brito";



CLASS_MODIFIER const char* getAPIVersion ();
CLASS_MODIFIER const char* getAuthors ();
CLASS_MODIFIER const char* getCompiledDate ();
CLASS_MODIFIER const char* getCompiledTime ();



#endif // _API_INFO_H_
