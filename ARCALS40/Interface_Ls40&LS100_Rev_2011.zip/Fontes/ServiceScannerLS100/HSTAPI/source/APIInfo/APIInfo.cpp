#include "APIInfo.h"

const char* getAPIVersion ()
{
	return API_VERSION;
}

const char* getAuthors ()
{
	return AUTHORS;
}

const char* getCompiledDate ()
{
	return __DATE__;
}

const char* getCompiledTime ()
{
	return __TIME__;
}

