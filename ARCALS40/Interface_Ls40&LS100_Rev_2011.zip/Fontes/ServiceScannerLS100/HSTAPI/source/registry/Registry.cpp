//#include <crtdbg.h>
#include "registry.h"

BOOL CRegistry::OpenKey(enum Keys hKey, LPCTSTR szKey, KeyAccess access)
{	
	if(RegOpenKeyEx((HKEY)hKey,(LPCSTR)szKey, 0, access, &m_hKey) == ERROR_SUCCESS)
	{
		return TRUE;
	}
	else
	{
		m_hKey = NULL;
		return FALSE;
	}
}

BOOL CRegistry::CreateKey(enum Keys hKey, LPCTSTR szKey)
{	
	if(RegCreateKeyEx((HKEY)hKey,(LPCSTR)szKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &m_hKey, NULL) == ERROR_SUCCESS)
	{
		return TRUE;
	}
	else
	{
		m_hKey = NULL;
		return FALSE;
	}
}

BOOL CRegistry::SetValue(LPCTSTR lpValueName, LPCTSTR lpData)
{
//-	_ASSERT(m_hKey != NULL);

	DWORD dwType = REG_SZ;

	if(::RegSetValueEx(m_hKey, (LPCSTR)lpValueName, 0, dwType, (LPBYTE)(LPCTSTR)lpData, strlen(lpData)) == ERROR_SUCCESS)
	{
		::RegFlushKey(m_hKey);
		return TRUE;
	}
	return FALSE;
}

BOOL CRegistry::SetValue(LPCTSTR lpValueName, DWORD dwValue)
{
//-	_ASSERT(m_hKey != NULL);
	
	DWORD dwType = REG_DWORD;
	
	if(::RegSetValueEx(m_hKey, (LPCSTR)lpValueName, 0, dwType, (LPBYTE)&dwValue, sizeof(DWORD)) == ERROR_SUCCESS)
	{
		::RegFlushKey(m_hKey);
		return TRUE;
	}
	return FALSE;
}

BOOL CRegistry::GetValue(LPCTSTR lpValueName, DWORD& dwValue)
{
	BOOL bRet = FALSE;
	DWORD dwType = REG_DWORD;
	DWORD lpcbData = sizeof(DWORD);
	dwValue = 0;	
	
		
	if(RegQueryValueEx(m_hKey,
		lpValueName,
		NULL,
		&dwType, 
		(BYTE*)(DWORD)&dwValue,
		&lpcbData) == ERROR_SUCCESS)
		bRet = TRUE;

	return bRet;
}

BOOL CRegistry::GetValue(LPCTSTR lpValueName, LPSTR strValue)
{
	DWORD len = 256;
	return GetValue(lpValueName, strValue, len);
}

BOOL CRegistry::GetValue(LPCTSTR lpValueName, LPSTR strValue, DWORD lenght)
{
	return GetValue(lpValueName, strValue, &lenght);
}

BOOL CRegistry::GetValue(LPCTSTR lpValueName, LPSTR strValue, DWORD* lenghtInOut)
{
	BOOL bRet = FALSE;
	DWORD dwType = REG_SZ;
	//DWORD lpcbData;
	
	bRet = FALSE;	
	//lpcbData = lenght;

	if(::RegQueryValueEx(m_hKey,
		lpValueName,
		NULL,
		&dwType, 
		(BYTE*)(LPCTSTR)strValue,
		lenghtInOut) == ERROR_SUCCESS)
	{
		bRet = TRUE;
	}
	else
	{
		strValue = NULL;
	}

	return bRet;
}


BOOL CRegistry::DeleteKey(enum Keys hKey, LPCTSTR szKey)
{	
	return ::RegDeleteKey((HKEY)hKey,(LPCSTR)szKey) == ERROR_SUCCESS;
}

BOOL CRegistry::DeleteValue(LPCTSTR lpValueName)
{	
	if(::RegDeleteValue(m_hKey,(LPCSTR)lpValueName) == ERROR_SUCCESS)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	
}

void CRegistry::CloseKey()
{
	::RegCloseKey(m_hKey);
	m_hKey = NULL;
}

BOOL CRegistry::SaveKey(LPCTSTR lpszFileName)
{
//-	_ASSERT(m_hKey != NULL);
	return ::RegSaveKey(m_hKey, lpszFileName, NULL) == ERROR_SUCCESS;
}

BOOL CRegistry::RestoreKey(LPCSTR lpszFileName, DWORD dwFlags)
{
//-	_ASSERT(m_hKey != NULL);
	return ::RegRestoreKey(m_hKey, lpszFileName, dwFlags) == ERROR_SUCCESS;
}

BOOL CRegistry::LoadKey(enum Keys hKey, LPCTSTR lpszSubKey, LPCSTR lpszFileName)
{
	return ::RegLoadKey((HKEY)hKey, lpszSubKey, lpszFileName) == ERROR_SUCCESS;
}

BOOL CRegistry::GetSubKeyNames (LPSubKeyArray subKeyArray)
{
	BOOL ret = FALSE;
	int idx = 0;
	char name[MAX_KEY_NAME + 1] = {0};
	DWORD nameSize = MAX_KEY_NAME;

	if (subKeyArray != NULL)
	{
		memset (subKeyArray, '\0', sizeof (SubKeyArray));

		while(RegEnumKeyEx(m_hKey, idx, name, &nameSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS && (idx < MAX_SUB_KEYS))
		{
			strcpy (subKeyArray->subKey[idx].name, name);
			nameSize = MAX_KEY_NAME;
			idx++;
		}
		subKeyArray->count = idx;
		ret = TRUE;
	}
	return ret;
}

