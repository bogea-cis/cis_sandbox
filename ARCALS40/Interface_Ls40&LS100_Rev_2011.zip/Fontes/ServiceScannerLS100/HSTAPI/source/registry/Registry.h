#ifndef _CREGISTRY_H_
#define _CREGISTRY_H_

#include <windows.h>
#include "CImpExpRules.h"

const int MAX_SUB_KEYS = 500;
const int MAX_KEY_NAME = 128;

class CLASS_MODIFIER CRegistry
{
public:
	enum cregRestoreEnum
	{
		regVolatile = REG_WHOLE_HIVE_VOLATILE,
		regRefresh = REG_REFRESH_HIVE,
		regNoLazy = REG_NO_LAZY_FLUSH
	};

	enum Keys
	{
		classesRoot = HKEY_CLASSES_ROOT,
		currentUser = HKEY_CURRENT_USER,
		localMachine = HKEY_LOCAL_MACHINE,
		currentConfig = HKEY_CURRENT_CONFIG,
		users = HKEY_USERS,
		performanceData = HKEY_PERFORMANCE_DATA,	//Windows NT/2000
		dynData = HKEY_DYN_DATA						//Windows 95/98
	};

	enum KeyAccess
	{
		regRead = KEY_READ,
		regWrite = KEY_WRITE,
		regExecute = KEY_EXECUTE,
		regAllAccess = KEY_ALL_ACCESS
	};

	struct SubKey
	{
		char name[MAX_KEY_NAME];
	};

	struct SubKeyArray
	{
		SubKey subKey[MAX_SUB_KEYS];
		int count;
	};

	typedef SubKeyArray* LPSubKeyArray;

	CRegistry()
		{
			m_hKey = NULL;
		};

	~CRegistry()
		{
			CloseKey();
			m_hKey = NULL;
		};

	BOOL OpenKey(enum Keys hKey, LPCTSTR szKey, KeyAccess access = regAllAccess);
	BOOL CreateKey(enum Keys hKey, LPCTSTR szKey);
	BOOL DeleteKey(enum Keys hKey, LPCTSTR szKey);
	BOOL DeleteValue(LPCTSTR lpValueName);
	BOOL GetValue(LPCTSTR lpValueName, LPSTR strValue);
	BOOL GetValue(LPCTSTR lpValueName, LPSTR strValue, DWORD lenght);
	BOOL GetValue(LPCTSTR lpValueName, LPSTR strValue, DWORD* lenghtInOut);

	BOOL GetValue(LPCTSTR lpValueName, DWORD& dwValue);
	BOOL SetValue(LPCTSTR lpValueName, LPCTSTR lpData);
	BOOL SetValue(LPCTSTR lpValueName, DWORD dwValue);
	BOOL SaveKey(LPCTSTR lpszFileName);
	BOOL RestoreKey(LPCSTR lpszFileName, DWORD dwFlag);
	BOOL LoadKey(enum Keys hKey, LPCTSTR lpszSubKey, LPCSTR lpszFileName);
	BOOL GetSubKeyNames (LPSubKeyArray subKeyArray);
	void CloseKey();	

protected:
	HKEY m_hKey;
};

#endif