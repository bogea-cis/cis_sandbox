///////////
//Defines//
///////////

#ifndef HST_CONCURRENCY_CCRITICALSECTION_H
#define HST_CONCURRENCY_CCRITICALSECTION_H



////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>
#include <winbase.h>


////////////////////////
//Includes espec�ficos//
////////////////////////
#include "CImpExpRules.h"


///////////////////
//Namespaces(Uso)//
///////////////////


//////////////
//Enumerados//
//////////////

enum ECriticalSectionInitializationState	{
											csisUnknown		/**TODO - Descri��o*/,
											csisFailed		/**TODO - Descri��o*/,
											csisInitialized	/**TODO - Descri��o*/
											};

//////////
//Classe//
//////////

/**
\class CCriticalSection
\brief Classe de se��o cr�tica para Windows.
Classe de se��o cr�tica, utilizada para evitar que determinado trecho de c�digo seja
acessados por duas threads ou mais threads ao mesmo tempo, dentro de um mesmo processo.
Sua implementa��o se d� atrav�s do emcapsulamento de fun��es j� existentes da API do Windows.

\author Diego Felipe Lassa
\version 1.0.0.0
\date 01/01/2008
\bug
\warning
*/
class CLASS_MODIFIER CCriticalSection{

	private:

		/**Armazena a estrutura com os dados utilizados para o controle do critical-section*/
		LPCRITICAL_SECTION m_criticalSectionObject;

		/**Armazena o status da inicializa��o do Critical Section*/
		ECriticalSectionInitializationState m_initializationState;

		/**Armazena o n�mero de spins realizados pela thread antes de de ficar em estado de espera, caso n�o consiga obter o lock*/
		int m_spinCount;


	protected:

		/**
		\brief Realiza as inicializa��es necess�rias aos membros da classe.
		Use initialization para centralizar as inicializa��es necess�rias � 
		classe, comuns a todas as vers�es do construtor dispon�veis.
		Isto evita que sobrecargas do construtor tenham que replicar c�digo
		a fim de inicializar os membros da classe.
		\see finalization
		*/
		virtual void initialization();

		/**
		\brief Realiza as finaliza��es necess�rias aos membros da classe.
		Use initialization para centralizar as finaliza��es necess�rias � 
		classe, comuns a todas as vers�es do construtor dispon�veis.
		Isto evita que sobrecargas do destrutores tenham que replicar c�digo
		a fim de finalizar os membros da classe.
		\see initialization
		*/
		virtual void finalization();


	public:

		/**
		\brief Cria o critical-section.
		Cria um objeto de CriticalSection.
		\see ~CCriticalSection
		*/
		CCriticalSection();

		/**
		\brief Cria o critical-section otimizado para multi processamento.
		Cria um objeto de Critical Section otimizado para ambiente em que exista mais de um n�cleo.
		Caso a critical section falhe em obter a trava, ao inv�s de entrar em estado de espera ( custoso )
		a thread entra em um loop, efetuando "n" spins ( menos custoso ). Se a trava for liberada nesse per�odo,
		a thread evita de entrar em modo de espera.
		Caso o ambiente n�o seja multi-processado, o par�metro � ignorado.
		\param spinCount N�mero de Spin�s que a thread ir� aguardar entes de entrar em modo de espera.
		\see ~CCriticalSection
		*/
		CCriticalSection( int spinCount );

		/**
		\brief Cria o critical-section, utilizando como base uma estrutura de controle externa.
		Cria um objeto de CCritialSection utilizando como base uma estrutura de controle passada como par�metro.
		Como n�o h� forma de verificar o status da estrutura, o objeto assume que que estrutura foi criada e
		inicializada corretamente. Seu estado de inicializa��o ser� setado para "csisInitialized".	
		\param Estrutura de Critical Section a ser utilizada. Deve ter sido previamente inicializada.
		\see ~CCriticalSection
		*/
		CCriticalSection( LPCRITICAL_SECTION criticalSection );


		/**
		\brief Destrutor da classe.
		Destr�i o objeto de critical-section.
		\see CMutex
		*/
		~CCriticalSection();


		/**
		\brief Notifica o in�cio do trecho do critical-section.
		Use leave para notificar o in�cio do trecho de c�digo delimitado
		pelo critical-section.
		*/
		void enter();

		/*
		\brief 
		\return
		*/
		//bool tryEnter(); 

		/**
		\brief Notifica o t�rmino do trecho do critical-section.
		Use leave para notificar o t�rmino do trecho de c�digo delimitado
		pelo critical-section.
		*/
		void leave();


		/**
		\brief Retorna a estrutura de dados de controle do critical-section.
		Use getCriticalSectionObject para obter uma rafer�ncia para a estrutura
		RTL_CRITICAL_SECTION.
		Esta estrutura armazena as informa��es neces�rias para o controle do
		critical-section. Sua inicializa��o e manipula��o � interna ao objeto.
		\return Estrutura de controle do critical-section.
		*/
		const LPCRITICAL_SECTION getCriticalSectionObject();


		/**
		\brief Informa o status da inicializa��o do Critical-Section.
		Use getInitializationState para obter o resultado da inicializa��o da estrutura de
		CRITICAL_SECTION.
		Caso o objeto tenha sido criado utilizando uma estrutura externa, o estado ser� marcado
		automaticamente como "csisInitialized".
		Os estados poss�veis s�o :
		csisUnknown
		csisFailed
		csisInitialized
		\return Estado da inicializa��o do Critical-Section.
		*/
		ECriticalSectionInitializationState getInitializationState();


		/**
		\brief Retorna o n�mero de spins realizados pela thread antes de de ficar em estado de espera, caso n�o consiga obter o lock.
		Use getSpinCount para obter o n�mero de spins configurado pelo Critical Section. Este valor se refere ao n�mero de Spins
		que a thread ir� executar, caso a trava do Critical Section n�o esteja dispon�vel.
		Executar spin�s ( entrar em loop ) � menos custoso do que entrar em modo de espera. Se a trava se tornar dispon�vel enquanto
		a thread est� no loop, evita-se este overhead.
		\return N�mero de spins configurado.
		*/
		int getSpinCount();

};//class CCriticalSection



#endif//#ifndef HST_CONCURRENCY_CCRITICALSECTION_H