////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>
#include <winbase.h>


////////////////////////
//Includes espec�ficos//
////////////////////////

#include "CCriticalSection.h"


///////////////////
//Inicialiaza��es//
///////////////////


//////////////////////////////
//Implementa��es dos m�todos//
//////////////////////////////


CCriticalSection::CCriticalSection()
{

	//Inicializa��es dos membros da classe.
	this->initialization();

	//Cria a estrutura de controle da se��o cr�tica
	this->m_criticalSectionObject= new RTL_CRITICAL_SECTION;

	//Inicializa o critical-section, preenchendo a estrutura de controle
	///interna com os dados necess�rios.
	InitializeCriticalSection( this->m_criticalSectionObject );

	//Armazena o valor utilizado no SpinCount
	this->m_spinCount= 0;

	
	//Armazena o c�digo do �ltimo erro gerado.
	DWORD lastError= GetLastError();
	
	//Verifica se ocorreram erros na inicializa��o do critical-section
	if( lastError == 0 ){

		//Armazena o status de sucesso na cria��o do critical-section
		this->m_initializationState= csisInitialized;


	}else{//if( GetLastError() != 0 )

		//Armazena o status de erro na cria��o do critical-section
		this->m_initializationState= csisFailed;

		switch( lastError ){

			case STATUS_NO_MEMORY:{

				//Mem�ria Insuficiente

			};break;//STATUS_NO_MEMORY

			
			default:{

				//Erro gen�rico

			}//default

		}//switch( lastError )

	}//else if( GetLastError() != 0 )

}


CCriticalSection::CCriticalSection( int spinCount )
{

	//Inicializa��es dos membros da classe.
	this->initialization();

	//Cria a estrutura de controle da se��o cr�tica
	this->m_criticalSectionObject= new RTL_CRITICAL_SECTION;

	//Inicializa o critical-section, preenchendo a estrutura de controle
	///interna com os dados necess�rios.
	//TODO - Verificar qual o include correto desta API
	//InitializeCriticalSectionAndSpinCount( this->m_criticalSectionObject, spinCount );

	//Armazena o valor utilizado no SpinCount
	this->m_spinCount= spinCount;

	
	//Armazena o c�digo do �ltimo erro gerado.
	DWORD lastError= GetLastError();
	
	//Verifica se ocorreram erros na inicializa��o do critical-section
	if( lastError == 0 ){

		//Armazena o status de sucesso na cria��o do critical-section
		this->m_initializationState= csisInitialized;


	}else{//if( GetLastError() != 0 )

		//Armazena o status de erro na cria��o do critical-section
		this->m_initializationState= csisFailed;

		switch( lastError ){

			case STATUS_NO_MEMORY:{

				//Mem�ria Insuficiente

			};break;//STATUS_NO_MEMORY

			
			default:{

				//Erro gen�rico

			}//default

		}//switch( lastError )

	}//else if( GetLastError() != 0 )

}

CCriticalSection::CCriticalSection( LPCRITICAL_SECTION criticalSection )
{

	//Inicializa��es dos membros da classe.
	this->initialization();

	//Inicializa��es dos membros da classe.
	this->m_criticalSectionObject= criticalSection;

	//Armazena o status de sucesso na cria��o do critical-section
	///OBS: Consideramos que a estrutura de Critical Section passada como par�metro
	///j� foi inicializada corretamente pois n�o h� como verificar seu estado.
	this->m_initializationState= csisInitialized;

}
	

CCriticalSection::~CCriticalSection()
{
	
	//Realiza as desaloca��es necess�rias.
	this->finalization();

}


void CCriticalSection::initialization()
{

	//Seta o valor do estado inicial da Critical Section como Unknown 
	this->m_initializationState= csisUnknown;

}


void CCriticalSection::finalization()
{

	//Verifica se o critical-section foi alocado com sucesso.
	if( this->getInitializationState() == csisInitialized ){

		//Desaloca o critical-section
		DeleteCriticalSection( this->m_criticalSectionObject );

	}//if( this->getInitializationState() == csisInitialized )
	
	//Destr�i a estrutura de controle da se��o cr�tica
	delete this->m_criticalSectionObject;

}


void CCriticalSection::enter()
{

	//Marca a entrada do trecho do critical-section.
	EnterCriticalSection( this->m_criticalSectionObject );

}


/*
bool CCriticalSection::tryEnter()
{

	return TryEnterCriticalSection( this->m_criticalSectionObject );

}
*/



void CCriticalSection::leave()
{

	//Marca o t�rmino do trecho do critical-section.
	LeaveCriticalSection( this->m_criticalSectionObject );

}


const LPCRITICAL_SECTION CCriticalSection::getCriticalSectionObject()
{

	//Retorna a estrurura do objeto de critical section
	return static_cast<const LPCRITICAL_SECTION>( this->m_criticalSectionObject );

}



ECriticalSectionInitializationState CCriticalSection::getInitializationState()
{
	
	//Retorna o status da inicializa��o do critical-section.
	return this->m_initializationState;

}


int CCriticalSection::getSpinCount()
{

	return this->m_spinCount;

}