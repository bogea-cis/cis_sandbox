///////////
//Defines//
///////////

#ifndef HST_CONCURRENCY_CMUTEX_H
#define HST_CONCURRENCY_CMUTEX_H


////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>


////////////////////////
//Includes espec�ficos//
////////////////////////
#include "CImpExpRules.h"


///////////////////
//Namespaces(Uso)//
///////////////////


//////////////
//Enumerados//
//////////////

enum EMutexInitializationState {
									masUnknown	/**Estado desconhecido.*/,
									masInvalid	/**Handle inv�lido.*/,
									masOpened	/**Mutex aberto com sucesso.*/,
									masCreated	/**Mutex criado com sucesso.*/
								};


//////////
//Classe//
//////////

/**
\class CMutex
\brief Classe de mutex para Windows.
Classe de mutex, utilizada para evitar que determinados trechos de c�digo sejam
acessados por duas threads ou processos concorrentes. Sua implementa��o se d�
atrav�s do emcapsulamento de fun��es j� existentes da API do Windows.
A cria��o do Mutex � feita atrav�s de um identificador ( nome ) deve ser fornecido
via construtor ou via setter a fim de que o Mutex seja criado.


\author Diego Felipe Lassa
\version 1.0.0.0
\date 01/01/2008
\bug
\warning
*/


const int MUT_WAIT_INFINITE	= INFINITE;	//Tempo de espera infinito. Deve ser utilizado em conjunto com o m�todo @see request()
const int MUT_RET_SUCCESS	= 0;		//O Mutex foi travado com sucesso.
const int MUT_RET_TIMEOUT	= 1;		//A tentativa de trava foi abortada devido a Timeout.
const int MUT_RET_ABANDONED	= 2;		//Thread terminated not released the mutex
const int MUT_RET_FAILED	= 3;		//Falha gen�rica na tentativa de trava do Mutex.

class CLASS_MODIFIER CMutex
{
	public:
		/////////////
		//Constants//
		/////////////

	private:

		/**Handle do mutex obtido. Caso o mutex n�o tenha sido inicializado, vale NULL.*/
		HANDLE m_handle;

		/**Armazena o nome do Mutex. Caso o mutex n�o tenha sido inicializado, vale NULL. */
		char* m_name;

		/**Armazena o status da trava do mutex. TRUE se a trava foi obtida, FALSE caso contr�rio.*/
		bool m_isLocked;

		/**Armazena o status de inicializa��o do Mutex*/
		EMutexInitializationState m_initializationState;

		/**Estabelece acesso ao mutex cujo nome � passado como par�metro.
		\param name Nome do mutex.
		*/
		void bind( const char* name );


	protected:

		/**
		\brief Realiza as inicializa��es necess�rias aos membros da classe.
		Use initialization para centralizar as inicializa��es necess�rias � 
		classe, comuns a todas as vers�es do construtor dispon�veis.
		Isto evita que sobrecargas do construtor tenham que replicar c�digo
		a fim de inicializar os membros da classe.
		\see finalization
		*/
		virtual void initialization();

		/**
		\brief Realiza as finaliza��es necess�rias aos membros da classe.
		Use initialization para centralizar as finaliza��es necess�rias � 
		classe, comuns a todas as vers�es do construtor dispon�veis.
		Isto evita que sobrecargas do destrutores tenham que replicar c�digo
		a fim de finalizar os membros da classe.
		\see initialization
		*/
		virtual void finalization();


	public:

		/**
		\brief Construtor padr�o.
		Cria um mutex n�o nomeado.
		Para determinar se o status do acesso ao mutex, utilize getInitializationState.
		\param name Nome do mutex.
		\see ~CMutex
		\see getInitializationState
		*/
		CMutex();


		/**
		\brief Construtor de c�pia.
		Para determinar se o status do acesso ao mutex, utilize getInitializationState.
		\param name Nome do mutex.
		\see ~CMutex
		\see getInitializationState
		*/
		CMutex( CMutex &mutex );


		/**
		\brief Cria o mutex, utilizando o nome passado como par�metro.
		Para determinar se o status do acesso ao mutex, utilize getInitializationState.
		\param name Nome do mutex.
		\see ~CMutex
		\see getInitializationState
		*/
		CMutex( const char* name );


		/**
		\brief Destrutor da classe.
		\see CMutex
		*/
		~CMutex();


		/**
		\brief Tenta obter a trava do Mutex. 
		Esta chamada deve ser feita no in�cio do c�digo que se deseja proteger.
		\param timeout Tempo m�ximo de espera para a obten��o do mutex. Caso seja utilizado CMutex::MUT_WAIT_INFINITE, o m�todo ir� aguardar at� que o mutex seja liberado.
		\return Status da requisi��o. Seus valores podem ser :
			-#CMutex::SEM_SUCCESS
			-#CMutex::SEM_TIMEOUT
			-#CMutex::SEM_ABANDONED
			-#CMutex::SEM_FAILED
		\see release
		*/
		int  request( int timeout = MUT_WAIT_INFINITE );

		/**
		\brief Libera a trava do Mutex.
		Esta chamada deve ser feita no fim do c�digo que se deseja proteger.
		\see request
		*/
		void release();

		/**
		\brief Identifica se o objeto possui a trava do Mutex.
		\return TRUE se o objeto possui a trava do Mutex, FALSE se contr�rio. 
		\see request
		\see release
		*/
		bool isLocked();

		/**
		\brief Retorna o Handle do mutex criado.
		\return Handle do mutex criado.
		*/
		HANDLE getHandle();

		/**
		\brief Retorna o nome utilizado pelo Mutex.
		\return Nome do mutex.
		*/
		const char* getName();

		/**
		\brief
		\return
		*/
		EMutexInitializationState getInitializationState();



};//class CMutex


#endif//#ifndef HST_CONCURRENCY_CMUTEX_H