// CEvent.h: interface for the CEvent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CEVENT_H__78E719F7_A37E_4D14_8FEE_3B3AB7EED99E__INCLUDED_)
#define AFX_CEVENT_H__78E719F7_A37E_4D14_8FEE_3B3AB7EED99E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include "CImpExpRules.h"


const int EVENT_SIGNED = 1;
const int EVENT_TIMEOUT = 0;
const int EVENT_ERROR = -1;

class CLASS_MODIFIER CEvent  
{
public:
	/**
	*  Contrutor da classe de evento
	* \param eventName descreve o nome do evento, caso n�o seja passado assumi-se NULL
	* \param initialState define o estado inicial do evento, TRUE para setado e FALSE para n�o setado, o default � FALSE
	* \param manualReset define se o evento sera resetado manualmente, TRUE � o default
	*/
	CEvent(const char* eventName, BOOL initialState = FALSE, BOOL manualReset = TRUE);

	/**
	*  Contrutor default
	*/
	CEvent();

	/**
	* Destrutor
	*/
	virtual ~CEvent();

	/**
	*  Metodo que tenta abrir um named mutex
	*/
	bool open (const char* eventName);

	/**
	*  Metodo que cria um mutex
	*/
	bool create (const char* eventName = NULL, BOOL initialState = FALSE, BOOL manualReset = TRUE);


	/**
	* Metodo para setar o evento
	*/
	void setEvent();

	/**
	* Metodo para resetar o evento
	*/
	void resetEvent();

	/**
	* Metodo para esperar o evento por um tempo determinado, o padrao e infinito
	*/
	int wait(long timeout = INFINITE);

	/**
	* Retorna o ultinmo erro reportado pelo GetLastError
	*/
	int error ();

private:
	HANDLE m_hEvent;
	int m_error;
};



#endif // !defined(AFX_CEVENT_H__78E719F7_A37E_4D14_8FEE_3B3AB7EED99E__INCLUDED_)
