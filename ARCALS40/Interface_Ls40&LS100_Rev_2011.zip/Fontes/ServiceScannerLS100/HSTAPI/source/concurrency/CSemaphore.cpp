////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>


////////////////////////
//Includes espec�ficos//
////////////////////////

#include "CSemaphore.h"


//////////////
//Namespaces//
//////////////



///////////////////
//Inicialiaza��es//
///////////////////

const int CSemaphore::SEM_WAIT_INFINITE	= INFINITE;	//Tempo de espera infinito. Deve ser utilizado em conjunto com o m�todo @see request()
const int CSemaphore::SEM_RET_SUCCESS	= 0;		//O Sem�foro foi travado com sucesso.
const int CSemaphore::SEM_RET_TIMEOUT	= 1;		//A tentativa de trava foi abortada devido a Timeout.
const int CSemaphore::SEM_RET_ABANDONED	= 2;		//Thread terminated not released the Sem�foro
const int CSemaphore::SEM_RET_FAILED	= 3;		//Falha gen�rica na tentativa de trava do Sem�foro.

const int CSemaphore::DEFAULT_INITIAL_COUNT	= 0;
const int CSemaphore::DEFAULT_MAX_COUNT		= 10;


//////////////////////////////
//Implementa��es dos m�todos//
//////////////////////////////

CSemaphore::CSemaphore()
{

	//Inicializa��es da classe
	this->initialization(); 

	//Estabelece conex�o com o sem�foro utilizando os valores-padr�o
	this->bind( CSemaphore::DEFAULT_INITIAL_COUNT, CSemaphore::DEFAULT_MAX_COUNT, NULL );

}


CSemaphore::CSemaphore( CSemaphore &semaphore )
{

	//Inicializa��es da classe
	this->initialization();

	//Estabelece conex�o com o sem�foro.
	///OBS: Neste caso consideramos que o sem�foro j� estar� aberto,
	///logo os par�metros initial_count e max_count ser�o irrelevantes
	///pois j� foram setados por quem o criou.
	this->bind( CSemaphore::DEFAULT_INITIAL_COUNT, CSemaphore::DEFAULT_MAX_COUNT, semaphore.getName() );

}


CSemaphore::CSemaphore( int initialCount, int maxCount, const char* name )
{

	//Inicializa��es da classe
	this->initialization(); 

	//Acessa o sem�foro utilizando os par�metros passados.
	///OBS: Caso o sem�foro j� tenha sido criado, os dois primeiros par�metros n�o
	///ter�o efeito.
	this->bind( initialCount, maxCount, name );

}


CSemaphore::CSemaphore( const char* name )
{

	//Inicializa��es da classe
	this->initialization(); 

	//Acessa o sem�foro utilizando os valores padr�o para o InitialCount e MaxCount
	this->bind( CSemaphore::DEFAULT_INITIAL_COUNT, CSemaphore::DEFAULT_MAX_COUNT, name );

}


CSemaphore::~CSemaphore ()
{

	//Executa o c�digo de limpeza da classe
	this->finalization(); 

}


void CSemaphore::initialization()
{

	//Seta o valor do Handle para NULL
	this->m_handle= NULL; 

	//Seta o valor do Name para NULL
	this->m_name= NULL;

	//Seta o valor de IsLocked para FALSE
	this->m_isLocked= false;

	//Seta o estado atual do acesso ao sem�foro como "desconhecido"
	this->m_initializationState= sasUnknown;

}


void CSemaphore::finalization()
{

	//Verifica se o nome foi alocado corretamente
	if( this->getName() != NULL ){

		//Deleta a String que armazena o nome da classe
		free( this->m_name ); 

	}//if( this->m_name != NULL )

	if( ! CloseHandle( this->getHandle() ) ){

		//Erro ao fechar o handle

	}//if( ! CloseHandle( this->getHandle() ) )

}



int CSemaphore::request ( int timeout )
{

	//Armazena o c�digo de retorno do m�todo "WaitForSingleObject"
	DWORD returnWaitForSingleObject= -1;;

	int result= 0;

	//Tenta obter a trava do Sem�foro "m_handle", pelo per�odo de tempo especificado por "timeout"	
	returnWaitForSingleObject= WaitForSingleObject( this->getHandle(), timeout );

	//Verifica qual o c�digo de retorno, e o traduz para as constantes
	///utilizadas pela classe do Sem�foro.
	switch( returnWaitForSingleObject ){

		case WAIT_ABANDONED:{

			result= CSemaphore::SEM_RET_ABANDONED;

		}break;//WAIT_ABANDONED
		

		case WAIT_OBJECT_0:{

			//Seta o Flag de objeto travado para True
			this->m_isLocked= true;

			result= CSemaphore::SEM_RET_SUCCESS;

		}break;//WAIT_OBJECT_0

		case WAIT_TIMEOUT:{

			result= CSemaphore::SEM_RET_TIMEOUT;

		}break;//WAIT_TIMEOUT

		default:{

			result= CSemaphore::SEM_RET_FAILED;

		}//default

	}//switch( ret )

	//Retorna o c�digo obtido.
	return result;

}//CSemaforo::Request



void CSemaphore::release()
{

	//Libera a trava do Sem�foro
	ReleaseSemaphore( this->getHandle(), 1, NULL );

	//Seta o flag de Sem�foro travado para False
	this->m_isLocked= false;

}//CSemaforo::Release


bool CSemaphore::isLocked()
{

	//Retorna o Status da trava do Sem�foro. TRUE para travado, FALSE se contr�rio.
	return this->m_isLocked;

}


HANDLE CSemaphore::getHandle()
{

	//Retorna o valor do Handle obtido para o Sem�foro.
	//return const_cast<const HANDLE>( this->m_handle );
	return this->m_handle;

}


const char* CSemaphore::getName()
{

	//Retorna o nome utilizado pelo Sem�foro.
	return const_cast<const char*>( this->m_name );

}


void CSemaphore::bind( int initialCount, int maxCount, const char* name )
{

	//Desaloca��o da string anterior
	////////////////////////////////

	//Verifica se o nome j� foi alocado
	if( this->m_name != NULL ){

		//Se sim, deleta-o
		free( this->m_name ); 

		this->m_name= NULL;

	}//if( this->m_name != NULL )

	
	
	//Estabelecimento de acesso ao sem�foro
	///////////////////////////////////////

	if( this->getHandle() != NULL ){

		this->finalization();

	}//if( this->getHandle() != NULL )

	//Tenta abrir o Sem�foro ( para o caso dele j� existir )
	this->m_handle= OpenSemaphore( SEMAPHORE_ALL_ACCESS, false, name );

	//Verifica se foi poss�vel obter o Handle para o nome desejado.
	if( this->getHandle() == NULL ){

		//Caso negativo, ent�o o Sem�foro deve ser criado.
		this->m_handle= CreateSemaphore( NULL, initialCount, maxCount, name );

		//Verifica se foi poss�vel obter o handle para o sem�foro.
		if( this->getHandle() != NULL ){

			//Se sim, ent�o marcamos o estado do acesso como Criado
			this->m_initializationState= sasCreated;

		}else{//if( this->getHandle() != NULL )

			//Caso contr�rio, marcamos a tentativa de acesso como erro.
			this->m_initializationState= sasInvalid;

		}//else if( this->getHandle() != NULL )

	}else{//if( this->getHandle() == NULL )

		//Marca o acesso ao sem�foro como aberto
		this->m_initializationState= sasOpened;

	}//else if( this->getHandle() == NULL )


	//Armazenamento do nome utilizado
	/////////////////////////////////

	this->m_name= strdup( name );

}


ESemaphoreInitializationState CSemaphore::getInitializationState()
{

	//Retorna o status do acesso
	return this->m_initializationState;

}