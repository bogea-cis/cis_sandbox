// CEvent.cpp: implementation of the CEvent class.
//
//////////////////////////////////////////////////////////////////////

#include "CEvent.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CEvent::CEvent(const char* eventName, BOOL initialState, BOOL manualReset)
{
	m_hEvent = NULL;
	m_error = 0;

	if (!open (eventName))
	{
		create( eventName, initialState, manualReset);
	}
}

CEvent::CEvent()
{
	m_hEvent = NULL;
	m_error = 0;
}

CEvent::~CEvent()
{
	if (m_hEvent != NULL)
	{
		CloseHandle(m_hEvent);
	}
}

bool CEvent::open (const char* eventName)
{
	bool ret = false;

	if (eventName != NULL)
	{
		m_hEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, eventName);
		if (m_hEvent)
		{
			ret = true;
		}
	}

	return ret;
}

bool CEvent::create (const char* eventName, BOOL initialState, BOOL manualReset)
{
	bool ret = false;

	if (m_hEvent)
	{
		CloseHandle(m_hEvent);
		m_hEvent = NULL;
	}

	m_hEvent = CreateEvent(NULL, manualReset, initialState, eventName);
	if (m_hEvent)
	{
		ret = true;
	}

	return ret;
}


void CEvent::setEvent()
{
	SetEvent(m_hEvent);
}

void CEvent::resetEvent()
{
	ResetEvent(m_hEvent);
}

int CEvent::wait(long timeout)
{
	switch (WaitForSingleObject(m_hEvent, timeout))
	{
		case WAIT_OBJECT_0:
			return EVENT_SIGNED;

		case WAIT_TIMEOUT:
			return EVENT_TIMEOUT;

		default:
			m_error = GetLastError();
			return EVENT_ERROR;
	}
}

int CEvent::error ()
{
	return m_error;
}

