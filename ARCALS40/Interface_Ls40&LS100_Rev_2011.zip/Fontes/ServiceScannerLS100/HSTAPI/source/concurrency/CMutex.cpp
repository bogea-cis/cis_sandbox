////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>


////////////////////////
//Includes espec�ficos//
////////////////////////

#include "CMutex.h"


//////////////
//Namespaces//
//////////////



///////////////////
//Inicialiaza��es//
///////////////////



//////////////////////////////
//Implementa��es dos m�todos//
//////////////////////////////

CMutex::CMutex()
{

	//Inicializa��es da classe
	this->initialization(); 

	//Estabelece conex�o com o mutex ( unnamed mutex )
	this->bind( NULL );

}

CMutex::CMutex( CMutex &mutex )
{

	//Inicializa��es da classe
	this->initialization();

	//Estabelece conex�o com o mutex ( unnamed mutex )
	this->bind( mutex.getName() );

}

CMutex::CMutex( const char* name )
{

	//Inicializa��es da classe
	this->initialization(); 

	//Seta o nome do mutex criado
	this->bind( name );

}


CMutex::~CMutex ()
{

	//Executa o c�digo de limpeza da classe
	this->finalization(); 

}


void CMutex::initialization()
{

	//Seta o valor do Handle para NULL
	this->m_handle= NULL; 

	//Seta o valor do Name para NULL
	this->m_name= NULL;

	//Seta o valor de IsLocked para FALSE
	this->m_isLocked= false;

	//Seta o estado atual do acesso ao mutex como "desconhecido"
	this->m_initializationState= masUnknown;

}


void CMutex::finalization()
{

	//Verifica se o nome foi alocado corretamente
	if( this->m_name != NULL ){

		//Deleta a String que armazena o nome da classe
		free( this->m_name ); 

	}//if( this->m_name != NULL )

	if( ! CloseHandle( this->getHandle() ) ){

		//Erro ao fechar o handle

	}//if( ! CloseHandle( this->getHandle() ) )

}



int CMutex::request ( int timeout )
{

	//Armazena o c�digo de retorno do m�todo "WaitForSingleObject"
	DWORD returnWaitForSingleObject= -1;;

	int result= 0;

	//Tenta obter a trava do Mutex "m_handle", pelo per�odo de tempo especificado por "timeout"	
	returnWaitForSingleObject= WaitForSingleObject( this->getHandle(), timeout );

	//Verifica qual o c�digo de retorno, e o traduz para as constantes
	///utilizadas pela classe do Mutex.
	switch( returnWaitForSingleObject ){

		case WAIT_ABANDONED:{

			result= MUT_RET_ABANDONED;

		}break;//WAIT_ABANDONED
		

		case WAIT_OBJECT_0:{

			//Seta o Flag de objeto travado para True
			this->m_isLocked= true;

			result= MUT_RET_SUCCESS;

		}break;//WAIT_OBJECT_0

		case WAIT_TIMEOUT:{

			result= MUT_RET_TIMEOUT;

		}break;//WAIT_TIMEOUT

		default:{

			result= MUT_RET_FAILED;

		}//default

	}//switch( ret )

	//Retorna o c�digo obtido.
	return result;

}



void CMutex::release()
{

	//Libera a trava do Mutex
	ReleaseMutex( this->m_handle );

	//Seta o flag de Mutex travado para False
	this->m_isLocked= false;

}


bool CMutex::isLocked()
{

	//Retorna o Status da trava do Mutex. TRUE para travado, FALSE se contr�rio.
	return this->m_isLocked;

}


HANDLE CMutex::getHandle()
{

	//Retorna o valor do Handle obtido para o Mutex.
	//return const_cast<const HANDLE>( this->m_handle );
	return this->m_handle;

}


const char* CMutex::getName()
{

	//Retorna o nome utilizado pelo Mutex.
	return const_cast<const char*>( this->m_name );

}


void CMutex::bind( const char* name )
{

	//Desaloca��o da string anterior
	////////////////////////////////

	//Verifica se o nome j� foi alocado
	if( this->m_name != NULL ){

		//Se sim, deleta-o
		free( this->m_name ); 

		this->m_name= NULL;

	}//if( this->m_name != NULL )



	//Estabelecimento de acesso ao mutex
	////////////////////////////////////

	if( this->getHandle() != NULL ){

		this->finalization();

	}//if( this->getHandle() != NULL )

	//Tenta abrir o Mutex ( para o caso dele j� existir )
	this->m_handle= OpenMutex( MUTEX_ALL_ACCESS, false, name );

	//Verifica se foi poss�vel obter o Handle para o nome desejado.
	if( this->getHandle() == NULL ){

		//Caso negativo, ent�o o Mutex deve ser criado.
		this->m_handle= CreateMutex( NULL, false, name );

		//Verifica se foi poss�vel obter o handle para o mutex.
		if( this->getHandle() != NULL ){

			//Se sim, ent�o marcamos o estado do acesso como Criado
			this->m_initializationState= masCreated;

		}else{//if( this->m_handle != NULL )

			//Caso contr�rio, marcamos a tentativa de acesso como erro.
			this->m_initializationState= masInvalid;

		}//else if( this->getHandle() != NULL )

	}else{//if( this->getHandle() == NULL )

		//Marca o acesso ao mutex como aberto
		this->m_initializationState= masOpened;

	}//else if( this->getHandle() == NULL )


	//Armazenamento do nome utilizado
	/////////////////////////////////
	this->m_name= strdup( name );

}


EMutexInitializationState CMutex::getInitializationState()
{

	//Retorna o status do acesso
	return this->m_initializationState;

}