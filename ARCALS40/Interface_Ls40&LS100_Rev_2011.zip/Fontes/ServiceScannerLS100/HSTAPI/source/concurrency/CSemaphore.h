///////////
//Defines//
///////////

#ifndef HST_CONCURRENCY_CSEMAPHORE_H
#define HST_CONCURRENCY_CSEMAPHORE_H


////////////////////////
//Includes gen�ricos  //
//(bibliotecas-padr�o)//
////////////////////////

#include <windows.h>


////////////////////////
//Includes espec�ficos//
////////////////////////
#include "CImpExpRules.h"


///////////////////
//Namespaces(Uso)//
///////////////////


//////////////////////////
//Namespaces(Declara��o)//
//////////////////////////


//////////////
//Enumerados//
//////////////

typedef enum ESemaphoreInitializationState {
												sasUnknown	/**Estado desconhecido.*/,
												sasInvalid	/**Handle inv�lido.*/,
												sasOpened	/**Mutex aberto com sucesso.*/,
												sasCreated	/**Mutex criado com sucesso.*/
											};


//////////
//Classe//
//////////

/**
\class CSemaphore
\brief Classe de sem�foro para Windows.
Classe de mutex, utilizada para evitar que determinados trechos de c�digo sejam
acessados por duas threads ou processos concorrentes. Sua implementa��o se d�
atrav�s do emcapsulamento de fun��es j� existentes da API do Windows.
A cria��o do Mutex � feita atrav�s de um identificador ( nome ) deve ser fornecido
via construtor ou via setter a fim de que o Mutex seja criado.

\author Diego Felipe Lassa
\version 1.0.0.0
\date 01/01/2008
\bug
\warning
*/
class CLASS_MODIFIER CSemaphore{

	private:

		/**Handle do sem�foro obtido. Caso o sem�foro n�o tenha sido inicializado, vale NULL.*/
		HANDLE m_handle;

		/**Armazena o nome do Sem�foro. Caso ele n�o tenha sido inicializado, vale NULL. */
		char* m_name;

		/**Armazena o status da trava do sem�foro. TRUE se a trava foi obtida, FALSE caso contr�rio.*/
		bool m_isLocked;

		/**Armazena o status de inicializa��o do Sem�foro*/
		ESemaphoreInitializationState m_initializationState;

		/**Estabelece acesso ao sem�foro cujo nome � passado como par�metro.
		\param initialCount
		\param maxCount
		\param name Nome do sem�foro.
		*/
		void bind( int initialCount, int maxCount, const char* name );


	protected:

		/**
		\brief Realiza as inicializa��es necess�rias aos membros da classe.
		Use initialization para centralizar as inicializa��es necess�rias � 
		classe, comuns a todas as vers�es do construtor dispon�veis.
		Isto evita que sobrecargas do construtor tenham que replicar c�digo
		a fim de inicializar os membros da classe.
		\see finalization
		*/
		virtual void initialization();

		/**
		\brief Realiza as finaliza��es necess�rias aos membros da classe.
		Use initialization para centralizar as finaliza��es necess�rias � 
		classe, comuns a todas as vers�es do construtor dispon�veis.
		Isto evita que sobrecargas do destrutores tenham que replicar c�digo
		a fim de finalizar os membros da classe.
		\see initialization
		*/
		virtual void finalization();


	public:

		/**
		\brief Construtor padr�o.
		Use este construtor para acessar ou criar um sem�foro n�o nomeado.
		Se o sem�foro n�o existir, ele ser� criado.
		Se j� existente, o sem�foro simplesmente ser� aberto.
		Para determinar se o status do acesso ao sem�foro, utilize getInitializationState.
		\param name Nome do sem�foro.
		\see ~CSemaphore
		\see getInitializationState
		*/
		CSemaphore();

		/**
		\brief Construtor de c�pia.
		Use este construtor para acessar um sem�foro baseado nas configura��es e outro objeto.
		Neste caso sup�e-se que o sem�foro j� exista, contudo:
		Se o sem�foro n�o existir, ser� criado utilizando o nome obtido em getName, do objeto passado como par�metro.
		Se j� existente, o sem�foro simplesmente ser� aberto.
		Para determinar se o status do acesso ao sem�foro, utilize getInitializationState.
		\param semaphore Objeto de c�pia.
		\see ~CSemaphore
		\see getName
		\see getInitializationState
		*/
		CSemaphore( CSemaphore &semaphore );

		/**
		\brief Cria o sem�foro, utilizando o nome passado como par�metro.
		Use este construtor para acessar ou criar um sem�foro com o nome contido em "name".
		Se o sem�foro n�o existir, ser� criado utilizando as configura��es passadas como par�metro.
		Se j� existente, o sem�foro simplesmente ser� aberto. Os demais par�metros ser�o ignorados.
		Para determinar se o status do acesso ao sem�foro, utilize getInitializationState.
		\param initialCount 
		\param maxCount 
		\param name Nome do sem�foro.
		\see ~CSemaphore
		\see getInitializationState
		*/
		CSemaphore( int initialCount, int maxCount, const char* name );	
	
		/**
		\brief Cria o mutex, utilizando o nome passado como par�metro.
		Use este construtor para acessar ou criar um sem�foro com o nome contido em "name".
		Se o sem�foro n�o existir, ser� criado utilizando as configura��es passadas como par�metro.
		Se j� existente, o sem�foro simplesmente ser� aberto.
		Para determinar se o status do acesso ao sem�foro, utilize getInitializationState.
		\param name Nome do sem�foro.
		\see ~CSemaphore
		\see getInitializationState
		*/
		CSemaphore( const char* name );



		/**
		\brief Destrutor da classe.
		\see CSemaphore
		*/
		~CSemaphore();


		/**
		\brief Tenta obter a trava do Sem�foro. 
		Esta chamada deve ser feita no in�cio do c�digo que se deseja proteger.
		\param timeout Tempo m�ximo de espera para a obten��o do sem�foro. Caso seja utilizado CMutex::SEM_INFINITE, o m�todo ir� aguardar at� que o mutex seja liberado.
		\return Status da requisi��o. Seus valores podem ser :
			-#CSemaphore::SEM_SUCCESS
			-#CSemaphore::SEM_TIMEOUT
			-#CSemaphore::SEM_ABANDONED
			-#CSemaphore::SEM_FAILED
		\see release
		*/
		int  request( int timeout );

		/**
		\brief Libera a trava do Sem�foro.
		Esta chamada deve ser feita no fim do c�digo que se deseja proteger.
		\see request
		*/
		void release();

		/**
		\brief Identifica se o objeto possui a trava do Sem�foro.
		\return TRUE se o objeto possui a trava do Sem�foro, FALSE se contr�rio. 
		\see request
		\see release
		*/
		bool isLocked();

		/**
		\brief Retorna o Handle do sem�foro criado.
		\return Handle do sem�foro criado.
		*/
		HANDLE getHandle();

		/**
		\brief Retorna o nome utilizado pelo Sem�foro.
		\return Nome do sem�foro.
		*/
		const char* getName();

		/**
		\brief
		\return
		*/
		ESemaphoreInitializationState getInitializationState();

		/////////////
		//Constants//
		/////////////

		/**Tempo de espera infinito. Deve ser utilizado em conjunto com o m�todo @see request().*/
		static const int SEM_WAIT_INFINITE;
		/**O Sem�foro foi travado com sucesso.*/
		static const int SEM_RET_SUCCESS;
		/**A tentativa de trava foi abortada devido a Timeout.*/
		static const int SEM_RET_TIMEOUT;
		/**Thread terminated not released the sem�foro.*/
		static const int SEM_RET_ABANDONED;
		/**Falha gen�rica na tentativa de trava do sem�foro.*/
		static const int SEM_RET_FAILED;

		/**Valor padr�o do n�mero de acessos iniciais.*/
		static const int DEFAULT_INITIAL_COUNT;
		/**Valor padr�o do n�mero m�ximo acessos iniciais.*/
		static const int DEFAULT_MAX_COUNT;


};//class CSemaphore



#endif//#ifndef HST_CONCURRENCY_CSEMAPHORE_H