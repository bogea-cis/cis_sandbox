// CProcess.h: interface for the CProcess class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CPROCESS_UTILS_H__AA0AE628_49C3_4851_BD19_DFA35EE1551C__INCLUDED_)
#define AFX_CPROCESS_UTILS_H__AA0AE628_49C3_4851_BD19_DFA35EE1551C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"
#include "CBasicStringList.h"
#include "CProcess.h"
#include "CList.h"

class CLASS_MODIFIER CProcessUtils  
{
public:
	CProcessUtils();
	virtual ~CProcessUtils();

	static DWORD getFirstProcessIdFromName (const char* processName);
	static bool getFirstProcessFromName (const char* processName, CProcess& out);
	static bool getProcessFromId (DWORD pid, CProcess& out);
	static bool getCurrentProcess (CProcess& out);
	static bool getProcessesFromName (const char* processName, CList<CProcess*>& out);
	static bool getAllProcess (CList<CProcess*>& out);

	static bool killProcess (const char* processName, int exitCode, bool allProcess);
	static bool killProcess (DWORD pid, int exitCode);

	static DWORD createProcess (const char* processPath, bool visible = true);
	static DWORD createProcess (const char* processPath, CBasicStringList& bslArguments, bool visible = true);
	static DWORD createProcess (const char* processPath, const char* workingDirectory, CBasicStringList& bslArguments, bool visible = true);

	static bool waitProcess (DWORD pid, int timeout);
	static bool waitProcess (const char* processName, int timeout);

	static bool processRunning (const char* processName);
	static bool processRunning (DWORD pid);

	static void getProcessModules (DWORD pid, CBasicStringList& bslModules);
	static void getProcessTimes (CProcess& process);

	static DWORD getUsedMemory (DWORD pid);
	static bool getProcessFullPath (DWORD pid, char* out, int outLen);


private:
	static bool getProcessesFromName (const char* processName, CList<CProcess*>& out, bool stopFirst);
};

#endif // !defined(AFX_CPROCESS_UTILS_H__AA0AE628_49C3_4851_BD19_DFA35EE1551C__INCLUDED_)

