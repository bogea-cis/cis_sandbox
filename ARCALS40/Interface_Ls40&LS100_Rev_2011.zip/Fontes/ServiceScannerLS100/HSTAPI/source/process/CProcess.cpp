// CProcess.cpp: implementation of the CProcess class.
//
//////////////////////////////////////////////////////////////////////

#include "CProcess.h"
#include "CProcessUtils.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcess::CProcess()
{
	memset (&m_creationTime, 0, sizeof(FILETIME));
	memset (&m_exitTime, 0, sizeof(FILETIME));
	memset (&m_kernelTime, 0, sizeof(FILETIME));
	memset (&m_userTime, 0, sizeof(FILETIME));
	memset (m_processName, '\0', sizeof(m_processName));
	m_processId = 0;
	m_cpuFirstTime = true;
}

CProcess::CProcess(const char* processName, DWORD pid)
{
	strcpy (m_processName, processName);
	m_processId = pid;
}

CProcess::~CProcess()
{
}

const char* CProcess::getProcessName ()
{
	return m_processName;
}

DWORD CProcess::getProcessId ()
{
	return m_processId;
}

void CProcess::setProcessName (const char* processName)
{
	strcpy(m_processName, processName);
}

void CProcess::setProcessId (DWORD pid)
{
	m_processId = pid;
}

int CProcess::getCpuUsage (int timeInterval)
{

	FILETIME kernel;
	FILETIME user;

	if (m_cpuFirstTime)
	{
		m_cpuFirstTime = false;
		updateProcessTimes();
	}

	kernel.dwHighDateTime = m_kernelTime.dwHighDateTime;
	kernel.dwLowDateTime = m_kernelTime.dwLowDateTime;

	user.dwHighDateTime = m_userTime.dwHighDateTime;
	user.dwLowDateTime = m_userTime.dwLowDateTime;


	Sleep (timeInterval);

	updateProcessTimes();

	ULONGLONG ftKernelDiff = subtractTimes (m_kernelTime, kernel);
	ULONGLONG ftUserDiff = subtractTimes (m_userTime, user);
	
	int ret = (int)((ftKernelDiff + ftUserDiff) / timeInterval) / 100;

	if (ret > 100)
	{
		ret = 100;
	}


	return ret;
}

DWORD CProcess::getUsedMemory ()
{
	return 	CProcessUtils::getUsedMemory(m_processId);
}

void CProcess::getCreationTime (FILETIME& out)
{
	out.dwHighDateTime = m_creationTime.dwHighDateTime;
	out.dwLowDateTime = m_creationTime.dwLowDateTime;
}

void CProcess::getExitTime (FILETIME& out)
{
	out.dwHighDateTime = m_exitTime.dwHighDateTime;
	out.dwLowDateTime = m_exitTime.dwLowDateTime;
}

void CProcess::getKernelTime (FILETIME& out)
{
	out.dwHighDateTime = m_kernelTime.dwHighDateTime;
	out.dwLowDateTime = m_kernelTime.dwLowDateTime;
}

void CProcess::getUserTime (FILETIME& out)
{
	out.dwHighDateTime = m_userTime.dwHighDateTime;
	out.dwLowDateTime = m_userTime.dwLowDateTime;
}

void CProcess::setCreationTime (FILETIME& in)
{
	m_creationTime.dwHighDateTime = in.dwHighDateTime;
	m_creationTime.dwLowDateTime = in.dwLowDateTime;
}

void CProcess::setExitTime (FILETIME& in)
{
	m_exitTime.dwHighDateTime = in.dwHighDateTime;
	m_exitTime.dwLowDateTime = in.dwLowDateTime;
}

void CProcess::setKernelTime (FILETIME& in)
{
	m_kernelTime.dwHighDateTime = in.dwHighDateTime;
	m_kernelTime.dwLowDateTime = in.dwLowDateTime;
}

void CProcess::setUserTime (FILETIME& in)
{
	m_userTime.dwHighDateTime = in.dwHighDateTime;
	m_userTime.dwLowDateTime = in.dwLowDateTime;
}


void CProcess::updateProcessTimes ()
{
	CProcessUtils::getProcessTimes(*this);
}

ULONGLONG CProcess::subtractTimes(const FILETIME& ftA, const FILETIME& ftB)
{
    LARGE_INTEGER a, b;

    a.LowPart = ftA.dwLowDateTime;
    a.HighPart = ftA.dwHighDateTime;

    b.LowPart = ftB.dwLowDateTime;
    b.HighPart = ftB.dwHighDateTime;

    return a.QuadPart - b.QuadPart;
}