// CProcess.cpp: implementation of the CProcess class.
//
//////////////////////////////////////////////////////////////////////

#include "CProcessUtils.h"
#include "psapi.h"
#include "CBasicString.h"
#include <windows.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcessUtils::CProcessUtils()
{

}

CProcessUtils::~CProcessUtils()
{

}


DWORD CProcessUtils::getFirstProcessIdFromName (const char* processName)
{
	DWORD pid = -1;
	CList<CProcess*> list;
	
	if (getProcessesFromName(processName, list, true))
	{
		CProcess* p = list[0];
		if (p)
		{
			pid = p->getProcessId ();
			delete p;
		}
	}

	return pid;
}

bool CProcessUtils::getProcessFromId (DWORD pid, CProcess& out)
{
	bool ret = false;
	HANDLE hProcess = NULL;

	// First open for termination
	hProcess = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ, FALSE, pid);

	if (hProcess)
	{
		char pName[128] = {0};
		
		GetModuleBaseName(hProcess, NULL, pName, sizeof (pName));
		out.setProcessName(pName);
		out.setProcessId(pid);
		ret = true;
	}

	return ret;
}

bool CProcessUtils::getCurrentProcess (CProcess& out)
{
	bool ret = false;

	DWORD pid = GetCurrentProcessId();
	ret = CProcessUtils::getProcessFromId(pid, out);

	return ret;
}


bool CProcessUtils::getProcessesFromName (const char* processName, CList<CProcess*>& out)
{
	return getProcessesFromName(processName, out, false);
}

bool CProcessUtils::getProcessesFromName (const char* processName, CList<CProcess*>& out, bool stopFirst)
{
	bool ret = false;
	DWORD aiPID[1000];
	DWORD iCb = 1000;
	DWORD iCbneeded = 0;
	DWORD iNumProcess = 0;
	HANDLE hProcess = NULL;
	HMODULE hModule = NULL;
	BOOL bResult = FALSE;

	bResult = EnumProcesses (aiPID, iCb, &iCbneeded);

	if(bResult)
	{
		char szName[MAX_PATH];

		iNumProcess = iCbneeded / sizeof(DWORD);

		for (DWORD i = 0; i < iNumProcess; i++)
		{
			memset (szName, '\0', sizeof (szName));

			// First, get a handle to the process
			hProcess = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,
									FALSE,
									aiPID[i]);

	        // Now, get the process name
			if (hProcess)
			{
				if (EnumProcessModules(hProcess, &hModule, sizeof(hModule), &iCbneeded))
				{
					GetModuleBaseName(hProcess, hModule, szName, sizeof(szName));
				}

				CloseHandle(hProcess);
			}
			
			if (szName && strlen (szName) > 0)
			{
				if (processName == NULL || stricmp (processName, szName) == 0)
				{
					// Process found
					out.add(new CProcess(szName, aiPID[i]));
					ret = true;

					if (stopFirst)
					{
						break;
					}
				}
			}
		}
	}


	return ret;
}

bool CProcessUtils::getFirstProcessFromName (const char* processName, CProcess& out)
{
	bool ret = false;
	DWORD pid = getFirstProcessIdFromName (processName);

	if (pid >= 0)
	{
		out.setProcessName(processName);
		out.setProcessId(pid);
		ret = true;
	}

	return ret;
}

bool CProcessUtils::getAllProcess (CList<CProcess*>& out)
{
	//passando nulo retorna todos
	return  getProcessesFromName (NULL, out, false);
}


bool CProcessUtils::killProcess (const char* processName, int exitCode, bool allProcess)
{
	bool ret = false;

	CList<CProcess*> list;
	
	if (getProcessesFromName(processName, list, false))
	{
		int pid;
		int count = list.count();

		CProcess* p = NULL;

		for (int i = 0; i < count; i++)
		{
			p = list[i];
			if (p)
			{
				pid = -1;
				pid = p->getProcessId ();
				if (pid >= 0)
				{
					ret = killProcess (pid, exitCode);
				}
				delete p;

				if (!allProcess)
				{
					break;
				}
			}
		}
	}

	return ret;
}

bool CProcessUtils::killProcess (DWORD pid, int exitCode)
{
	bool ret = false;
	HANDLE hProcess = NULL;

	// First open for termination
	hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pid);

	if (hProcess)
	{
		if(TerminateProcess(hProcess, exitCode))
		{
			// process terminated
			ret = true;
		}

		CloseHandle (hProcess);
	}

	return ret;
}


DWORD CProcessUtils::createProcess (const char* processPath, bool visible)
{
	CBasicStringList bslAux;
	return createProcess(processPath, NULL, bslAux, visible);
}

DWORD CProcessUtils::createProcess (const char* processPath, CBasicStringList& bslArguments, bool visible)
{
	return createProcess(processPath, NULL, bslArguments, visible);
}

DWORD CProcessUtils::createProcess (const char* processPath, const char* workingDirectory, CBasicStringList& bslArguments, bool visible)
{
	DWORD ret = -1;
	PROCESS_INFORMATION pinfo;
	STARTUPINFO stInfo;	

	char* arguments = bslArguments.serialize(' ');


	ZeroMemory( &stInfo, sizeof(stInfo) );
	stInfo.cb = sizeof(STARTUPINFO);
	stInfo.lpTitle = NULL;

	ZeroMemory( &pinfo, sizeof(pinfo) );

	CBasicString cmdLine;

	cmdLine.append (processPath);
	cmdLine.append (" ");
	cmdLine.append (arguments);

	DWORD creationFlags = NORMAL_PRIORITY_CLASS;

	if (!visible) creationFlags |= CREATE_NO_WINDOW;

	if (CreateProcess(NULL, 
					(char*)cmdLine.cStr(), 
					NULL,
					NULL,
					TRUE,
					creationFlags,
					NULL,
					workingDirectory,
					&stInfo,
					&pinfo))
	{
		ret = pinfo.dwProcessId;
	}

	delete[] arguments;

	return ret;
}


bool CProcessUtils::waitProcess (DWORD pid, int timeout)
{
	bool ret = false;
	HANDLE hProcess = OpenProcess(SYNCHRONIZE,
									FALSE,
									pid);
	if (hProcess)
	{
		if (WaitForSingleObject(hProcess, timeout) == WAIT_OBJECT_0)
		{
			ret = true;
		}
		CloseHandle (hProcess);
	}
	else
	{
		//processo ja esta morto
		ret = true;
	}
	return ret;
}

bool CProcessUtils::waitProcess (const char* processName, int timeout)
{
	bool ret = false;
	DWORD pid  = getFirstProcessIdFromName(processName);

	if (pid != -1)
	{
		ret = waitProcess (pid, timeout);
	}

	return ret;
}

bool CProcessUtils::processRunning (const char* processName)
{
	return getFirstProcessIdFromName (processName) != -1;
}

bool CProcessUtils::processRunning (DWORD pid)
{
	bool ret = false;
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,
							FALSE,
							pid);

	if (hProcess)
	{
		CloseHandle (hProcess);
		ret = true;
	}

	return ret;
}

void CProcessUtils::getProcessModules (DWORD pid, CBasicStringList& bslModules)
{
    HMODULE hMods[1024];
    DWORD cbNeeded;
	HANDLE hProcess = NULL;

	hProcess = OpenProcess (PROCESS_QUERY_INFORMATION |
                            PROCESS_VM_READ,
							FALSE,
							pid);

	if (hProcess)
	{
		if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded))
		{
			DWORD amount = cbNeeded / sizeof(HMODULE);
			char szModName[MAX_PATH];
			
			bslModules.clear();

			for (DWORD i = 0; i < amount; i++)
			{
				szModName[0] = '\0';
				if ( GetModuleFileNameEx( hProcess, hMods[i], szModName, sizeof(szModName)))
				{
					bslModules.add(szModName);
				}
			}
		}

		CloseHandle (hProcess);
	}
}

void CProcessUtils::getProcessTimes (CProcess& process)
{
	HANDLE hProcess = OpenProcess (PROCESS_QUERY_INFORMATION |
									PROCESS_VM_READ,
									FALSE,
									process.getProcessId());

	if (hProcess)
	{
		FILETIME creation;
		FILETIME exit;
		FILETIME kernel;
		FILETIME user;

		if (GetProcessTimes (hProcess, &creation, &exit, &kernel, &user))
		{
			process.setCreationTime(creation);
			process.setExitTime(exit);
			process.setKernelTime(kernel);
			process.setUserTime(user);
		}

		CloseHandle(hProcess);
	}
}

DWORD CProcessUtils::getUsedMemory (DWORD pid)
{
	DWORD ret = 0;
    HANDLE hProcess;
    PROCESS_MEMORY_COUNTERS pmc;

	hProcess = OpenProcess(  PROCESS_QUERY_INFORMATION |
                                PROCESS_VM_READ,
                                FALSE, pid );

	if (hProcess)
	{
		if ( GetProcessMemoryInfo( hProcess, &pmc, sizeof(pmc)) )
		{
			ret = pmc.WorkingSetSize;//PagefileUsage;
		}

		CloseHandle (hProcess);
	}

	return ret;
}

bool CProcessUtils::getProcessFullPath (DWORD pid, char* out, int outLen)
{
	bool ret = false;
    HANDLE hProcess;

	hProcess = OpenProcess(  PROCESS_QUERY_INFORMATION |
                                PROCESS_VM_READ,
                                FALSE, pid );

	if (hProcess)
	{
		if (GetModuleFileNameEx(hProcess, NULL, out, outLen) > 0)
		{
			ret = true;
		}
		CloseHandle (hProcess);
	}

	return ret;
}

