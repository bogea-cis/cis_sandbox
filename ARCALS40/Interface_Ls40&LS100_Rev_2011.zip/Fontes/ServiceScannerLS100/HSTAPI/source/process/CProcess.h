// CProcess.h: interface for the CProcess class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CPROCESS_H__E6B5B830_8BE2_4667_8EB2_1CBAF836D642__INCLUDED_)
#define AFX_CPROCESS_H__E6B5B830_8BE2_4667_8EB2_1CBAF836D642__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CImpExpRules.h"
#include <windows.h>

class CLASS_MODIFIER CProcess  
{
public:
	CProcess();
	CProcess(const char* processName, DWORD pid);
	virtual ~CProcess();

	const char* getProcessName ();
	DWORD getProcessId ();

	void setProcessName (const char* processName);
	void setProcessId (DWORD pid);

	int getCpuUsage (int timeInterval = 200);
	DWORD getUsedMemory ();

	void getCreationTime (FILETIME& out);
	void getExitTime (FILETIME& out);
	void getKernelTime (FILETIME& out);
	void getUserTime (FILETIME& out);

	void setCreationTime (FILETIME& in);
	void setExitTime (FILETIME& in);
	void setKernelTime (FILETIME& in);
	void setUserTime (FILETIME& in);

	void updateProcessTimes ();

private:
	ULONGLONG subtractTimes(const FILETIME& ftA, const FILETIME& ftB);

private:
	FILETIME m_creationTime;
	FILETIME m_exitTime;
	FILETIME m_kernelTime;
	FILETIME m_userTime;

	char m_processName[128];
	DWORD m_processId;
	bool m_cpuFirstTime;
};

#endif // !defined(AFX_CPROCESS_H__E6B5B830_8BE2_4667_8EB2_1CBAF836D642__INCLUDED_)
