#ifndef _CIMP_EXP_RULES_H_
#define _CIMP_EXP_RULES_H_


//Verifica qual o modo de declara��o da classe deve ser utilizado
///HST_DLL_LIB_IMPORT : A classe est� contida em uma DLL, e seu s�mbolo ser� importado.
///                     Este define deve ser utilizado quando o projeto deseja utilizar uma classe contida em uma DLL ( que seja exportada ).
///HST_DLL_LIB_EXPORT : A classe est� contida em uma DLL, e seu s�mbolo ser� exportado.
///                     Este define deve ser utilizado quando o projeto ( DLL ) deseja torna a classe acess�vel para uso.
///"ELSE"             : A classe ser� utilizada atrav�s da inclus�o de seu c�digo fonte.
#ifdef HST_DLL_LIB_IMPORT
	#define CLASS_MODIFIER __declspec(dllimport)
#elif HST_DLL_LIB_EXPORT
	#define CLASS_MODIFIER __declspec(dllexport)
#else 
	#define CLASS_MODIFIER 
#endif


#endif //_CIMP_EXP_RULES_H_
