///////////////////////////////////////////////////////////////////////////////
// Descricao:
// Autor: Amadeu Vilar Filho / Luis Gustavo de Brito
// Data de criacao: 11/12/2007
//
// Alteracoes:
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __I_SERIALIZABLE_H__
#define __I_SERIALIZABLE_H__

#include "CImpExpRules.h"

class CLASS_MODIFIER ISerializable {
	public:
		virtual bool saveToFile(const char* fileName) = 0;
		virtual bool loadFromFile(const char* fileName) = 0;
};

#endif //__I_SERIALIZABLE_H__