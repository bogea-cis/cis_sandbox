///////////////////////////
//Define of Scanner
///////////////////////////
#define BUFFER_LEN		513

#define RUNNING			0
#define PAUSE			1
#define STOP			2


///////////////////////////
//Define of configurations
///////////////////////////
#define PATH_CONFIG				".\\Config"
#define PATH_FILE_NAME			"\\ScannerConfig.ini"

#define SCANNER_SECTION			"Scanner"
#define PORTCOM_SECTION			"PortCom"
#define IMAGES_SECTION			"Images"

#define LOG_PATH_KEY			"LogPath"
#define LOG_NAME_KEY			"LogName"

#define COM_PORT_KEY			"Name"
#define BAUDRATE_KEY			"Baudrate"
#define DATABIT_KEY				"DataBit"
#define PARITY_KEY				"Parity"
#define STOPBIT_KEY				"StopBit"

#define IMAGE_QUALITY_KEY		"ImageQuality"
#define SIDE_KEY				"Side"
#define SAVE_PATH_KEY			"SavePath"
#define IMAGE_FRONT_NAME_KEY	"ImageFrontName"
#define IMAGE_BACK_NAME_KEY		"ImageBackName"


///////////////////////////
//Defines new errors 
///////////////////////////
#define APLIC_ERROR_DOCUMENT_PRESENT_LEAFER		-200
#define APLIC_ERROR_DOCUMENT_PRESENT_BIN		-201
#define APLIC_ERROR_PHOTO_MICR_COVERED			-202


///////////////////////////
//State machine of LS100
///////////////////////////
enum STATE_SCANNER{
	CONFIGURATION,
	OPEN,
	SERVICE_STATUS_CHECK,
	READ,
	STATUS,
	CODELINE,
	BARCODE,
	SEND_BUFFER,
	IMAGES,
	MOUNT_IMAGES_NAMES,
	SAVE_FRONT_IMAGE,
	SAVE_BACK_IMAGE,
	FREE_IMAGE,
	CHECK_NR_DOC_COUNTER,
	TREAT_ERROR,
	CLOSE,
	FINAL
};


///////////////////////////
//Types of document that�s 
//scanner accept
///////////////////////////
enum DOCUMENT_TYPE{
	MICR_DOC,
	BARCODE_DOC
};
