// CScannerLS100.cpp: implementation of the CScannerLS100 class.
//
//////////////////////////////////////////////////////////////////////

#include "CScannerLS100.h"
#include "LS100.h"
#include "LsApi.h"

const char* THIS_FILE = "CScannerLS100.cpp";

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CScannerLS100::CScannerLS100()
{
	char log[300] = {0};
	char directory[65] = {0};
	
	this->m_state = CONFIGURATION;
	this->m_document = MICR_DOC;
	this->m_status = false;
	this->m_read = true;

	this->m_hConnect = 0;

	this->m_retAPI = LS_HARDWARE_ERROR;
	memset(this->m_buffer, 0x00, sizeof(this->m_buffer));
	memset(this->m_imageFrontName, 0x00, sizeof(this->m_imageFrontName));
	memset(this->m_imageBackName, 0x00, sizeof(this->m_imageBackName));

	this->m_frontImage = &this->m_frontImageH;
	this->m_backImage = &this->m_backImageH;

	this->m_nrDoc = 1;
	this->m_errorTry = 1;
	this->m_serviceStatus = RUNNING;

	sprintf(directory, "%s\\CIS\\ScannerLS100", getenv("PROGRAMFILES"));
	SetCurrentDirectory(directory);

	this->m_info = new CInfoContainer();
	
	sprintf(log, "%s\\%s", this->m_info->getLogPath(), this->m_info->getLogName());

	this->m_log = new CLogger(log, LOW_PRIORITY);

	this->m_serial = new CSerial();
}

CScannerLS100::~CScannerLS100()
{
	if(this->m_info != NULL)
	{
		delete this->m_info;
		this->m_info = NULL;
	}
	
	if(this->m_log != NULL)
	{
		delete this->m_log;
		this->m_log = NULL;
	}

	if(this->m_serial != NULL)
	{
		if(this->m_serial->IsOpen() == true)
		{
			this->m_serial->Close();
			delete this->m_serial;
			this->m_serial = NULL;
		}
	}
}

bool CScannerLS100::execute()
{
	this->m_log->logMsg(THIS_FILE, "execute", LOW_PRIORITY, "INITIALIZING SERVICE");

	while(this->m_read == true)
	{
		switch(this->m_state)
		{
			case CONFIGURATION:
				this->m_state = this->configuration();
				continue;

			case OPEN:
				this->m_state = this->open();
				continue;

			case SERVICE_STATUS_CHECK:
				this->m_state = this->verifyServiceStatus();
				continue;

			case READ:
				this->m_state = this->readDocument();
				continue;

			case STATUS:
				this->m_state = this->status();
				continue;

			case CODELINE:
				this->m_state = this->codeLine();
				continue;

			case BARCODE:
				this->m_state = this->barCode();
				continue;

			case SEND_BUFFER:
				this->m_state = this->sendBuffer();
				continue;

			case IMAGES:
				this->m_state = this->images();
				continue;

			case MOUNT_IMAGES_NAMES:
				this->m_state = this->mountImagesNames();
				continue;

			case SAVE_FRONT_IMAGE:
				this->m_state = this->saveFrontImage();
				continue;

			case SAVE_BACK_IMAGE:
				this->m_state = this->saveBackImage();
				continue;

			case FREE_IMAGE:
				this->m_state = this->freeImage();
				continue;

			case CHECK_NR_DOC_COUNTER:
				this->m_state = this->checkNrDocCounter();
				continue;

			case TREAT_ERROR:
				this->m_state = this->treatError();
				continue;
			
			case CLOSE:
				this->m_state = this->close();
				continue;

			case FINAL:
			default:
				this->m_read = false;
				continue;
		}
	}

	return this->m_status;
}

void CScannerLS100::setServiceStatus(int status)
{
	this->m_serviceStatus = status;
}

STATE_SCANNER CScannerLS100::configuration()
{
	STATE_SCANNER ret = OPEN;
	char com[32+1] = {0};
	char directory[256+1] = {0};

	sprintf(directory, "%s\\CIS\\ScannerLS100", getenv("PROGRAMFILES"));
	SetCurrentDirectory(directory);
	
	this->m_log->logMsg(THIS_FILE, "configuration", LOW_PRIORITY, "Begin");

	this->m_hwndApp = (HWND)new HANDLE;
	this->m_hinstApp = (HINSTANCE)new HANDLE;

	sprintf(com, "\\\\.\\%s", this->m_info->getComPort());

	for(int i = 0; i < 3; i++)
	{
		this->m_serial->Open(com);

		if(this->m_serial->GetLastError() > 0)
		{
			this->m_log->logMsg(THIS_FILE, "configuration", LOW_PRIORITY, "Error %d when opening %s, try open again", this->m_serial->GetLastError(), com);
			
			Sleep(3000);
		}
		else
		{
			this->setupCom();
			break;
		}
	}

	if(this->m_serial->GetLastError() > 0)
	{
		ret = FINAL;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::open()
{
	STATE_SCANNER ret = SERVICE_STATUS_CHECK;

	this->m_log->logMsg(THIS_FILE, "open", LOW_PRIORITY, "Begin");

	this->m_retAPI = LSConnect(this->m_hwndApp, this->m_hinstApp, 
								LS_100_USB, &this->m_hConnect);
	
	if(this->m_retAPI == LS_TRY_TO_RESET)
	{
		this->m_log->logMsg(THIS_FILE, "open", HIGH_PRIORITY, "Error opening scanner, error: %d", this->m_retAPI);
		ret = TREAT_ERROR;
	}
	else if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "open", HIGH_PRIORITY, "Error opening scanner, error: %d", this->m_retAPI);
		ret = FINAL;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::verifyServiceStatus()
{
	STATE_SCANNER ret = READ;

	this->m_log->logMsg(THIS_FILE, "verifyServiceStatus", LOW_PRIORITY, "Begin");

	while(this->m_serviceStatus == PAUSE)
	{
		Sleep(1000);
	}
	
	if(this->m_serviceStatus == STOP)
	{
		this->m_log->logMsg(THIS_FILE, "verifyServiceStatus", LOW_PRIORITY, "Set to close scanner");
		ret = CLOSE;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::readDocument()
{
	STATE_SCANNER ret = STATUS;

	this->m_log->logMsg(THIS_FILE, "readDocument", LOW_PRIORITY, "Begin");
	
	this->m_retAPI = LSDocHandle(this->m_hConnect, this->m_hwndApp, NO_FRONT_STAMP,
									 NO_PRINT_VALIDATE, READ_CODELINE_MICR, SIDE_ALL_IMAGE,
									 SCAN_MODE_256GR200, AUTOFEED, SORTER_BAY1,
									 WAIT_YES, BEEP, &this->m_nrDoc, NULL, NULL);

	if(this->m_retAPI == LS_FEEDER_EMPTY)
	{
		ret = CHECK_NR_DOC_COUNTER;
	}
	else if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "readDocument", HIGH_PRIORITY, "Error reading document, error: %d", this->m_retAPI);
		ret = TREAT_ERROR;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::status()
{
	STATE_SCANNER ret = CODELINE;
	unsigned char senseKey[8] = {0};
	unsigned char sensorStatus[16] = {0};

	this->m_log->logMsg(THIS_FILE, "status", LOW_PRIORITY, "Begin");

	senseKey[0] = 0x04;
	this->m_retAPI = LSPeripheralStatus(this->m_hConnect, this->m_hwndApp, 
										senseKey, sensorStatus);

	if(this->m_retAPI == LS_OKAY)
	{
		if(sensorStatus[0] & 0x02)
		{
			if(sensorStatus[0] & 0x01)
			{
				this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Document present in the leafer");
				this->m_retAPI = APLIC_ERROR_DOCUMENT_PRESENT_LEAFER;
				ret = TREAT_ERROR;
			}
			else
			{
				this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Bit 0 isn�t setted");
			}
		}
		else
		{
			this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Bit 1 isn�t setted");
		}

		if(sensorStatus[0] & 0x08)
		{
			if(sensorStatus[0] & 0x04)
			{
				this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Photo MICR covered");
				this->m_retAPI = APLIC_ERROR_PHOTO_MICR_COVERED;
				ret = TREAT_ERROR;
			}
			else
			{
				this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Bit 2 isn�t setted");		
			}
		}
		else
		{
			this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Bit 3 isn�t setted");
		}
		
		if(sensorStatus[0] & 0x80)
		{
			this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Peripheral just ON");
			this->m_retAPI = APLIC_ERROR_DOCUMENT_PRESENT_BIN;
			ret = TREAT_ERROR;
		}
		else
		{
			this->m_log->logMsg(THIS_FILE, "status", HIGH_PRIORITY, "Bit 7 isn�t setted");
		}
	}

	return ret;
}

STATE_SCANNER CScannerLS100::codeLine()
{
	STATE_SCANNER ret = SEND_BUFFER;
	char buffer[BUFFER_LEN] = {0};
	short bufferLen = BUFFER_LEN - 1;
	char bufferBarCode[BUFFER_LEN] = {0};
	short bufferLenBarCode = BUFFER_LEN - 1;
	char bufferOptic[BUFFER_LEN] = {0};
	short bufferLenOptic = BUFFER_LEN - 1;

	this->m_log->logMsg(THIS_FILE, "codeLine", LOW_PRIORITY, "Begin");

	this->m_retAPI = LSReadCodeline(this->m_hConnect, this->m_hwndApp, 
									buffer, &bufferLen, bufferBarCode, &bufferLenBarCode,
									bufferOptic, &bufferLenOptic);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "codeLine", HIGH_PRIORITY, "Error getting code line, error: %d", this->m_retAPI);
		ret = TREAT_ERROR;
	}
	else if(bufferLen == 0)
	{
		this->m_log->logMsg(THIS_FILE, "codeLine", HIGH_PRIORITY, "Possible barcode document, try read bar code");
		this->m_document = BARCODE_DOC;
		ret = IMAGES;
	}
	else if(bufferLen < 0 || bufferLen > 40 || this->validateCodeLine(buffer) == false)
	{
		this->m_log->logMsg(THIS_FILE, "codeLine", HIGH_PRIORITY, "Error getting code line, codeLine: %s, len:%d", buffer, bufferLen);
		ret = SERVICE_STATUS_CHECK;
	}
	else
	{
		memset(this->m_buffer, 0x00, sizeof(this->m_buffer));
		strncpy(this->m_buffer, buffer, bufferLen);
		this->m_document = MICR_DOC;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::barCode()
{
	STATE_SCANNER ret = SEND_BUFFER;
	char tempNameImage[512+1] = {0};
	char buffer[BUFFER_LEN] = {0};
	unsigned int bufferLen = BUFFER_LEN - 1;

	this->m_log->logMsg(THIS_FILE, "barCode", LOW_PRIORITY, "Begin");

	sprintf(tempNameImage, "%s\\tmpBarcode.bmp", this->m_info->getSavePathImage());
	this->m_retAPI = LSSaveDIB(this->m_hwndApp, *this->m_frontImage, 
								tempNameImage);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "barCode", HIGH_PRIORITY, "Error saving document, error: %d", this->m_retAPI);
		return TREAT_ERROR;
	}

	try
	{
		this->m_retAPI = LSReadBarcodeFromBitmap(this->m_hwndApp, *this->m_frontImage, 
													READ_BARCODE_2_OF_5, 0, 0, 0, 0, 
													buffer, &bufferLen);
	}
	catch(...)
	{
		this->m_log->logMsg(THIS_FILE, "barCode", HIGH_PRIORITY, "Error reading bitmap image, exception");
	}

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "barCode", HIGH_PRIORITY, "Error reading bitmap image, error: %d", this->m_retAPI);
		ret = TREAT_ERROR;
	}

	if(bufferLen > 0 && this->m_retAPI == LS_OKAY)
	{
		char nameImage[512+1] = {0};
		sprintf(nameImage, "%s\\%s_%s.bmp",this->m_info->getSavePathImage(), 
											this->m_info->getImageFrontName(),
											buffer);

		rename(tempNameImage, nameImage);
		unlink(tempNameImage);
		strcpy(this->m_imageFrontName, nameImage);
		
		memset(this->m_buffer, 0x00, sizeof(this->m_buffer));
		strncpy(this->m_buffer, buffer, bufferLen);
	}
	else
	{
		unlink(tempNameImage);
		this->m_log->logMsg(THIS_FILE, "barCode", HIGH_PRIORITY, "Invalid barcode");
		ret = FREE_IMAGE;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::sendBuffer()
{
	STATE_SCANNER ret = IMAGES;
	
	this->m_log->logMsg(THIS_FILE, "sendBuffer", LOW_PRIORITY, "Begin");
		
	if(this->m_serial->Write(this->m_buffer, 0, 0, 5000))
	{
		this->m_log->logMsg(THIS_FILE, "sendBuffer", LOW_PRIORITY, "Error %d when sending codeLine", this->m_serial->GetLastError());
	}

	if(this->m_document == BARCODE_DOC)
	{
		this->m_log->logMsg(THIS_FILE, "sendBuffer", HIGH_PRIORITY, "Barcode document");
		ret = FREE_IMAGE;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::images()
{
	STATE_SCANNER ret = MOUNT_IMAGES_NAMES;
	
	this->m_log->logMsg(THIS_FILE, "images", LOW_PRIORITY, "Begin");

	this->m_retAPI = LSReadImage(this->m_hConnect, this->m_hwndApp, CLEAR_ALL_BLACK,
									 SIDE_ALL_IMAGE, READMODE_BRUTTO, this->m_nrDoc, 
									 this->m_frontImage, this->m_backImage, NULL, NULL);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "images", HIGH_PRIORITY, "Error getting images handles, error: %d", this->m_retAPI);
		ret = TREAT_ERROR;
	}

	if(this->m_document == BARCODE_DOC)
	{
		ret = BARCODE;
	}

	return ret;
}

STATE_SCANNER CScannerLS100::mountImagesNames()
{
	STATE_SCANNER ret = SAVE_FRONT_IMAGE;
	char codeLineEdited[BUFFER_LEN] = {0};
	int codeLineLen = 0;

	this->m_log->logMsg(THIS_FILE, "mountImagesNames", LOW_PRIORITY, "Begin");

	strcpy(codeLineEdited, this->m_buffer);
	codeLineLen = strlen(codeLineEdited);

	for(int i = 0; i < codeLineLen; i++)
	{
		if(isdigit(codeLineEdited[i]) == 0)
		{
			codeLineEdited[i] = 'C';
		}
	}

	sprintf(this->m_imageFrontName, "%s\\%s_%s.jpg", this->m_info->getSavePathImage(), 
			this->m_info->getImageFrontName(), codeLineEdited);

	sprintf(this->m_imageBackName, "%s\\%s_%s.jpg", this->m_info->getSavePathImage(), 
			this->m_info->getImageBackName(), codeLineEdited);

	return ret;
}

STATE_SCANNER CScannerLS100::saveFrontImage()
{
	STATE_SCANNER ret = SAVE_BACK_IMAGE;

	this->m_log->logMsg(THIS_FILE, "saveFrontImage", LOW_PRIORITY, "Begin");

	this->m_retAPI = LSSaveJPEG(this->m_hwndApp, *this->m_frontImage,
									this->m_info->getImageQuality(), this->m_imageFrontName);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "saveFrontImage", HIGH_PRIORITY, "Error saving JPEG front image without edit, error: %d", this->m_retAPI);
	}

	return ret;
}

STATE_SCANNER CScannerLS100::saveBackImage()
{
	STATE_SCANNER ret = FREE_IMAGE;

	this->m_log->logMsg(THIS_FILE, "saveBackImage", LOW_PRIORITY, "Begin");

	this->m_retAPI = LSSaveJPEG(this->m_hwndApp, *this->m_backImage,
									this->m_info->getImageQuality(), this->m_imageBackName);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "saveBackImage", HIGH_PRIORITY, "Error saving JPEG back image without edit, error: %d", this->m_retAPI);
	}

	return ret;
}

STATE_SCANNER CScannerLS100::freeImage()
{
	STATE_SCANNER ret = CHECK_NR_DOC_COUNTER;

	this->m_log->logMsg(THIS_FILE, "freeImage", HIGH_PRIORITY, "Begin", this->m_retAPI);

	this->m_retAPI = LSFreeImage(this->m_hwndApp, this->m_frontImage);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "freeImage", HIGH_PRIORITY, "Error free front image, error: %d", this->m_retAPI);
	}

	this->m_retAPI = LSFreeImage(this->m_hwndApp, this->m_backImage);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "freeImage", HIGH_PRIORITY, "Error free back image, error: %d", this->m_retAPI);
	}

	if(stricmp(this->m_info->getSide(), "Front") == 0)
	{
		unlink(this->m_imageBackName);
	}
	else if(stricmp(this->m_info->getSide(), "Back") == 0)
	{
		unlink(this->m_imageFrontName);
	}
	else if(stricmp(this->m_info->getSide(), "None") == 0)
	{
		unlink(this->m_imageFrontName);
		unlink(this->m_imageBackName);
	}

	return ret;
}


STATE_SCANNER CScannerLS100::checkNrDocCounter()
{
	STATE_SCANNER ret = SERVICE_STATUS_CHECK;

	this->m_log->logMsg(THIS_FILE, "checkNrDocCounter", LOW_PRIORITY, "Begin");

	if(this->m_nrDoc > 10000)
	{
		this->m_log->logMsg(THIS_FILE, "checkNrDocCounter", HIGH_PRIORITY, "Set nrDoc to 1");
		this->m_nrDoc = 1;
	}
	
	return ret;	
}

STATE_SCANNER CScannerLS100::treatError()
{
	STATE_SCANNER ret = FREE_IMAGE;

	this->m_log->logMsg(THIS_FILE, "treatError", LOW_PRIORITY, "Begin");

	if(this->m_retAPI == LS_TRY_TO_RESET)
	{
		if(this->m_errorTry++ > 3)
		{
			this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Exceded open try");
			ret = FINAL;
		}
		else
		{
			LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);
			ret = OPEN;
		}
	}
	else if(this->m_retAPI == LS_BOURRAGE)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Document jammed");

		//MessageBox(NULL, "Documento enroscado, retire e pressione o bot�o OK", "Scanner LS100", MB_OK);
		
		LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);
	}
	else if(this->m_retAPI == LS_INVALID_COMMAND)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Invalid command, send read again");
	}
	else if(this->m_retAPI == LS_DATA_TRUNCATED)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Software error, send read again");
	}
	else if(this->m_retAPI == LS_NO_LIBRARY_LOAD)
	{
		//MessageBox(NULL, "Arquivo IMG_UTIL.dll n�o encontrado, reinstale o scanner", "Scanner LS100", MB_OK);
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Verify if file IMG_UTIL.dll are installed ");
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "and in the same directory of LS100.dll, closing scanner");
		ret = CLOSE;
	}
	else if(this->m_retAPI == LS_QUEUE_FULL)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Queue full, try reset");
		LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);
	}
	else if(this->m_retAPI == APLIC_ERROR_DOCUMENT_PRESENT_LEAFER)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Document present in the leafer");
		//MessageBox(NULL, "Documento enroscado, retire e pressione o bot�o OK", "Scanner LS100", MB_OK);
		LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);
	}
	else if(this->m_retAPI == APLIC_ERROR_PHOTO_MICR_COVERED)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Photo Micr covered");
		//MessageBox(NULL, "Leitor de codeLine obstru�do, desobistrua e pressione o bot�o OK", "Scanner LS100", MB_OK);
		LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);
	}
	else if(this->m_retAPI == APLIC_ERROR_DOCUMENT_PRESENT_BIN)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Document present in the bin");
		//MessageBox(NULL, "Documento enroscado, retire e pressione o bot�o OK", "Scanner LS100", MB_OK);
		LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);
	}
	else if(this->m_retAPI == LS_RETRY)
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Try read image again");
	}
	else
	{
		this->m_log->logMsg(THIS_FILE, "treatError", HIGH_PRIORITY, "Error manipulating bitmap, try read image again");
	}

	return ret;
}

STATE_SCANNER CScannerLS100::close()
{
	this->m_log->logMsg(THIS_FILE, "close", LOW_PRIORITY, "Begin");

	this->m_retAPI = LSDisconnect(this->m_hConnect, this->m_hwndApp);

	if(this->m_retAPI != LS_OKAY)
	{
		this->m_log->logMsg(THIS_FILE, "close", HIGH_PRIORITY, "Error closing scanner, error: %d", this->m_retAPI);
		this->m_retAPI = LSReset(this->m_hConnect, this->m_hwndApp, RESET_BELT_CLEANING);

		if(this->m_retAPI != LS_OKAY)
		{
			this->m_log->logMsg(THIS_FILE, "close", HIGH_PRIORITY, "Error reseting scanner, error: %d", this->m_retAPI);
		}

		this->m_retAPI = LSDisconnect(this->m_hConnect, this->m_hwndApp);
		
		if(this->m_retAPI != LS_OKAY)
		{
			this->m_log->logMsg(THIS_FILE, "close", HIGH_PRIORITY, "Error closing scanner, error: %d", this->m_retAPI);
			this->m_log->logMsg(THIS_FILE, "close", HIGH_PRIORITY, "Closing scanner, error: %d", this->m_retAPI);
		}
		else
		{
			this->m_status = true;
		}
	}
	else
	{
		this->m_log->logMsg(THIS_FILE, "close", HIGH_PRIORITY, "Success closing scanner");
		this->m_status = true;
	}

	return FINAL;
}

bool CScannerLS100::validateCodeLine(const char* codeLine) const
{
	bool ret = false;

	this->m_log->logMsg(THIS_FILE, "setupCom", LOW_PRIORITY, "validateCodeLine");

	if(!isdigit(codeLine[0]) && isdigit(codeLine[1]) && isdigit(codeLine[2]) &&
		isdigit(codeLine[3]) && isdigit(codeLine[4]) &&
		isdigit(codeLine[5]) && isdigit(codeLine[6]) &&
		isdigit(codeLine[7]) && isdigit(codeLine[8]) &&
		!isdigit(codeLine[9]))
	{
		ret = true;
	}

	return ret;
}

void CScannerLS100::setupCom()
{
	this->m_log->logMsg(THIS_FILE, "setupCom", LOW_PRIORITY, "Begin");

	CSerial::EBaudrate baudrate = CSerial::EBaud9600;
	CSerial::EDataBits dataBit = CSerial::EData8;
	CSerial::EParity parity = CSerial::EParNone;
	CSerial::EStopBits stopBits = CSerial::EStop1;
	
	baudrate = (CSerial::EBaudrate)atoi(this->m_info->getBaudrate());
	
	dataBit = (CSerial::EDataBits)atoi(this->m_info->getDataBit());

	parity = (CSerial::EParity)atoi(this->m_info->getParity());

	stopBits = (CSerial::EStopBits)atoi(this->m_info->getStopBit());

	this->m_log->logMsg(THIS_FILE, "setupCom", LOW_PRIORITY, "Setup BaudRate: %d, DataBit: %d", baudrate, dataBit);
	this->m_log->logMsg(THIS_FILE, "setupCom", LOW_PRIORITY, "Setup Parity: %d, StopBits: %d", parity, stopBits);

	this->m_serial->Setup(baudrate, dataBit, parity, stopBits);
}
