// CInfoContainer.h: interface for the CInfoContainer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CINFOCONTAINER_H__2AC08D24_00AE_441A_AE4D_147BA7C3F1DD__INCLUDED_)
#define AFX_CINFOCONTAINER_H__2AC08D24_00AE_441A_AE4D_147BA7C3F1DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CInfoContainer  
{
public:
	CInfoContainer();
	virtual ~CInfoContainer();

	bool loadInformations();
	bool getValueStr(const char* session, const char* key, char* value);

	void setLogPath();
	const char* getLogPath();
	void setLogName();
	const char* getLogName();
	void setComPort();
	const char* getComPort();


	void setBaudrate();
	const char* getBaudrate();
	void setDataBit();
	const char* getDataBit();
	void setParity();
	const char* getParity();
	void setStopBit();
	const char* getStopBit();


	void setImageQuality();
	int getImageQuality();
	void setSide();
	const char* getSide();
	void setSavePathImage();
	const char* getSavePathImage();
	void setImageFrontName();
	const char* getImageFrontName();
	void setImageBackName();
	const char* getImageBackName();

private:
	char m_logPath[256+1];
	char m_logName[256+1];

	char m_comPort[8+1];
	char m_baudrate[8+1];
	char m_dataBit[8+1];
	char m_parity[8+1];
	char m_stopBit[8+1];

	int m_imageQuality;
	char m_side[8+1];
	char m_savePathImage[256+1];
	char m_imageFrontName[64+1];
	char m_imageBackName[64+1];

};

#endif // !defined(AFX_CINFOCONTAINER_H__2AC08D24_00AE_441A_AE4D_147BA7C3F1DD__INCLUDED_)

