#include "HSTAPI.h"
#include <stdio.h>


void testProcess ()
{
	bool bRet;
	CBasicStringList bslArguments;

	bslArguments.add("d:\\fones.txt");

	DWORD pid = CProcessUtils::createProcess("c:\\windows\\notepad.exe", bslArguments);


	CList<CProcess*> processes;
	CProcessUtils::getAllProcess(processes);

	CProcess* pProcess;
	for (int i = 0; i < processes.count(); i++)
	{
		pProcess = processes.at(i);
		printf ("name [%s]  CPU [%d] Memory[%d]\n", pProcess->getProcessName(), pProcess->getCpuUsage(), pProcess->getUsedMemory());


		delete pProcess;
	}

	processes.clear();



	Sleep (300);
	pid = CProcessUtils::getFirstProcessIdFromName("notepad.exe");


	char path[256];
	CProcessUtils::getProcessFullPath(pid, path, sizeof(path));


	CProcess proc;
	CProcessUtils::getProcessFromId(pid, proc);


	CBasicStringList bslAux;
	CProcessUtils::getProcessModules(pid, bslAux);
	//bslAux.show();

	//bRet = CProcessUtils::waitProcess(pid, 2000);
	bRet = CProcessUtils::waitProcess("firefox.exe", INFINITE);

	pid = CProcessUtils::createProcess("c:\\windows\\notepad.exe", bslArguments);
	printf ("pid %d", pid);

	Sleep (200);

	CProcessUtils::processRunning(pid);
	CProcessUtils::processRunning("notepad.exe");


	CProcessUtils::killProcess("notepad.exe", 0, false);
	CProcessUtils::killProcess("notepad.exe", 0, true);

	CProcess proc2;
	CProcessUtils::getFirstProcessFromName("firefox.exe", proc2);
	while (true)
	{
		printf ("Firefox MEM %d\n", proc2.getUsedMemory());
		printf ("Firefox CPU %d%%\n", proc2.getCpuUsage(500));
		Sleep (2000);
	}
}

void testBasicStringList ()
{
	CBasicStringList bsl;
	

	bsl.deserialize("||luis|gustavo", "|");

	//bsl.show();
	printf ("count %d", bsl.count());


	DWORD start = GetTickCount();

	printf ("Adding begin\n");
	for (int i = 0; i < 100000; i ++)
	{
		bsl.add("ABCDEFGHIJKLMINOPQRSTUVXWYZ");
	}

	printf ("Adding end %d \n", GetTickCount() - start);
	start = GetTickCount();



	printf ("Removing start\n");

	bsl.clear();

	printf ("Removing end %d \n", GetTickCount() - start);
	start = GetTickCount();

}

void testeCBuffer ()
{
	CBuffer buff;

	buff.setDefaultMemoryBlockLength (3);

	unsigned char teste[] = "\x10\x15\x65\x84\xFF\x00\x65\x66\x67\x68\x69\x70\x71\x72\x73\x74\x00\x75\x76";
	int size = sizeof(teste);


	buff.setBuffer((unsigned char*)"\x00\x02\x03", 3);
	buff.clear();
	buff.setBuffer((unsigned char*)"\x00\x02\x03", 3);

	int rc;
	
	buff.setBuffer(teste, size);
	rc = buff.compare((unsigned char*)"\x00\x02\x04", 3);
	rc = buff.compare((unsigned char*)"\x00\x01\x03", 3);
	rc = buff.compare((unsigned char*)"\x00\x02\x05", 2);

	buff.append((unsigned char*)"\x00\x02\x03", 3);
	buff.append(teste, size);
	
	rc = buff.compare((unsigned char*)"\x00\x02", 2);
	rc = buff.compare(teste, size);

	CBuffer aux;

	buff.clear();
	buff.setBuffer((unsigned char*)"\x00\xaa\x9a\xa9\x02\x03\xff\xf0\x0f\x40", 7);

	buff.unpack(aux);
	printf ("unpacked [%s]\n", aux.getBuffer());


	CBuffer aux2;
	aux.pack(aux2);
	printf ("unpacked [%s]\n", aux2.getBuffer());

}


void testCBasicString ()
{
	CBasicString teste("Luis Gustavo");

	teste.subString(0, 3, teste);
	teste.show();
	teste.append(teste);
	teste.show();

	teste.replace("L", "12");
	//teste.replace(teste, teste);
	teste.show();
}

void testCBufferFormatter ()
{
	CBufferFormatter f("AO40");

	f.add("Preamb", 3, CFieldBuffer::EFT_AlphaNumeric);
	f.add("Cod Transac", 4, CFieldBuffer::EFT_AlphaNumeric);
	f.add("CodPais", 10, CFieldBuffer::EFT_Numeric);
	f.add("DDD", 2, CFieldBuffer::EFT_Numeric);
	f.add("Fone", 8, CFieldBuffer::EFT_Numeric);
	f.add("Nome", 32, CFieldBuffer::EFT_AlphaNumeric);
	f.add("Nome2", 32, CFieldBuffer::EFT_AlphaNumeric, CFieldBuffer::EFA_Rigth);
	f.add("Biometria", 32, CFieldBuffer::EFT_Binary);


	f.elmtAt("Preamb")->setValue("'  ");
	f.elmtAt("Cod Transac")->setValue("AO40");
	f.elmtAt("CodPais")->setValue("555");
	f.elmtAt("ddd")->setValue("19");
	f.elmtAt("Fone")->setValue("32940331");
	f.elmtAt("Nome")->setValue("HST Sistemas & Tecnologia Luis Gustavo de Brito");
	f.elmtAt("Nome2")->setValue("HST Sistemas & Tecnologia");
	f.elmtAt("Biometria")->setValue((unsigned char*)"\x00\x01\xff\x30\x31\x32\x33", 7);

	f.log("d:\\buffer.txt");

	CBuffer out;
	f.serialize(out);

	CFileUtils::appendDataInFile("d:\\buffer2.txt", out.getBuffer(), out.length());

}


void testIniFile ()
{
	/*
	CConfigContainer* ini = CConfigContainer::getInstance();

	ini->loadFromFile("teste.ini");

	
	char aux[256];
	strcpy (aux, ini->getValueStr("bla", "key"));


	ini->saveToFile();
	*/

}

bool getFilesFoundInZip(const char* zipFilePath, EFindOptions fOptions, CBasicStringList& output)
{
	bool ret = false;
	ZRESULT zRet;

	//Vamos percorrer os arquivos que estao no zip
	//e adicionalos na lista

	
	printf ("Opening zip %s\n", zipFilePath);
	
	ZIPENTRY zipInformation;
	HZIP hzTemp = OpenZip (zipFilePath, NULL);

	output.clear();

	if (hzTemp)
	{
		memset (&zipInformation, '\0', sizeof(ZIPENTRY));

		//vamos pegar informacoes do arquivo zip
		//para isto passamos -1 no index
		if (GetZipItem(hzTemp, -1, &zipInformation) == ZR_OK)
		{
			int len = zipInformation.index;
			for (int i = 0; i < len; i++)
			{
				zRet = GetZipItem(hzTemp, i, &zipInformation);

				//se for pasta ignora
				
				if ((fOptions == EFOAll) ||
					(fOptions == EFOOnlyFiles && ((zipInformation.attr & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)) ||
					(fOptions == EFOOnlyDirectories && ((zipInformation.attr & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY))
					)
				{
					output.add(zipInformation.name);
				}
			}

			ret = true;
		}
		else
		{
			printf ("Error getting zip information\n");
			ret = false;
		}
		CloseZip( hzTemp );
	}

	return ret;

}

bool unCompressFile (const char* zipName, const char* baseDir)
{
	bool ret = true;
	ZRESULT zRet;
	ZIPENTRY zipInformation;

	HZIP hzTemp = OpenZip (zipName, NULL);

	if (hzTemp)
	{
		memset (&zipInformation, '\0', sizeof(ZIPENTRY));
		SetUnzipBaseDir(hzTemp, baseDir);

		//vamos pegar informacoes do arquivo zip
		//para isto passamos -1 no index
		if (GetZipItem(hzTemp, -1, &zipInformation) == ZR_OK)
		{
			int len = zipInformation.index;
			for (int i = 0; i < len; i++)
			{
				GetZipItem(hzTemp, i, &zipInformation);

				zRet = UnzipItem(hzTemp, i, zipInformation.name);
				//qdo unzipa um arquivo com tamanho 0 retorna ZR_ENDED e isto nao eh erro
				if (zRet != ZR_OK && zRet != ZR_ENDED)
				{
					if (zRet != ZR_CORRUPT)
					{
						// ficamos com erro, mais vamos continuar unzipando
						ret = false;
					}
					else
					{
						break;
					}
				}
			}
			if (ret)
			{
				printf ("unzip OK!\n");
			}
		}
		else
		{
			printf ("Error getting zip information\n");
			ret = false;
		}
		CloseZip( hzTemp );
	}
	else
	{
		ret = false;
		printf ("Error Opening zip\n");
	}
	return ret;
}


void testUnzip ()
{
	CBasicStringList bsl;
	getFilesFoundInZip("F:\\TempF\\N-W-2010-02-02-00.zip", EFOOnlyFiles, bsl);
	unCompressFile("F:\\TempF\\N-W-2010-02-02-00.zip", "F:\\TempF");

		/*
	HZIP hzTemp = OpenZip ("F:\\TempF\\N-W-2010-02-02-00.zip", NULL);

	if (hzTemp)
	{
		printf ("ok\n");
		CloseZip(hzTemp);
	}
	else
	{
		printf ("nok\n");
	}
	*/
}


#include <conio.h>
void main ()
{
	testUnzip();
	//testCBufferFormatter();
	//testCBasicString();
	//testeCBuffer();
	//testBasicStringList();
	//testProcess();

	getch ();
}
