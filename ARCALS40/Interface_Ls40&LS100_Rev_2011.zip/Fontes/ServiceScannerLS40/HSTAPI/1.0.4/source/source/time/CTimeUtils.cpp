// CTimeUtils.cpp: implementation of the CTimeUtils class.
//
//////////////////////////////////////////////////////////////////////

#include "CTimeUtils.h"
#include <windows.h>
#include <time.h>

CTimeUtils::CTimeUtils ()
{
	m_timeout = 0;
	m_start = 0;
}

CTimeUtils::~CTimeUtils()
{

}

void CTimeUtils::msleep(unsigned long milisec)  
{  
	Sleep(milisec);
} 

void CTimeUtils::start (int timeout)
{
	//struct timeval current;

	//gettimeofday (&current, NULL);
	m_start = GetTickCount();
	
	m_timeout = timeout;
}

bool CTimeUtils::checkTimeout ()
{
	int now;
	//struct timeval current;

	//gettimeofday (&current, NULL);
	now = GetTickCount();//current.tv_sec * 1000 + current.tv_usec / 1000;
		
	if ((now - m_start) > m_timeout)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int CTimeUtils::getElapsedTime ()
{
	int now;
	//struct timeval current;

	//gettimeofday (&current, NULL);
	now = GetTickCount(); //current.tv_sec * 1000 + current.tv_usec / 1000;
	
	return now - m_start;
}


