//-------------------------------------------------------------------------------------------------------
//	(c) COPYRIGHT 2004  HST EQUIPAMENTOS
//	ELETRONICOS Ltda, Campinas (SP), Brasil
//	ALL RIGHTS RESERVED - TODOS OS DIREITOS RESERVADOS
//	CONFIDENTIAL, UNPUBLISHED PROPERTY OF HST E. E. Ltda
//	PROPRIEDADE CONFIDENCIAL NAO PUBLICADA DA HST Ltda.
//
//	A HST nao se responsabiliza pelo uso indevido de seu codigo.
//
//-------------------------------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   NAME OF THE MODULE: 
// 
//   VERSION: 1.0
//
//   PURPOSE:
//       Class to manipulate Threads.
//	
//	Author: Luis Gustavo de Brito
//	Date:	23/08/2008
//
// 	COMMENTS:
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CThread.cpp: implementation of the CThread class.
//
//////////////////////////////////////////////////////////////////////

#include "CThread.h"

int CThread::m_threadObjectsCounter = 0;
bool CThread::m_allExit = false;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CThread::CThread() : bRunning( false ), m_tid( 0L ), m_exit ( false )
{
	CThread::m_threadObjectsCounter ++;
}

CThread::~CThread()
{
	CThread::m_threadObjectsCounter --;
}

void CThread::start()
{                  
	if ( !bRunning )                   
	{
	   // tenta criar thread
	   m_handle = (HANDLE) _beginthreadex(NULL, 0, &CThread::dispatch,  this, 0, &m_tid);
	}
}             

unsigned __stdcall CThread::dispatch( void* threadObj )
{                  
	( (CThread*)threadObj )->bRunning = true;
	( (CThread*)threadObj )->run();

	delete (CThread*)threadObj;
	return 0;
}                  

bool CThread::join (int timeout)
{
	m_exit = true;
	return WaitForSingleObject (m_handle, timeout) == WAIT_OBJECT_0;
}
     
void CThread::waitAllThreadsToDie (bool currentIsCThread)
{
	m_allExit = true;

	//se a trhread que chamou este metodo eh um CThread entao nao podemos espera-la
	if (currentIsCThread)
	{
		while (CThread::m_threadObjectsCounter > 1)
		{
			Sleep(100);
		}
	}
	else
	{
		while (CThread::m_threadObjectsCounter > 0)
		{
			Sleep(100);
		}
	}

	m_allExit = false;
}

bool CThread::isToExit ()
{
	return m_exit || CThread::m_allExit;
}

unsigned long CThread::getThreadId() const
{
	return m_tid;
}

HANDLE CThread::getHandle() const
{
	return m_handle;
}

bool CThread::stop()
{
	bool bRet = false;

	TerminateThread(getHandle(), 0);

	if ( CloseHandle( getHandle() ) == TRUE )
	{
		bRet = true;
		bRunning = false;
	}


	return bRet;
}
