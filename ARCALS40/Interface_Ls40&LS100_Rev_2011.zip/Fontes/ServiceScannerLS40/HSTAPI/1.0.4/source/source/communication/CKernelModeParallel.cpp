// CKernelModeParallel.cpp: implementation of the CKernelModeParallel class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <string.h>
#include "CKernelModeParallel.h"


//command addr
const int PARALLEL_CMD_STROBE			= 0X01;
const int PARALLEL_CMD_AUTO_FEED		= 0X02;
const int PARALLEL_CMD_INIT				= 0X04;
const int PARALLEL_CMD_SELECT			= 0X08;
const int PARALLEL_CMD_ENABLE_INT		= 0X10;


//status addr
const int PARALLEL_ST_ERROR				= 0X08;
const int PARALLEL_ST_SELECT			= 0X10;
const int PARALLEL_ST_PAPER				= 0X20;
const int PARALLEL_ST_ACK				= 0X40;
const int PARALLEL_ST_BUSY				= 0X80;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CKernelModeParallel::CKernelModeParallel(const char* portName)
{
	if (!stricmp (portName, "LPT1"))
	{
		//configura��o padrao para porta LPT1
		m_data = new CInpOut32(0x378);
		m_status = new CInpOut32(0x379);
		m_command = new CInpOut32(0x37A);

	}
	else if (!stricmp (portName, "LPT2"))
	{
		//configura��o padrao para porta LPT2
		m_data = new CInpOut32(0x278);
		m_status = new CInpOut32(0x279);
		m_command = new CInpOut32(0x27A);
	}
	else
	{
		//TODO log
		m_data = NULL;
		m_status = NULL;
		m_command = NULL;
	}
	m_handle = NULL;
}

CKernelModeParallel::CKernelModeParallel(int parallelDataAddr, 
											int parallelStatusAddr, 
											int parallelCommandAddr)
{
	m_data = new CInpOut32(parallelDataAddr);
	m_status = new CInpOut32(parallelStatusAddr);
	m_command = new CInpOut32(parallelCommandAddr);
	m_handle = NULL;
}


CKernelModeParallel::~CKernelModeParallel()
{
	//chama close para ter certeza que o recurso foi liberado
	this->close();

	if (m_data)
	{
		delete m_data;
		m_data = NULL;
	}
	if (m_status)
	{
		delete m_status;
		m_status = NULL;
	}
	if (m_command)
	{
		delete m_command;
		m_command = NULL;
	}
}


//abre comunica��o com a porta atravez do giveio
bool CKernelModeParallel::open ()
{
	bool ret = false;

	if (m_data == NULL || 
		m_status == NULL || 
		m_command == NULL)
	{
		return ret;
	}

	m_handle = ::CreateFile(GIVEIO_DEVICE_NAME,
						   GENERIC_READ|GENERIC_WRITE, 
						   0,
						   0,
						   OPEN_EXISTING,
						   0,
						   0);

	if (m_handle != INVALID_HANDLE_VALUE && m_handle != NULL)
	{
		ret = true;
	}

	return ret;
}


//fecha comunica��o com a porta
void CKernelModeParallel::close ()
{
	if (m_handle)
	{
		CloseHandle(m_handle);
		m_handle = NULL;
	}
}


//leitura de dados da porta
int CKernelModeParallel::writeByte (unsigned char byte)
{
	int written = 0;

	//aguarda a porta estar disponivel
	if (waitAvailability(DEFAULT_AVAILABITY_TIMEOUT))
	{
		//indica que vamos escrever
		setStrobePin(true);

		//escreve
		if (m_data->putByte(byte))
		{
			written = 1;
		}
		//indica que j� escrevemos
		setStrobePin(false);
	}
	return written;
}

int CKernelModeParallel::writeByteArray (const unsigned char* byteArray, unsigned int byteArrayLen)
{
	int written = 0;
	const unsigned char* p = byteArray;

	for (unsigned int i = 0; i < byteArrayLen; p++, i++)
	{
		if (writeByte(*p))
		{
			written++;
		}
		else
		{
			//se der erro para de escrever para nao demorar mto
			break;
		}
	}

	if (written == 0)
	{
		//erro
		return -1;
	}
	return written;
}

//leitura de dados da porta
int CKernelModeParallel::readByte (unsigned char *byte)
{
	int readed = 0;

	//aguarda a porta estar disponivel
	if (waitAvailability(DEFAULT_AVAILABITY_TIMEOUT))
	{
		//escreve
		if (*byte = m_status->getByte())
		{
			readed = 1;
		}
	}

	return readed;
}

int CKernelModeParallel::readByteArray (unsigned char* byteArray, unsigned int byteArrayLen)
{
	int readed = 0;
	unsigned char *p = byteArray;

	for (unsigned int i = 0; i < byteArrayLen; p++, i++)
	{
		if (readByte(p))
		{
			readed++;
		}
		else
		{
			//se der erro para de escrever para nao demorar mto
			break;
		}
	}

	if (readed == 0)
	{
		//erro
		return -1;
	}
	return readed;
}


//Status Register 0x309 (LPT1)

//obtem byte de status da impressora
unsigned char CKernelModeParallel::getStatusByte ()
{
	return m_status->getByte();
}


//verifica o estado o pino busy
bool CKernelModeParallel::busyPin (unsigned char statusByte)
{
	return (statusByte & PARALLEL_ST_BUSY) == PARALLEL_ST_BUSY ? true : false;
}


//verifica o estado o pino ack
bool CKernelModeParallel::ackPin (unsigned char statusByte)
{
	return (statusByte & PARALLEL_ST_ACK) == PARALLEL_ST_ACK ? true : false;
}


//verifica o estado o pino paper
bool CKernelModeParallel::paperPin (unsigned char statusByte)
{
	return (statusByte & PARALLEL_ST_PAPER) == PARALLEL_ST_PAPER ? true : false;
}


//verifica o estado o pino select
bool CKernelModeParallel::selectPin (unsigned char statusByte)
{
	return (statusByte & PARALLEL_ST_SELECT) == PARALLEL_ST_SELECT ? true : false;
}


//verifica o estado o pino error
bool CKernelModeParallel::errorPin (unsigned char statusByte)
{
	return (statusByte & PARALLEL_ST_ERROR) == PARALLEL_ST_ERROR ? true : false;
}



//Command register 0x30A (LPT1)

unsigned char CKernelModeParallel::getCommandByte ()
{
	return m_command->getByte();
}


//seta valor do pino enable interruption
void CKernelModeParallel::setEnableIntPin (bool value)
{
	unsigned char stByte = getCommandByte();
	unsigned char newByte = value ? (stByte | PARALLEL_CMD_ENABLE_INT) : (stByte & (~PARALLEL_CMD_ENABLE_INT)) ;
	setCommandPinsByte (newByte);
}


//seta valor do pino select
void CKernelModeParallel::setSelectPin (bool value)
{
	unsigned char stByte = getCommandByte();
	unsigned char newByte = value ? (stByte | PARALLEL_CMD_SELECT) : (stByte & (~PARALLEL_CMD_SELECT)) ;
	setCommandPinsByte (newByte);
}


//seta valor do pino init
void CKernelModeParallel::setInitPin (bool value)
{
	unsigned char stByte = getCommandByte();
	unsigned char newByte = value ? (stByte | PARALLEL_CMD_INIT) : (stByte & (~PARALLEL_CMD_INIT)) ;
	setCommandPinsByte (newByte);
}


//seta valor do pino autoFeed
void CKernelModeParallel::setAutoFeedPin (bool value)
{
	unsigned char stByte = getCommandByte();
	unsigned char newByte = value ? (stByte | PARALLEL_CMD_AUTO_FEED) : (stByte & (~PARALLEL_CMD_AUTO_FEED)) ;
	setCommandPinsByte (newByte);
}


//seta valor do pino strobe
void CKernelModeParallel::setStrobePin (bool value)
{
	unsigned char stByte = getCommandByte();
	unsigned char newByte = value ? (stByte | PARALLEL_CMD_STROBE) : (stByte & (~PARALLEL_CMD_STROBE)) ;
	setCommandPinsByte (newByte);
}

//seta valor do pino strobe
void CKernelModeParallel::setCommandPinsByte (unsigned char value)
{
	m_command->putByte (value);
}

//aguarda pino busy ser setado para 0
bool CKernelModeParallel::waitAvailability (int miliseconds)
{
	bool ret = false;
	int start = GetTickCount();
	unsigned int end = start + miliseconds;
	unsigned char stByte = getStatusByte();

	do
	{
		if (busyPin(getStatusByte()))
		{
			ret = true;
			break;
		}
	}while (GetTickCount() <= end);

	return ret;
}
