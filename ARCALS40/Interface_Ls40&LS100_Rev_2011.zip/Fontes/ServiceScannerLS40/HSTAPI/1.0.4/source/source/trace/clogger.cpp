//-----------------------------------------------------------------------------
// (c) COPYRIGHT 2004 HST EQUIPAMENTOS
// ELETRONICOS Ltda, Campinas (SP), Brasil
// ALL RIGHTS RESERVED - TODOS OS DIREITOS RESERVADOS
// CONFIDENTIAL, UNPUBLISHED PROPERTY OF HST E. E. Ltda
// PROPRIEDADE CONFIDENCIAL NAO PUBLICADA DA HST Ltda.
//
// A HST nao se responsabiliza pelo uso indevido de seu codigo.
//
//-----------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
//
// NAME OF THE MODULE: CLogger
//
// VERSION: 1.0
//
// PURPOSE:
// Module of support to log
//
// Author: Lu�s Gustavo de Brito
// Date: 19/05/2005 - dd/mm/yyyy
//
// COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <time.h>
#include <sys/timeb.h>
#include <windows.h>
#include "CLogger.h"
#include "CFileUtils.h"
#include "CObjectContainer.h"


#define THIS_FILE "clogger.cpp"



///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: CLogger
//
// OBJECTIVE:
// initialize the CLogger Class
//
// ENTRANCE ARGUMENTS:
// logFileName: specifies the name of log's file, its cannot be
//				bigger that 256 characters.
// 			    example: CLogger ("c:\\ejm\\traces\\ejmtrc.log", ..., ...)
//
// priority: define the minimum priority of the messages's log.
//		     its can be modified calling setPriorty method. The
//		     possible values for this parameter are:
//		     -	LOW_PRIORITY
//		     -	MEDIUM_PRIORITY
//		     -	HIGH_PRIORITY
//		     example: CLogger (..., HIGH_PRIORITY, ...)
//
//
// sizeLimit: determine the log's file length, a default
//			  value is assumed(FLOPPY_SIZE_LIMIT = ~ a floppy with 1,44 Mb)
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// none
//
// COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////
CLogger::CLogger(const char* logPath, CPriority priority, ULONG sizeLimit, short numberOfBackupFiles, const char* enableFile)
{
	char path[256];
	char fileName[64];
	char ext[16] = {0};
	memset(m_path, '\0', sizeof(m_path));
	memset(m_fileName, '\0', sizeof(m_fileName));

	//quebra o nome do arquivo
	if (CFileUtils::breakFileName(logPath, path, fileName, ext))
	{
		strcpy (m_path, path);
		strcpy (m_fileName, fileName);
	}

	m_sizeLimit = sizeLimit;
	setPriority(priority);
	setNumberOfBackupFiles(numberOfBackupFiles);


	strcpy (m_enableFilePath, enableFile);

	//quebra o nome do arquivo
	if (CFileUtils::breakFileName(m_enableFilePath, path, fileName, ext))
	{
		//verifica se o diretorio nao existe
		if (!CFileUtils::fileExists(path))
		{
			//cria diretorio
			CFileUtils::createDirectoryRecursive(path);
		}
	}

	m_mutex = new CMutex(m_fileName);
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: ~CLogger
//
// OBJECTIVE:
// finalize the CLogger Class
//
// ENTRANCE ARGUMENTS:
//	none
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// none
//
// COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////
CLogger::~CLogger()
{
	if (m_mutex != NULL)
	{
		delete m_mutex;
	}
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: logMsg
//
// OBJECTIVE:
// log the content passed in the corresponding file
//
// ENTRANCE ARGUMENTS:
//
// fileName: determine the name of file of the function
//			 that called logMsg
//			 example: logMsg("c:/hst/test.cpp", ..., ..., ..., ...)
//
// functionName: determine the name of the function
//				 that called logMsg
//				 example: logMsg(..., "showArray", ..., ..., ...)
//
// priority: determine the priority of the log's message.
//		     possible values for this parameter are:
//		     -	LOW_PRIORITY
//		     -	MEDIUM_PRIORITY
//		     -	HIGH_PRIORITY
//			 example: logMsg(..., ..., HIGH_PRIORITY, ..., ...)
//
// message: specifies the message that will be logged, this
//			parameter is used with ...
//			example: logMsg(..., ..., ..., "number is %d %c %x", 25, 25, 25)
//
// ...: specifies the arguments to be used for the message
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// LOG_SUCCESS - if message was logged
// LOG_ERROR - if message wasn't logged
// COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////
void CLogger::logMsg(const char* fileName,
        			const char* functionName,
                    CPriority priority,
                    const char* message,
                    ...)
{
	va_list args;
	va_start( args, message );

	vlogMsg( fileName, functionName, priority, message, args );

	va_end( args );
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: vlogMsg
//
// OBJECTIVE:
// log the content passed in the corresponding file
//
// ENTRANCE ARGUMENTS:
//
// fileName: determine the name of file of the function
//			 that called logMsg
//			 example: logMsg("c:/hst/test.cpp", ..., ..., ..., ...)
//
// functionName: determine the name of the function
//				 that called logMsg
//				 example: logMsg(..., "showArray", ..., ..., ...)
//
// priority: determine the priority of the log's message.
//		     possible values for this parameter are:
//		     -	LOW_PRIORITY
//		     -	MEDIUM_PRIORITY
//		     -	HIGH_PRIORITY
//			 example: logMsg(..., ..., HIGH_PRIORITY, ..., ...)
//
// message: specifies the message that will be logged, this
//			parameter is used with ...
//			example: logMsg(..., ..., ..., "number is %d %c %x", 25, 25, 25)
//
// args: specifies the arguments to be used for the message
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// LOG_SUCCESS - if message was logged
// LOG_ERROR - if message wasn't logged
// COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////
void CLogger::vlogMsg(const char* fileName,
        			const char* functionName,
                    CPriority priority,
                    const char* message,
                    va_list args)
{
	FILE* fp = NULL;
	
	if (priority >= getPriority() && 
		isEnable())
	{
        m_mutex->request(INFINITE);

		fp = openFile();

		if (fp != NULL)
		{
			int fileSize = getFileSize(fp);
			if (fileSize >= (long)m_sizeLimit)
			{
				fclose(fp);
				createBackup();
				fp = openFile();
				fileSize = 0;
			}


			if (fp != NULL)
			{
				char dateTime[64];
				char str[256] = {0};


				//verifica se eh um novo arquivo
				if (fileSize == 0)
				{
					//escreve header
					fwrite (FILE_HEADER_STRING, strlen(FILE_HEADER_STRING), 1, fp);
				}

				sprintf (str, "%s;%s;%s;prt %d;", getDateAndTime(dateTime),
									fileName,
									functionName,
									priority);
				
				fwrite( str, strlen(str), 1, fp);
				vfprintf( fp, message, args );
				#ifdef _DEBUG
				vprintf (message, args);
				printf ("\n");
				#endif
				fwrite( "\n", 1, 1, fp);
				fclose(fp);
			}
		}
		m_mutex->release();	
	}
}

void CLogger::logHex (const char* fileName,
						const char* functionName,
						CPriority priority,
						const char* headerMsg,
						const unsigned char* hexData,
						int hexDataLen)
{
	FILE* fp = NULL;
	
	if (priority >= getPriority() &&
		isEnable())
	{
        m_mutex->request(INFINITE);

		fp = openFile();

		if (fp != NULL)
		{
			if (getFileSize(fp) >= (long)m_sizeLimit)
			{
				fclose(fp);
				createBackup();
				fp = openFile();
			}

			if (fp != NULL)
			{
				char dateTime[64];
				char str[256] = {0};

				fprintf (fp, "%s,%s,%s,prt %d,%s ",
									getDateAndTime(dateTime),
									fileName,
									functionName,
									priority,
									headerMsg);

				for (int i = 0; i < hexDataLen; i++)
				{
					fprintf (fp, "%x ", (unsigned char)hexData[i]);
					#ifdef _DEBUG
					printf ("%x ", (unsigned char)hexData[i]);
					#endif
				}
				fprintf (fp, "\n");
				#ifdef _DEBUG
				printf ("\n");
				#endif
				fclose(fp);
			}
		}
        m_mutex->release();	
	}
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: setPriority
//
// OBJECTIVE:
// set the minimum priority of the message log
//
// ENTRANCE ARGUMENTS:
// priority: determine the priority of the log message.
//		     possible values for this parameter are:
//		     -	LOW_PRIORITY
//		     -	MEDIUM_PRIORITY
//		     -	HIGH_PRIORITY
//			 example: logMsg(..., ..., HIGH_PRIORITY, ..., ...)
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// none
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
void CLogger::setPriority (CPriority priority)
{
	m_priority = priority;
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: getPriority
//
// OBJECTIVE:
// get the minimum priority of the message log
//
// ENTRANCE ARGUMENTS:
// none
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// LOW_PRIORITY: specifies that the minimum priority of the message log is LOW
// MEDIUM_PRIORITY: specifies that the minimum priority of the message log is MEDIUM
// HIGH_PRIORITY: specifies that the minimum priority of the message log is HIGH
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
CPriority CLogger::getPriority ()
{
	return m_priority;
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: setFileName
//
// OBJECTIVE:
// set the name of file and treat names with more that 8 characters
//
// ENTRANCE ARGUMENTS:
// fileName: specifies the name of file
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// none
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
void CLogger::setFileName(const char* fileName)
{
	if (fileName != NULL)
	{
		memset(m_fileName, '\0', sizeof(m_fileName));
		strcpy(m_fileName, fileName);
	}
}


///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: getFileName
//
// OBJECTIVE:
// get teh name of file without extension
//
// ENTRANCE ARGUMENTS:
// none
//
// EXIT ARGUMENTS:
// outFileName: it return the name of file
//
// RETURNS:
// none
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
const char* CLogger::getFileName()
{
	return m_fileName;
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: getNumberOfBackupFiles
//
// OBJECTIVE:
// get the number of backup files
//
// ENTRANCE ARGUMENTS:
// none
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// number of backup files
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
short CLogger::getNumberOfBackupFiles()
{
	return m_numberOfBackupFiles;
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: setNumberOfBackupFiles
//
// OBJECTIVE:
// set the number of backup files
//
// ENTRANCE ARGUMENTS:
// numberOfBackupFiles: determine the number of backup files
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// none
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
void CLogger::setNumberOfBackupFiles(short numberOfBackupFiles)
{
	m_numberOfBackupFiles = numberOfBackupFiles;
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: getFileSize
//
// OBJECTIVE:
// it takes the length of file in bytes
//
// ENTRANCE ARGUMENTS:
// fp:  valid pointer to a file
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// size of file in bytes
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
long CLogger::getFileSize(FILE* fp)
{
	long start, end, cur;

	cur = ftell(fp);
	fseek(fp, 0L, SEEK_SET);
	start = ftell(fp);
	fseek(fp,0L,SEEK_END);
	end = ftell(fp);

	fseek(fp, cur, SEEK_SET);
	return (end - start);
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: openFile
//
// OBJECTIVE:
// open log file
//
// ENTRANCE ARGUMENTS:
// none
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// if file can be opened, it returns a pointer to a file, else
// a pointer to NULL is returned
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
FILE* CLogger::openFile()
{
	char date[DATE_MAX_ARRAY_LEN + 1] = {0};
	char fileName[FILE_NAME_MAX_LENGTH + 1] = {0};
	
	FILE* fp = NULL;
	char path[FILE_NAME_MAX_LENGTH] = {0};


	sprintf (path, "%s\\%s.%s", m_path, m_fileName, LOG_EXTENSION);

	if (verifyFileAccess(path, READ_WRITE_PERMISSION) != ACCESS_DENIED)
	{
		fp = fopen(path, "a");

		if(fp == NULL)
		{
			CFileUtils::createDirectoryRecursive(m_path);

			fp = fopen(path, "a");

			char traceMsg[256];
			sprintf (traceMsg, "Error opening file %s", path);
			thisTrace("::openFile", traceMsg);
		}
	}		
	else
	{
		char traceMsg[256];
		sprintf (traceMsg, "Error accessing file %s", path);
		thisTrace("::openFile", traceMsg);
	}


	return fp;
}


char* CLogger::getDateAndTime (char* outTime)
{
	if (outTime)
	{
		struct _timeb timebuffer;
		char *timeline;

		_ftime( &timebuffer );
		timeline = ctime( & ( timebuffer.time ) );

		sprintf(outTime, "%.19s.%03hu", timeline, timebuffer.millitm);
	}

	return outTime;
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: verifyFileAccess
//
// OBJECTIVE: this function returns if the archive has the permission
// defined in permission variable
//
// ENTRANCE ARGUMENTS:
// fileName: determine the name of archive with extention
//			 example: vetifyFileAccess ("comms.txt", ...)
//
// permission: determine the type of permission that
//		  	   if desires to verify
//			   example: verifyFileAccess(..., READ_WRITE_PERMISSION)
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// ACCESS_ALLOWED: the archive has the permission defined in permission variable
// ACCESS_DENIED: the archive hasn't the permission defined in permission variable
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////
int CLogger::verifyFileAccess (char* fileName, int permission)
{
	int ret = ACCESS_ALLOWED; //default

	if (CFileUtils::fileExists(fileName))
	{
		ret = _access (fileName, permission);
	}
	return ret;
}


bool CLogger::isEnable()
{
	return CFileUtils::fileExists(m_enableFilePath);
}

///////////////////////////////////////////////////////////////////////////////
// NAME OF THE METHOD: createBackup
//
// OBJECTIVE:
// this function do backup of current log file
//
// ENTRANCE ARGUMENTS:
// none
//
// EXIT ARGUMENTS:
// none
//
// RETURNS:
// none
//
// COMMENTS:
// none
///////////////////////////////////////////////////////////////////////////////

void CLogger::createBackup() 
{
    static char bakFullPathNew[FILE_NAME_MAX_LENGTH];
    static char bakFullPath[FILE_NAME_MAX_LENGTH];
    
	char current[FILE_NAME_MAX_LENGTH];
	sprintf (current, "%s\\%s.%s", m_path, m_fileName, LOG_EXTENSION);
    
	if (m_numberOfBackupFiles <= 0)
	{
		unlink(current);
	}
	else
	{
	    //apaga o mais velho
	    sprintf(bakFullPath, "%s\\%s%02d.%s", 
			m_path, 
			m_fileName, 
			m_numberOfBackupFiles, 
			BACKUP_EXTENSION);
	
	    unlink(bakFullPath);
	    
	    //renomeia
	    for (int i = m_numberOfBackupFiles - 1; i > 0; i--) 
		{
	        sprintf(bakFullPath, "%s/%s%02d.%s", m_path, m_fileName, i, BACKUP_EXTENSION);
	        sprintf(bakFullPathNew, "%s/%s%02d.%s", m_path, m_fileName, i + 1, BACKUP_EXTENSION);
	        rename(bakFullPath, bakFullPathNew);
	    }
	    
			//renomeia o corrente para o backup mais recente
	    rename(current, bakFullPath);
	}
}

void CLogger::thisTrace (const char* function, const char* msg)
{
	static bool logging = false;

	if (logging == false)
	{
		logging = true;
		CObjectContainer::getTraceInstance()->logMsg(THIS_FILE, function, HIGH_PRIORITY, msg);
		logging = false;
	}
}

