#ifndef _HST_API_H_
#define _HST_API_H_

#ifdef HST_DLL_LIB_EXPORT

#pragma include_alias( "CInpOut32.h",			"../../source/communication/CInpOut32.h" )
#pragma include_alias( "CKernelModeParallel.h", "../../source/communication/CKernelModeParallel.h")
#pragma include_alias( "CParallel.h",			"../../source/communication/CParallel.h" )
#pragma include_alias( "CPipe.h",				"../../source/communication/CPipe.h" )
#pragma include_alias( "CSerial.h",				"../../source/communication/CSerial.h" )
#pragma include_alias( "CCriticalSection.h",	"../../source/concurrency/CCriticalSection.h" )
#pragma include_alias( "CMutex.h",				"../../source/concurrency/CMutex.h" )
#pragma include_alias( "CSemaphore.h",			"../../source/concurrency/CSemaphore.h" )
#pragma include_alias( "CEvent.h",				"../../source/concurrency/CEvent.h" )
#pragma include_alias( "CFileUtils.h",			"../../source/file/CFileUtils.h" )
#pragma include_alias( "CSocket.h",				"../../source/net/CSocket.h" )
#pragma include_alias( "CBasicStringList.h",	"../../source/queue/CBasicStringList.h" )
#pragma include_alias( "CList.h",				"../../source/queue/CList.h" )
#pragma include_alias( "registry.h",			"../../source/registry/registry.h" )
#pragma include_alias( "CThread.h",				"../../source/thread/CThread.h" )
#pragma include_alias( "tthread.h",				"../../source/thread/tthread.h" )
#pragma include_alias( "CLogger.h",				"../../source/trace/CLogger.h" )
#pragma include_alias( "unzip.h",				"../../source/unzip/unzip.h" )
#pragma include_alias( "zip.h",					"../../source/zip/zip.h" )
#pragma include_alias( "CConfigContainer.h",	"../../source/ini/CConfigContainer.h" )
#pragma include_alias( "CConfigSerializer.h",	"../../source/ini/CConfigSerializer.h" )
#pragma include_alias( "CFileReader.h",			"../../source/ini/CFileReader.h" )
#pragma include_alias( "CFileWriter.h",			"../../source/ini/CFileWriter.h" )
#pragma include_alias( "CSectionContainer.h",	"../../source/ini/CSectionContainer.h" )
#pragma include_alias( "CImpExpRules.h",		"../../source/common/CImpExpRules.h" )
#pragma include_alias( "ISerializable.h",		"../../source/common/ISerializable.h" )
#pragma include_alias( "CBasicString.h",		"../../source/string/CBasicString.h" )
#pragma include_alias( "CConsoleMenu.h",		"../../source/menu/CConsoleMenu.h" )
#pragma include_alias( "CProcessUtils.h",		"../../source/process/CProcessUtils.h" )
#pragma include_alias( "CProcess.h",			"../../source/process/CProcess.h" )
#pragma include_alias( "CBuffer.h",				"../../source/buffer/CBuffer.h" )
#pragma include_alias( "CFieldBuffer.h",		"../../source/buffer/CFieldBuffer.h" )
#pragma include_alias( "CBufferFormatter.h",	"../../source/buffer/CBufferFormatter.h" )
#pragma include_alias( "CRequestProtocol.h",	"../../source/net/CRequestProtocol.h" )
#pragma include_alias( "CResponseProtocol.h",	"../../source/net/CResponseProtocol.h" )
#pragma include_alias( "CTimeUtils.h",			"../../source/time/CTimeUtils.h" )

#else

#pragma include_alias( "CInpOut32.h",			"api/communication/CInpOut32.h" )
#pragma include_alias( "CKernelModeParallel.h", "api/communication/CKernelModeParallel.h")
#pragma include_alias( "CParallel.h",			"api/communication/CParallel.h" )
#pragma include_alias( "CPipe.h",				"api/communication/CPipe.h" )
#pragma include_alias( "CSerial.h",				"api/communication/CSerial.h" )
#pragma include_alias( "CCriticalSection.h",	"api/concurrency/CCriticalSection.h" )
#pragma include_alias( "CMutex.h",				"api/concurrency/CMutex.h" )
#pragma include_alias( "CSemaphore.h",			"api/concurrency/CSemaphore.h" )
#pragma include_alias( "CEvent.h",				"api/concurrency/CEvent.h" )
#pragma include_alias( "CFileUtils.h",			"api/file/CFileUtils.h" )
#pragma include_alias( "CSocket.h",				"api/net/CSocket.h" )
#pragma include_alias( "CBasicStringList.h",	"api/queue/CBasicStringList.h" )
#pragma include_alias( "CList.h",				"api/queue/CList.h" )
#pragma include_alias( "registry.h",			"api/registry/registry.h" )
#pragma include_alias( "CThread.h",				"api/thread/CThread.h" )
#pragma include_alias( "tthread.h",				"api/thread/tthread.h" )
#pragma include_alias( "CLogger.h",				"api/trace/CLogger.h" )
#pragma include_alias( "unzip.h",				"api/unzip/unzip.h" )
#pragma include_alias( "zip.h",					"api/zip/zip.h" )
#pragma include_alias( "CConfigContainer.h",	"api/ini/CConfigContainer.h" )
#pragma include_alias( "CConfigSerializer.h",	"api/ini/CConfigSerializer.h" )
#pragma include_alias( "CFileReader.h",			"api/ini/CFileReader.h" )
#pragma include_alias( "CFileWriter.h",			"api/ini/CFileWriter.h" )
#pragma include_alias( "CSectionContainer.h",	"api/ini/CSectionContainer.h" )
#pragma include_alias( "CImpExpRules.h",		"api/common/CImpExpRules.h" )
#pragma include_alias( "ISerializable.h",		"api/common/ISerializable.h" )
#pragma include_alias( "CBasicString.h",		"api/string/CBasicString.h" )
#pragma include_alias( "CConsoleMenu.h",		"api/menu/CConsoleMenu.h" )
#pragma include_alias( "CProcessUtils.h",		"api/process/CProcessUtils.h" )
#pragma include_alias( "CProcess.h",			"api/process/CProcess.h" )
#pragma include_alias( "CBuffer.h",				"api/buffer/CBuffer.h" )
#pragma include_alias( "CFieldBuffer.h",		"api/buffer/CFieldBuffer.h" )
#pragma include_alias( "CBufferFormatter.h",	"api/buffer/CBufferFormatter.h" )
#pragma include_alias( "CRequestProtocol.h",	"api/net/CRequestProtocol.h" )
#pragma include_alias( "CResponseProtocol.h",	"api/net/CResponseProtocol.h" )
#pragma include_alias( "CTimeUtils.h",			"api/time/CTimeUtils.h" )
#endif


#include "CSocket.h"
#include "CInpOut32.h"                        
#include "CKernelModeParallel.h"
#include "CParallel.h"
#include "CPipe.h"
#include "CSerial.h"
#include "CCriticalSection.h"
#include "CMutex.h"
#include "CSemaphore.h"
#include "CEvent.h"
#include "CFileUtils.h"
#include "CBasicStringList.h"
#include "registry.h"
#include "CThread.h"
#include "tthread.h"
#include "CLogger.h"
#include "unzip.h"
#include "zip.h"
#include "ISerializable.h"
#include "CConfigContainer.h"
#include "CConfigSerializer.h"
#include "CFileReader.h"
#include "CFileWriter.h"
#include "CSectionContainer.h"
#include "CBasicString.h"
#include "CConsoleMenu.h"
#include "CProcessUtils.h"
#include "CProcess.h"
#include "CBuffer.h"
#include "CFieldBuffer.h"
#include "CBufferFormatter.h"
#include "CRequestProtocol.h"
#include "CResponseProtocol.h"
#include "CTimeUtils.h"

//Template classes that can't be exported
//#include "CLinkedList.h"
#include "CList.h"



#endif //_HST_API_H_
