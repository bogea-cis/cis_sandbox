//-------------------------------------------------------------------------------------------------------
//	(c) COPYRIGHT 2004  HST EQUIPAMENTOS
//	ELETRONICOS Ltda, Campinas (SP), Brasil
//	ALL RIGHTS RESERVED - TODOS OS DIREITOS RESERVADOS
//	CONFIDENTIAL, UNPUBLISHED PROPERTY OF HST E. E. Ltda
//	PROPRIEDADE CONFIDENCIAL NAO PUBLICADA DA HST Ltda.
//
//	A HST nao se responsabiliza pelo uso indevido de seu codigo.
//
//-------------------------------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   NAME OF THE MODULE: 
// 
//   VERSION: 1.0
//
//   PURPOSE:
//       Class to manipulate Threads.
//	
//	Author: Luis Gustavo de Brito
//	Date:	23/08/2008
//
// 	COMMENTS:
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CThread.h: interface for the CThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTHREAD_H__19D1AB46_BDBF_4687_8339_F6C20C99904A__INCLUDED_)
#define AFX_CTHREAD_H__19D1AB46_BDBF_4687_8339_F6C20C99904A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
#include <windows.h>
#include <process.h>    /* _beginthread, _endthread */
#include <stdlib.h>
#include <errno.h>

#include "CImpExpRules.h"

class CLASS_MODIFIER CThread  
{
public:
	CThread();
	virtual ~CThread();

	void start();
	bool stop();
	bool join (int timeout=INFINITE);
	HANDLE  getHandle() const;
	unsigned long getThreadId() const;

	static void waitAllThreadsToDie (bool currentIsCThread);

protected:
	virtual void* run() = 0;
	bool isToExit ();

private:
	bool bRunning;
	unsigned int m_tid;
	HANDLE m_handle;
	bool m_exit;
	static bool m_allExit;
	static int m_threadObjectsCounter;

	static unsigned __stdcall dispatch( void* threadObj ); 

};

#endif // !defined(AFX_CTHREAD_H__19D1AB46_BDBF_4687_8339_F6C20C99904A__INCLUDED_)
