#ifndef _C_LOGGER_H_
#define _C_LOGGER_H_

//-----------------------------------------------------------------------------
// (c) COPYRIGHT 2004 HST EQUIPAMENTOS
// ELETRONICOS Ltda, Campinas (SP), Brasil
// ALL RIGHTS RESERVED - TODOS OS DIREITOS RESERVADOS
// CONFIDENTIAL, UNPUBLISHED PROPERTY OF HST E. E. Ltda
// PROPRIEDADE CONFIDENCIAL NAO PUBLICADA DA HST Ltda.
//
// A HST nao se responsabiliza pelo uso indevido de seu codigo.
//
//-----------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
//
// NAME OF THE MODULE: CLogger
//
// VERSION: 1.0
//
// PURPOSE:
// Module of support to log
//
// Author: Lu�s Gustavo de Brito
// Date: 19/05/2005 - dd/mm/yyyy
//
// COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////

#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <io.h>
#include "CMutex.h"
#include "CImpExpRules.h"


const int DATE_MAX_ARRAY_LEN = 10;
const int TIME_MAX_ARRAY_LEN = 8;
const int DATE_TIME_MAX_ARRAY_LEN = DATE_MAX_ARRAY_LEN + TIME_MAX_ARRAY_LEN + 1;
const int FILE_NAME_MAX_LENGTH = 256;
const char LOG_EXTENSION[] = "log";
const char BACKUP_EXTENSION[] = "bak";
const char DEFAULT_ENABLE_FILE[] = "c:\\enablelog";
const char FILE_HEADER_STRING[] = "DATE_AND_HOUR;FILE;FUNCTION;PRIORITY;MESSAGE\n";

const int ACCESS_DENIED = -1;
const int ACCESS_ALLOWED = 0;

const int WRITE_PERMISSION = 2;
const int READ_PERMISSION = 4;
const int READ_WRITE_PERMISSION = 6;

const short DEFAULT_NUMBER_OF_BACKUP_FILES = 3;

//~ a floppy with 1,44 Mb
const ULONG FLOPPY_SIZE_LIMIT = (1024 * 1024) + (1024 * 350);


typedef enum _CPriority
{
	LOW_PRIORITY	= 1,
	MEDIUM_PRIORITY	= 2,
	HIGH_PRIORITY	= 3
} CPriority;


class CLASS_MODIFIER CLogger
{
public:

	CLogger(const char* logPath,
		CPriority priority,
		ULONG sizeLimit = FLOPPY_SIZE_LIMIT,
		short numberOfBackupFiles = DEFAULT_NUMBER_OF_BACKUP_FILES,
		const char* enableFile = DEFAULT_ENABLE_FILE);

	~CLogger();

	void logMsg(const char* fileName,
			const char* functionName,
			CPriority priority,
			const char* message,
			...);

	void vlogMsg(const char* fileName,
			const char* functionName,
			CPriority priority,
			const char* message,
			va_list args);

	void logHex (const char* fileName,
			const char* functionName,
			CPriority priority,
			const char* headerMsg,
			const unsigned char* hexData,
			int hexDataLen);

	void setPriority (CPriority priority);
	CPriority getPriority ();
	void setNumberOfBackupFiles(short numberOfBackupFiles);
	short getNumberOfBackupFiles();

private:

	void setFileName(const char* fileName);
	const char* getFileName();
	long getFileSize(FILE* fp);
	char* getDateAndTime (char* outTime);
	bool isEnable ();
	FILE* openFile();
	int verifyFileAccess (char* fileName, int permission);
	void createBackup ();

	void thisTrace (const char* function, const char* msg);

	ULONG m_sizeLimit;
	char m_enableFilePath[256];
	char m_path[256];
	char m_fileName[64];
	CPriority m_priority;
	short m_numberOfBackupFiles;
	
	CMutex* m_mutex;
};

#endif /* CLogger_h */
