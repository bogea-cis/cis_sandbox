// ServiceTest.cpp : Defines the entry point for the application.
//

#include "CScannerLS40.h"
#include <windows.h>
#include <winsvc.h>
#include <stdio.h>
#include <stdlib.h>

// evento usado para esperar o ServiceMain ser completado
HANDLE terminateEvent = NULL;

// handle usado para comunicar o status com o SCM (criado pelo RegisterServiceCtrlHandler)
SERVICE_STATUS_HANDLE serviceStatusHandle;

// flags de status corrente do servi�o
BOOL pauseService = FALSE;
BOOL runningService = FALSE;

// thread
HANDLE threadHandle = 0;


HANDLE SEM_PROCESS;

// objeto do scanner
CScannerLS40* scanner = NULL;

char serviceName[100];	// Nome do Servico

int failRegistry = 0;	// Flag de Falha do Registry



/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: RoutineMain
//
//    OBJETIVO:
//        Fun��o principal para inicializa��o do aplicativo.
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
DWORD RoutineMain()
{
	if(scanner != NULL)
	{
		scanner->setServiceStatus(2);
		Sleep(10000);
		delete scanner;
		scanner = NULL;
	}

	scanner = new CScannerLS40();
	scanner->execute();

	delete scanner;
	scanner = NULL;

	while (1)
	{
		Sleep (0xffffffff);
	}

	return 0;
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: ResumeService
//
//    OBJETIVO:
//        Recome�a um servi�o pausado.
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID ResumeService()
{
	pauseService = FALSE;
	
	if(scanner != NULL)
	{
		scanner->setServiceStatus(0);
		Sleep(10000);
	}

	ResumeThread(threadHandle);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: PauseService
//
//    OBJETIVO:
//        Pausa o Servi�o.
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID PauseService()
{
	pauseService = TRUE;
	if(scanner != NULL)
	{
		scanner->setServiceStatus(1);
	}

	SuspendThread(threadHandle);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: StopService
//
//    OBJETIVO:
//        P�ra o Servi�o, permitindo que o ServiceMain seja conclu�do.
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID StopService()
{
	runningService = FALSE;

	if(scanner != NULL)
	{
		scanner->setServiceStatus(2);
		Sleep(10000);
	}

	// Ajusta o evento que est� prendendo o ServiceMain, de modo que o ServiceMain 
	// possa retornar
	SetEvent(terminateEvent);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: SendStatusToSCM
//
//    OBJETIVO:
//        Consolida as atividades de atualiza��o do status do servi�o feita
//		  pelo SetServiceStatus.
//
//    ARGUMENTOS DE ENTRADA:
//        dwCurrentState:				estado corrente
//        dwWin32ExitCode:				c�digo de sa�da padr�o Win32
//        dwServiceSpecificExitCode:	c�digo de sa�da especificado pelo servi�o
//        dwCheckPoint:					CheckPoint
//        dwWaitHint:					tempo de espera
//
//    RETORNO:
//        confirma��o de sucesso (true) ou n�o da fun��o (false).
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
BOOL SendStatusToSCM( DWORD dwCurrentState,
					  DWORD dwWin32ExitCode,
					  DWORD dwServiceSpecificExitCode,
					  DWORD dwCheckPoint,
					  DWORD dwWaitHint )
{
	BOOL success;
	SERVICE_STATUS serviceStatus;

	// Preenchimento de todos os campos do status do servi�o (SERVICE_STATUS)
	serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	serviceStatus.dwCurrentState = dwCurrentState;

	// No processo de algo, n�o aceite ent�o nenhum evento do controle. 
	// Aceite qualquer outra coisa 
	if(dwCurrentState == SERVICE_START_PENDING)
		serviceStatus.dwControlsAccepted = 0;
	else
		serviceStatus.dwControlsAccepted = 
			SERVICE_ACCEPT_STOP | 
			SERVICE_ACCEPT_PAUSE_CONTINUE |
			SERVICE_ACCEPT_SHUTDOWN;

	// Se um c�digo espec�fico da sa�da for definido, ajuste o c�digo de sa�da win32 corretamente 
	if(dwServiceSpecificExitCode == 0)
		serviceStatus.dwWin32ExitCode = dwWin32ExitCode;
	else
		serviceStatus.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;

	// Ajusta os demais campos de um status de servi�o
	serviceStatus.dwServiceSpecificExitCode = dwServiceSpecificExitCode;
	serviceStatus.dwCheckPoint = dwCheckPoint;
	serviceStatus.dwWaitHint = dwWaitHint;

	// Grava o registro do status no SCM
	success = SetServiceStatus(serviceStatusHandle, &serviceStatus);

	if(!success)
		StopService();

	return success;
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: ServiceCtrlHandler
//
//    OBJETIVO:
//        Despacha os eventos recebidos do gerente de controle do servi�o.
//
//    ARGUMENTOS DE ENTRADA:
//        controlCode:		c�digo de controle
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID ServiceCtrlHandler(DWORD controlCode)
{
	DWORD currentState = 0;
	BOOL success;

	switch(controlCode)
	{
        // OBS: N�o h� nenhuma op��o START porque o ServiceMain � inicizalizado  
		// somente uma vez e no in�cio (main)

		// SERVICE_CONTROL_STOP = Parada do servi�o 
		case SERVICE_CONTROL_STOP:
			currentState = SERVICE_STOP_PENDING;
			// Diz ao SCM o que est� acontecendo
			success = SendStatusToSCM(SERVICE_STOP_PENDING, NO_ERROR, 0,1,5000);
			// N�o h� o que fazer se n�o houver sucesso

			// Parada do servi�o (ServiceThread)
			StopService();
			return;

		// SERVICE_CONTROL_PAUSE = Pausa do Servi�o
		case SERVICE_CONTROL_PAUSE:
			if(runningService && !pauseService)
			{
				// Diz ao SCM o que est� acontecendo
				success = SendStatusToSCM(SERVICE_PAUSE_PENDING, NO_ERROR, 0,1,1000);

				// Pausa do servi�o
				PauseService();
				currentState = SERVICE_PAUSED;
			}
			else
			{
				if (pauseService)
					currentState = SERVICE_PAUSED;
				else
					currentState = SERVICE_STOPPED;
			}
			break;

		// SERVICE_CONTROL_CONTINUE = continua o servi�o, recome�ando a thread servi�o (ServiceThread)
		case SERVICE_CONTROL_CONTINUE:
			if(runningService && pauseService)
			{
				// Diz ao SCM o que est� acontecendo
				success = SendStatusToSCM(SERVICE_CONTINUE_PENDING, NO_ERROR, 0,1,1000);
				
				// A thread � recome�ada
				ResumeService();
				currentState = SERVICE_RUNNING;
			}
            else
            {
                if (!pauseService)
                    currentState = SERVICE_RUNNING;
                else
                    currentState = SERVICE_STOPPED;
            }

			break;

		// SERVICE_CONTROL_INTERROGATE = atualiza o estado corrente
		case SERVICE_CONTROL_INTERROGATE:
			// Executar� e emitir� o status
			if (runningService)
				currentState = SERVICE_RUNNING;
			else
				currentState = SERVICE_STOPPED;
			break;

		// SERVICE_CONTROL_SHUTDOWN = N�o fa�a nada em uma parada. Poderia se fazer a limpeza 
			                       // aqui, mas deve ser muito r�pida
		case SERVICE_CONTROL_SHUTDOWN:
			// N�o fa�a nada em uma parada!
			return;

		default:
			break;
	}
	// Diz ao SCM o que est� acontecendo (seu estado corrente)
	SendStatusToSCM(currentState, NO_ERROR, 0,0,0);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: InitService
//
//    OBJETIVO:
//        Inicializa o Servi�o com a Rotina Principal.
//
//    RETORNO:
//        status de inicializa��o (true/false).
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
BOOL InitService()
{
	DWORD id;

	// Inicializa a thread
	threadHandle = CreateThread(0,0,(LPTHREAD_START_ROUTINE) RoutineMain, 0,0, &id);

	if(threadHandle == 0)
		return FALSE; // Falha ao inicializar a Thread
	else
	{
		runningService = TRUE;
		return TRUE;  // Thread inicializada
	}
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: InstallService
//
//    OBJETIVO:
//        Instala o servi�o no service manager
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID InstallService()
{
	SC_HANDLE schSCManager;
    SC_HANDLE schService;
    TCHAR szPath[MAX_PATH];

    if( !GetModuleFileName( NULL, szPath, MAX_PATH ) )
    {
        printf("Cannot install service (%d)\n", GetLastError());
        return;
    }

      schSCManager = OpenSCManager( 
        NULL, NULL,     SC_MANAGER_ALL_ACCESS);  
 
    if (NULL == schSCManager) 
    {
        printf("OpenSCManager failed (%d)\n", GetLastError());
        return;
    }

       schService = CreateService(
						schSCManager,
						"CISScannerLS40",
						"CIS Scanner LS40",
						SERVICE_ALL_ACCESS,
						SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,
						SERVICE_DEMAND_START,
						SERVICE_ERROR_NORMAL,
						szPath,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL);
 
    if (schService == NULL) 
    {
        printf("CreateService failed (%d)\n", GetLastError()); 
        CloseServiceHandle(schSCManager);
        return;
    }

	SERVICE_DESCRIPTION svcDescription;
	svcDescription.lpDescription = "CIS Scanner LS40 Service";
	ChangeServiceConfig2(schService, SERVICE_CONFIG_DESCRIPTION, &svcDescription);

    printf("Service Installed successfully\n"); 
	
    CloseServiceHandle(schService); 
    CloseServiceHandle(schSCManager);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: UninstallService
//
//    OBJETIVO:
//        Desinstala o servi�o no service manager
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID UninstallService()
{
	SC_HANDLE schSCManager;
    SC_HANDLE schService;
    TCHAR szPath[MAX_PATH];

    if( !GetModuleFileName( NULL, szPath, MAX_PATH ) )
    {
        printf("Cannot install service (%d)\n", GetLastError());
        return;
    }

      schSCManager = OpenSCManager( 
        NULL, NULL,     SC_MANAGER_ALL_ACCESS);  
 
    if (NULL == schSCManager) 
    {
        printf("OpenSCManager failed (%d)\n", GetLastError());
        return;
    }

       schService = OpenService( 
						schSCManager,
						"CISScannerLS40",
						SERVICE_ALL_ACCESS);
 
    if (schService == NULL) 
    {
        printf("OpenService failed (%d)\n", GetLastError()); 
        CloseServiceHandle(schSCManager);
        return;
    }

	if ( !DeleteService(schService) )
	{
		printf("DeleteService failed (%d)\n", GetLastError()); 
        CloseServiceHandle(schService); 
		CloseServiceHandle(schSCManager);
        return;
	}

    printf("Service Uninstalled successfully\n"); 
	
    CloseServiceHandle(schService); 
    CloseServiceHandle(schSCManager);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: terminate
//
//    OBJETIVO:
//        Manipula um erro do ServiceMain, limpando-o e dizendo
//		  � SCM que o servi�o n�o come�ou.
//
//    ARGUMENTOS DE ENTRADA:
//        error:	erro no sistema
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID terminate(DWORD error)
{
	// Se ocorreu um evento de finaliza��o, fecho-o
	if(terminateEvent)
		CloseHandle(terminateEvent);

	// Envie uma mensagem ao SCM dizendo sobre a parada
	if(serviceStatusHandle)
		SendStatusToSCM(SERVICE_STOPPED, error, 0,0,0);

	// Se uma thread de Servi�o ("ServiceThread") foi inicializada, mate-a!
	if(threadHandle)
		CloseHandle(threadHandle);

	// N�o h� necessidade de fechar o "serviceStatusHandle"
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: ServiceMain
//
//    OBJETIVO:
//		  O ServiceMain � chamado quando o SCM quer come�ar o servi�o.       
//        Quando ele retorna, o servi�o parou. Conseq�entemente, ele espera   
//        um evento antes de terminar a fun��o. Assim, esse evento           
//        � que mostra quando � hora de parar. O ServiceMain � que tamb�m    
//		  retorna qualquer erro ocorrido, uma vez que um servi�o n�o pode    
//		  come�ar se houver um erro.                                         
//
//    ARGUMENTOS DE ENTRADA:
//        argc e argv:	argumentos da fun��o main
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
VOID ServiceMain(DWORD argc, LPTSTR *argv)
{
	BOOL success;

	// Imediatamente chama a fun��o que registra um servi�o
	serviceStatusHandle = RegisterServiceCtrlHandler(serviceName, 
		                                             (LPHANDLER_FUNCTION)ServiceCtrlHandler);

	if(!serviceStatusHandle)
	{
		terminate(GetLastError());
		return;
	}

	// Notifica o SCM do progresso
	success = SendStatusToSCM(SERVICE_START_PENDING, NO_ERROR, 0,1,5000);

	if(!success)
	{
		terminate(GetLastError());
		return;
	}

	// Cria um evento de finaliza��o
	terminateEvent = CreateEvent(0, TRUE, FALSE, 0);

	if(!terminateEvent)
	{
		terminate(GetLastError());
		return;
	}

	// Notifica o SCM do progresso
	success = SendStatusToSCM(SERVICE_START_PENDING, NO_ERROR, 0,2,1000);

	if(!success)
	{
		terminate(GetLastError());
		return;
	}

	// Notifica o SCM do progresso
	success = SendStatusToSCM(SERVICE_START_PENDING, NO_ERROR, 0,3,5000);
	if(!success)
	{
		terminate(GetLastError());
		return;
	}

	// Inicializa o servi�o
	success = InitService();
	if(!success)
	{
		terminate(GetLastError());
		return;
	}

	// O Servi�o est� rodando. Notifica-se o SCM!
	success = SendStatusToSCM(SERVICE_RUNNING, NO_ERROR, 0,0,0);
	if(!success)
	{
		terminate(GetLastError());
		return;
	}

	// Aguarda-se um sinal de parada ou de finaliza��o
	WaitForSingleObject(terminateEvent, INFINITE);

	terminate(0);
}

/////////////////////////////////////////////////////////////
//    NOME DA FUN��O: main
//
//    OBJETIVO:
//        ROTINA PRINCIPAL DO SERVICO.
//
//    OBSERVACOES:
//
/////////////////////////////////////////////////////////////
#ifndef NOSERVICE
int main(int argc, char* argv[])
{
	if (argc == 2)
	{
		if (strcmp(argv[1], "/i") == 0)
		{
			InstallService();
			return 0;
		}
		else if (strcmp(argv[1], "/u") == 0)
		{
			UninstallService();
			return 0;
		}
	}
	
	char directory[50] = {0};

	strcpy(serviceName, "CISScannerLS40");
	
	SERVICE_TABLE_ENTRY serviceTable[] = 
	{ {serviceName, (LPSERVICE_MAIN_FUNCTION) ServiceMain}, {NULL, NULL} };
	
	BOOL success;

	sprintf(directory, "%s\\CIS\\ScannerLS40", getenv("PROGRAMFILES"));
	SetCurrentDirectory(directory);

	// Conecta a thread main com o SCM
	success = StartServiceCtrlDispatcher(serviceTable);
	if(!success)
	{
		char msg[50];
		sprintf(msg, "Error in StartServiceCtrlDispatcher\nError number:%ld",GetLastError());
        printf(msg);
	}

    return 0;	
}
#else
int main()
{
	RoutineMain();
	return 0;
}
#endif
