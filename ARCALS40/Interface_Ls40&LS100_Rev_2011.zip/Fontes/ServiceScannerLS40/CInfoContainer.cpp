// CInfoContainer.cpp: implementation of the CInfoContainer class.
//
//////////////////////////////////////////////////////////////////////

#include "CInfoContainer.h"
#include "Consts.h"

#include <windows.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInfoContainer::CInfoContainer()
{
	memset(this->m_logPath, 0x00, sizeof(this->m_logPath));
	memset(this->m_logName, 0x00, sizeof(this->m_logName));
	memset(this->m_scannerModel, 0x00, sizeof(this->m_scannerModel));
	memset(this->m_dataOutput, 0x00, sizeof(this->m_dataOutput));

	memset(this->m_comPort, 0x00, sizeof(this->m_comPort));
	memset(this->m_baudrate, 0x00, sizeof(this->m_baudrate));
	memset(this->m_dataBit, 0x00, sizeof(this->m_dataBit));
	memset(this->m_parity, 0x00, sizeof(this->m_parity));
	memset(this->m_stopBit, 0x00, sizeof(this->m_stopBit));

	memset(this->m_keysAllowed, 0x00, sizeof(this->m_keysAllowed));

	this->m_imageQuality = 100;
	memset(this->m_side, 0x00, sizeof(this->m_side));
	memset(this->m_savePathImage, 0x00, sizeof(this->m_savePathImage));
	memset(this->m_imageFrontName, 0x00, sizeof(this->m_imageFrontName));
	memset(this->m_imageBackName, 0x00, sizeof(this->m_imageBackName));
	memset(this->m_imageTypeExt, 0x00, sizeof(this->m_imageTypeExt));
	

	this->loadInformations();
}	

CInfoContainer::~CInfoContainer()
{

}

bool CInfoContainer::loadInformations()
{
	bool ret = true;

	if(ret == true)
	{
		this->setLogPath();
		this->setLogName();
		this->setScannerModel();
		this->setDataOutput();
		this->setComPort();
		this->setBaudrate();
		this->setDataBit();
		this->setParity();
		this->setStopBit();
		this->setKeysAllowed();
		this->setImageQuality();
		this->setSide();
		this->setSavePathImage();
		this->setImageFrontName();
		this->setImageBackName();
		this->setImageTypeExt();
	}

	return ret;
}

bool CInfoContainer::getValueStr(const char* session, const char* key, char* value)
{
	bool ret = false;
	char path[300] = {0};
	
	sprintf(path, "%s\\%s", PATH_CONFIG, PATH_FILE_NAME);
	
	GetPrivateProfileString(session, key, "", value, 256, path);
	
	if(strlen(value) > 0)
	{
		ret = true;
	}

	return ret;
}

void CInfoContainer::setLogPath()
{
	char value[256+1] = {0};
	this->getValueStr(SCANNER_SECTION, LOG_PATH_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_logPath, value);
	}
	else
	{
		strcpy(this->m_logPath, ".\\traces");
	}
}

const char* CInfoContainer::getLogPath()
{
	return this->m_logPath;
}

void CInfoContainer::setLogName()
{
	char value[256+1] = {0};
	this->getValueStr(SCANNER_SECTION, LOG_NAME_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_logName, value);
	}
	else
	{
		strcpy(this->m_logName, "scanner.log");
	}
}

const char* CInfoContainer::getLogName()
{
	return this->m_logName;
}

void CInfoContainer::setComPort()
{
	char value[256+1] = {0};
	this->getValueStr(PORTCOM_SECTION, COM_PORT_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_comPort, value);
	}
	else
	{
		strcpy(this->m_comPort, "CNCB0");
	}
}

const char* CInfoContainer::getComPort()
{
	return this->m_comPort;
}

void CInfoContainer::setBaudrate()
{
	char value[256+1] = {0};
	this->getValueStr(PORTCOM_SECTION, BAUDRATE_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_baudrate, value);
	}
	else
	{
		strcpy(this->m_baudrate, "9600");
	}
}

const char* CInfoContainer::getBaudrate()
{
	return this->m_baudrate;
}

void CInfoContainer::setDataBit()
{
	char value[256+1] = {0};
	this->getValueStr(PORTCOM_SECTION, DATABIT_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_dataBit, value);
	}
	else
	{
		strcpy(this->m_dataBit, "8");
	}
}

const char* CInfoContainer::getDataBit()
{
	return this->m_dataBit;
}

void CInfoContainer::setParity()
{
	char value[256+1] = {0};
	this->getValueStr(PORTCOM_SECTION, PARITY_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_parity, value);
	}
	else
	{
		strcpy(this->m_parity, "N");
	}
}

const char* CInfoContainer::getParity()
{
	return this->m_parity;
}

void CInfoContainer::setStopBit()
{
	char value[256+1] = {0};
	this->getValueStr(PORTCOM_SECTION, STOPBIT_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_stopBit, value);
	}
	else
	{
		strcpy(this->m_stopBit, "1");
	}
}

const char* CInfoContainer::getStopBit()
{
	return this->m_stopBit;
}

void CInfoContainer::setKeysAllowed()
{
	char value[256+1] = {0};
	this->getValueStr(KEYBOARD_SECTION, KEYS_ALLOWED_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_keysAllowed, value);
	}
	else
	{
		strcpy(this->m_keysAllowed, "0123456789");
	}
}

const char* CInfoContainer::getKeysAllowed()
{
	return this->m_keysAllowed;
}

void CInfoContainer::setImageQuality()
{
	char value[256+1] = {0};
	this->getValueStr(IMAGES_SECTION, IMAGE_QUALITY_KEY, value);

	if(strlen(value))
	{
		this->m_imageQuality = atoi(value);
	}
}

int CInfoContainer::getImageQuality()
{
	return this->m_imageQuality;
}

void CInfoContainer::setSide()
{
	char value[256+1] = {0};
	this->getValueStr(IMAGES_SECTION, SIDE_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_side, value);
	}
	else
	{
		strcpy(this->m_side, "ALL");
	}	
}

const char* CInfoContainer::getSide()
{
	return this->m_side;
}

void CInfoContainer::setSavePathImage()
{
	char value[256+1] = {0};
	this->getValueStr(IMAGES_SECTION, SAVE_PATH_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_savePathImage, value);
	}
	else
	{
		strcpy(this->m_savePathImage, ".\\Images");
	}
}

const char* CInfoContainer::getSavePathImage()
{
	return this->m_savePathImage;
}

void CInfoContainer::setImageFrontName()
{
	char value[256+1] = {0};
	this->getValueStr(IMAGES_SECTION, IMAGE_FRONT_NAME_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_imageFrontName, value);
	}
	else
	{
		strcpy(this->m_imageFrontName, "front");
	}
}

const char* CInfoContainer::getImageFrontName()
{
	return this->m_imageFrontName;
}

void CInfoContainer::setImageBackName()
{
	char value[256+1] = {0};
	this->getValueStr(IMAGES_SECTION, IMAGE_BACK_NAME_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_imageBackName, value);
	}
	else
	{
		strcpy(this->m_imageBackName, "back");
	}
}

const char* CInfoContainer::getImageBackName()
{
	return this->m_imageBackName;
}

void CInfoContainer::setScannerModel()
{
	char value[256+1] = {0};
	this->getValueStr(SCANNER_SECTION, SCANNER_MODEL_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_scannerModel, value);
	}
	else
	{
		strcpy(this->m_scannerModel, "LS100_USB");
	}	
}

const char* CInfoContainer::getScannerModel()
{
	return this->m_scannerModel;
}

void CInfoContainer::setDataOutput()
{
	char value[256+1] = {0};
	this->getValueStr(SCANNER_SECTION, DATA_OUTPUT_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_dataOutput, value);
	}
	else
	{
		strcpy(this->m_dataOutput, "Serial");
	}
}

const char* CInfoContainer::getDataOutput()
{
	return this->m_dataOutput;
}

void CInfoContainer::setImageTypeExt()
{
	char value[256+1] = {0};
	this->getValueStr(IMAGES_SECTION, IMAGE_TYPE_EXT_KEY, value);

	if(strlen(value))
	{
		strcpy(this->m_imageTypeExt, value);
	}
	else
	{
		strcpy(this->m_imageTypeExt, "jpg");
	}
}

const char* CInfoContainer::getImageTypeExt()
{
	return this->m_imageTypeExt;
}