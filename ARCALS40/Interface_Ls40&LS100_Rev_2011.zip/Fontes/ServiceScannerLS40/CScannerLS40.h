// CScannerLS40.h: interface for the CScannerLS40 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CSCANNERLS40_H__58D7BCBB_2C85_40F4_8B89_F96B37470655__INCLUDED_)
#define AFX_CSCANNERLS40_H__58D7BCBB_2C85_40F4_8B89_F96B37470655__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define _WIN32_WINNT 0x0501
#include <windows.h>
#undef _WIN32_WINNT

#include "HSTAPI.h"
#include "CInfoContainer.h"
#include "Consts.h"


class CScannerLS40
{
public:
	CScannerLS40();
	virtual ~CScannerLS40();

	bool execute();
	void setServiceStatus(int status);

private:
	STATE_SCANNER configuration();
	STATE_SCANNER open();
	STATE_SCANNER verifyServiceStatus();
	STATE_SCANNER readDocument();
	STATE_SCANNER status();
	STATE_SCANNER codeLine();
	STATE_SCANNER barCode();
	STATE_SCANNER sendBuffer();
	STATE_SCANNER sendKeys();
	STATE_SCANNER images();
	STATE_SCANNER mountImagesNames();
	STATE_SCANNER saveFrontImage();
	STATE_SCANNER saveBackImage();
	STATE_SCANNER freeImage();
	STATE_SCANNER checkNrDocCounter();
	STATE_SCANNER treatError();
	STATE_SCANNER close();
	bool validateCodeLine(const char* codeLine) const;
	void setupCom();
	STATE_SCANNER getDataOutputState();
	short getScannerModel();
	bool isAllowedKey(char key);
	
private:
	STATE_SCANNER m_state;
	DOCUMENT_TYPE m_document;
	bool m_status;
	bool m_read;

	HWND m_hwndApp;
	HINSTANCE m_hinstApp;
	short m_hConnect;

	int m_retAPI;
	char m_buffer[512+1];
	char m_imageFrontName[512+1];
	char m_imageBackName[512+1];
	LPHANDLE m_frontImage;
	LPHANDLE m_backImage;
	
	HANDLE m_frontImageH;
	HANDLE m_backImageH;

	unsigned long m_nrDoc;
	short m_errorTry;
	short m_serviceStatus;
	
	CInfoContainer* m_info;
	CLogger* m_log;
	CSerial* m_serial;
};

#endif // !defined(AFX_CSCANNERLS40_H__58D7BCBB_2C85_40F4_8B89_F96B37470655__INCLUDED_)
