This demo program will work with the following models:
LS40, LS100, LS515, LS150

Copy the DLL included in LsApi_Base.zip in this project before running the program
