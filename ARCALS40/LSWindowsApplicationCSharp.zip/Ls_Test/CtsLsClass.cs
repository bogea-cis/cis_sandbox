﻿using System;
using System.Runtime.InteropServices;

namespace Ls_Test
{
    public class CtsLs
    {
        [DllImport("LsApi.dll")]
        public static extern int LSConnect(int hWnd, int hInst, short Peripheral, ref short hConnect);
        [DllImport("LsApi.dll")]
        public static extern int LSDisconnect(short hConnect, int hWnd);
        [DllImport("LsApi.dll")]
        public static extern int LSUnitIdentify(short hConnect, int hWnd, byte[] pLsCfg, IntPtr LsModel, IntPtr FwVersion, IntPtr FwDate, IntPtr PeripheralID, IntPtr BoardVersion, IntPtr DecoderExpVersion, IntPtr InkJetVersion, IntPtr FeederVersion, IntPtr SorterVersion, IntPtr MotorVersion, IntPtr Reserved1, IntPtr Reserved2);
        [DllImport("LsApi.dll")]
        public static extern int LSUnitStatus(short hConnect, int hWnd, ref UNITSTATUS lpStatus);
        [DllImport("LsApi.dll")]
        public static extern int LSReset(short hConnect, int hWnd, short ResetType);
        [DllImport("LsApi.dll")]
        public static extern int LSLoadStringWithCounterEx(short hConnect, int hWnd, short PrintType, IntPtr strEndorse, short LenEndorse, UInt32 StartNumber, short Step);
        [DllImport("LsApi.dll")]
        public static extern int LSLoadString(short hConnect, int hWnd, short PrintType, short LenEndorse, IntPtr strEndorse);
        [DllImport("LsApi.dll")]
        public static extern int LSConfigDoubleLeafingAndDocLength(short hConnect, int hWnd, Int32 Type, short Value, Int32 DocMin, Int32 DocMax);
        [DllImport("LsApi.dll")]
        public static extern int LSChangeStampPosition(short hConnect, int hWnd, short Step, byte Reserved);
        [DllImport("LsApi.dll")]
        public static extern int LSDisableWaitDocument(short hConnect, int hWnd, bool fWait);
        [DllImport("LsApi.dll")]
        public static extern int LSSetUnitSpeed(short hConnect, int hWnd, short UnitSpeed);
        [DllImport("LsApi.dll")]
        public static extern int LSSetLightIntensity(short hConnect, int hWnd, short UnitSpeed);
        [DllImport("LsApi.dll")]
        public static extern int LSModifyPWMUltraViolet(short hConnect, int hWnd, short UnitSpeed, bool HighContrast, short Reserved);
        [DllImport("LsApi.dll")]
        public static extern int LSAutoDocHandle(short hConnect, int hWnd, short Stamp, short Validate, short CodeLine, short ScanMode, short Feeder, short Sorter, short NumDocument, short ClearBlack, char Side, short ReadMode, short SaveImage, IntPtr DirectoryFile, IntPtr BaseFilename, Single pos_x, Single pos_y, Single sizeW, Single sizeH, short OriginMeasureDoc, short OcrImageSide, short FileFormat, int Quality, int SaveMode, int PageNumber, short WaitTimeout, short Beep, int Reserved1, IntPtr Reserved2, IntPtr Reserved3);
        [DllImport("LsApi.dll")]
        public static extern int LSGetDocData(short hConnect, int hWnd, ref UInt32 NrDoc, IntPtr FilenameFront, IntPtr FilenameRear, IntPtr Reserved1, IntPtr Reserved2, ref IntPtr FrontImage, ref IntPtr RearImage, ref IntPtr Reserved3, ref IntPtr Reserved4, IntPtr CodelineSW, IntPtr CodelineHW, IntPtr Barcode, IntPtr CodelinesOptical, ref short DocToRead, ref Int32 NrPrinted, IntPtr Reserved5, IntPtr Reserved6);
        [DllImport("LsApi.dll")]
        public static extern int LSDocHandle(short hConnect, int hWnd, short Stamp, short Validate, short CodeLine, char Side, short ScanMode, short Feeder, short Sorter, short WaitTimeout, short Beep, ref UInt32 NrDoc, Int16 ScanDocType, Int32 Reserved);
        [DllImport("LsApi.dll")]
        public static extern int LSReadCodeline(short hConnect, int hWnd, IntPtr CodelineHW, ref short LenCodelineHW, IntPtr Barcode, ref short LenBarcode, IntPtr CodelinesOptical, ref short LenOptic);
        [DllImport("LsApi.dll")]
        public static extern int LSReadImage(short hConnect, int hWnd, short ClearBlack, char Side, short ReadMode, UInt32 NrDoc, ref IntPtr FrontImage, ref IntPtr RearImage, ref IntPtr Reserved1, IntPtr Reserved2);
        [DllImport("LsApi.dll")]
        public static extern int LSCodelineReadFromBitmap(int hWnd, IntPtr hImage, byte[] CodelineType, short UintMeasure, float Pos_x, float Pos_y, float Width, float Height, ref READOPTIONS ro, IntPtr Codeline, ref int Length_Codeline);
        [DllImport("LsApi.dll")]
        public static extern int LSReadBarcodeFromBitmap(int hWnd, IntPtr hImage, byte BarcodeType, float Pos_x, float Pos_y, float Width, float Height, IntPtr Codeline, ref int Length_Codeline);
        [DllImport("LsApi.dll")]
        public static extern int LSReadPdf417FromBitmap(int hWnd, IntPtr hImage, IntPtr Codeline, ref int Length_Codeline, byte Reserved, float Pos_x, float Pos_y, float Width, float Height);
        [DllImport("LsApi.dll")]
        public static extern int LSMergeImageGrayAndUV(int hWnd, IntPtr hFrontGrayImage, IntPtr hFrontUVImage, float Reserved, float Reserved2, ref IntPtr hGrayUVImage);
        [DllImport("LsApi.dll")]
        public static extern int LSFreeImage(int hWnd, ref IntPtr hImage);
        [DllImport("LsApi.dll")]
        public static extern int LSUnitHistory(short hConnect, int hWnd, ref UNITHISTORY UnitHistory);

        public struct BITMAPINFOHEADER
        {
            public UInt32 biSize;
            public Int32 biWidth;
            public Int32 biHeight;
            public Int16 biPlanes;
            public Int16 biBitCount;
            public UInt32 biCompression;
            public UInt32 biSizeImage;
            public Int32 biXPelsPerMeter;
            public Int32 biYPelsPerMeter;
            public UInt32 biClrUsed;
            public UInt32 biClrImportant;
        };


        public struct UNITSTATUS
        {
            public int Size;						// Size of the structure

            public int UnitStatus;					// Ls40 Ls100 Ls150 Ls5xx Ls800

            public bool Photo_Feeder;				// Ls40 Ls100 Ls150 Ls5xx Ls800
            public bool Photo_Sorter;				//      Ls100
            public bool Photo_MICR;					//      Ls100 Ls150 Ls5xx
            public bool Photo_Path_Ls100;			//      Ls100
            public bool Photo_Scanners;				//      Ls100
            public bool Unit_Just_ON;				// Ls40 Ls100 Ls150
            public bool Photo_Double_Leafing_Down;	//      Ls100 Ls150
            public bool Photo_Double_Leafing_Middle;//            Ls150
            public bool Photo_Double_Leafing_Up;	//      Ls100 Ls150
            public bool Photo_Card;					//            Ls150
            public bool Pockets_All_Full;			//            Ls150 Ls5xx
            public bool Photo_Stamp;				//                  Ls5xx
            public bool Photo_Exit;					//                  Ls5xx
            public bool Pocket_1_Full;				//                  Ls5xx
            public bool Pocket_2_Full;				//                  Ls5xx

            public bool Photo_Path_Feeder;			//                        Ls800
            public bool Photo_Path_Module_Begin;	//                        Ls800
            public bool Photo_Path_Binary_Rigth;	//                        Ls800
            public bool Photo_Path_Binary_Left;		//                        Ls800
            public bool Photo_Path_Module_End;		//                        Ls800
            public bool Sorter_1_input_pocket_1;	//                        Ls800
            public bool Sorter_1_pocket_1_full;		//                        Ls800
            public bool Sorter_1_input_pocket_2;	//                        Ls800
            public bool Sorter_1_pocket_2_full;		//                        Ls800
            public bool Sorter_1_input_pocket_3;	//                        Ls800
            public bool Sorter_1_pocket_3_full;		//                        Ls800
            public bool Sorter_2_input_pocket_1;	//                        Ls800
            public bool Sorter_2_pocket_1_full;		//                        Ls800
            public bool Sorter_2_input_pocket_2;	//                        Ls800
            public bool Sorter_2_pocket_2_full;		//                        Ls800
            public bool Sorter_2_input_pocket_3;	//                        Ls800
            public bool Sorter_2_pocket_3_full;		//                        Ls800
            public bool Sorter_3_input_pocket_1;	//                        Ls800
            public bool Sorter_3_pocket_1_full;		//                        Ls800
            public bool Sorter_3_input_pocket_2;	//                        Ls800
            public bool Sorter_3_pocket_2_full;		//                        Ls800
            public bool Sorter_3_input_pocket_3;	//                        Ls800
            public bool Sorter_3_pocket_3_full;		//                        Ls800
            public bool Sorter_4_input_pocket_1;	//                        Ls800
            public bool Sorter_4_pocket_1_full;		//                        Ls800
            public bool Sorter_4_input_pocket_2;	//                        Ls800
            public bool Sorter_4_pocket_2_full;		//                        Ls800
            public bool Sorter_4_input_pocket_3;	//                        Ls800
            public bool Sorter_4_pocket_3_full;		//                        Ls800
            public bool Sorter_5_input_pocket_1;	//                        Ls800
            public bool Sorter_5_pocket_1_full;		//                        Ls800
            public bool Sorter_5_input_pocket_2;	//                        Ls800
            public bool Sorter_5_pocket_2_full;		//                        Ls800
            public bool Sorter_5_input_pocket_3;	//                        Ls800
            public bool Sorter_5_pocket_3_full;		//                        Ls800
            public bool Sorter_6_input_pocket_1;	//                        Ls800
            public bool Sorter_6_pocket_1_full;		//                        Ls800
            public bool Sorter_6_input_pocket_2;	//                        Ls800
            public bool Sorter_6_pocket_2_full;		//                        Ls800
            public bool Sorter_6_input_pocket_3;	//                        Ls800
            public bool Sorter_6_pocket_3_full;		//                        Ls800
            public bool Sorter_7_input_pocket_1;	//                        Ls800
            public bool Sorter_7_pocket_1_full;		//                        Ls800
            public bool Sorter_7_input_pocket_2;	//                        Ls800
            public bool Sorter_7_pocket_2_full;		//                        Ls800
            public bool Sorter_7_input_pocket_3;	//                        Ls800
            public bool Sorter_7_pocket_3_full;		//                        Ls800

            public bool Photo_Trigger;				// Ls40
            public bool Document_Retained;			// Ls40
        };

        public struct UNITHISTORY
        {
            public Int32 Size;					    // Size of the structure

            public UInt32 doc_sorted;				// Document sortered
            public UInt32 doc_retained;			    // Nr. of document retained
            public UInt32 doc_retained_micr;		// Nr. documents retained after MICR header
            public UInt32 doc_retained_scan;		// Nr. documents retained after front scanning
            public UInt32 doc_ink_jet;  			// Nr. of document printed
            public UInt32 doc_stamped;	    		// Nr. of document stamped

            public UInt32 tot_paper_jams;			// Totally of Paper jam
            public UInt32 jams_in_feeder;			// Nr. jam in the feeder
            public UInt32 jams_in_micr;		    	// Nr. jam during the MICR reading
            public UInt32 jams_scanner;			    // Nr. jam between scanners
            public UInt32 jams_stamp;				// Nr. jam at stamp document
            public UInt32 jams_on_exit; 			// Nr. jam after the film
            public UInt32 jams_card;				// Nr. jam in the card entry
            public UInt32 nr_double_leafing;		// Nr. double leafing occurs Ls800 only

            public UInt32 tot_doc_MICR_err; 		// Totally MICR document, read with error
            public UInt32 doc_cmc7_err;		    	// Nr. of document CMC7, read with error
            public UInt32 doc_e13b_err;			    // Nr. of document E13B, read with error
            public UInt32 doc_hw_barcode_err;		// Nr. of document Barcode, read from LS with error
            public UInt32 doc_hw_optic_err; 		// Nr. of document OCR, read from LS with error

            public UInt32 num_turn_on;		    	// Nr. of power ON
            public UInt32 time_peripheral_on;		// Minutes peripheral time life

            // Section specific Ls800 unit
            public UInt32 jam_front_scanner;		// Jam in scanner front
            public UInt32 jam_track_left;			// Jam in the left track
            public UInt32 jam_track_right;		    // Jam in the right track
            public UInt32 jam_back_scanner;	    	// Jam in scanner back
            public UInt32 jam_in_the_sorters;		// Jam in sorters track
            // Section compiled only from Ls800 unit

            public UInt32 nr_drops_printed;		    // Nr. drops printed
        };

        public struct READOPTIONS
        {
            public int PutBlanks;       // 0 = CodeLIne whitout blans, 1 = CodeLine with 1 blanks
            public char TypeRead;       // 'N' for 1 type of CodeLine, 'X' for CodeLine E13B switch OCRB
        };


        // Parameter Peripheral Type
        public enum LsUnitType : short
		{
            LS_40_LSCONNECT = 39,
            LS_40_USB = 40,
            LS_100_LSCONNECT = 109,
            LS_100_USB = 100,
            LS_100_RS232 = 101,
            LS_100_ETH = 110,
            LS_150_LSCONNECT = 149,
            LS_150_USB = 150,
            LS_200_USB = 201,
            LS_5xx_SCSI = 500,
            LS_515_LSCONNECT = 501,
            LS_515_USB = 502,
            LS_520_USB = 520,
            LS_800_USB = 801,
        };

        public enum Stamp : short
		{
			STAMP_NO = 0,				// No stamp is done
			STAMP_FRONT = 1,			// Stamp on front document
			STAMP_BACK = 2,				// Stamp on rear document
			STAMP_FRONT_AND_BACK = 3,	// Stamp front and rear document
		};

        public enum PrintValidate : short
		{
			NO_PRINT_VALIDATE = 0,			// No print is done
			PRINT_VALIDATE = 1,			    // Print done
            PRINT_LOGO = 4,                 // Print a logo only
			PRINT_VALIDATE_WITH_LOGO = 5,	// Print logo and lines
		};

        public enum Feeder : short
		{
			FEED_AUTO = 0,				// Start Document from Feeder
			FEED_FROM_PATH = 1,			// Start Document from Unit Path
		};

        public enum Sorter : short
		{
			SORTER_DOC_HOLDED = 0,
			SORTER_POCKET_1 = 1,
			SORTER_POCKET_2 = 2,
			SORTER_AUTOMATIC = 3,
			SORTER_SWICTH_1_TO_2 = 4,
			SORTER_DOC_EJECTED = 5,
			SORTER_ON_CODELINE_CALLBACK = 6,

			// For Ls800 unit
			SORTER_CIRCULAR = 48,
			SORTER_SEQUENTIAL = 49,
			SORTER_POCKET_0_SELECTED = 50,
			SORTER_POCKET_1_SELECTED = 51,
			SORTER_POCKET_2_SELECTED = 52,
			SORTER_POCKET_3_SELECTED = 53,
			SORTER_POCKET_4_SELECTED = 54,
			SORTER_POCKET_5_SELECTED = 55,
			SORTER_POCKET_6_SELECTED = 56,
			SORTER_POCKET_7_SELECTED = 57,
			SORTER_POCKET_8_SELECTED = 58,
			SORTER_POCKET_9_SELECTED = 59,
			SORTER_POCKET_10_SELECTED = 60,
			SORTER_POCKET_11_SELECTED = 61,
			SORTER_POCKET_12_SELECTED = 62,
			SORTER_POCKET_13_SELECTED = 63,
			SORTER_POCKET_14_SELECTED = 64,
			SORTER_POCKET_15_SELECTED = 65,
			SORTER_POCKET_16_SELECTED = 66,
			SORTER_POCKET_17_SELECTED = 67,
			SORTER_POCKET_18_SELECTED = 68,
			SORTER_POCKET_19_SELECTED = 69,
			SORTER_POCKET_20_SELECTED = 70,
			SORTER_POCKET_21_SELECTED = 71,
		};

        public enum CodeLineType : byte
		{
			NO_READ_CODELINE = 0,
			READ_CODELINE_HW_MICR = 1,
			READ_CODELINE_E13B_MICR_WITH_OCR = 15,

			READ_CODELINE_SW_OCRA = 65, //'A',
			READ_CODELINE_SW_OCRB_NUM = 66, //'B',
			READ_CODELINE_SW_OCRB_ALFANUM = 67, //'C',
			READ_CODELINE_SW_OCRB_ITALY = 70, //'F',
			READ_CODELINE_SW_E13B = 69, //'E',
			READ_CODELINE_SW_E13B_X_OCRB = 88, //'X',

			READ_BARCODE_2_OF_5 = 50,
			READ_BARCODE_CODE39 = 51,
			READ_BARCODE_CODE128 = 52,
//			READ_BARCODE_EAN13 = 53,

            MAX_CODE_LINE_LENGTH = 254,
		};

        public enum Unit : short
		{
			UNIT_MM = 0,
			UNIT_INCH = 1,
		};

		public class OcrHeight
		{
		    public const double OCR_MAX_HEIGHT_IN_MM = 10.5;
            public const double OCR_MAX_HEIGHT_IN_INCH = 0.41;
		};

		public enum BlankInCodeline : short
		{
			BLANK_IN_CODELINE_NO = 0,
			BLANK_IN_CODELINE_YES = 1,
		};

		public enum OriginOCR : short
		{
			ORIGIN_BOTTOM_RIGHT_MM = 10,
			ORIGIN_BOTTOM_RIGHT_INCH = 20,
		};

		public enum ScanMode : short
		{
			SCAN_MODE_BW = 1,
			SCAN_MODE_16_GRAY_100 = 2,
			SCAN_MODE_16_GRAY_200 = 3,
			SCAN_MODE_256_GRAY_100 = 4,
			SCAN_MODE_256_GRAY_200 = 5,
			SCAN_MODE_COLOR_100 = 10,
			SCAN_MODE_COLOR_200 = 11,
			SCAN_MODE_16_GRAY_300 = 20,
			SCAN_MODE_256_GRAY_300 = 21,
			SCAN_MODE_COLOR_300	= 22,
			SCAN_MODE_256GR100_AND_UV = 40,
			SCAN_MODE_256GR200_AND_UV = 41,
			SCAN_MODE_256GR300_AND_UV = 42,
		};

		public enum ScanDocType : short
		{
			SCAN_PAPER_DOCUMENT = 0 ,
			SCAN_CARD = 1 , 
		};

		public enum Side : short
		{
			SIDE_NONE_IMAGE = 78, //'N',
			SIDE_FRONT_IMAGE = 70, //'F',
			SIDE_BACK_IMAGE = 66, //'B',
			SIDE_ALL_IMAGE = 88, //'X',
			SIDE_FRONT_UV = 85, //'U',
			SIDE_FRONT_MERGED = 77, //'M',
		};

		public enum Wait : short
		{
			WAIT_NO = 71, //'G',
			WAIT_YES = 87, //'W',
		};

		public enum Beep : short
		{
			BEEP_NO = 0,
			BEEP_YES = 1,
		};

		public enum ClearBlack : short
		{
			CLEAR_BLACK_NO = 0,
			CLEAR_BLACK_YES = 1,
			CLEAR_AND_ALIGN_IMAGE = 2 , 
		};

		public enum PrintFont : byte
		{
            PRINT_NO_STRING = 0,
			PRINT_FONT_NORMAL = 78, //'N',
			PRINT_FONT_BOLD = 66, //'B',
			PRINT_FONT_NORMAL_15 = 65, //'A',

			PRINT_UP_FONT_NORMAL = 110, //'n',
			PRINT_UP_FONT_BOLD = 98, //'b',
			PRINT_UP_FONT_NORMAL_15_CHAR = 97, //'a',
		};

		public enum DoubleLeafing : short
		{

			DOUBLE_LEAFING_WARNING = 0 ,
			DOUBLE_LEAFING_ERROR = 1 ,
			//DOUBLE_LEAFING_LEVEL1 = 1,non lo uso piu'
			DOUBLE_LEAFING_LEVEL2 = 2,
			DOUBLE_LEAFING_LEVEL3 = 3,
			DOUBLE_LEAFING_DEFAULT = 4,
			DOUBLE_LEAFING_LEVEL4 = 5,
			DOUBLE_LEAFING_LEVEL5 = 6,
			DOUBLE_LEAFING_DISABLE = 7,
		};

		public enum Reset : short
		{
			RESET_ERROR = 48, //'0',
			RESET_PATH = 49, //'1',
			RESET_BELT_CLEANING	= 50, //'2',
		};

		public enum ImageSave : short
		{
			IMAGE_SAVE_ON_FILE = 4,
			IMAGE_SAVE_HANDLE = 5,
			IMAGE_SAVE_BOTH = 6,
			IMAGE_SAVE_NONE = 7,
		};

		public enum FileType : short
		{
			FILE_JPEG = 10,
			FILE_BMP = 11,
			FILE_TIF = 3,
			FILE_CCITT = 25,
			FILE_CCITT_GROUP3_1DIM = 27,
			FILE_CCITT_GROUP3_2DIM = 28,
			FILE_CCITT_GROUP4 = 29,
		};

		public enum FileAttribute : short
		{
			SAVE_OVERWRITE = 0,
			SAVE_APPEND = 1,
			SAVE_REPLACE = 2,
			SAVE_INSERT = 3,
		};

        public enum LsSpeed : short
        {
            SPEED_DEFAULT = 0,
            SPEED_STAMP = 1,
        };

		public enum Badge : short
		{
			BADGE_READ_TRACK_1 = 0x20,
			BADGE_READ_TRACK_2 = 0x40,
			BADGE_READ_TRACK_3 = 0x80,
			BADGE_READ_TRACKS_1_2 = 0x60,
			BADGE_READ_TRACKS_2_3 = 0xc0,
			BADGE_READ_TRACKS_1_2_3 = 0xe0,
		};

        public class LsReply
        {
            // ------------------------------------------------------------------------
            //                          REPLY-CODE
            // ------------------------------------------------------------------------
            public const int LS_OKAY = 0;


            // ------------------------------------------------------------------------
            //                  ERRORS
            // ------------------------------------------------------------------------
            public const int LS_SYSTEM_ERROR = -1;
            public const int LS_USB_ERROR = -2;
            public const int LS_PERIPHERAL_NOT_FOUND = -3;
            public const int LS_HARDWARE_ERROR = -4;
            public const int LS_PERIPHERAL_OFF_ON = -5;
            public const int LS_RESERVED_ERROR = -6;
            public const int LS_PAPER_JAM = -7;
            public const int LS_TARGET_BUSY = -8;
            public const int LS_INVALID_COMMAND = -9;
            public const int LS_DATA_LOST = -10;
            public const int LS_COMMAND_IN_EXECUTION_YET = -11;
            public const int LS_JPEG_ERROR = -12;
            public const int LS_COMMAND_SEQUENCE_ERROR = -13;
            public const int LS_PC_HW_ERROR = -14;
            public const int LS_IMAGE_OVERWRITE = -15;
            public const int LS_INVALID_HANDLE = -16;
            public const int LS_NO_LIBRARY_LOAD = -17;
            public const int LS_BMP_ERROR = -18;
            public const int LS_TIFF_ERROR = -19;
            public const int LS_IMAGE_NO_MORE_AVAILABLE = -20;
            public const int LS_IMAGE_NO_FILMED = -21;
            public const int LS_IMAGE_NOT_PRESENT = -22;
            public const int LS_FUNCTION_NOT_AVAILABLE = -23;
            public const int LS_DOCUMENT_NOT_SUPPORTED = -24;
            public const int LS_BARCODE_ERROR = -25;
            public const int LS_INVALID_LIBRARY = -26;
            public const int LS_INVALID_IMAGE = -27;
            public const int LS_INVALID_IMAGE_FORMAT = -28;
            public const int LS_INVALID_BARCODE_TYPE = -29;
            public const int LS_OPEN_NOT_DONE = -30;
            public const int LS_INVALID_TYPE_COMMAND = -31;
            public const int LS_INVALID_CLEARBLACK = -32;
            public const int LS_INVALID_SIDE = -33;
            public const int LS_MISSING_IMAGE = -34;
            public const int LS_INVALID_TYPE = -35;
            public const int LS_INVALID_SAVEMODE = -36;
            public const int LS_INVALID_PAGE_NUMBER = -37;
            public const int LS_INVALID_NRIMAGE = -38;
            public const int LS_INVALID_STAMP = -39;
            public const int LS_INVALID_WAITTIMEOUT = -40;
            public const int LS_INVALID_VALIDATE = -41;
            public const int LS_INVALID_CODELINE_TYPE = -42;
            public const int LS_MISSING_NRIMAGE = -43;
            public const int LS_INVALID_SCANMODE = -44;
            public const int LS_INVALID_BEEP = -45;
            public const int LS_INVALID_FEEDER = -46;
            public const int LS_INVALID_SORTER = -47;
            public const int LS_INVALID_BADGE_TRACK = -48;
            public const int LS_MISSING_FILENAME = -49;
            public const int LS_INVALID_QUALITY = -50;
            public const int LS_INVALID_FILEFORMAT = -51;
            public const int LS_INVALID_COORDINATE = -52;
            public const int LS_MISSING_HANDLE_VARIABLE = -53;
            public const int LS_INVALID_POLO_FILTER = -54;
            public const int LS_INVALID_ORIGIN_MEASURES = -55;
            public const int LS_INVALID_SIZEH_VALUE = -56;
            public const int LS_INVALID_FORMAT = -57;
            public const int LS_STRINGS_TOO_LONGS = -58;
            public const int LS_READ_IMAGE_FAILED = -59;
            public const int LS_INVALID_CMD_HISTORY = -60;
            public const int LS_MISSING_BUFFER_HISTORY = -61;
            public const int LS_INVALID_ANSWER = -62;
            public const int LS_OPEN_FILE_ERROR_OR_NOT_FOUND = -63;
            public const int LS_READ_TIMEOUT_EXPIRED = -64;
            public const int LS_INVALID_METHOD = -65;
            public const int LS_CALIBRATION_FAILED = -66;
            public const int LS_INVALID_SAVEIMAGE = -67;
            public const int LS_INVALID_UNIT = -68;
            public const int LS_INVALID_NRWINDOWS = -71;
            public const int LS_INVALID_VALUE = -72;
            public const int LS_ILLEGAL_REQUEST = -73;
            public const int LS_INVALID_NR_CRITERIA = -74;
            public const int LS_MISSING_CRITERIA_STRUCTURE = -75;
            public const int LS_INVALID_MOVEMENT = -76;
            public const int LS_INVALID_DEGREE = -77;
            public const int LS_R0TATE_ERROR = -78;
            public const int LS_MICR_VALUE_OUT_OF_RANGE = -79;
            public const int LS_PERIPHERAL_RESERVED = -80;
            public const int LS_INVALID_NCHANGE = -81;
            public const int LS_BRIGHTNESS_ERROR = -82;
            public const int LS_CONTRAST_ERROR = -83;
            public const int LS_INVALID_SIDETOPRINT = -84;
            public const int LS_DOUBLE_LEAFING_ERROR = -85;
            public const int LS_INVALID_BADGE_TIMEOUT = -86;
            public const int LS_INVALID_RESET_TYPE = -87;
            public const int LS_MISSING_SET_CALLBACK = -88;
            public const int LS_IMAGE_NOT_200_DPI = -89;
            public const int LS_DOWNLOAD_ERROR = -90;
            public const int LS_INVALID_SORT_ON_CHOICE = -91;
            public const int LS_INVALID_FONT = -92;
            public const int LS_INVALID_UNIT_SPEED = -93;
            public const int LS_INVALID_LENGTH = -94;
            public const int LS_SHORT_PAPER = -95;
            public const int LS_INVALID_DOC_LENGTH = -96;
            public const int LS_INVALID_DOCSLONG = -97;
            public const int LS_IMAGE_NOT_256_COLOR = -98;
            public const int LS_BATTERY_NOT_CHARGED = -99;
            public const int LS_INVALID_SCAN_DOC_TYPE = -100;
            public const int LS_ILLEGAL_SCAN_CARD_SPEED = -101;
            public const int LS_INVALID_PWM_VALUE = -102;
            public const int LS_INVALID_KEY_LENGTH = -103;
            public const int LS_INVALID_PASSWORD = -104;
            public const int LS_UNIT_LOCKED = -105;
            public const int LS_INVALID_IMAGEFORMAT = -106;
            public const int LS_INVALID_THRESHOLD = -107;
            public const int LS_NO_START_FOR_SORTER_FULL = -108;
            public const int LS_IPBOX_ADDRESS_NOT_FOUNDED = -109;
            public const int LS_INVALID_LED_COMMAND = -110;
            public const int LS_INVALID_COLOR_PARAMETER = -111;

            public const int LS_JAM_AT_MICR_PHOTO = -201;
            public const int LS_JAM_DOC_TOO_LONG = -202;
            public const int LS_JAM_AT_SCANNER_PHOTO = -203;

            public const int LS_SCAN_NETTO_IMAGE_NOT_SUPPORTED = -521;
            public const int LS_256_GRAY_NOT_SUPPORTED = -522;
            public const int LS_INVALID_PATH = -523;
            public const int LS_MISSING_CALLBACK_FUNCTION = -526;
            public const int LS_INVALID_OCR_IMAGE_SIDE = -558;
            public const int LS_PERIPHERAL_NOT_ANSWER = -599;

            public const int LS_INVALID_CONNECTION_HANDLE = -1000;
            public const int LS_INVALID_CONNECT_PERIPHERAL = -1001;
            public const int LS_PERIPHERAL_NOT_YET_INTEGRATE = -1002;
            public const int LS_UNKNOW_PERIPHERAL_REPLY = -1003;
            public const int LS_CODELINE_ALREADY_DEFINED = -1004;
            public const int LS_INVALID_NUMBER_OF_DOC = -1005;

            public const int LS_DECODE_FONT_NOT_PRESENT = -1101;
            public const int LS_DECODE_INVALID_COORDINATE = -1102;
            public const int LS_DECODE_INVALID_OPTION = -1103;
            public const int LS_DECODE_INVALID_CODELINE_TYPE = -1104;
            public const int LS_DECODE_SYSTEM_ERROR = -1105;
            public const int LS_DECODE_DATA_TRUNC = -1106;
            public const int LS_DECODE_INVALID_BITMAP = -1107;
            public const int LS_DECODE_ILLEGAL_USE = -1108;

            public const int LS_BARCODE_GENERIC_ERROR = -1201;
            public const int LS_BARCODE_NOT_DECODABLE = -1202;
            public const int LS_BARCODE_OPENFILE_ERROR = -1203;
            public const int LS_BARCODE_READBMP_ERROR = -1204;
            public const int LS_BARCODE_MEMORY_ERROR = -1205;
            public const int LS_BARCODE_START_NOTFOUND = -1206;
            public const int LS_BARCODE_STOP_NOTFOUND = -1207;

            public const int LS_PDF_NOT_DECODABLE = -1301;
            public const int LS_PDF_READBMP_ERROR = -1302;
            public const int LS_PDF_BITMAP_FORMAT_ERROR = -1303;
            public const int LS_PDF_MEMORY_ERROR = -1304;
            public const int LS_PDF_START_NOTFOUND = -1305;
            public const int LS_PDF_STOP_NOTFOUND = -1306;
            public const int LS_PDF_LEFTIND_ERROR = -1307;
            public const int LS_PDF_RIGHTIND_ERROR = -1308;
            public const int LS_PDF_OPENFILE_ERROR = -1309;


            // ------------------------------------------------------------------------
            //                  WARNINGS
            // ------------------------------------------------------------------------
            public const int LS_FEEDER_EMPTY = 1;
            public const int LS_DATA_TRUNCATED = 2;
            public const int LS_DOC_PRESENT = 3;
            public const int LS_BADGE_TIMEOUT = 4;
            public const int LS_ALREADY_OPEN = 5;
            public const int LS_PERIPHERAL_BUSY = 6;
            public const int LS_DOUBLE_LEAFING_WARNING = 7;
            public const int LS_COMMAND_NOT_ENDED = 8;
            public const int LS_RETRY = 9;
            public const int LS_NO_OTHER_DOCUMENT = 10;
            public const int LS_QUEUE_FULL = 11;
            public const int LS_NO_SENSE = 12;
            public const int LS_TRY_TO_RESET = 14;
            public const int LS_STRING_TRUNCATED = 15;
            public const int LS_COMMAND_NOT_SUPPORTED = 19;
            public const int LS_SORTER1_FULL = 35;
            public const int LS_SORTER2_FULL = 36;
            public const int LS_SORTERS_BOTH_FULL = 37;
            public const int LS_KEEP_DOC_ON_CODELINE_ERROR = 39;
            public const int LS_LOOP_INTERRUPTED = 40;

            public const int LS_SORTER_1_POCKET_1_FULL = 51;
            public const int LS_SORTER_1_POCKET_2_FULL = 52;
            public const int LS_SORTER_1_POCKET_3_FULL = 53;
            public const int LS_SORTER_2_POCKET_1_FULL = 54;
            public const int LS_SORTER_2_POCKET_2_FULL = 55;
            public const int LS_SORTER_2_POCKET_3_FULL = 56;
            public const int LS_SORTER_3_POCKET_1_FULL = 57;
            public const int LS_SORTER_3_POCKET_2_FULL = 58;
            public const int LS_SORTER_3_POCKET_3_FULL = 59;
            public const int LS_SORTER_4_POCKET_1_FULL = 60;
            public const int LS_SORTER_4_POCKET_2_FULL = 61;
            public const int LS_SORTER_4_POCKET_3_FULL = 62;
            public const int LS_SORTER_5_POCKET_1_FULL = 63;
            public const int LS_SORTER_5_POCKET_2_FULL = 64;
            public const int LS_SORTER_5_POCKET_3_FULL = 65;
            public const int LS_SORTER_6_POCKET_1_FULL = 66;
            public const int LS_SORTER_6_POCKET_2_FULL = 67;
            public const int LS_SORTER_6_POCKET_3_FULL = 68;
            public const int LS_SORTER_7_POCKET_1_FULL = 69;
            public const int LS_SORTER_7_POCKET_2_FULL = 70;
            public const int LS_SORTER_7_POCKET_3_FULL = 71;
        };
    }
}
