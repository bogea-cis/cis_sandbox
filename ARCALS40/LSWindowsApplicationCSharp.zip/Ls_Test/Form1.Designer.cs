﻿namespace Ls_Test
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.btIdentify = new System.Windows.Forms.Button();
            this.btStatus = new System.Windows.Forms.Button();
            this.btMonitor = new System.Windows.Forms.Button();
            this.btOptions = new System.Windows.Forms.Button();
            this.btProcessDoc = new System.Windows.Forms.Button();
            this.btStopDoc = new System.Windows.Forms.Button();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.btRear = new System.Windows.Forms.Button();
            this.btReset = new System.Windows.Forms.Button();
            this.tbCodeline = new System.Windows.Forms.TextBox();
            this.btExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.SuspendLayout();
            // 
            // btIdentify
            // 
            this.btIdentify.Location = new System.Drawing.Point(12, 12);
            this.btIdentify.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btIdentify.Name = "btIdentify";
            this.btIdentify.Size = new System.Drawing.Size(75, 33);
            this.btIdentify.TabIndex = 0;
            this.btIdentify.Text = "&Identify";
            this.btIdentify.UseVisualStyleBackColor = true;
            this.btIdentify.Click += new System.EventHandler(this.btIdentify_Click);
            // 
            // btStatus
            // 
            this.btStatus.Location = new System.Drawing.Point(111, 12);
            this.btStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btStatus.Name = "btStatus";
            this.btStatus.Size = new System.Drawing.Size(75, 33);
            this.btStatus.TabIndex = 1;
            this.btStatus.Text = "&Status";
            this.btStatus.UseVisualStyleBackColor = true;
            this.btStatus.Click += new System.EventHandler(this.btStatus_Click);
            // 
            // btMonitor
            // 
            this.btMonitor.Location = new System.Drawing.Point(211, 12);
            this.btMonitor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btMonitor.Name = "btMonitor";
            this.btMonitor.Size = new System.Drawing.Size(75, 33);
            this.btMonitor.TabIndex = 2;
            this.btMonitor.Text = "&History";
            this.btMonitor.UseVisualStyleBackColor = true;
            this.btMonitor.Click += new System.EventHandler(this.btMonitor_Click);
            // 
            // btOptions
            // 
            this.btOptions.Location = new System.Drawing.Point(535, 12);
            this.btOptions.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btOptions.Name = "btOptions";
            this.btOptions.Size = new System.Drawing.Size(75, 33);
            this.btOptions.TabIndex = 3;
            this.btOptions.Text = "&Options";
            this.btOptions.UseVisualStyleBackColor = true;
            this.btOptions.Click += new System.EventHandler(this.btOptions_Click);
            // 
            // btProcessDoc
            // 
            this.btProcessDoc.Location = new System.Drawing.Point(637, 12);
            this.btProcessDoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btProcessDoc.Name = "btProcessDoc";
            this.btProcessDoc.Size = new System.Drawing.Size(111, 33);
            this.btProcessDoc.TabIndex = 4;
            this.btProcessDoc.Text = "&Process Doc.";
            this.btProcessDoc.UseVisualStyleBackColor = true;
            this.btProcessDoc.Click += new System.EventHandler(this.btProcessDoc_Click);
            // 
            // btStopDoc
            // 
            this.btStopDoc.Enabled = false;
            this.btStopDoc.Location = new System.Drawing.Point(775, 12);
            this.btStopDoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btStopDoc.Name = "btStopDoc";
            this.btStopDoc.Size = new System.Drawing.Size(111, 33);
            this.btStopDoc.TabIndex = 5;
            this.btStopDoc.Text = "&Stop Process";
            this.btStopDoc.UseVisualStyleBackColor = true;
            this.btStopDoc.Click += new System.EventHandler(this.btStopDoc_Click);
            // 
            // pbImage
            // 
            this.pbImage.Location = new System.Drawing.Point(32, 123);
            this.pbImage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(835, 378);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImage.TabIndex = 6;
            this.pbImage.TabStop = false;
            // 
            // btRear
            // 
            this.btRear.Enabled = false;
            this.btRear.Location = new System.Drawing.Point(32, 508);
            this.btRear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btRear.Name = "btRear";
            this.btRear.Size = new System.Drawing.Size(92, 30);
            this.btRear.TabIndex = 7;
            this.btRear.Text = "Show Rear";
            this.btRear.UseVisualStyleBackColor = true;
            this.btRear.Click += new System.EventHandler(this.btRear_Click);
            // 
            // btReset
            // 
            this.btReset.Location = new System.Drawing.Point(309, 12);
            this.btReset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btReset.Name = "btReset";
            this.btReset.Size = new System.Drawing.Size(75, 33);
            this.btReset.TabIndex = 8;
            this.btReset.Text = "&Reset";
            this.btReset.UseVisualStyleBackColor = true;
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // tbCodeline
            // 
            this.tbCodeline.Location = new System.Drawing.Point(32, 87);
            this.tbCodeline.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbCodeline.Name = "tbCodeline";
            this.tbCodeline.ReadOnly = true;
            this.tbCodeline.Size = new System.Drawing.Size(835, 22);
            this.tbCodeline.TabIndex = 9;
            this.tbCodeline.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(776, 508);
            this.btExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(92, 30);
            this.btExit.TabIndex = 10;
            this.btExit.Text = "Exit";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(899, 542);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.tbCodeline);
            this.Controls.Add(this.btReset);
            this.Controls.Add(this.btRear);
            this.Controls.Add(this.pbImage);
            this.Controls.Add(this.btStopDoc);
            this.Controls.Add(this.btProcessDoc);
            this.Controls.Add(this.btOptions);
            this.Controls.Add(this.btMonitor);
            this.Controls.Add(this.btStatus);
            this.Controls.Add(this.btIdentify);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LS Test Unit";
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btIdentify;
        private System.Windows.Forms.Button btStatus;
        private System.Windows.Forms.Button btMonitor;
        private System.Windows.Forms.Button btOptions;
        private System.Windows.Forms.Button btProcessDoc;
        private System.Windows.Forms.Button btStopDoc;
        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.Button btRear;
        private System.Windows.Forms.Button btReset;
        private System.Windows.Forms.TextBox tbCodeline;
        private System.Windows.Forms.Button btExit;
    }
}

