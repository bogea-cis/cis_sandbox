﻿namespace Ls_Test
{
    partial class FormOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbScanMode = new System.Windows.Forms.GroupBox();
            this.rbUV300 = new System.Windows.Forms.RadioButton();
            this.rbUV200 = new System.Windows.Forms.RadioButton();
            this.rbUV100 = new System.Windows.Forms.RadioButton();
            this.rbColor300 = new System.Windows.Forms.RadioButton();
            this.rbColor200 = new System.Windows.Forms.RadioButton();
            this.rbColor100 = new System.Windows.Forms.RadioButton();
            this.rb256gray300 = new System.Windows.Forms.RadioButton();
            this.rb256gray200 = new System.Windows.Forms.RadioButton();
            this.rb256gray100 = new System.Windows.Forms.RadioButton();
            this.rb16gray300 = new System.Windows.Forms.RadioButton();
            this.rb16gray200 = new System.Windows.Forms.RadioButton();
            this.rb16gray100 = new System.Windows.Forms.RadioButton();
            this.rbBW200 = new System.Windows.Forms.RadioButton();
            this.gbCodelines = new System.Windows.Forms.GroupBox();
            this.btViewBarcode = new System.Windows.Forms.Button();
            this.btViewOCR = new System.Windows.Forms.Button();
            this.cbMOCR = new System.Windows.Forms.CheckBox();
            this.cbBarcode = new System.Windows.Forms.CheckBox();
            this.cbOCR = new System.Windows.Forms.CheckBox();
            this.cbMICR = new System.Windows.Forms.CheckBox();
            this.gbSide = new System.Windows.Forms.GroupBox();
            this.cbSide = new System.Windows.Forms.ComboBox();
            this.gbCoordinate = new System.Windows.Forms.GroupBox();
            this.btSetCoordinate = new System.Windows.Forms.Button();
            this.cbOCRfont = new System.Windows.Forms.ComboBox();
            this.tbHeight = new System.Windows.Forms.TextBox();
            this.tbWidth = new System.Windows.Forms.TextBox();
            this.tbY = new System.Windows.Forms.TextBox();
            this.tbX = new System.Windows.Forms.TextBox();
            this.lbHeight = new System.Windows.Forms.Label();
            this.lbWidth = new System.Windows.Forms.Label();
            this.lbY = new System.Windows.Forms.Label();
            this.lbX = new System.Windows.Forms.Label();
            this.gbEndorse = new System.Windows.Forms.GroupBox();
            this.cbFontPrint = new System.Windows.Forms.ComboBox();
            this.tbPrintString = new System.Windows.Forms.TextBox();
            this.gbDocProcess = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.tbNumDoc = new System.Windows.Forms.TextBox();
            this.rbNum = new System.Windows.Forms.RadioButton();
            this.rbAllDoc = new System.Windows.Forms.RadioButton();
            this.cbWaitTimeout = new System.Windows.Forms.CheckBox();
            this.cbLinear = new System.Windows.Forms.CheckBox();
            this.cbLowSpeed = new System.Windows.Forms.CheckBox();
            this.gbDoubleLafing = new System.Windows.Forms.GroupBox();
            this.cbWarning = new System.Windows.Forms.CheckBox();
            this.cbDisabled = new System.Windows.Forms.CheckBox();
            this.gbDocLen = new System.Windows.Forms.GroupBox();
            this.tbMax = new System.Windows.Forms.TextBox();
            this.tbMin = new System.Windows.Forms.TextBox();
            this.gbSensibility = new System.Windows.Forms.GroupBox();
            this.tbSensibility = new System.Windows.Forms.TextBox();
            this.btOk = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.gbScanMode.SuspendLayout();
            this.gbCodelines.SuspendLayout();
            this.gbSide.SuspendLayout();
            this.gbCoordinate.SuspendLayout();
            this.gbEndorse.SuspendLayout();
            this.gbDocProcess.SuspendLayout();
            this.gbDoubleLafing.SuspendLayout();
            this.gbDocLen.SuspendLayout();
            this.gbSensibility.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbScanMode
            // 
            this.gbScanMode.Controls.Add(this.rbUV300);
            this.gbScanMode.Controls.Add(this.rbUV200);
            this.gbScanMode.Controls.Add(this.rbUV100);
            this.gbScanMode.Controls.Add(this.rbColor300);
            this.gbScanMode.Controls.Add(this.rbColor200);
            this.gbScanMode.Controls.Add(this.rbColor100);
            this.gbScanMode.Controls.Add(this.rb256gray300);
            this.gbScanMode.Controls.Add(this.rb256gray200);
            this.gbScanMode.Controls.Add(this.rb256gray100);
            this.gbScanMode.Controls.Add(this.rb16gray300);
            this.gbScanMode.Controls.Add(this.rb16gray200);
            this.gbScanMode.Controls.Add(this.rb16gray100);
            this.gbScanMode.Controls.Add(this.rbBW200);
            this.gbScanMode.Location = new System.Drawing.Point(12, 14);
            this.gbScanMode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbScanMode.Name = "gbScanMode";
            this.gbScanMode.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbScanMode.Size = new System.Drawing.Size(206, 426);
            this.gbScanMode.TabIndex = 0;
            this.gbScanMode.TabStop = false;
            this.gbScanMode.Text = "ScanMode";
            // 
            // rbUV300
            // 
            this.rbUV300.AutoSize = true;
            this.rbUV300.Enabled = false;
            this.rbUV300.Location = new System.Drawing.Point(15, 390);
            this.rbUV300.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbUV300.Name = "rbUV300";
            this.rbUV300.Size = new System.Drawing.Size(172, 21);
            this.rbUV300.TabIndex = 12;
            this.rbUV300.TabStop = true;
            this.rbUV300.Text = "256 gray && UV 300 dpi";
            this.rbUV300.UseVisualStyleBackColor = true;
            // 
            // rbUV200
            // 
            this.rbUV200.AutoSize = true;
            this.rbUV200.Enabled = false;
            this.rbUV200.Location = new System.Drawing.Point(15, 360);
            this.rbUV200.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbUV200.Name = "rbUV200";
            this.rbUV200.Size = new System.Drawing.Size(172, 21);
            this.rbUV200.TabIndex = 11;
            this.rbUV200.TabStop = true;
            this.rbUV200.Text = "256 gray && UV 200 dpi";
            this.rbUV200.UseVisualStyleBackColor = true;
            // 
            // rbUV100
            // 
            this.rbUV100.AutoSize = true;
            this.rbUV100.Enabled = false;
            this.rbUV100.Location = new System.Drawing.Point(15, 330);
            this.rbUV100.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbUV100.Name = "rbUV100";
            this.rbUV100.Size = new System.Drawing.Size(172, 21);
            this.rbUV100.TabIndex = 10;
            this.rbUV100.TabStop = true;
            this.rbUV100.Text = "256 gray && UV 100 dpi";
            this.rbUV100.UseVisualStyleBackColor = true;
            // 
            // rbColor300
            // 
            this.rbColor300.AutoSize = true;
            this.rbColor300.Enabled = false;
            this.rbColor300.Location = new System.Drawing.Point(16, 300);
            this.rbColor300.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbColor300.Name = "rbColor300";
            this.rbColor300.Size = new System.Drawing.Size(113, 21);
            this.rbColor300.TabIndex = 9;
            this.rbColor300.TabStop = true;
            this.rbColor300.Text = "Color 300 dpi";
            this.rbColor300.UseVisualStyleBackColor = true;
            // 
            // rbColor200
            // 
            this.rbColor200.AutoSize = true;
            this.rbColor200.Enabled = false;
            this.rbColor200.Location = new System.Drawing.Point(16, 270);
            this.rbColor200.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbColor200.Name = "rbColor200";
            this.rbColor200.Size = new System.Drawing.Size(113, 21);
            this.rbColor200.TabIndex = 8;
            this.rbColor200.TabStop = true;
            this.rbColor200.Text = "Color 200 dpi";
            this.rbColor200.UseVisualStyleBackColor = true;
            // 
            // rbColor100
            // 
            this.rbColor100.AutoSize = true;
            this.rbColor100.Enabled = false;
            this.rbColor100.Location = new System.Drawing.Point(16, 240);
            this.rbColor100.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbColor100.Name = "rbColor100";
            this.rbColor100.Size = new System.Drawing.Size(113, 21);
            this.rbColor100.TabIndex = 7;
            this.rbColor100.TabStop = true;
            this.rbColor100.Text = "Color 100 dpi";
            this.rbColor100.UseVisualStyleBackColor = true;
            // 
            // rb256gray300
            // 
            this.rb256gray300.AutoSize = true;
            this.rb256gray300.Location = new System.Drawing.Point(16, 210);
            this.rb256gray300.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb256gray300.Name = "rb256gray300";
            this.rb256gray300.Size = new System.Drawing.Size(136, 21);
            this.rb256gray300.TabIndex = 6;
            this.rb256gray300.TabStop = true;
            this.rb256gray300.Text = "256 gray 300 dpi";
            this.rb256gray300.UseVisualStyleBackColor = true;
            // 
            // rb256gray200
            // 
            this.rb256gray200.AutoSize = true;
            this.rb256gray200.Location = new System.Drawing.Point(16, 180);
            this.rb256gray200.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb256gray200.Name = "rb256gray200";
            this.rb256gray200.Size = new System.Drawing.Size(136, 21);
            this.rb256gray200.TabIndex = 5;
            this.rb256gray200.TabStop = true;
            this.rb256gray200.Text = "256 gray 200 dpi";
            this.rb256gray200.UseVisualStyleBackColor = true;
            // 
            // rb256gray100
            // 
            this.rb256gray100.AutoSize = true;
            this.rb256gray100.Location = new System.Drawing.Point(16, 150);
            this.rb256gray100.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb256gray100.Name = "rb256gray100";
            this.rb256gray100.Size = new System.Drawing.Size(136, 21);
            this.rb256gray100.TabIndex = 4;
            this.rb256gray100.TabStop = true;
            this.rb256gray100.Text = "256 gray 100 dpi";
            this.rb256gray100.UseVisualStyleBackColor = true;
            // 
            // rb16gray300
            // 
            this.rb16gray300.AutoSize = true;
            this.rb16gray300.Location = new System.Drawing.Point(16, 120);
            this.rb16gray300.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb16gray300.Name = "rb16gray300";
            this.rb16gray300.Size = new System.Drawing.Size(128, 21);
            this.rb16gray300.TabIndex = 3;
            this.rb16gray300.TabStop = true;
            this.rb16gray300.Text = "16 gray 300 dpi";
            this.rb16gray300.UseVisualStyleBackColor = true;
            // 
            // rb16gray200
            // 
            this.rb16gray200.AutoSize = true;
            this.rb16gray200.Location = new System.Drawing.Point(16, 90);
            this.rb16gray200.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb16gray200.Name = "rb16gray200";
            this.rb16gray200.Size = new System.Drawing.Size(128, 21);
            this.rb16gray200.TabIndex = 2;
            this.rb16gray200.TabStop = true;
            this.rb16gray200.Text = "16 gray 200 dpi";
            this.rb16gray200.UseVisualStyleBackColor = true;
            // 
            // rb16gray100
            // 
            this.rb16gray100.AutoSize = true;
            this.rb16gray100.Location = new System.Drawing.Point(16, 60);
            this.rb16gray100.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb16gray100.Name = "rb16gray100";
            this.rb16gray100.Size = new System.Drawing.Size(128, 21);
            this.rb16gray100.TabIndex = 1;
            this.rb16gray100.TabStop = true;
            this.rb16gray100.Text = "16 gray 100 dpi";
            this.rb16gray100.UseVisualStyleBackColor = true;
            // 
            // rbBW200
            // 
            this.rbBW200.AutoSize = true;
            this.rbBW200.Location = new System.Drawing.Point(16, 30);
            this.rbBW200.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbBW200.Name = "rbBW200";
            this.rbBW200.Size = new System.Drawing.Size(102, 21);
            this.rbBW200.TabIndex = 0;
            this.rbBW200.TabStop = true;
            this.rbBW200.Text = "BW 200 dpi";
            this.rbBW200.UseVisualStyleBackColor = true;
            // 
            // gbCodelines
            // 
            this.gbCodelines.Controls.Add(this.btViewBarcode);
            this.gbCodelines.Controls.Add(this.btViewOCR);
            this.gbCodelines.Controls.Add(this.cbMOCR);
            this.gbCodelines.Controls.Add(this.cbBarcode);
            this.gbCodelines.Controls.Add(this.cbOCR);
            this.gbCodelines.Controls.Add(this.cbMICR);
            this.gbCodelines.Location = new System.Drawing.Point(234, 14);
            this.gbCodelines.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCodelines.Name = "gbCodelines";
            this.gbCodelines.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCodelines.Size = new System.Drawing.Size(181, 186);
            this.gbCodelines.TabIndex = 1;
            this.gbCodelines.TabStop = false;
            this.gbCodelines.Text = "CodeLines";
            // 
            // btViewBarcode
            // 
            this.btViewBarcode.Enabled = false;
            this.btViewBarcode.Location = new System.Drawing.Point(122, 143);
            this.btViewBarcode.Name = "btViewBarcode";
            this.btViewBarcode.Size = new System.Drawing.Size(48, 23);
            this.btViewBarcode.TabIndex = 5;
            this.btViewBarcode.Text = "View";
            this.btViewBarcode.UseVisualStyleBackColor = true;
            this.btViewBarcode.Click += new System.EventHandler(this.btViewBarcode_Click);
            // 
            // btViewOCR
            // 
            this.btViewOCR.Enabled = false;
            this.btViewOCR.Location = new System.Drawing.Point(122, 105);
            this.btViewOCR.Name = "btViewOCR";
            this.btViewOCR.Size = new System.Drawing.Size(48, 23);
            this.btViewOCR.TabIndex = 4;
            this.btViewOCR.Text = "View";
            this.btViewOCR.UseVisualStyleBackColor = true;
            this.btViewOCR.Click += new System.EventHandler(this.btViewOCR_Click);
            // 
            // cbMOCR
            // 
            this.cbMOCR.AutoSize = true;
            this.cbMOCR.Location = new System.Drawing.Point(17, 69);
            this.cbMOCR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbMOCR.Name = "cbMOCR";
            this.cbMOCR.Size = new System.Drawing.Size(125, 21);
            this.cbMOCR.TabIndex = 3;
            this.cbMOCR.Text = "MICR with OCR";
            this.cbMOCR.UseVisualStyleBackColor = true;
            // 
            // cbBarcode
            // 
            this.cbBarcode.AutoSize = true;
            this.cbBarcode.Location = new System.Drawing.Point(17, 145);
            this.cbBarcode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbBarcode.Name = "cbBarcode";
            this.cbBarcode.Size = new System.Drawing.Size(83, 21);
            this.cbBarcode.TabIndex = 2;
            this.cbBarcode.Text = "Barcode";
            this.cbBarcode.UseVisualStyleBackColor = true;
            this.cbBarcode.CheckedChanged += new System.EventHandler(this.cbBarcode_CheckedChanged);
            // 
            // cbOCR
            // 
            this.cbOCR.AutoSize = true;
            this.cbOCR.Location = new System.Drawing.Point(17, 107);
            this.cbOCR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbOCR.Name = "cbOCR";
            this.cbOCR.Size = new System.Drawing.Size(60, 21);
            this.cbOCR.TabIndex = 1;
            this.cbOCR.Text = "OCR";
            this.cbOCR.UseVisualStyleBackColor = true;
            this.cbOCR.CheckedChanged += new System.EventHandler(this.cbOCR_CheckedChanged);
            // 
            // cbMICR
            // 
            this.cbMICR.AutoSize = true;
            this.cbMICR.Location = new System.Drawing.Point(17, 31);
            this.cbMICR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbMICR.Name = "cbMICR";
            this.cbMICR.Size = new System.Drawing.Size(63, 21);
            this.cbMICR.TabIndex = 0;
            this.cbMICR.Text = "MICR";
            this.cbMICR.UseVisualStyleBackColor = true;
            // 
            // gbSide
            // 
            this.gbSide.Controls.Add(this.cbSide);
            this.gbSide.Location = new System.Drawing.Point(12, 458);
            this.gbSide.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbSide.Name = "gbSide";
            this.gbSide.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbSide.Size = new System.Drawing.Size(181, 75);
            this.gbSide.TabIndex = 2;
            this.gbSide.TabStop = false;
            this.gbSide.Text = "Side";
            // 
            // cbSide
            // 
            this.cbSide.FormattingEnabled = true;
            this.cbSide.Items.AddRange(new object[] {
            "All",
            "Front",
            "None"});
            this.cbSide.Location = new System.Drawing.Point(23, 30);
            this.cbSide.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbSide.Name = "cbSide";
            this.cbSide.Size = new System.Drawing.Size(136, 24);
            this.cbSide.TabIndex = 0;
            this.cbSide.Text = "All";
            // 
            // gbCoordinate
            // 
            this.gbCoordinate.Controls.Add(this.btSetCoordinate);
            this.gbCoordinate.Controls.Add(this.cbOCRfont);
            this.gbCoordinate.Controls.Add(this.tbHeight);
            this.gbCoordinate.Controls.Add(this.tbWidth);
            this.gbCoordinate.Controls.Add(this.tbY);
            this.gbCoordinate.Controls.Add(this.tbX);
            this.gbCoordinate.Controls.Add(this.lbHeight);
            this.gbCoordinate.Controls.Add(this.lbWidth);
            this.gbCoordinate.Controls.Add(this.lbY);
            this.gbCoordinate.Controls.Add(this.lbX);
            this.gbCoordinate.Enabled = false;
            this.gbCoordinate.Location = new System.Drawing.Point(431, 14);
            this.gbCoordinate.Name = "gbCoordinate";
            this.gbCoordinate.Size = new System.Drawing.Size(262, 173);
            this.gbCoordinate.TabIndex = 3;
            this.gbCoordinate.TabStop = false;
            this.gbCoordinate.Text = "Coordinate";
            // 
            // btSetCoordinate
            // 
            this.btSetCoordinate.Location = new System.Drawing.Point(190, 121);
            this.btSetCoordinate.Name = "btSetCoordinate";
            this.btSetCoordinate.Size = new System.Drawing.Size(48, 23);
            this.btSetCoordinate.TabIndex = 6;
            this.btSetCoordinate.Text = "Set";
            this.btSetCoordinate.UseVisualStyleBackColor = true;
            this.btSetCoordinate.Click += new System.EventHandler(this.btSetCoordinate_Click);
            // 
            // cbOCRfont
            // 
            this.cbOCRfont.FormattingEnabled = true;
            this.cbOCRfont.Location = new System.Drawing.Point(34, 120);
            this.cbOCRfont.Name = "cbOCRfont";
            this.cbOCRfont.Size = new System.Drawing.Size(121, 24);
            this.cbOCRfont.TabIndex = 8;
            // 
            // tbHeight
            // 
            this.tbHeight.Location = new System.Drawing.Point(203, 76);
            this.tbHeight.Name = "tbHeight";
            this.tbHeight.Size = new System.Drawing.Size(39, 22);
            this.tbHeight.TabIndex = 7;
            this.tbHeight.WordWrap = false;
            // 
            // tbWidth
            // 
            this.tbWidth.Location = new System.Drawing.Point(70, 76);
            this.tbWidth.Name = "tbWidth";
            this.tbWidth.Size = new System.Drawing.Size(39, 22);
            this.tbWidth.TabIndex = 6;
            this.tbWidth.WordWrap = false;
            // 
            // tbY
            // 
            this.tbY.Location = new System.Drawing.Point(203, 35);
            this.tbY.Name = "tbY";
            this.tbY.Size = new System.Drawing.Size(39, 22);
            this.tbY.TabIndex = 5;
            this.tbY.WordWrap = false;
            // 
            // tbX
            // 
            this.tbX.Location = new System.Drawing.Point(70, 35);
            this.tbX.Name = "tbX";
            this.tbX.Size = new System.Drawing.Size(39, 22);
            this.tbX.TabIndex = 4;
            this.tbX.WordWrap = false;
            this.tbX.TextChanged += new System.EventHandler(this.tbX_TextChanged);
            // 
            // lbHeight
            // 
            this.lbHeight.AutoSize = true;
            this.lbHeight.Location = new System.Drawing.Point(138, 78);
            this.lbHeight.Name = "lbHeight";
            this.lbHeight.Size = new System.Drawing.Size(57, 17);
            this.lbHeight.TabIndex = 3;
            this.lbHeight.Text = "Height :";
            // 
            // lbWidth
            // 
            this.lbWidth.AutoSize = true;
            this.lbWidth.Location = new System.Drawing.Point(11, 80);
            this.lbWidth.Name = "lbWidth";
            this.lbWidth.Size = new System.Drawing.Size(52, 17);
            this.lbWidth.TabIndex = 2;
            this.lbWidth.Text = "Width :";
            // 
            // lbY
            // 
            this.lbY.AutoSize = true;
            this.lbY.Location = new System.Drawing.Point(170, 37);
            this.lbY.Name = "lbY";
            this.lbY.Size = new System.Drawing.Size(25, 17);
            this.lbY.TabIndex = 1;
            this.lbY.Text = "Y :";
            // 
            // lbX
            // 
            this.lbX.AutoSize = true;
            this.lbX.Location = new System.Drawing.Point(38, 37);
            this.lbX.Name = "lbX";
            this.lbX.Size = new System.Drawing.Size(25, 17);
            this.lbX.TabIndex = 0;
            this.lbX.Text = "X :";
            // 
            // gbEndorse
            // 
            this.gbEndorse.Controls.Add(this.cbFontPrint);
            this.gbEndorse.Controls.Add(this.tbPrintString);
            this.gbEndorse.Enabled = false;
            this.gbEndorse.Location = new System.Drawing.Point(431, 216);
            this.gbEndorse.Name = "gbEndorse";
            this.gbEndorse.Size = new System.Drawing.Size(261, 94);
            this.gbEndorse.TabIndex = 4;
            this.gbEndorse.TabStop = false;
            this.gbEndorse.Text = "Set Print String";
            // 
            // cbFontPrint
            // 
            this.cbFontPrint.FormattingEnabled = true;
            this.cbFontPrint.Items.AddRange(new object[] {
            "No Print",
            "Normal",
            "Bold",
            "15 char Inch"});
            this.cbFontPrint.Location = new System.Drawing.Point(117, 21);
            this.cbFontPrint.Name = "cbFontPrint";
            this.cbFontPrint.Size = new System.Drawing.Size(121, 24);
            this.cbFontPrint.TabIndex = 1;
            this.cbFontPrint.Text = "No Print";
            // 
            // tbPrintString
            // 
            this.tbPrintString.Location = new System.Drawing.Point(21, 62);
            this.tbPrintString.Name = "tbPrintString";
            this.tbPrintString.Size = new System.Drawing.Size(217, 22);
            this.tbPrintString.TabIndex = 0;
            this.tbPrintString.Text = "CTS Electronics S.p.A.";
            // 
            // gbDocProcess
            // 
            this.gbDocProcess.Controls.Add(this.comboBox2);
            this.gbDocProcess.Controls.Add(this.tbNumDoc);
            this.gbDocProcess.Controls.Add(this.rbNum);
            this.gbDocProcess.Controls.Add(this.rbAllDoc);
            this.gbDocProcess.Location = new System.Drawing.Point(234, 216);
            this.gbDocProcess.Name = "gbDocProcess";
            this.gbDocProcess.Size = new System.Drawing.Size(180, 126);
            this.gbDocProcess.TabIndex = 5;
            this.gbDocProcess.TabStop = false;
            this.gbDocProcess.Text = "Doc. Processed";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Sortered",
            "Retained",
            "Ejected"});
            this.comboBox2.Location = new System.Drawing.Point(24, 94);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(131, 24);
            this.comboBox2.TabIndex = 10;
            this.comboBox2.Text = "Sortered";
            // 
            // tbNumDoc
            // 
            this.tbNumDoc.Location = new System.Drawing.Point(116, 58);
            this.tbNumDoc.Name = "tbNumDoc";
            this.tbNumDoc.Size = new System.Drawing.Size(39, 22);
            this.tbNumDoc.TabIndex = 9;
            this.tbNumDoc.Text = "1";
            this.tbNumDoc.WordWrap = false;
            // 
            // rbNum
            // 
            this.rbNum.AutoSize = true;
            this.rbNum.Location = new System.Drawing.Point(25, 59);
            this.rbNum.Name = "rbNum";
            this.rbNum.Size = new System.Drawing.Size(62, 21);
            this.rbNum.TabIndex = 1;
            this.rbNum.TabStop = true;
            this.rbNum.Text = "Num.";
            this.rbNum.UseVisualStyleBackColor = true;
            // 
            // rbAllDoc
            // 
            this.rbAllDoc.AutoSize = true;
            this.rbAllDoc.Location = new System.Drawing.Point(24, 28);
            this.rbAllDoc.Name = "rbAllDoc";
            this.rbAllDoc.Size = new System.Drawing.Size(77, 21);
            this.rbAllDoc.TabIndex = 0;
            this.rbAllDoc.TabStop = true;
            this.rbAllDoc.Text = "All Doc.";
            this.rbAllDoc.UseVisualStyleBackColor = true;
            // 
            // cbWaitTimeout
            // 
            this.cbWaitTimeout.AutoSize = true;
            this.cbWaitTimeout.Location = new System.Drawing.Point(246, 378);
            this.cbWaitTimeout.Name = "cbWaitTimeout";
            this.cbWaitTimeout.Size = new System.Drawing.Size(113, 21);
            this.cbWaitTimeout.TabIndex = 6;
            this.cbWaitTimeout.Text = "Wait Timeout";
            this.cbWaitTimeout.UseVisualStyleBackColor = true;
            // 
            // cbLinear
            // 
            this.cbLinear.AutoSize = true;
            this.cbLinear.Enabled = false;
            this.cbLinear.Location = new System.Drawing.Point(246, 419);
            this.cbLinear.Name = "cbLinear";
            this.cbLinear.Size = new System.Drawing.Size(115, 21);
            this.cbLinear.TabIndex = 7;
            this.cbLinear.Text = "Process Card";
            this.cbLinear.UseVisualStyleBackColor = true;
            this.cbLinear.CheckedChanged += new System.EventHandler(this.cbLinear_CheckedChanged);
            // 
            // cbLowSpeed
            // 
            this.cbLowSpeed.AutoSize = true;
            this.cbLowSpeed.Enabled = false;
            this.cbLowSpeed.Location = new System.Drawing.Point(246, 460);
            this.cbLowSpeed.Name = "cbLowSpeed";
            this.cbLowSpeed.Size = new System.Drawing.Size(100, 21);
            this.cbLowSpeed.TabIndex = 8;
            this.cbLowSpeed.Text = "Low Speed";
            this.cbLowSpeed.UseVisualStyleBackColor = true;
            // 
            // gbDoubleLafing
            // 
            this.gbDoubleLafing.Controls.Add(this.cbWarning);
            this.gbDoubleLafing.Controls.Add(this.cbDisabled);
            this.gbDoubleLafing.Controls.Add(this.gbDocLen);
            this.gbDoubleLafing.Controls.Add(this.gbSensibility);
            this.gbDoubleLafing.Enabled = false;
            this.gbDoubleLafing.Location = new System.Drawing.Point(429, 333);
            this.gbDoubleLafing.Name = "gbDoubleLafing";
            this.gbDoubleLafing.Size = new System.Drawing.Size(263, 132);
            this.gbDoubleLafing.TabIndex = 9;
            this.gbDoubleLafing.TabStop = false;
            this.gbDoubleLafing.Text = "Double Leafing";
            // 
            // cbWarning
            // 
            this.cbWarning.AutoSize = true;
            this.cbWarning.Location = new System.Drawing.Point(153, 100);
            this.cbWarning.Name = "cbWarning";
            this.cbWarning.Size = new System.Drawing.Size(83, 21);
            this.cbWarning.TabIndex = 2;
            this.cbWarning.Text = "Warning";
            this.cbWarning.UseVisualStyleBackColor = true;
            // 
            // cbDisabled
            // 
            this.cbDisabled.AutoSize = true;
            this.cbDisabled.Location = new System.Drawing.Point(36, 100);
            this.cbDisabled.Name = "cbDisabled";
            this.cbDisabled.Size = new System.Drawing.Size(85, 21);
            this.cbDisabled.TabIndex = 1;
            this.cbDisabled.Text = "Disabled";
            this.cbDisabled.UseVisualStyleBackColor = true;
            // 
            // gbDocLen
            // 
            this.gbDocLen.Controls.Add(this.tbMax);
            this.gbDocLen.Controls.Add(this.tbMin);
            this.gbDocLen.Location = new System.Drawing.Point(100, 30);
            this.gbDocLen.Name = "gbDocLen";
            this.gbDocLen.Size = new System.Drawing.Size(163, 58);
            this.gbDocLen.TabIndex = 0;
            this.gbDocLen.TabStop = false;
            this.gbDocLen.Text = "Min Max Doc. Len.";
            // 
            // tbMax
            // 
            this.tbMax.Location = new System.Drawing.Point(97, 30);
            this.tbMax.Name = "tbMax";
            this.tbMax.Size = new System.Drawing.Size(39, 22);
            this.tbMax.TabIndex = 11;
            this.tbMax.Text = "215";
            this.tbMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbMax.WordWrap = false;
            // 
            // tbMin
            // 
            this.tbMin.Location = new System.Drawing.Point(32, 30);
            this.tbMin.Name = "tbMin";
            this.tbMin.Size = new System.Drawing.Size(39, 22);
            this.tbMin.TabIndex = 10;
            this.tbMin.Text = "150";
            this.tbMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbMin.WordWrap = false;
            // 
            // gbSensibility
            // 
            this.gbSensibility.Controls.Add(this.tbSensibility);
            this.gbSensibility.Location = new System.Drawing.Point(0, 30);
            this.gbSensibility.Name = "gbSensibility";
            this.gbSensibility.Size = new System.Drawing.Size(102, 58);
            this.gbSensibility.TabIndex = 0;
            this.gbSensibility.TabStop = false;
            this.gbSensibility.Text = "Sensibility %";
            // 
            // tbSensibility
            // 
            this.tbSensibility.Location = new System.Drawing.Point(31, 30);
            this.tbSensibility.Name = "tbSensibility";
            this.tbSensibility.Size = new System.Drawing.Size(39, 22);
            this.tbSensibility.TabIndex = 9;
            this.tbSensibility.Text = "50";
            this.tbSensibility.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbSensibility.WordWrap = false;
            // 
            // btOk
            // 
            this.btOk.Location = new System.Drawing.Point(448, 507);
            this.btOk.Name = "btOk";
            this.btOk.Size = new System.Drawing.Size(75, 33);
            this.btOk.TabIndex = 10;
            this.btOk.Text = "OK";
            this.btOk.UseVisualStyleBackColor = true;
            this.btOk.Click += new System.EventHandler(this.btOk_Click);
            // 
            // btCancel
            // 
            this.btCancel.Location = new System.Drawing.Point(572, 507);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(75, 33);
            this.btCancel.TabIndex = 11;
            this.btCancel.Text = "Cancel";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // FormOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 552);
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.btOk);
            this.Controls.Add(this.gbDoubleLafing);
            this.Controls.Add(this.cbLowSpeed);
            this.Controls.Add(this.cbLinear);
            this.Controls.Add(this.cbWaitTimeout);
            this.Controls.Add(this.gbDocProcess);
            this.Controls.Add(this.gbEndorse);
            this.Controls.Add(this.gbCoordinate);
            this.Controls.Add(this.gbSide);
            this.Controls.Add(this.gbCodelines);
            this.Controls.Add(this.gbScanMode);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Scan Options";
            this.Load += new System.EventHandler(this.FormOptions_Load);
            this.gbScanMode.ResumeLayout(false);
            this.gbScanMode.PerformLayout();
            this.gbCodelines.ResumeLayout(false);
            this.gbCodelines.PerformLayout();
            this.gbSide.ResumeLayout(false);
            this.gbCoordinate.ResumeLayout(false);
            this.gbCoordinate.PerformLayout();
            this.gbEndorse.ResumeLayout(false);
            this.gbEndorse.PerformLayout();
            this.gbDocProcess.ResumeLayout(false);
            this.gbDocProcess.PerformLayout();
            this.gbDoubleLafing.ResumeLayout(false);
            this.gbDoubleLafing.PerformLayout();
            this.gbDocLen.ResumeLayout(false);
            this.gbDocLen.PerformLayout();
            this.gbSensibility.ResumeLayout(false);
            this.gbSensibility.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbScanMode;
        private System.Windows.Forms.RadioButton rb16gray200;
        private System.Windows.Forms.RadioButton rb16gray100;
        private System.Windows.Forms.RadioButton rbBW200;
        private System.Windows.Forms.RadioButton rb256gray300;
        private System.Windows.Forms.RadioButton rb256gray200;
        private System.Windows.Forms.RadioButton rb256gray100;
        private System.Windows.Forms.RadioButton rb16gray300;
        private System.Windows.Forms.GroupBox gbCodelines;
        private System.Windows.Forms.CheckBox cbMICR;
        private System.Windows.Forms.CheckBox cbBarcode;
        private System.Windows.Forms.CheckBox cbOCR;
        private System.Windows.Forms.GroupBox gbSide;
        private System.Windows.Forms.ComboBox cbSide;
        private System.Windows.Forms.RadioButton rbColor300;
        private System.Windows.Forms.RadioButton rbColor200;
        private System.Windows.Forms.RadioButton rbColor100;
        private System.Windows.Forms.CheckBox cbMOCR;
        private System.Windows.Forms.GroupBox gbCoordinate;
        private System.Windows.Forms.Label lbX;
        private System.Windows.Forms.TextBox tbX;
        private System.Windows.Forms.Label lbHeight;
        private System.Windows.Forms.Label lbWidth;
        private System.Windows.Forms.Label lbY;
        private System.Windows.Forms.TextBox tbY;
        private System.Windows.Forms.ComboBox cbOCRfont;
        private System.Windows.Forms.TextBox tbHeight;
        private System.Windows.Forms.TextBox tbWidth;
        private System.Windows.Forms.GroupBox gbEndorse;
        private System.Windows.Forms.ComboBox cbFontPrint;
        private System.Windows.Forms.TextBox tbPrintString;
        private System.Windows.Forms.GroupBox gbDocProcess;
        private System.Windows.Forms.TextBox tbNumDoc;
        private System.Windows.Forms.RadioButton rbNum;
        private System.Windows.Forms.RadioButton rbAllDoc;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.CheckBox cbWaitTimeout;
        private System.Windows.Forms.RadioButton rbUV300;
        private System.Windows.Forms.RadioButton rbUV200;
        private System.Windows.Forms.RadioButton rbUV100;
        private System.Windows.Forms.CheckBox cbLinear;
        private System.Windows.Forms.CheckBox cbLowSpeed;
        private System.Windows.Forms.GroupBox gbDoubleLafing;
        private System.Windows.Forms.GroupBox gbSensibility;
        private System.Windows.Forms.GroupBox gbDocLen;
        private System.Windows.Forms.TextBox tbMax;
        private System.Windows.Forms.TextBox tbMin;
        private System.Windows.Forms.TextBox tbSensibility;
        private System.Windows.Forms.Button btViewBarcode;
        private System.Windows.Forms.Button btViewOCR;
        private System.Windows.Forms.CheckBox cbWarning;
        private System.Windows.Forms.CheckBox cbDisabled;
        private System.Windows.Forms.Button btOk;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btSetCoordinate;
    }
}