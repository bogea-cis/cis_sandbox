﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Ls_Test
{
    public partial class FormHistory : Form
    {
        public FormHistory()
        {
            InitializeComponent();
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Int16 Last_x1 = 26, Last_x2 = 340;
        Int16 Last_y = 46;
        Int16 tabIndex = 2;
        const Int16 STEP_LABEL = 34;

        private void AddLabel(string Description, string Value)
        {
            Last_y += STEP_LABEL;

            // 
            // new Label
            // 
            Label newLabelTiTle = new Label();
            newLabelTiTle.AutoSize = true;
            newLabelTiTle.Location = new System.Drawing.Point(20, Last_y);
            newLabelTiTle.Name = "newLabelTiTle" + tabIndex.ToString();
            newLabelTiTle.Size = new System.Drawing.Size(72, 17);
            newLabelTiTle.TabIndex = tabIndex;
            newLabelTiTle.Text = Description; // "Description";

            // 
            // new Label
            // 
            Label newLabelValue = new Label();
            newLabelValue.AutoSize = true;
            newLabelValue.Location = new System.Drawing.Point(330, Last_y);
            newLabelValue.Name = "newLabelValue" + tabIndex.ToString();
            newLabelValue.Size = new System.Drawing.Size(72, 17);
            newLabelValue.TabIndex = tabIndex;
            newLabelValue.Text = Value; // "00000000";

            gbHistory.Controls.Add(newLabelTiTle);
            gbHistory.Controls.Add(newLabelValue);

            // Resize the dialog ...
            System.Drawing.Size currSize = this.Size;
            currSize.Height += STEP_LABEL;
            this.Size = currSize;

            // ... the GroupBox and ...
            currSize = gbHistory.Size;
            currSize.Height += STEP_LABEL;
            gbHistory.Size = currSize;

            // ... move the button
            System.Drawing.Point currLocation = btExit.Location;
            currLocation.Y += STEP_LABEL;
            btExit.Location = currLocation;
        }

        const Int16 HISTORY_TIME_UNIT = 300;

        private void FormHistory_Load(object sender, EventArgs e)
        {
            lbDocProcessed.Text = Form1.UnitHistory.doc_sorted.ToString();

            if( Form1.UnitHistory.doc_retained != 0 )
                AddLabel("Nr. Documents Retained", Form1.UnitHistory.doc_retained.ToString());

            if (Form1.UnitHistory.doc_retained_micr != 0)
                AddLabel("Nr. Documents Retained after read MICR", Form1.UnitHistory.doc_retained_micr.ToString());

            if (Form1.UnitHistory.doc_retained_scan != 0)
                AddLabel("Nr. Documents Retained after film", Form1.UnitHistory.doc_retained_scan.ToString());

            if (Form1.UnitHistory.doc_stamped != 0)
                AddLabel("Nr. Documents Stamped", Form1.UnitHistory.doc_stamped.ToString());

            if (Form1.UnitHistory.doc_ink_jet != 0)
                AddLabel("Nr. Documents Printed", Form1.UnitHistory.doc_ink_jet.ToString());

            if (Form1.UnitHistory.nr_drops_printed != 0)
                AddLabel("Nr. of ink drops Printed", Form1.UnitHistory.nr_drops_printed.ToString());

            if (Form1.UnitHistory.jams_in_feeder != 0)
                AddLabel("Nr. of jam in feedering", Form1.UnitHistory.jams_in_feeder.ToString());

            if (Form1.UnitHistory.jams_in_micr != 0)
                AddLabel("Nr. of jam in MICR sensor", Form1.UnitHistory.jams_in_micr.ToString());

            if (Form1.UnitHistory.jams_stamp != 0)
                AddLabel("Nr. of jam in stamp sensor", Form1.UnitHistory.jams_stamp.ToString());

            if (Form1.UnitHistory.jams_scanner != 0)
                AddLabel("Nr. of jam in scanners sensor", Form1.UnitHistory.jams_scanner.ToString());

            if (Form1.UnitHistory.jams_on_exit != 0)
                AddLabel("Nr. of jam in pocket sensor", Form1.UnitHistory.jams_on_exit.ToString());

            if (Form1.UnitHistory.doc_cmc7_err != 0)
                AddLabel("Nr. of CMC7 codeline read with error", Form1.UnitHistory.doc_cmc7_err.ToString());

            if (Form1.UnitHistory.doc_e13b_err != 0)
                AddLabel("Nr. of E13B codeline read with error", Form1.UnitHistory.doc_e13b_err.ToString());

            if (Form1.UnitHistory.num_turn_on != 0)
                AddLabel("Nr. of power ON", Form1.UnitHistory.num_turn_on.ToString());

            if (Form1.UnitHistory.time_peripheral_on != 0)
            {
                UInt64 totalTime;
                UInt32 totHours, totMinutes, totSeconds;
                string stTime;

                if (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS515"))
                    totalTime = (UInt64)(Form1.UnitHistory.time_peripheral_on);
                else
                    totalTime = (UInt64)(Form1.UnitHistory.time_peripheral_on * HISTORY_TIME_UNIT);
                totHours = (UInt32)(totalTime / 3600);
                totMinutes = (UInt32)(totalTime % 3600);
                totSeconds = (UInt32)(totalTime % 60);
                totMinutes /= 60;
                stTime = totHours.ToString() + ":" + totMinutes.ToString() + ":" + totSeconds.ToString();
                AddLabel("Total time of work (hh:mm:ss)", stTime);
            }
        }
    }
}
