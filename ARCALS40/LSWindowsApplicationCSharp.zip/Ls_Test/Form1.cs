﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;


namespace Ls_Test
{
    public partial class Form1 : Form
    {
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory")]
        static extern void CopyMemory(IntPtr Destination, IntPtr Source, uint Length);

 

        public struct ParDocHandle
        {
            public bool ScanCard;
            public short PrintHigh;
            public short FrontStamp;
            public CtsLs.CodeLineType CodelineMICR;
            public CtsLs.CodeLineType CodelineOCR;
            public short Unit_measure;
            public float Codeline_Sw_x;				//per ocr
            public float Codeline_Sw_y;				//per ocr
            public float Codeline_Sw_w;				//per ocr
            public float Codeline_Sw_h;				//per ocr
            public CtsLs.PrintFont PrintValidate;
            public bool PrintBold;
            public string Endorse_str;
            public CtsLs.CodeLineType BarcodeType;
            public float Barcode_Sw_x;				//per Barcode
            public float Barcode_Sw_y;				//per Barcode
            public float Barcode_Sw_w;				//per Barcode
            public float Barcode_Sw_h;				//per Barcode
            // short Sorter;
            public short ScanMode;
            public char Side;
            // byte BadgeTrack;
            public short SaveImage;
            public short FileFormat;
            public short Qual;
            public short ClearAlignImage;
            public short NumDoc;
            public char BeepOnError;
            public bool WaitTimeout;
            // short Sorter_PrintValidate;
            // bool Sorter_PrintBold;
            // string Sorter_Endorse_str[200];
            // char Sorter_Side;
            // short Sorter_Stamp;
            public byte TypeOfDecod;				// Decodifiche selezionate
            public Int32 DL_Type;
            public short DL_Value;
            public Int32 DL_MinDoc;
            public Int32 DL_MaxDoc;
            //float Pdf417_Sw_x;
            //float Pdf417_Sw_y;
            //float Pdf417_Sw_w;
            //float Pdf417_Sw_h;
            public short StampPosition;
            //	        char	Digital_str[200];
            //short Digital_SidePrint;
            //	        char	Digital_FontName[120];
            //short Digital_FontSize;
            //short Digital_Unit;
            //float Digital_x;
            //float Digital_y;
            //short Digital_Tone;
            //bool Digital_Bold;
            //bool Digital_Italic;
            //bool Digital_Undeline;
            public short LowSpeed;

            public short PercentPWM_UV;
            public bool Contrast_UV;
            public short Threshold_UV;

            public bool	PrintHighDefinition;		// Printer HD
            //bool	PrintLine1;
            //bool	PrintLine2;
            //bool	PrintLine3;
            //bool	PrintLine4;
            public bool	PrintLogo;
            //char	PrintFontLine1;
            //char	PrintStringLine1[128];
            //char	PrintFontLine2;
            //char	PrintStringLine2[128];
            //char	PrintFontLine3;
            //char	PrintStringLine3[128];
            //char	PrintFontLine4;
            //char	PrintStringLine4[128];

            //bool	Setup_DropIn;
            //char	IpAddress[20];
            //ushort  Net_Port;
            //char	IpBoxNodeName[40];
            //bool	fConnectByNodeName;

            public short LightIntensity;

            public bool fTestPrinter;
        };

        const string TITLE_POPUP = "LS TEST UNIT";
        const string TITLE_ERROR = "LS TEST UNIT - Error";

        const string SAVE_DIRECTORY_IMAGE = "Images";
        const string NAME_IMAGE = "Image_";

        const byte MASK_SCANNER_UV = 0x04;

        const byte DECODE_MICR = 0x01;
        const byte DECODE_OCR = 0x02;
        const byte DECODE_BARCODE = 0x04;
        const byte DECODE_PDF417 = 0x08;

        bool fProcessDoc;
        string PathAppl;
        public static ParDocHandle stParAppl = new ParDocHandle();
        IntPtr Save_FrontImage;
        IntPtr Save_RearImage;

        public static byte[] UnitCfg = new byte[4];
        public static IntPtr LsModel = Marshal.AllocHGlobal(20);


        public Form1()
        {
            InitializeComponent();

            PathAppl = Directory.GetCurrentDirectory();

            // Set default configuration
            stParAppl.PrintValidate = CtsLs.PrintFont.PRINT_NO_STRING;
            stParAppl.Endorse_str = "CTS Electronics S.p.A.";
            stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_200;
            stParAppl.Side = (char)CtsLs.Side.SIDE_ALL_IMAGE;
            stParAppl.ScanCard = false;
            stParAppl.SaveImage = (short)CtsLs.ImageSave.IMAGE_SAVE_HANDLE;
            stParAppl.Qual = 128;
            stParAppl.NumDoc = 0;
            stParAppl.DL_Type = (Int32)CtsLs.DoubleLeafing.DOUBLE_LEAFING_ERROR;
            stParAppl.DL_Value = 50;
            stParAppl.DL_MinDoc = 150;
            stParAppl.DL_MaxDoc = 215;
            stParAppl.ClearAlignImage = (short)CtsLs.ClearBlack.CLEAR_BLACK_YES;
            stParAppl.CodelineMICR = CtsLs.CodeLineType.READ_CODELINE_HW_MICR;
            stParAppl.CodelineOCR = CtsLs.CodeLineType.NO_READ_CODELINE;
            stParAppl.BarcodeType = CtsLs.CodeLineType.NO_READ_CODELINE;
            stParAppl.PercentPWM_UV = 100;
            stParAppl.WaitTimeout = true;
            stParAppl.LowSpeed = (short)CtsLs.LsSpeed.SPEED_DEFAULT;
            //stParAppl = (short)CtsLs;
        }

        // *******************************************************************
        // *    CheckReply()
        // *******************************************************************
        bool CheckReply(int ChReply, string Requester)
        {
            bool RcError = false;
            string szTextMsg;

            szTextMsg = Requester + "\n\n";

            switch (ChReply)
            {
                case CtsLs.LsReply.LS_OKAY:
                    //	szTextMsg += "LS_OKAY";
                    break;

                // --- ERRORS ---------------------------------------------------------
                case CtsLs.LsReply.LS_SYSTEM_ERROR:
                    szTextMsg += "The module was unable to execute command due to a system error.\n\nPossible reasons: memory allocation error.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_USB_ERROR:
                    szTextMsg += "The module was unable to execute command due to a USB hardware error.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_PERIPHERAL_NOT_FOUND:
                    szTextMsg += "Peripheral not found.\n\nPossible reasons: peripheral is switched off or not connected to the USB bus.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_HARDWARE_ERROR:
                    szTextMsg += "Peripheral hardware error.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_PERIPHERAL_OFF_ON:
                    szTextMsg += "Peripheral has been switched off and on again.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_PAPER_JAM:
                    szTextMsg += "Document jammed.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_TARGET_BUSY:
                    szTextMsg += "Peripheral busy";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_INVALID_COMMAND:
                    //			DebugBreak();
                    szTextMsg += "Invalid command.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_COMMAND_IN_EXECUTION_YET:
                    szTextMsg += "A command is already in execution\nCurrent command aborted";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_JPEG_ERROR:
                    szTextMsg += "JPEG image not created !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_COMMAND_SEQUENCE_ERROR:
                    szTextMsg += "There's another command in execution\nImpossible execute the command";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_NO_LIBRARY_LOAD:
                    szTextMsg += "Support library not present";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_BMP_ERROR:
                    szTextMsg += "DIB image not created !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_TIFF_ERROR:
                    szTextMsg += "TIFF image not created !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_IMAGE_NOT_PRESENT:
                    szTextMsg += "Image not present.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_READ_TIMEOUT_EXPIRED:
                    szTextMsg += "The peripheral was disconnected";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_DOUBLE_LEAFING_ERROR:
                    szTextMsg += "Double Leafing occurred.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_INVALID_FORMAT:
                    szTextMsg += "Print format not supported.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_SHORT_PAPER:
                    szTextMsg += "Paper Short !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_INVALID_DOC_LENGTH:
                    szTextMsg += "Invalid Length !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_JAM_AT_MICR_PHOTO:
                    szTextMsg += "Jam at MICR photo.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_JAM_DOC_TOO_LONG:
                    szTextMsg += "Double Feeding occurred or document too long !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_JAM_AT_SCANNER_PHOTO:
                    szTextMsg += "Jam at Scanner photo.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_INVALID_PWM_VALUE:
                    szTextMsg += "Invalid Ultra Violet PWM value.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_IPBOX_ADDRESS_NOT_FOUNDED:
                    szTextMsg += "LSConnect Box IP address not founded !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;

                // --- ERRORS CALIBRATION ---------------------------------------------
                case CtsLs.LsReply.LS_CALIBRATION_FAILED:
                    szTextMsg += "Calibration FAILED !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                //case CtsLs.LsReply.LS_MICR_TRIMMER_VALUE_NEGATIVE:
                //    szTextMsg += "The Trimmer value is negative !!!";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_OFFSET_FRONT:
                //    szTextMsg += "ERROR_OFFSET_FRONT";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_OFFSET_REAR:
                //    szTextMsg += "ERROR_OFFSET_REAR";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_SCANNER_PWM:
                //    szTextMsg += "ERROR_SCANNER_PWM";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_GAIN_FRONT:
                //    szTextMsg += "ERROR_GAIN_FRONT";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_GAIN_REAR:
                //    szTextMsg += "ERROR_GAIN_REAR";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_COEFF_FRONT:
                //    szTextMsg += "ERROR_COEFF_FRONT";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_COEFF_REAR:
                //    szTextMsg += "ERROR_COEFF_REAR";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;
                //case CtsLs.LsReply.LS_ERROR_SCANNER_GENERICO:
                //    szTextMsg += "ERROR_SCANNER_GENERICO";
                //    MessageBox.Show(szTextMsg, TITLE_ERROR);
                //    RcError = true;
                //    break;

                // --- WARNINGS -------------------------------------------------------
                case CtsLs.LsReply.LS_FEEDER_EMPTY:
                    szTextMsg += "CtsLs.LsReply.LS_FEEDER_EMPTY";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_DATA_TRUNCATED:
                    szTextMsg += "Codeline truncated !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_ALREADY_OPEN:
                    szTextMsg += "Peripheral already connected !\n Do reset command before continue test.";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_COMMAND_NOT_SUPPORTED:
                    szTextMsg += "CtsLs.LsReply.LS_COMMAND_NOT_SUPPORTED";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_TRY_TO_RESET:
                    szTextMsg += "Open failed retry";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_OPEN_NOT_DONE:
                    szTextMsg += "Open failed retry";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_PERIPHERAL_BUSY:
                    szTextMsg += "Peripheral busy, command NOT terminate !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
                case CtsLs.LsReply.LS_DOUBLE_LEAFING_WARNING:
                    szTextMsg += "Warning Double Leafing occurs !";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = false;
                    break;
                case CtsLs.LsReply.LS_SORTER1_FULL:
                    szTextMsg += "Sorter FULL";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = false;
                    break;
                case CtsLs.LsReply.LS_NO_OTHER_DOCUMENT:
                    szTextMsg += "No other documents or Sorter Full";
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;

                default:
                    szTextMsg += "UNKNOWN REPLY CODE NUMBER " + ChReply.ToString();
                    MessageBox.Show(szTextMsg, TITLE_ERROR);
                    RcError = true;
                    break;
            }

            return RcError;
        } // end CheckReply

        private int TryConnect(ref short hConnect)
        {
            int Reply;

            Reply = CtsLs.LSConnect(0, 0, (short)CtsLs.LsUnitType.LS_40_USB, ref hConnect);
            if (Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_TRY_TO_RESET )
            {
                Reply = CtsLs.LSConnect(0, 0, (short)CtsLs.LsUnitType.LS_100_USB, ref hConnect);
                if (Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_TRY_TO_RESET )
                {
                    Reply = CtsLs.LSConnect(0, 0, (short)CtsLs.LsUnitType.LS_150_USB, ref hConnect);
                    if (Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_TRY_TO_RESET )
                    {
                        Reply = CtsLs.LSConnect(0, 0, (short)CtsLs.LsUnitType.LS_515_USB, ref hConnect);
                    }
                }
            }

            if (Reply == CtsLs.LsReply.LS_OKAY || Reply == CtsLs.LsReply.LS_OKAY || Reply == CtsLs.LsReply.LS_TRY_TO_RESET)
                Reply = CtsLs.LsReply.LS_OKAY;

            return Reply;
        }

        private void btIdentify_Click(object sender, EventArgs e)
        {
            int Reply;
            short hConnect;

            byte[] UnitCfg = new byte[4];
            IntPtr strLsModel = Marshal.AllocHGlobal(20);
            IntPtr strFwVersion = Marshal.AllocHGlobal(20);
            IntPtr Date_Fw = Marshal.AllocHGlobal(20);
            IntPtr strUnitID = Marshal.AllocHGlobal(20);
            IntPtr strInkJetVersion = Marshal.AllocHGlobal(20);
            IntPtr DecoderExpVersion = Marshal.AllocHGlobal(20);


            hConnect = 0;

            Reply = TryConnect(ref hConnect);
            if (Reply == CtsLs.LsReply.LS_OKAY)
            {
                String strIdentify;
                string blankOpt = "      ";

                Reply = CtsLs.LSUnitIdentify(hConnect, 0,
                                             UnitCfg,
                                             strLsModel,
                                             strFwVersion,
                                             Date_Fw,
                                             strUnitID,
                                             IntPtr.Zero, // BoardVersion
                                             DecoderExpVersion,
                                             strInkJetVersion,
                                             IntPtr.Zero, //FeederVersion,
                                             IntPtr.Zero, //SorterVersion,
                                             IntPtr.Zero, //Motorversion,
                                             IntPtr.Zero, //Reserved1,
                                             IntPtr.Zero);//Reserved2

                if (Reply == CtsLs.LsReply.LS_OKAY)
                {
                    strIdentify = "Model : " + Marshal.PtrToStringAnsi(strLsModel) + "\n" +
                                  "FW version : " + Marshal.PtrToStringAnsi(strFwVersion) + "\n" +
                                  "FW date : " + Marshal.PtrToStringAnsi(Date_Fw) + "\n\n" +
                                  "Serial #: " + Marshal.PtrToStringAnsi(strUnitID) + "\n\n" +
                                  "Options :\n";

                    if (Marshal.PtrToStringAnsi(strLsModel).Contains("LS40") == true)
                    {
                        if ((UnitCfg[0] & 0x01) == 0x01)
                            strIdentify += blankOpt + "MICR reader\n";
                        if ((UnitCfg[0] & 0x02) == 0x02)
                            strIdentify += blankOpt + "Card Processing\n";
                        if ((UnitCfg[0] & 0x08) == 0x08)
                            strIdentify += blankOpt + "Endorsement Ink-jet printer\n";
                        if ((UnitCfg[0] & 0x10) == 0x10)
                            strIdentify += blankOpt + "USB Powered\n";
                        if ((UnitCfg[0] & 0x20) == 0x20)
                            strIdentify += blankOpt + "Voiding front stamp\n";

                        if ((UnitCfg[1] & 0x01) == 0x01)
                            strIdentify += blankOpt + "Scanner FRONT\n";
                        if ((UnitCfg[1] & 0x02) == 0x02)
                            strIdentify += blankOpt + "Scanner REAR\n";
                        if ((UnitCfg[1] & 0x04) == 0x04)
                            strIdentify += blankOpt + "Badge reader with tracks 1/2\n";
                        if ((UnitCfg[1] & 0x08) == 0x08)
                            strIdentify += blankOpt + "Badge reader with tracks 2/3\n";
                        if ((UnitCfg[1] & 0x10) == 0x10)
                            strIdentify += blankOpt + "Badge reader with tracks 1/2/3\n";
                    }
                    else if (Marshal.PtrToStringAnsi(strLsModel).Contains("LS100") == true)
                    {
                        if ((UnitCfg[1] & 0x01) == 0x01)
                            strIdentify += blankOpt + "MICR reader\n";
                        if ((UnitCfg[1] & 0x02) == 0x02)
                            strIdentify += blankOpt + "OCR reader\n";
                        if ((UnitCfg[1] & 0x08) == 0x08)
                            strIdentify += blankOpt + "Endorsement Ink-jet printer\n";
                        if ((UnitCfg[1] & 0x10) == 0x10)
                            strIdentify += blankOpt + "Feeder \n";
                        if ((UnitCfg[1] & 0x20) == 0x20)
                            strIdentify += blankOpt + "Voiding front stamp\n";

                        if ((UnitCfg[2] & 0x01) == 0x01)
                            strIdentify += blankOpt + "Scanner FRONT\n";
                        if ((UnitCfg[2] & 0x02) == 0x02)
                            strIdentify += blankOpt + "Scanner REAR\n";
                        if ((UnitCfg[2] & 0x04) == 0x04)
                        {
                            if ((UnitCfg[2] & 0x10) == 0x10)
                                strIdentify += blankOpt + "Badge reader with tracks 1/2/3\n";
                            else
                            {
                                if ((UnitCfg[2] & 0x08) == 0x08)
                                    strIdentify += blankOpt + "Badge reader with tracks 1/2\n";
                                else
                                    strIdentify += blankOpt + "Badge reader with tracks 2/3\n";
                            }
                        }
                    }
                    else if (Marshal.PtrToStringAnsi(strLsModel).Contains("LS150") == true)
                    {
                        if ((UnitCfg[0] & 0x01) == 0x01)
                            strIdentify += blankOpt + "MICR reader\n";
                        if ((UnitCfg[0] & 0x02) == 0x02)
                            strIdentify += blankOpt + "Unit set in Normal Speed\n";
                        else
                            strIdentify += blankOpt + "Unit set in High Speed\n";
                        if ((UnitCfg[0] & 0x04) == 0x04)
                            strIdentify += blankOpt + "Feeder Motorized\n";
                        if ((UnitCfg[0] & 0x08) == 0x08)
                        {
                            if ((UnitCfg[2] & 0x08) == 0x08)
                                strIdentify += blankOpt + "High Definition Ink-jet printer\n";
                            else
                                strIdentify += blankOpt + "Endorsement Ink-jet printer\n";
                        }
                        if ((UnitCfg[0] & 0x10) == 0x10)
                            strIdentify += blankOpt + "Feeder with Electromagnet 50 Doc.\n";
                        if ((UnitCfg[0] & 0x20) == 0x20)
                            strIdentify += blankOpt + "Voiding front stamp\n";

                        if ((UnitCfg[1] & 0x04) == 0x04)
                            strIdentify += blankOpt + "Scanner FRONT with Ultra Violet\n";
                        else if ((UnitCfg[1] & 0x01) == 0x01)
                            strIdentify += blankOpt + "Scanner FRONT\n";
                        if ((UnitCfg[1] & 0x02) == 0x02)
                            strIdentify += blankOpt + "Scanner REAR\n";
                        if ((UnitCfg[1] & 0x20) == 0x20)
                            strIdentify += blankOpt + "COLOR version\n";
                        if ((UnitCfg[1] & 0x08) == 0x08)
                        {
                            if ((UnitCfg[1] & 0x10) == 0x10)
                                strIdentify += blankOpt + "Badge reader with tracks 1/2/3\n";
                            else
                                strIdentify += blankOpt + "Badge reader with tracks 2/3\n";
                        }
                        else if ((UnitCfg[1] & 0x10) == 0x10)
                            strIdentify += blankOpt + "Badge reader with tracks 1/2\n";
                    }
                    else if (Marshal.PtrToStringAnsi(strLsModel).Contains("LS515") == true)
                    {
                        if ((UnitCfg[1] & 0x01) == 0x01)
                            strIdentify += blankOpt + "CMC7 reader\n";
                        if ((UnitCfg[1] & 0x01) == 0x02)
                            strIdentify += blankOpt + "E13B reader\n";
                        if ((UnitCfg[1] & 0x08) == 0x08)
                            strIdentify += blankOpt + "Endorsement Ink-jet printer\n";
                        if ((UnitCfg[1] & 0x20) == 0x20)
                            strIdentify += blankOpt + "Voiding front stamp\n";

                        if ((UnitCfg[2] & 0x01) == 0x01)
                        {
                            if ((UnitCfg[2] & 0x0c) == 0x04)
                                strIdentify += blankOpt + "Scanner FRONT with Ultra Violet\n";
                            else
                                strIdentify += blankOpt + "Scanner FRONT\n";
                        }
                        if ((UnitCfg[2] & 0x02) == 0x02)
                            strIdentify += blankOpt + "Scanner REAR\n";
                        if ((UnitCfg[1] & 0x10) == 0x10)
                            strIdentify += blankOpt + "Badge reader\n";
                        if ((UnitCfg[1] & 0x20) == 0x20)
                            strIdentify += blankOpt + "Double Leafing sensor\n";
                    }

                    MessageBox.Show(strIdentify, TITLE_POPUP);
                }

                Reply = CtsLs.LSDisconnect(hConnect, 0);
            }
            else
                CheckReply(Reply, "LSConnect");
        }

        private void btStatus_Click(object sender, EventArgs e)
        {
            int Reply;
            short hConnect;
            CtsLs.UNITSTATUS UnitStatus;

            UnitStatus = new CtsLs.UNITSTATUS();
            UnitStatus.Size = Marshal.SizeOf(UnitStatus);


            hConnect = 0;

            Reply = TryConnect(ref hConnect);
            if (Reply == CtsLs.LsReply.LS_OKAY)
            {
                String strIdentify;

                Reply = CtsLs.LSUnitStatus(hConnect, 0, ref UnitStatus);

//                if (Reply == CtsLs.LsReply.LS_OKAY)
                {
                    switch( UnitStatus.UnitStatus )
                    {
                        case 0:
                            strIdentify = "Periferal OK !\n";
                            break;
                        case 2:
                            strIdentify = "Peripheral busy\n";
                            break;
                        case 3:
                            strIdentify = "Paper Jam\n";
                            break;
                        case 4:
                            strIdentify = "Hardware error\n";
                             break;
                       case 5:
                            strIdentify = "Illegal request\n";
                            break;
                        case 6:
                            strIdentify = "Feeder Empty\n";
                            break;
                        case 7:
                            strIdentify = "Error Double Leafing\n";
                            break;
                        case 9:
                            strIdentify = "Illegal Command\n";
                            break;
                        case 11:
                            strIdentify = "Aborted command\n";
                            break;
                        case 16:
                            strIdentify = "Calibration Aborted\n";
                            break;
                        case 64:
                            strIdentify = "Jam at MICR sensor\n";
                            break;
                        case 65:
                            strIdentify = "Jam or Doc to long\n";
                            break;
                        case 66:
                            strIdentify = "Jam between Scanners\n";
                            break;
                        default:
                            strIdentify = "Error " + UnitStatus.UnitStatus.ToString() + " not contempled !\n";
                            break;
                    }

                    strIdentify += "\n";

                    if( UnitStatus.Photo_Feeder )
                        strIdentify += "Document present in the feeder" + "\n";
                    else
                        strIdentify += "Feeder Empty" + "\n";

                    if( UnitStatus.Photo_Sorter )
                        strIdentify += "Document present in the sorter" + "\n";

                    if( UnitStatus.Photo_MICR )
                        strIdentify += "Document present at the MICR sensor" + "\n";

                    if( UnitStatus.Photo_Path_Ls100 )
                        strIdentify += "Document in the path near the scanner" + "\n";

                    if( UnitStatus.Photo_Card )
                        strIdentify += "Document present at the Card sensor" + "\n";

                    if( UnitStatus.Photo_Stamp )
                        strIdentify += "Document present at the stamp sensor" + "\n";

                    if( UnitStatus.Photo_Scanners )
                        strIdentify += "Photo scanner covered" + "\n";

                    if( UnitStatus.Photo_Exit )
                        strIdentify += "Document present at the exit sensor" + "\n";

                    if( UnitStatus.Photo_Path_Module_Begin)
                        strIdentify += "Photo at begin path base module covered" + "\n";

                    if( UnitStatus.Photo_Path_Binary_Rigth)
                        strIdentify += "Photo path binary right covered" + "\n";

                    if( UnitStatus.Photo_Path_Binary_Left)
                        strIdentify += "Photo path binary left covered" + "\n";

                    if( UnitStatus.Photo_Path_Module_End)
                        strIdentify += "Photo at end path base module covered" + "\n";

                    if( UnitStatus.Pockets_All_Full )
                        strIdentify += "Bin(s) full" + "\n";

                    if( UnitStatus.Pocket_1_Full )
                        strIdentify += "Bin 1 full" + "\n";

                    if( UnitStatus.Pocket_1_Full )
                        strIdentify += "Bin 2 full" + "\n";

                    if( UnitStatus.Unit_Just_ON )
                        strIdentify += "Periferal just ON" + "\n";

                    if( UnitStatus.Photo_Path_Feeder )
                        strIdentify += "Photo path Feeder covered" + "\n";

                    if( UnitStatus.Photo_Double_Leafing_Down )
                        strIdentify += "Photo DOWN Double Leafing covered" + "\n";

                    if( UnitStatus.Photo_Double_Leafing_Middle )
                        strIdentify += "Photo MIDDLE Double Leafing covered" + "\n";

                    if( UnitStatus.Photo_Double_Leafing_Up )
                        strIdentify += "Photo UP Double Leafing covered" + "\n";

                    if( UnitStatus.Sorter_1_input_pocket_1 )
                        strIdentify += "Sorter 1 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_1_pocket_1_full )
                        strIdentify += "Sorter 1 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_1_input_pocket_2 )
                        strIdentify += "Sorter 1 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_1_pocket_2_full )
                        strIdentify += "Sorter 1 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_1_input_pocket_3 )
                        strIdentify += "Sorter 1 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_1_pocket_3_full )
                        strIdentify += "Sorter 1 - pocket 3 full" + "\n";

                    if( UnitStatus.Sorter_2_input_pocket_1 )
                        strIdentify += "Sorter 2 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_2_pocket_1_full )
                        strIdentify += "Sorter 2 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_2_input_pocket_2 )
                        strIdentify += "Sorter 2 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_2_pocket_2_full )
                        strIdentify += "Sorter 2 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_2_input_pocket_3 )
                        strIdentify += "Sorter 2 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_2_pocket_3_full )
                        strIdentify += "Sorter 2 - pocket 3 full" + "\n";

                    if( UnitStatus.Sorter_3_input_pocket_1 )
                        strIdentify += "Sorter 3 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_3_pocket_1_full )
                        strIdentify += "Sorter 3 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_3_input_pocket_2 )
                        strIdentify += "Sorter 3 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_3_pocket_2_full )
                        strIdentify += "Sorter 3 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_3_input_pocket_3 )
                        strIdentify += "Sorter 3 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_3_pocket_3_full )
                        strIdentify += "Sorter 3 - pocket 3 full" + "\n";

                    if( UnitStatus.Sorter_4_input_pocket_1 )
                        strIdentify += "Sorter 4 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_4_pocket_1_full )
                        strIdentify += "Sorter 4 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_4_input_pocket_2 )
                        strIdentify += "Sorter 4 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_4_pocket_2_full )
                        strIdentify += "Sorter 4 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_4_input_pocket_3 )
                        strIdentify += "Sorter 4 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_4_pocket_3_full )
                        strIdentify += "Sorter 4 - pocket 3 full" + "\n";

                    if( UnitStatus.Sorter_5_input_pocket_1 )
                        strIdentify += "Sorter 5 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_5_pocket_1_full )
                        strIdentify += "Sorter 5 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_5_input_pocket_2 )
                        strIdentify += "Sorter 5 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_5_pocket_2_full )
                        strIdentify += "Sorter 5 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_5_input_pocket_3 )
                        strIdentify += "Sorter 5 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_5_pocket_3_full )
                        strIdentify += "Sorter 5 - pocket 3 full" + "\n";

                    if( UnitStatus.Sorter_6_input_pocket_1 )
                        strIdentify += "Sorter 6 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_6_pocket_1_full )
                        strIdentify += "Sorter 6 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_6_input_pocket_2 )
                        strIdentify += "Sorter 6 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_6_pocket_2_full )
                        strIdentify += "Sorter 6 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_6_input_pocket_3 )
                        strIdentify += "Sorter 6 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_1_pocket_3_full )
                        strIdentify += "Sorter 6 - pocket 3 full" + "\n";

                    if( UnitStatus.Sorter_7_input_pocket_1 )
                        strIdentify += "Sorter 7 - photo input pocket 1 covered" + "\n";
                    if( UnitStatus.Sorter_7_pocket_1_full )
                        strIdentify += "Sorter 7 - pocket 1 full" + "\n";
                    if( UnitStatus.Sorter_7_input_pocket_2 )
                        strIdentify += "Sorter 7 - photo input pocket 2 covered" + "\n";
                    if( UnitStatus.Sorter_7_pocket_2_full )
                        strIdentify += "Sorter 7 - pocket 2 full" + "\n";
                    if( UnitStatus.Sorter_7_input_pocket_3 )
                        strIdentify += "Sorter 7 - photo input pocket 3 covered" + "\n";
                    if( UnitStatus.Sorter_7_pocket_3_full )
                        strIdentify += "Sorter 7 - pocket 3 full" + "\n";

                    MessageBox.Show(strIdentify, "Peripheral status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                Reply = CtsLs.LSDisconnect(hConnect, 0);
            }
            else
                CheckReply(Reply, "LSConnect");
        }


        public static CtsLs.UNITHISTORY UnitHistory = new CtsLs.UNITHISTORY();

        private void btMonitor_Click(object sender, EventArgs e)
        {
            int Reply;
            short hConnect;


            hConnect = 0;

            Reply = TryConnect(ref hConnect);
            if (Reply == CtsLs.LsReply.LS_OKAY)
            {
                Reply = CtsLs.LSUnitIdentify(hConnect, 0,
                                             UnitCfg,
                                             LsModel,
                                             IntPtr.Zero, //strFwVersion,
                                             IntPtr.Zero, //Date_Fw,
                                             IntPtr.Zero, //strUnitID,
                                             IntPtr.Zero, // BoardVersion
                                             IntPtr.Zero, //DecoderExpVersion,
                                             IntPtr.Zero, //strInkJetVersion,
                                             IntPtr.Zero, //FeederVersion,
                                             IntPtr.Zero, //SorterVersion,
                                             IntPtr.Zero, //Motorversion,
                                             IntPtr.Zero, //Reserved1,
                                             IntPtr.Zero);//Reserved2

                UnitHistory.Size = Marshal.SizeOf(UnitHistory);          

                Reply = CtsLs.LSUnitHistory(hConnect, 0, ref UnitHistory);

                if (Reply == CtsLs.LsReply.LS_OKAY)
                {
                    // Create and show the dialog
                    FormHistory formHistory = new FormHistory();

                    formHistory.ShowDialog();
                }

                Reply = CtsLs.LSDisconnect(hConnect, 0);
            }
            else
                CheckReply(Reply, "LSConnect");
        }

        private void btOptions_Click(object sender, EventArgs e)
        {
            int Reply;
            short hConnect;

            IntPtr strFwVersion = Marshal.AllocHGlobal(20);
            IntPtr Date_Fw = Marshal.AllocHGlobal(20);
            IntPtr strUnitID = Marshal.AllocHGlobal(20);
            IntPtr strInkJetVersion = Marshal.AllocHGlobal(20);
            IntPtr DecoderExpVersion = Marshal.AllocHGlobal(20);


            hConnect = 0;

            Reply = TryConnect(ref hConnect);
            if (Reply == CtsLs.LsReply.LS_OKAY)
            {
                Reply = CtsLs.LSUnitIdentify(hConnect, 0,
                                             UnitCfg,
                                             LsModel,
                                             strFwVersion,
                                             Date_Fw,
                                             strUnitID,
                                             IntPtr.Zero, // BoardVersion
                                             DecoderExpVersion,
                                             strInkJetVersion,
                                             IntPtr.Zero, //FeederVersion,
                                             IntPtr.Zero, //SorterVersion,
                                             IntPtr.Zero, //Motorversion,
                                             IntPtr.Zero, //Reserved1,
                                             IntPtr.Zero);//Reserved2

                Reply = CtsLs.LSDisconnect(hConnect, 0);

                // Create and show the dialog
                FormOptions OptForm = new FormOptions();

                OptForm.ShowDialog();
            }
            else
                CheckReply(Reply, "LSConnect");
        }

        private void EnableButton(bool fEnable)
        {
            btIdentify.Enabled = fEnable;
            btStatus.Enabled = fEnable;
            btMonitor.Enabled = fEnable;
            btReset.Enabled = fEnable;
            btOptions.Enabled = fEnable;
            btProcessDoc.Enabled = fEnable;
            btStopDoc.Enabled = !fEnable;
            btExit.Enabled = fEnable;
        }

        private bool TestDocPresent(short hConnect, ref int Reply)
        {
            bool ret;
            CtsLs.UNITSTATUS UnitStatus;

            UnitStatus = new CtsLs.UNITSTATUS();
            UnitStatus.Size = Marshal.SizeOf(UnitStatus);

            ret = false;
            Reply = CtsLs.LSUnitStatus(hConnect, 0, ref UnitStatus);
            if (Reply == CtsLs.LsReply.LS_OKAY || Reply == CtsLs.LsReply.LS_FEEDER_EMPTY)
            {
                if( UnitStatus.Photo_Feeder )
                    ret = true;

                if ((Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS150") == true) && stParAppl.ScanCard && UnitStatus.Photo_Scanners)
                    ret = true;
            }

            return ret;
        }

        //***************************************************************************
        // FUNCTION  : DoAutoDocHandle
        //
        // PURPOSE   : 
        //
        // PARAMETER : 
        //***************************************************************************
        int DoAutoDocHandle(short hConnect, byte[] UnitCfg)
        {
	        int		Reply;
        //	string	FileOut;

	        IntPtr  BufFrontFile = Marshal.AllocHGlobal(1024);
	        IntPtr  BufRearFile = Marshal.AllocHGlobal(1024);
            IntPtr BufFrontImage;
            IntPtr BufRearImage;
            IntPtr BufFrontUVImage;
            IntPtr BufFrontGrayUVImage;
            IntPtr NoImage;
            IntPtr  BufCodelineSW = Marshal.AllocHGlobal((int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH);
            IntPtr  BufCodelineHW = Marshal.AllocHGlobal((int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH);
            IntPtr  BufBarcode = Marshal.AllocHGlobal((int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH);
	        CtsLs.CodeLineType CodelineType;
            float   C_x;
            float   C_y;
            float   C_w;
            float   C_h;

//	        int	    ImageBW;
	        short	DocToRead;
	        Int32	NrPrinted;

	        Int32    DocToProcess;
            UInt32  NrDoc;
	        short   NrCheque = 1;
            CtsLs.PrintValidate PrintValidate;
            IntPtr  dirBase;
            IntPtr  Filename;

            //FILE  *fhCodeline = NULL;

	        // COORDINATE PER BARCODE O PER OCR
	        byte TypeOfDecod;


	        //-----------Digital Signature-------------------------------
            //if (stParAppl.ImageDigitalSignature )
            //{
            //    Reply = LSSetSignatureKey( hConnect,  hWnd, stParAppl.SignedKey, stParAppl.LenKey ,FALSE);
            //    if (Reply != CtsLs.LsReply. LS_OKAY)
            //    {
            //        if (CheckReply(Reply, "LSLoadString"))
            //        {
            //            return Reply;
            //        }
            //    }
            //}


            PrintValidate = CtsLs.PrintValidate.NO_PRINT_VALIDATE;
	        //-----------LoadString--------------------------------------
            if (stParAppl.PrintValidate != CtsLs.PrintFont.PRINT_NO_STRING)
	        {
                IntPtr strEndorse = Marshal.AllocHGlobal(160); ;

                // Copy the Secure string to unmanaged memory (and decrypt it).
                strEndorse = Marshal.StringToHGlobalAnsi(stParAppl.Endorse_str);

		        if( stParAppl.Endorse_str.Contains("%d") )
			        Reply = CtsLs.LSLoadStringWithCounterEx(hConnect, 0,
                                                            (short)stParAppl.PrintValidate,
                                                            strEndorse,
											                (short)stParAppl.Endorse_str.Length,
											                8, 3);
		        else
                    Reply = CtsLs.LSLoadString(hConnect, 0,
                                               (short)stParAppl.PrintValidate,
                                               (short)stParAppl.Endorse_str.Length,
                                               strEndorse);
                if (Reply != CtsLs.LsReply.LS_OKAY)
		        {
			        if (CheckReply(Reply, "LSLoadString"))
			        {
				        return Reply;
			        }
		        }

		        // Set variable for print
                PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE;
	        }
            else if (stParAppl.fTestPrinter)
	        {
                //PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE;
                //Reply = CtsLs.LSLoadString(hConnect, 0, PRINT_FORMAT_HEAD_TEST, 1, " ");

                //if (Reply != CtsLs.LsReply.LS_OKAY)
                //{
                //    if (CheckReply(Reply, "LSLoadString"))
                //    {
                //        return Reply;
                //    }
                //}
	        }
	        else if( stParAppl.PrintHighDefinition )
	        {
                //PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE;
                //if( stParAppl.PrintLogo )
                //    PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE_WITH_LOGO;

		        // Se c'è la print HD costruisco la stringa
                //Reply = LSLoadMultiStrings(hConnect, hWnd,
                //                stParAppl.PrintFontLine1, (char *)(stParAppl.PrintLine1 ? stParAppl.PrintStringLine1 : NULL), (short)(stParAppl.PrintLine1 ? strlen(stParAppl.PrintStringLine1) : 0),
                //                stParAppl.PrintFontLine2, (char *)(stParAppl.PrintLine2 ? stParAppl.PrintStringLine2 : NULL), (short)(stParAppl.PrintLine2 ? strlen(stParAppl.PrintStringLine2) : 0),
                //                stParAppl.PrintFontLine3, (char *)(stParAppl.PrintLine3 ? stParAppl.PrintStringLine3 : NULL), (short)(stParAppl.PrintLine3 ? strlen(stParAppl.PrintStringLine3) : 0),
                //                stParAppl.PrintFontLine4, (char *)(stParAppl.PrintLine4 ? stParAppl.PrintStringLine4 : NULL), (short)(stParAppl.PrintLine4 ? strlen(stParAppl.PrintStringLine4) : 0));

                //if (Reply != CtsLs.LsReply.LS_OKAY)
                //{
                //    if (CheckReply(Reply, "LSLoadMultiStrings"))
                //    {
                //        return Reply;
                //    }
                //}
	        }
	        //-----------Print Logo--------------------------------------
	        else if( stParAppl.PrintLogo )
	        {
                PrintValidate = CtsLs.PrintValidate.PRINT_LOGO;
	        }


	        //-----------Load Digital String----------------------------------
            //if (stParAppl.PrintValidate == CtsLs.PrintValidate.PRINT_DIGITAL_VALIDATE)
            //{
            //    switch( stParAppl.Digital_SidePrint )
            //    {
            //    case 1:
            //        SidePrint = SIDE_BACK_IMAGE;
            //        break;
            //    case 2:
            //        SidePrint = SIDE_FRONT_IMAGE;
            //        break;
            //    case 3:
            //        SidePrint = SIDE_ALL_IMAGE;
            //        break;
            //    }

            //    Reply = LSLoadDigitalStringWithCounter(hConnect, hWnd,
            //                                            SidePrint,
            //                                            stParAppl.Digital_str,
            //                                            (short)strlen(stParAppl.Digital_str),
            //                                            7, //StartNumber,
            //                                            0, //Step,
            //                                            stParAppl.Digital_FontName,
            //                                            stParAppl.Digital_FontSize,
            //                                            stParAppl.Digital_Bold,
            //                                            stParAppl.Digital_Italic,
            //                                            stParAppl.Digital_Undeline,
            //                                            stParAppl.Digital_Tone,
            //                                            stParAppl.Digital_Unit,
            //                                            stParAppl.Digital_x,
            //                                            stParAppl.Digital_y);

            //    // Set variable for print
            //    PrintValidate += CtsLs.PrintValidate.PRINT_DIGITAL_VALIDATE;
            //}


	        //----------- Set Sensibilità foto doppia sfogliatura -----------
            Reply = CtsLs.LSConfigDoubleLeafingAndDocLength(hConnect, 0,
                                                            stParAppl.DL_Type,
											                stParAppl.DL_Value,
											                stParAppl.DL_MinDoc, stParAppl.DL_MaxDoc);
	        if (Reply != CtsLs.LsReply.LS_OKAY)
	        {
		        if( CheckReply(Reply, "LSConfigDoubleLeafingAndDocLength"))
		        {
			        return Reply;
		        }
	        }


	        //----------- Change stamp position -----------
            //Reply = CtsLs.LSChangeStampPosition(hConnect, 0, stParAppl.StampPosition, 0);
            //if (Reply != CtsLs.LsReply.LS_OKAY)
            //{
            //    if (CheckReply(Reply, "LSChangeStampPosition"))
            //    {
            //        return Reply;
            //    }
            //}


	        //----------- Set attesa introduzione documento -----------
            Reply = CtsLs.LSDisableWaitDocument(hConnect, 0, stParAppl.WaitTimeout);
	        if (Reply != CtsLs.LsReply.LS_OKAY)
	        {
		        if (CheckReply(Reply, "LSDisableWaitDocument"))
		        {
			        return Reply;
		        }
	        }


	        //----------- Set speed document -----------
            Reply = CtsLs.LSSetUnitSpeed(hConnect, 0, stParAppl.LowSpeed);
	        if (Reply != CtsLs.LsReply.LS_OKAY)
	        {
		        if (CheckReply(Reply, "LSSetSpeedUnit"))
		        {
			        return Reply;
		        }
	        }


	        //----------- Set Light Intensity --------------------------
	        Reply = CtsLs.LSSetLightIntensity(hConnect, 0, stParAppl.LightIntensity);
	        if (Reply != CtsLs.LsReply.LS_OKAY)
	        {
		        if (CheckReply(Reply, "LSSetLightIntensity"))
		        {
			        return Reply;
		        }
	        }


	        //----------- Only for Ultra Violet type -----------
	        if( (UnitCfg[1] & MASK_SCANNER_UV) == MASK_SCANNER_UV )
	        {
		        Reply = CtsLs.LSModifyPWMUltraViolet(hConnect, 0, stParAppl.PercentPWM_UV, stParAppl.Contrast_UV, stParAppl.Threshold_UV);
		        if (Reply != CtsLs.LsReply.LS_OKAY)
		        {
			        if (CheckReply(Reply, "LSModifyPWMUltraViolet"))
			        {
				        return Reply;
			        }
		        }
	        }


	        // Settaggio dei parametri fissi per LS_AutoDocHandle
            dirBase = Marshal.StringToHGlobalAnsi(PathAppl + SAVE_DIRECTORY_IMAGE);
            Filename = Marshal.StringToHGlobalAnsi(NAME_IMAGE);

            CodelineType = CtsLs.CodeLineType.NO_READ_CODELINE;
            TypeOfDecod = stParAppl.TypeOfDecod;
            C_x = C_y = C_w = C_h = 0;
            if( stParAppl.CodelineMICR != CtsLs.CodeLineType.NO_READ_CODELINE )
	        {
		        CodelineType = stParAppl.CodelineMICR;
	        }
	        else if( stParAppl.CodelineOCR != CtsLs.CodeLineType.NO_READ_CODELINE )
	        {
		        CodelineType = stParAppl.CodelineOCR;
                C_x = stParAppl.Codeline_Sw_x;
                C_y = stParAppl.Codeline_Sw_y;
                C_w = stParAppl.Codeline_Sw_w;
                C_h = stParAppl.Codeline_Sw_h;
                TypeOfDecod -= DECODE_OCR;
	        }
	        else if( stParAppl.BarcodeType != CtsLs.CodeLineType.NO_READ_CODELINE )
	        {
		        CodelineType = stParAppl.BarcodeType;
                C_x = stParAppl.Barcode_Sw_x;
                C_y = stParAppl.Barcode_Sw_y;
                C_w = stParAppl.Barcode_Sw_w;
                C_h = stParAppl.Barcode_Sw_h;
                TypeOfDecod -= DECODE_OCR;
            }

	        Reply = CtsLs.LSAutoDocHandle(hConnect, 0,
							              stParAppl.FrontStamp,
							              (short)PrintValidate,
                                          (short)CodelineType,
							              stParAppl.ScanMode,
                                          (short)CtsLs.Feeder.FEED_AUTO,
                                          (short)CtsLs.Sorter.SORTER_POCKET_1,
                                          stParAppl.NumDoc,
                                          stParAppl.ClearAlignImage,
                                          stParAppl.Side,
							              0,
							              stParAppl.SaveImage,
							              dirBase,
                                          Filename,
                                          C_x, C_y, C_w, C_h,
                                          (short)CtsLs.Unit.UNIT_MM,
                                          0,
                                          stParAppl.FileFormat,
                                          stParAppl.Qual,
                                          (short)CtsLs.FileAttribute.SAVE_OVERWRITE,
                                          1,
                                          (short)(stParAppl.WaitTimeout ? CtsLs.Wait.WAIT_YES : CtsLs.Wait.WAIT_NO),
                                          (short)stParAppl.BeepOnError,
                                          0,
                                          IntPtr.Zero,
                                          IntPtr.Zero);
	        if (Reply != CtsLs.LsReply.LS_OKAY)
	        {
		        if (CheckReply(Reply, "LSAutoDocHandle"))
		        {
			        return Reply;
		        }
	        }


	        // Salvo il nr. di documenti da processare
	        if( stParAppl.NumDoc != 0 )
		        DocToProcess = stParAppl.NumDoc;
	        else
		        DocToProcess = 1000000;


            if (Save_FrontImage != IntPtr.Zero)
            {
                CtsLs.LSFreeImage(0, ref Save_FrontImage);
                Save_FrontImage = IntPtr.Zero;
            }
            if (Save_RearImage != IntPtr.Zero)
            {
                CtsLs.LSFreeImage(0, ref Save_RearImage);
                Save_RearImage = IntPtr.Zero;
            }

	        //-----------GetDocData--------------------------------------
            Bitmap pBitmap = null;

            //	if( Reply == LS_OKAY )
        //	{
        //		while( TRUE )
            while (Reply == CtsLs.LsReply.LS_OKAY)
	        {
		        Marshal.WriteByte(BufFrontFile, 0);
                Marshal.WriteByte(BufRearFile, 0);
                BufFrontImage = IntPtr.Zero;
                BufRearImage = IntPtr.Zero;
                BufFrontUVImage = BufFrontGrayUVImage = IntPtr.Zero;
                NoImage = IntPtr.Zero;
                NrDoc = 0;
                DocToRead = 0;
                NrPrinted = 0;

                Marshal.WriteByte(BufCodelineSW, 0);
                Marshal.WriteByte(BufCodelineHW, 0);
                Marshal.WriteByte(BufBarcode, 0);

		        Reply = CtsLs.LSGetDocData(hConnect, 0,
								           ref NrDoc,
								           BufFrontFile,
								           BufRearFile,
								           IntPtr.Zero, //BufFrontNettoFile,
                                           IntPtr.Zero, //BufBackNettoFile,
								           ref BufFrontImage,
								           ref BufRearImage,
								           ref BufFrontUVImage,
								           ref NoImage,	//BufbackNettoImage,
								           BufCodelineSW,
								           BufCodelineHW,
                                           BufBarcode,
                                           IntPtr.Zero,
                                           ref DocToRead,
                                           ref NrPrinted,
                                           IntPtr.Zero,
                                           IntPtr.Zero);

		        // Se e` doppia sfogliatura non termino
                if (((Reply != CtsLs.LsReply.LS_OKAY) && (Reply != CtsLs.LsReply.LS_SORTER1_FULL) &&
                     (Reply != CtsLs.LsReply.LS_DOUBLE_LEAFING_WARNING)))
		        {
                    if( Reply != CtsLs.LsReply.LS_FEEDER_EMPTY )
				        CheckReply(Reply, "LS_GetDocData");
				    break;
		        }


		        //metto il test per le altre codeline
                if ((TypeOfDecod & DECODE_OCR) == DECODE_OCR )
		        {
                    CtsLs.READOPTIONS ro;
                    byte[] CodelineOpt  = new byte[4];
                    int len_codeline;

                    ro.PutBlanks = 1;
			        ro.TypeRead = 'N';
			        if( stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_E13B_X_OCRB )
			        {
				        ro.TypeRead = 'X';
                        CodelineOpt[0] = (byte)CtsLs.CodeLineType.READ_CODELINE_SW_E13B;
                        CodelineOpt[1] = (byte)CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_ITALY;
                        CodelineOpt[2] = (byte)'\0';
			        }
			        else
			        {
                        CodelineOpt[0] = (byte)stParAppl.CodelineOCR;
                        CodelineOpt[2] = (byte)'\0';
			        }

                    len_codeline = (int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;

                    Reply = CtsLs.LSCodelineReadFromBitmap(0,
                                                           BufFrontImage,
                                                           CodelineOpt,
                                                           stParAppl.Unit_measure,
                                                           stParAppl.Codeline_Sw_x,
                                                           stParAppl.Codeline_Sw_y,
                                                           stParAppl.Codeline_Sw_w,
                                                           stParAppl.Codeline_Sw_h,
                                                           ref ro,
                                                           BufCodelineSW,
                                                           ref len_codeline);
			        if( Reply != CtsLs.LsReply. LS_OKAY )
			        {
				        CheckReply(Reply, "LSCodelineReadFromBitmap");
                        Reply = CtsLs.LsReply.LS_OKAY;		// Set Ok for not exit from the loop
			        }
		        }
                if ((TypeOfDecod & DECODE_BARCODE) == DECODE_BARCODE )
		        {
                    int len_barcode = (int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;

                    Reply = CtsLs.LSReadBarcodeFromBitmap(0,
                                                          BufFrontImage,
                                                          (byte)stParAppl.BarcodeType,
                                                          (int)stParAppl.Barcode_Sw_x,
                                                          (int)stParAppl.Barcode_Sw_y,
                                                          (int)stParAppl.Barcode_Sw_w,
                                                          (int)stParAppl.Barcode_Sw_h,
                                                          BufBarcode,
                                                          ref len_barcode);
			        if (Reply != CtsLs.LsReply. LS_OKAY)
			        {
				        CheckReply(Reply, "LSReadBarcodeFromBitmap");
                        Reply = CtsLs.LsReply.LS_OKAY;		// Set Ok for not exit from the loop
			        }
		        }
                if ((TypeOfDecod & DECODE_PDF417) == DECODE_PDF417 )
		        {
                    int len_barcode = (int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;

                    Reply = CtsLs.LSReadPdf417FromBitmap(0,
										                 BufFrontImage,
                                                         BufBarcode,
                                                         ref len_barcode,
                                                         0, 0, 0, 0, 0);
			        if (Reply != CtsLs.LsReply. LS_OKAY)
			        {
				        CheckReply(Reply, "LSReadPdf417FromBitmap");
                        Reply = CtsLs.LsReply.LS_OKAY;		// Set Ok for not exit from the loop
			        }
		        }


                if (stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR100_AND_UV ||
                    stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR200_AND_UV ||
                    stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR300_AND_UV)
		        {
			        // Build the mergered gray UV image
                    if (BufFrontUVImage != IntPtr.Zero)
			        {
                        CtsLs.LSMergeImageGrayAndUV(0,
									                BufFrontImage,
									                BufFrontUVImage,
									                0, //stParAppl.Threshold_UV,
									                0,
									                ref BufFrontGrayUVImage);


                        //if( stParAppl.SaveImage == IMAGE_SAVE_ON_FILE || stParAppl.SaveImage == IMAGE_SAVE_BOTH )
                        //{
                        //    // Check if I must save the image
                        //    if( stParAppl.FileFormat == (short)CtsLs.FileType.FILE_JPEG )
                        //    {
                        //        FullFName, "%s\\%s%04dGUV.jpg", dirBase, Filename, (NrDoc - 1));
                        //        Reply = LSSaveJPEG(hWnd, BufFrontGrayUVImage, stParAppl.Qual, FullFName);
                        //    }
                        //    else if( stParAppl.FileFormat == (short)CtsLs.FileType.FILE_BMP )
                        //    {
                        //        sprintf(FullFName, "%s\\%s%04dGUV.bmp", dirBase, Filename, (NrDoc - 1));
                        //        Reply = LSSaveDIB(hWnd, BufFrontGrayUVImage, FullFName);
                        //    }
                        //    else if( stParAppl.FileFormat == (short)CtsLs.FileType.FILE_CCITT_GROUP4 )
                        //    {
                        //        sprintf(FullFName, "%s\\%s%04dGUV.tif", dirBase, Filename, (NrDoc - 1));
                        //        Reply = LSSaveTIFF(hWnd, BufFrontGrayUVImage, FullFName, FILE_TIF, SAVE_OVERWRITE, 1);
                        //    }
                        //}
			        }
                }


                // Show Codeline
                if (Marshal.ReadByte(BufCodelineHW) != 0)
                    tbCodeline.Text = Marshal.PtrToStringAnsi(BufCodelineHW);
                else
                    tbCodeline.Text = "";

                //// Show the immage
                if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_ALL_IMAGE || Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_FRONT_IMAGE)
                {
                    CtsLs.BITMAPINFOHEADER pBmp = (CtsLs.BITMAPINFOHEADER)Marshal.PtrToStructure(BufFrontImage, typeof(CtsLs.BITMAPINFOHEADER));

                    pBitmap = new Bitmap(pBmp.biWidth, pBmp.biHeight, PixelFormat.Format24bppRgb);

                    //                BitmapData bmpData = pBitmap.LockBits(new Rectangle(0, 0, pBitmap.Width, pBitmap.Height), ImageLockMode.WriteOnly, pBitmap.PixelFormat);
                    int xx, yy;
                    Int32 diff, WidthBytes = pBmp.biWidth;
                    if ((diff = WidthBytes % 4) != 0)
                        WidthBytes += (4 - diff);
                    Int32 row, col;
                    row = pBmp.biHeight - 1;
                    col = pBmp.biWidth - 1;
                    for (yy = 0; yy < pBmp.biHeight; yy++)
                    {
                        for (xx = 0; xx < pBmp.biWidth; xx++)
                        {
                            byte Pixel = Marshal.ReadByte((IntPtr)((int)BufFrontImage + 1064 + ((yy * WidthBytes) + xx)));
                            Color Pixel24;
                            Pixel24 = Color.FromArgb((Pixel * 256 * 256) + (Pixel * 256) + Pixel);
                            pBitmap.SetPixel(xx, (row - yy), Pixel24);
                            //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy)), Pixel);
                            //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy) + 1), Pixel);
                            //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy) + 2), Pixel);
                        }
                    }
                    //               CopyMemory(bmpData.Scan0, (IntPtr)((int)BufFrontImage + 1064), pBmp.biSizeImage);
                    //                pBitmap.UnlockBits(bmpData);

                    if (pbImage.Image != null)
                    {
                        pbImage.Image.Dispose();
                        //    //pbImage.Image = null;
                    }
                    pbImage.Image = pBitmap;
                }

                // Refresh the form
                Application.DoEvents();

                // Abilito il bottone visualizzazione retro
                if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_ALL_IMAGE)
                    btRear.Enabled = true;

                // Free the aree
//                pBitmap.Dispose();


                // Free the previous image memory and save the current
                if (Save_FrontImage != IntPtr.Zero)
                {
                    CtsLs.LSFreeImage(0, ref Save_FrontImage);
                }
                if (BufFrontGrayUVImage != IntPtr.Zero)
                {
                    Save_FrontImage = BufFrontGrayUVImage;
                    CtsLs.LSFreeImage(0, ref BufFrontImage);
                    CtsLs.LSFreeImage(0, ref BufFrontUVImage);
                }
                else if (BufFrontImage != IntPtr.Zero)
                {
                    Save_FrontImage = BufFrontImage;
                }

                if (Save_RearImage != IntPtr.Zero)
                {
                    CtsLs.LSFreeImage(0, ref Save_RearImage);
                }
                Save_RearImage = BufRearImage;


			    if( (--DocToProcess) == 0 )
				    break;

			    NrCheque ++;

		    }	// Fine while( TRUE )

            // Free of local variable
            Marshal.FreeHGlobal(Filename);
            Marshal.FreeHGlobal(dirBase);
            Marshal.FreeHGlobal(BufBarcode);
            Marshal.FreeHGlobal(BufCodelineHW);
            Marshal.FreeHGlobal(BufCodelineSW);
            Marshal.FreeHGlobal(BufRearFile);
            Marshal.FreeHGlobal(BufFrontFile);

	        return Reply;
        }  // End DoAutoDocHandle

        //***************************************************************************
        // FUNCTION  : DoAutoDocHandle
        //
        // PURPOSE   : 
        //
        // PARAMETER : 
        //***************************************************************************
        int DoSingleDocHandle(short hConnect, byte[] UnitCfg)
        {
            int Reply;
            //	string	FileOut;

            IntPtr BufFrontFile = Marshal.AllocHGlobal(1024);
            IntPtr BufRearFile = Marshal.AllocHGlobal(1024);
            IntPtr BufFrontImage;
            IntPtr BufRearImage;
            IntPtr BufFrontUVImage;
            IntPtr BufFrontGrayUVImage;
            IntPtr NoImage;
            IntPtr BufCodelineSW = Marshal.AllocHGlobal((int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH);
            IntPtr BufCodelineHW = Marshal.AllocHGlobal((int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH);
            IntPtr BufBarcode = Marshal.AllocHGlobal((int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH);

            UInt32 NrDoc;
            CtsLs.PrintValidate PrintValidate;

            // COORDINATE PER BARCODE O PER OCR
            short lenCodeline;
            short NotUsed, NotUsed2;


            //-----------Digital Signature-------------------------------
            //if (stParAppl.ImageDigitalSignature )
            //{
            //    Reply = LSSetSignatureKey( hConnect,  hWnd, stParAppl.SignedKey, stParAppl.LenKey ,FALSE);
            //    if (Reply != CtsLs.LsReply. LS_OKAY)
            //    {
            //        if (CheckReply(Reply, "LSLoadString"))
            //        {
            //            return Reply;
            //        }
            //    }
            //}


            PrintValidate = CtsLs.PrintValidate.NO_PRINT_VALIDATE;
            //-----------LoadString--------------------------------------
            if (stParAppl.PrintValidate != CtsLs.PrintFont.PRINT_NO_STRING)
            {
                IntPtr strEndorse = Marshal.AllocHGlobal(160); ;

                // Copy the Secure string to unmanaged memory (and decrypt it).
                strEndorse = Marshal.StringToHGlobalAnsi(stParAppl.Endorse_str);

                if (stParAppl.Endorse_str.Contains("%d"))
                    Reply = CtsLs.LSLoadStringWithCounterEx(hConnect, 0,
                                                            (short)stParAppl.PrintValidate,
                                                            strEndorse,
                                                            (short)stParAppl.Endorse_str.Length,
                                                            8, 3);
                else
                    Reply = CtsLs.LSLoadString(hConnect, 0,
                                               (short)stParAppl.PrintValidate,
                                               (short)stParAppl.Endorse_str.Length,
                                               strEndorse);
                if (Reply != CtsLs.LsReply.LS_OKAY)
                {
                    if (CheckReply(Reply, "LSLoadString"))
                    {
                        return Reply;
                    }
                }

                // Set variable for print
                PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE;
            }
            else if (stParAppl.fTestPrinter)
            {
                //PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE;
                //Reply = CtsLs.LSLoadString(hConnect, 0, PRINT_FORMAT_HEAD_TEST, 1, " ");

                //if (Reply != CtsLs.LsReply.LS_OKAY)
                //{
                //    if (CheckReply(Reply, "LSLoadString"))
                //    {
                //        return Reply;
                //    }
                //}
            }
            else if (stParAppl.PrintHighDefinition)
            {
                //PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE;
                //if( stParAppl.PrintLogo )
                //    PrintValidate = CtsLs.PrintValidate.PRINT_VALIDATE_WITH_LOGO;

                // Se c'è la print HD costruisco la stringa
                //Reply = LSLoadMultiStrings(hConnect, hWnd,
                //                stParAppl.PrintFontLine1, (char *)(stParAppl.PrintLine1 ? stParAppl.PrintStringLine1 : NULL), (short)(stParAppl.PrintLine1 ? strlen(stParAppl.PrintStringLine1) : 0),
                //                stParAppl.PrintFontLine2, (char *)(stParAppl.PrintLine2 ? stParAppl.PrintStringLine2 : NULL), (short)(stParAppl.PrintLine2 ? strlen(stParAppl.PrintStringLine2) : 0),
                //                stParAppl.PrintFontLine3, (char *)(stParAppl.PrintLine3 ? stParAppl.PrintStringLine3 : NULL), (short)(stParAppl.PrintLine3 ? strlen(stParAppl.PrintStringLine3) : 0),
                //                stParAppl.PrintFontLine4, (char *)(stParAppl.PrintLine4 ? stParAppl.PrintStringLine4 : NULL), (short)(stParAppl.PrintLine4 ? strlen(stParAppl.PrintStringLine4) : 0));

                //if (Reply != CtsLs.LsReply.LS_OKAY)
                //{
                //    if (CheckReply(Reply, "LSLoadMultiStrings"))
                //    {
                //        return Reply;
                //    }
                //}
            }
            //-----------Print Logo--------------------------------------
            else if (stParAppl.PrintLogo)
            {
                PrintValidate = CtsLs.PrintValidate.PRINT_LOGO;
            }


            //-----------Load Digital String----------------------------------
            //if (stParAppl.PrintValidate == CtsLs.PrintValidate.PRINT_DIGITAL_VALIDATE)
            //{
            //    switch( stParAppl.Digital_SidePrint )
            //    {
            //    case 1:
            //        SidePrint = SIDE_BACK_IMAGE;
            //        break;
            //    case 2:
            //        SidePrint = SIDE_FRONT_IMAGE;
            //        break;
            //    case 3:
            //        SidePrint = SIDE_ALL_IMAGE;
            //        break;
            //    }

            //    Reply = LSLoadDigitalStringWithCounter(hConnect, hWnd,
            //                                            SidePrint,
            //                                            stParAppl.Digital_str,
            //                                            (short)strlen(stParAppl.Digital_str),
            //                                            7, //StartNumber,
            //                                            0, //Step,
            //                                            stParAppl.Digital_FontName,
            //                                            stParAppl.Digital_FontSize,
            //                                            stParAppl.Digital_Bold,
            //                                            stParAppl.Digital_Italic,
            //                                            stParAppl.Digital_Undeline,
            //                                            stParAppl.Digital_Tone,
            //                                            stParAppl.Digital_Unit,
            //                                            stParAppl.Digital_x,
            //                                            stParAppl.Digital_y);

            //    // Set variable for print
            //    PrintValidate += CtsLs.PrintValidate.PRINT_DIGITAL_VALIDATE;
            //}


            //----------- Set Sensibilità foto doppia sfogliatura -----------
            Reply = CtsLs.LSConfigDoubleLeafingAndDocLength(hConnect, 0,
                                                            stParAppl.DL_Type,
                                                            stParAppl.DL_Value,
                                                            stParAppl.DL_MinDoc, stParAppl.DL_MaxDoc);
            if (Reply != CtsLs.LsReply.LS_OKAY)
            {
                if (CheckReply(Reply, "LSConfigDoubleLeafingAndDocLength"))
                {
                    return Reply;
                }
            }


            //----------- Change stamp position -----------
            //Reply = CtsLs.LSChangeStampPosition(hConnect, 0, stParAppl.StampPosition, 0);
            //if (Reply != CtsLs.LsReply.LS_OKAY)
            //{
            //    if (CheckReply(Reply, "LSChangeStampPosition"))
            //    {
            //        return Reply;
            //    }
            //}


            //----------- Set attesa introduzione documento -----------
            Reply = CtsLs.LSDisableWaitDocument(hConnect, 0, stParAppl.WaitTimeout);
            if (Reply != CtsLs.LsReply.LS_OKAY)
            {
                if (CheckReply(Reply, "LSDisableWaitDocument"))
                {
                    return Reply;
                }
            }


            //----------- Set speed document -----------
            Reply = CtsLs.LSSetUnitSpeed(hConnect, 0, stParAppl.LowSpeed);
            if (Reply != CtsLs.LsReply.LS_OKAY)
            {
                if (CheckReply(Reply, "LSSetSpeedUnit"))
                {
                    return Reply;
                }
            }


            //----------- Set Light Intensity --------------------------
            Reply = CtsLs.LSSetLightIntensity(hConnect, 0, stParAppl.LightIntensity);
            if (Reply != CtsLs.LsReply.LS_OKAY)
            {
                if (CheckReply(Reply, "LSSetLightIntensity"))
                {
                    return Reply;
                }
            }


            //----------- Only for Ultra Violet type -----------
            if ((UnitCfg[1] & MASK_SCANNER_UV) == MASK_SCANNER_UV)
            {
                Reply = CtsLs.LSModifyPWMUltraViolet(hConnect, 0, stParAppl.PercentPWM_UV, stParAppl.Contrast_UV, stParAppl.Threshold_UV);
                if (Reply != CtsLs.LsReply.LS_OKAY)
                {
                    if (CheckReply(Reply, "LSModifyPWMUltraViolet"))
                    {
                        return Reply;
                    }
                }
            }


            NrDoc = 0;
            // Start Doc.
            Reply = CtsLs.LSDocHandle(hConnect, 0,
                                      stParAppl.FrontStamp,
                                      (short)PrintValidate,
                                      (short)stParAppl.CodelineMICR,
                                      stParAppl.Side,
                                      stParAppl.ScanMode,
                                      (short)CtsLs.Feeder.FEED_AUTO,
                                      (short)CtsLs.Sorter.SORTER_POCKET_1,
                                      (short)(stParAppl.WaitTimeout ? CtsLs.Wait.WAIT_YES : CtsLs.Wait.WAIT_NO),
                                      (short)stParAppl.BeepOnError,
                                      ref NrDoc,
                                      (short)(stParAppl.ScanCard ? CtsLs.ScanDocType.SCAN_CARD : CtsLs.ScanDocType.SCAN_PAPER_DOCUMENT),
                                      0);
            if (Reply != CtsLs.LsReply.LS_OKAY)
            {
                if (CheckReply(Reply, "LSDocHandle"))
                {
                    return Reply;
                }
            }


            // Azzero le variabili
            if (Save_FrontImage != IntPtr.Zero)
            {
                CtsLs.LSFreeImage(0, ref Save_FrontImage);
                Save_FrontImage = IntPtr.Zero;
            }
            if (Save_RearImage != IntPtr.Zero)
            {
                CtsLs.LSFreeImage(0, ref Save_RearImage);
                Save_RearImage = IntPtr.Zero;
            }

            //-----------GetDocData--------------------------------------
            Bitmap pBitmap = null;

            Marshal.WriteByte(BufFrontFile, 0);
            Marshal.WriteByte(BufRearFile, 0);
            BufFrontImage = IntPtr.Zero;
            BufRearImage = IntPtr.Zero;
            BufFrontUVImage = BufFrontGrayUVImage = IntPtr.Zero;
            NoImage = IntPtr.Zero;

            Marshal.WriteByte(BufCodelineSW, 0);
            Marshal.WriteByte(BufCodelineHW, 0);
            Marshal.WriteByte(BufBarcode, 0);

            lenCodeline = (short)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;
            NotUsed = NotUsed2 = 0;

            // Read the Codeline MICR
            Reply = CtsLs.LSReadCodeline(hConnect, 0,
                                         BufCodelineHW,
                                         ref lenCodeline,
                                         IntPtr.Zero,
                                         ref NotUsed,
                                         IntPtr.Zero,
                                         ref NotUsed2);

            if( Reply != CtsLs.LsReply.LS_OKAY )
            {
                if( CheckReply(Reply, "LSReadCodeline") )
                    return Reply;
            }

            // Read the Images
            Reply = CtsLs.LSReadImage(hConnect, 0,
                                      (short)CtsLs.ClearBlack.CLEAR_BLACK_YES,
                                      stParAppl.Side,
                                      0,
                                      NrDoc,
                                      ref BufFrontImage,
                                      ref BufRearImage,
                                      ref BufFrontUVImage,
                                      IntPtr.Zero);

            if( Reply != CtsLs.LsReply.LS_OKAY )
            {
                if( CheckReply(Reply, "LSReadImage") )
                    return Reply;
            }


            //metto il test per le altre codeline
            if ((stParAppl.TypeOfDecod & DECODE_OCR) == DECODE_OCR)
            {
                CtsLs.READOPTIONS ro;
                byte[] CodelineOpt = new byte[4];
                int len_codeline;

                ro.PutBlanks = 1;
                ro.TypeRead = 'N';
                if (stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_E13B_X_OCRB)
                {
                    ro.TypeRead = 'X';
                    CodelineOpt[0] = (byte)CtsLs.CodeLineType.READ_CODELINE_SW_E13B;
                    CodelineOpt[1] = (byte)CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_ITALY;
                    CodelineOpt[2] = (byte)'\0';
                }
                else
                {
                    CodelineOpt[0] = (byte)stParAppl.CodelineOCR;
                    CodelineOpt[2] = (byte)'\0';
                }

                len_codeline = (int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;

                Reply = CtsLs.LSCodelineReadFromBitmap(0,
                                                       BufFrontImage,
                                                       CodelineOpt,
                                                       stParAppl.Unit_measure,
                                                       stParAppl.Codeline_Sw_x,
                                                       stParAppl.Codeline_Sw_y,
                                                       stParAppl.Codeline_Sw_w,
                                                       stParAppl.Codeline_Sw_h,
                                                       ref ro,
                                                       BufCodelineSW,
                                                       ref len_codeline);
                if (Reply != CtsLs.LsReply.LS_OKAY)
                {
                    CheckReply(Reply, "LSCodelineReadFromBitmap");
                    Reply = CtsLs.LsReply.LS_OKAY;		// Set Ok for not exit from the loop
                }
            }
            if ((stParAppl.TypeOfDecod & DECODE_BARCODE) == DECODE_BARCODE)
            {
                int len_barcode = (int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;

                Reply = CtsLs.LSReadBarcodeFromBitmap(0,
                                                      BufFrontImage,
                                                      (byte)stParAppl.BarcodeType,
                                                      (int)stParAppl.Barcode_Sw_x,
                                                      (int)stParAppl.Barcode_Sw_y,
                                                      (int)stParAppl.Barcode_Sw_w,
                                                      (int)stParAppl.Barcode_Sw_h,
                                                      BufBarcode,
                                                      ref len_barcode);
                if (Reply != CtsLs.LsReply.LS_OKAY)
                {
                    CheckReply(Reply, "LSReadBarcodeFromBitmap");
                    Reply = CtsLs.LsReply.LS_OKAY;		// Set Ok for not exit from the loop
                }
            }
            if ((stParAppl.TypeOfDecod & DECODE_PDF417) == DECODE_PDF417)
            {
                int len_barcode = (int)CtsLs.CodeLineType.MAX_CODE_LINE_LENGTH;

                Reply = CtsLs.LSReadPdf417FromBitmap(0,
                                                     BufFrontImage,
                                                     BufBarcode,
                                                     ref len_barcode,
                                                     0, 0, 0, 0, 0);
                if (Reply != CtsLs.LsReply.LS_OKAY)
                {
                    CheckReply(Reply, "LSReadPdf417FromBitmap");
                    Reply = CtsLs.LsReply.LS_OKAY;		// Set Ok for not exit from the loop
                }
            }


            if (stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR100_AND_UV ||
                stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR200_AND_UV ||
                stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR300_AND_UV)
            {
                // Build the mergered gray UV image
                if (BufFrontUVImage != IntPtr.Zero)
                {
                    CtsLs.LSMergeImageGrayAndUV(0,
                                                BufFrontImage,
                                                BufFrontUVImage,
                                                0, //stParAppl.Threshold_UV,
                                                0,
                                                ref BufFrontGrayUVImage);


                    //if( stParAppl.SaveImage == IMAGE_SAVE_ON_FILE || stParAppl.SaveImage == IMAGE_SAVE_BOTH )
                    //{
                    //    // Check if I must save the image
                    //    if( stParAppl.FileFormat == (short)CtsLs.FileType.FILE_JPEG )
                    //    {
                    //        FullFName, "%s\\%s%04dGUV.jpg", dirBase, Filename, (NrDoc - 1));
                    //        Reply = LSSaveJPEG(hWnd, BufFrontGrayUVImage, stParAppl.Qual, FullFName);
                    //    }
                    //    else if( stParAppl.FileFormat == (short)CtsLs.FileType.FILE_BMP )
                    //    {
                    //        sprintf(FullFName, "%s\\%s%04dGUV.bmp", dirBase, Filename, (NrDoc - 1));
                    //        Reply = LSSaveDIB(hWnd, BufFrontGrayUVImage, FullFName);
                    //    }
                    //    else if( stParAppl.FileFormat == (short)CtsLs.FileType.FILE_CCITT_GROUP4 )
                    //    {
                    //        sprintf(FullFName, "%s\\%s%04dGUV.tif", dirBase, Filename, (NrDoc - 1));
                    //        Reply = LSSaveTIFF(hWnd, BufFrontGrayUVImage, FullFName, FILE_TIF, SAVE_OVERWRITE, 1);
                    //    }
                    //}
                }
            }


            // Show Codeline
            if (Marshal.ReadByte(BufCodelineHW) != 0)
                tbCodeline.Text = Marshal.PtrToStringAnsi(BufCodelineHW);
            else
                tbCodeline.Text = "";

            //// Show the immage
            if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_ALL_IMAGE || Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_FRONT_IMAGE)
            {
                CtsLs.BITMAPINFOHEADER pBmp = (CtsLs.BITMAPINFOHEADER)Marshal.PtrToStructure(BufFrontImage, typeof(CtsLs.BITMAPINFOHEADER));

                pBitmap = new Bitmap(pBmp.biWidth, pBmp.biHeight, PixelFormat.Format24bppRgb);

                //                BitmapData bmpData = pBitmap.LockBits(new Rectangle(0, 0, pBitmap.Width, pBitmap.Height), ImageLockMode.WriteOnly, pBitmap.PixelFormat);
                int xx, yy;
                Int32 diff, WidthBytes = pBmp.biWidth;
                if ((diff = WidthBytes % 4) != 0)
                    WidthBytes += (4 - diff);
                Int32 row, col;
                row = pBmp.biHeight - 1;
                col = pBmp.biWidth - 1;
                for (yy = 0; yy < pBmp.biHeight; yy++)
                {
                    for (xx = 0; xx < pBmp.biWidth; xx++)
                    {
                        byte Pixel = Marshal.ReadByte((IntPtr)((int)BufFrontImage + 1064 + ((yy * WidthBytes) + xx)));
                        Color Pixel24;
                        Pixel24 = Color.FromArgb((Pixel * 256 * 256) + (Pixel * 256) + Pixel);
                        pBitmap.SetPixel(xx, (row - yy), Pixel24);
                        //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy)), Pixel);
                        //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy) + 1), Pixel);
                        //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy) + 2), Pixel);
                    }
                }
                //               CopyMemory(bmpData.Scan0, (IntPtr)((int)BufFrontImage + 1064), pBmp.biSizeImage);
                //                pBitmap.UnlockBits(bmpData);

                if (pbImage.Image != null)
                {
                    pbImage.Image.Dispose();
                    //    //pbImage.Image = null;
                }
                pbImage.Image = pBitmap;
            }

            // Refresh the form
            Application.DoEvents();

            // Abilito il bottone visualizzazione retro
            if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_ALL_IMAGE)
                btRear.Enabled = true;

            // Free the aree
            //                pBitmap.Dispose();


            // Free the previous image memory and save the current
            if (Save_FrontImage != IntPtr.Zero)
            {
                CtsLs.LSFreeImage(0, ref Save_FrontImage);
            }
            if (BufFrontGrayUVImage != IntPtr.Zero)
            {
                Save_FrontImage = BufFrontGrayUVImage;
                CtsLs.LSFreeImage(0, ref BufFrontImage);
                CtsLs.LSFreeImage(0, ref BufFrontUVImage);
            }
            else if (BufFrontImage != IntPtr.Zero)
            {
                Save_FrontImage = BufFrontImage;
            }

            if (Save_RearImage != IntPtr.Zero)
            {
                CtsLs.LSFreeImage(0, ref Save_RearImage);
            }
            Save_RearImage = BufRearImage;


            // Free of local variable
            Marshal.FreeHGlobal(BufBarcode);
            Marshal.FreeHGlobal(BufCodelineHW);
            Marshal.FreeHGlobal(BufCodelineSW);
            Marshal.FreeHGlobal(BufRearFile);
            Marshal.FreeHGlobal(BufFrontFile);

            return Reply;
        }  // End DoSingleDocHandle


        private const int CP_NOCLOSE_BUTTON = 0x200;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private void btProcessDoc_Click(object sender, EventArgs e)
        {
            int Reply;
            short hConnect;
            byte[] UnitCfg = new byte[8];

            hConnect = 0;
            fProcessDoc = true;

            Reply = TryConnect(ref hConnect);
            if (Reply == CtsLs.LsReply.LS_OKAY)
            {
                EnableButton(false);

                Reply = CtsLs.LSUnitIdentify(hConnect, 0,
                                             UnitCfg,
                                             IntPtr.Zero, //strLsModel,
                                             IntPtr.Zero, //strFwVersion,
                                             IntPtr.Zero, //Date_Fw,
                                             IntPtr.Zero, //strUnitID,
                                             IntPtr.Zero, // BoardVersion
                                             IntPtr.Zero, //DecoderExpVersion,
                                             IntPtr.Zero, //strInkJetVersion,
                                             IntPtr.Zero, //FeederVersion,
                                             IntPtr.Zero, //SorterVersion,
                                             IntPtr.Zero, //Motorversion,
                                             IntPtr.Zero, //Reserved1,
                                             IntPtr.Zero);//Reserved2);
                do
                {
                    if (TestDocPresent(hConnect, ref Reply))
                    {
                        if (stParAppl.ScanCard || stParAppl.NumDoc == 1)
                        {
                            Reply = DoSingleDocHandle(hConnect, UnitCfg);
                            if (stParAppl.NumDoc == 1)
                                fProcessDoc = false;
                            // Send reset for Fw problem
                            CtsLs.LSReset(hConnect, 0, (short)CtsLs.Reset.RESET_ERROR);
                        }
                        else
                            Reply = DoAutoDocHandle(hConnect, UnitCfg);

                        if (Reply == CtsLs.LsReply.LS_FEEDER_EMPTY)
                            btRear.Text = "Show Rear";
                        else if (Reply == CtsLs.LsReply.LS_OKAY)
                            btRear.Text = "Show Rear";
                        else //if (Reply != CtsLs.LsReply.LS_OKAY)
                            fProcessDoc = false;
                    }
                    else
                    {
                        if (Reply != CtsLs.LsReply.LS_OKAY && Reply != CtsLs.LsReply.LS_FEEDER_EMPTY)
                        {
                            // Visualizzo l'errore ed esco !
                            CheckReply(Reply, "LSUnitStatus");
                            fProcessDoc = false;
                        }
                        else
                            System.Threading.Thread.Sleep(400);
                    }
                    
                    // Refresh the form
                    Application.DoEvents();

                } while( fProcessDoc == true );

                Reply = CtsLs.LSDisconnect(hConnect, 0);

                EnableButton(true);
            }
            else
                CheckReply(Reply, "LSConnect");
        }

        private void btStopDoc_Click(object sender, EventArgs e)
        {
            fProcessDoc = false;
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            int Reply;
            short hConnect;

            byte[] UnitCfg = new byte[4];
            IntPtr strLsModel = Marshal.AllocHGlobal(20);
            IntPtr strFwVersion = Marshal.AllocHGlobal(20);
            IntPtr Date_Fw = Marshal.AllocHGlobal(20);
            IntPtr strUnitID = Marshal.AllocHGlobal(20);
            IntPtr strInkJetVersion = Marshal.AllocHGlobal(20);
            IntPtr DecoderExpVersion = Marshal.AllocHGlobal(20);


            hConnect = 0;

            Reply = TryConnect(ref hConnect);
            if (Reply == CtsLs.LsReply.LS_OKAY || Reply == CtsLs.LsReply.LS_ALREADY_OPEN || Reply == CtsLs.LsReply.LS_TRY_TO_RESET)
            {
                Reply = CtsLs.LSReset(hConnect, 0, (short)CtsLs.Reset.RESET_PATH);

                if (Reply == CtsLs.LsReply.LS_OKAY)
                {
                    MessageBox.Show("Reset ok !", TITLE_POPUP);
                }
                else
                    CheckReply(Reply, "LSReset");

                Reply = CtsLs.LSDisconnect(hConnect, 0);
            }
            else
                CheckReply(Reply, "LSConnect");
        }

        private void btRear_Click(object sender, EventArgs e)
        {
            IntPtr ImageShowed;
            Bitmap pBitmap = null;

            if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_ALL_IMAGE)
            {
                if (btRear.Text.CompareTo("Show Rear") == 0)
                {
                    btRear.Text = "Show Front";
                    ImageShowed = Save_RearImage;
                }
                else
                {
                    btRear.Text = "Show Rear";
                    ImageShowed = Save_FrontImage;
                }

                //// Show the immage
                CtsLs.BITMAPINFOHEADER pBmp = (CtsLs.BITMAPINFOHEADER)Marshal.PtrToStructure(ImageShowed, typeof(CtsLs.BITMAPINFOHEADER));

                pBitmap = new Bitmap(pBmp.biWidth, pBmp.biHeight, PixelFormat.Format24bppRgb);

                //                BitmapData bmpData = pBitmap.LockBits(new Rectangle(0, 0, pBitmap.Width, pBitmap.Height), ImageLockMode.WriteOnly, pBitmap.PixelFormat);
                int xx, yy;
                Int32 diff, WidthBytes = pBmp.biWidth;
                if ((diff = WidthBytes % 4) != 0)
                    WidthBytes += (4 - diff);
                Int32 row, col;
                row = pBmp.biHeight - 1;
                col = pBmp.biWidth - 1;
                for (yy = 0; yy < pBmp.biHeight; yy++)
                {
                    for (xx = 0; xx < pBmp.biWidth; xx++)
                    {
                        byte Pixel = Marshal.ReadByte((IntPtr)((int)ImageShowed + 1064 + ((yy * WidthBytes) + xx)));
                        Color Pixel24;
                        Pixel24 = Color.FromArgb((Pixel * 256 * 256) + (Pixel * 256) + Pixel);
                        pBitmap.SetPixel(xx, (row - yy), Pixel24);
                        //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy)), Pixel);
                        //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy) + 1), Pixel);
                        //Marshal.WriteByte((IntPtr)((int)bmpData.Scan0 + (xx * yy) + 2), Pixel);
                    }
                }
                //               CopyMemory(bmpData.Scan0, (IntPtr)((int)BufFrontImage + 1064), pBmp.biSizeImage);
                //                pBitmap.UnlockBits(bmpData);

                if (pbImage.Image != null)
                {
                    pbImage.Image.Dispose();
                    //    //pbImage.Image = null;
                }
                pbImage.Image = pBitmap;
            }

            // Refresh the form
            Application.DoEvents();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
