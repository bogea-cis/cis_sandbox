﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Ls_Test
{
    public partial class FormOptions : Form
    {
        public FormOptions()
        {
            InitializeComponent();
        }

        private void FormOptions_Load(object sender, EventArgs e)
        {
            // ScanMode
            if( Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_BW )
                rbBW200.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_16_GRAY_100)
                rb16gray100.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_16_GRAY_200)
                rb16gray200.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_16_GRAY_300)
                rb16gray300.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_100)
                rb256gray100.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_200)
                rb256gray200.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_300)
                rb256gray300.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_COLOR_100)
                rbColor100.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_COLOR_200)
                rbColor200.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_COLOR_300)
                rbColor300.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR100_AND_UV)
                rbUV100.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR200_AND_UV)
                rbUV200.Select();
            else if (Form1.stParAppl.ScanMode == (short)CtsLs.ScanMode.SCAN_MODE_256GR300_AND_UV)
                rbUV300.Select();

            // Side
            if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_ALL_IMAGE)
                cbSide.SelectedIndex = 0;
            else if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_FRONT_IMAGE)
                cbSide.SelectedIndex = 1;
            else if (Form1.stParAppl.Side == (char)CtsLs.Side.SIDE_NONE_IMAGE)
                cbSide.SelectedIndex = 2;

            // Codeline
            if (Form1.stParAppl.CodelineMICR == CtsLs.CodeLineType.READ_CODELINE_HW_MICR)
                cbMICR.Checked = true;
            if (Form1.stParAppl.CodelineMICR == CtsLs.CodeLineType.READ_CODELINE_E13B_MICR_WITH_OCR)
                cbMOCR.Checked = true;
            if (Form1.stParAppl.CodelineOCR != CtsLs.CodeLineType.NO_READ_CODELINE)
                cbOCR.Checked = true;
            if (Form1.stParAppl.BarcodeType != CtsLs.CodeLineType.NO_READ_CODELINE)
                cbBarcode.Checked = true;

            // Num Doc.
            if (Form1.stParAppl.NumDoc == 0)
                rbAllDoc.Checked = true;
            else
            {
                rbNum.Checked = true;
                tbNumDoc.Text = Form1.stParAppl.NumDoc.ToString();
            }

            // Wait Timeout
            if (Form1.stParAppl.WaitTimeout == true)
                cbWaitTimeout.Checked = true;

            // Linear Entrance
            if ((Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS40") == true) || (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS150") == true))
            {
                cbLinear.Enabled = true;
                if (Form1.stParAppl.ScanCard == true)
                {
                    cbLinear.Checked = true;
                }
            }

            // Low Speed
            if (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS150"))
            {
                cbLowSpeed.Enabled = true;
                if (Form1.stParAppl.LowSpeed == (short)CtsLs.LsSpeed.SPEED_STAMP)
                {
                    cbLowSpeed.Checked = true;
                }
            }

            // Printer Setting
            if ((((Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS100") == true) || (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS515") == true)) && ((Form1.UnitCfg[1] & 0x08) == 0x08)) ||
                (((Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS40") == true) || (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS150") == true)) && ((Form1.UnitCfg[0] & 0x08) == 0x08)))
            {
                gbEndorse.Enabled = true;
                if (Form1.stParAppl.PrintValidate == CtsLs.PrintFont.PRINT_FONT_NORMAL)
                    cbFontPrint.SelectedIndex = 1;
                else if (Form1.stParAppl.PrintValidate == CtsLs.PrintFont.PRINT_FONT_BOLD)
                    cbFontPrint.SelectedIndex = 2;
                else if (Form1.stParAppl.PrintValidate == CtsLs.PrintFont.PRINT_FONT_NORMAL_15)
                    cbFontPrint.SelectedIndex = 3;
                else // if (Form1.stParAppl.PrintValidate == CtsLs.PrintFont.PRINT_FONT_NORMAL)
                    cbFontPrint.SelectedIndex = 0;

                tbPrintString.Text = Form1.stParAppl.Endorse_str;
            }

            // Double Leafing
            if ((Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS100") == true) || (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS150") == true) || (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS515") == true))
            {
                gbDoubleLafing.Enabled = true;
                tbSensibility.Text = Form1.stParAppl.DL_Value.ToString();
                tbMin.Text = Form1.stParAppl.DL_MinDoc.ToString();
                tbMax.Text = Form1.stParAppl.DL_MaxDoc.ToString();
                if( Form1.stParAppl.DL_Type == (int)CtsLs.DoubleLeafing.DOUBLE_LEAFING_WARNING )
                    cbWarning.Checked = true;
                else if (Form1.stParAppl.DL_Type == (int)CtsLs.DoubleLeafing.DOUBLE_LEAFING_DISABLE)
                    cbDisabled.Checked = true;
            }
        }

        bool fCheckChar = true;

        private void tbX_TextChanged(object sender, EventArgs e)
        {
            char[] text = new char[4];

            if (fCheckChar)
            {
                int nrChar = tbX.Text.Length;

                while (nrChar > 0)
                {
                    text = tbX.Text.ToCharArray(nrChar - 1, 1);
                    if ((text[0] < '0' || text[0] > '9') && (text[0] != '-'))
                    {
                        fCheckChar = false;
                        // Cancel the last char
                        tbX.Text = tbX.Text.Remove(nrChar);
                        tbX.Select(nrChar, 0);
                    }
                    // Decrease the number of char to check
                    nrChar--;
                }
            }
            else
                fCheckChar = true;
        }

        public enum CoordinateFor : short
        {
            COORDINATE_NO,
            COORDINATE_OCR,
            COORDINATE_BARCODE,
        }
        CoordinateFor fCoordinateFor = CoordinateFor.COORDINATE_NO;

        private void btViewOCR_Click(object sender, EventArgs e)
        {
            fCoordinateFor = CoordinateFor.COORDINATE_OCR;

            btViewOCR.Enabled = true;
            gbCoordinate.Enabled = true;
            tbX.Text = Form1.stParAppl.Codeline_Sw_x.ToString();
            tbY.Text = Form1.stParAppl.Codeline_Sw_x.ToString();
            tbWidth.Text = Form1.stParAppl.Codeline_Sw_w.ToString();
            tbHeight.Text = Form1.stParAppl.Codeline_Sw_h.ToString();
            // Compile the Combo
            cbOCRfont.Items.Clear();
            cbOCRfont.Items.Add("OCRA");
            cbOCRfont.Items.Add("OCRB Num.");
            cbOCRfont.Items.Add("OCRB AlfaNum.");
            cbOCRfont.Items.Add("OCRB Italy");
            cbOCRfont.Items.Add("E13B");
            cbOCRfont.Items.Add("E13B switch OCRB");
            if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_OCRA)
                cbOCRfont.SelectedIndex = 0;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_NUM)
                cbOCRfont.SelectedIndex = 1;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_ALFANUM)
                cbOCRfont.SelectedIndex = 2;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_ITALY)
                cbOCRfont.SelectedIndex = 3;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_E13B)
                cbOCRfont.SelectedIndex = 4;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_CODELINE_SW_E13B_X_OCRB)
                cbOCRfont.SelectedIndex = 5;
            else
                cbOCRfont.SelectedIndex = 2;
        }

        private void btViewBarcode_Click(object sender, EventArgs e)
        {
            fCoordinateFor = CoordinateFor.COORDINATE_BARCODE;

            btViewBarcode.Enabled = true;
            gbCoordinate.Enabled = true;
            tbX.Text = Form1.stParAppl.Barcode_Sw_x.ToString();
            tbY.Text = Form1.stParAppl.Barcode_Sw_x.ToString();
            tbWidth.Text = Form1.stParAppl.Barcode_Sw_w.ToString();
            tbHeight.Text = Form1.stParAppl.Barcode_Sw_h.ToString();
            // Compile the Combo
            cbOCRfont.Items.Clear();
            cbOCRfont.Items.Add("Barcode 2 of 5");
            cbOCRfont.Items.Add("Barcode CODE 39");
            cbOCRfont.Items.Add("Barcode CODE 128");
            if (Form1.stParAppl.BarcodeType == CtsLs.CodeLineType.READ_BARCODE_2_OF_5)
                cbOCRfont.SelectedIndex = 0;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_BARCODE_CODE39)
                cbOCRfont.SelectedIndex = 1;
            else if (Form1.stParAppl.CodelineOCR == CtsLs.CodeLineType.READ_BARCODE_CODE128)
                cbOCRfont.SelectedIndex = 2;
            else
                cbOCRfont.SelectedIndex = 0;
        }

        private void cbOCR_CheckedChanged(object sender, EventArgs e)
        {
            if (cbOCR.Checked == true)
                btViewOCR_Click(sender, e);
            else
            {
                btViewOCR.Enabled = false;
                gbCoordinate.Enabled = false;
            }
        }

        private void cbBarcode_CheckedChanged(object sender, EventArgs e)
        {
            if (cbBarcode.Checked == true)
                btViewBarcode_Click(sender, e);
            else
            {
                btViewBarcode.Enabled = false;
                gbCoordinate.Enabled = false;
            }
        }

        private void btSetCoordinate_Click(object sender, EventArgs e)
        {
            if (fCoordinateFor == CoordinateFor.COORDINATE_OCR)
            {
                Form1.stParAppl.Codeline_Sw_x = (float)Convert.ToDouble(tbX.Text);
                Form1.stParAppl.Codeline_Sw_x = (float)Convert.ToDouble(tbY.Text);
                Form1.stParAppl.Codeline_Sw_w = (float)Convert.ToDouble(tbWidth.Text);
                Form1.stParAppl.Codeline_Sw_h = (float)Convert.ToDouble(tbHeight.Text);

                switch (cbOCRfont.SelectedIndex)
                {
                    case 0:
                        Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.READ_CODELINE_SW_OCRA;
                        break;
                    case 1:
                        Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_NUM;
                        break;
                    case 2:
                        Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_ALFANUM;
                        break;
                    case 3:
                        Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.READ_CODELINE_SW_OCRB_ITALY;
                        break;
                    case 4:
                        Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.READ_CODELINE_SW_E13B;
                        break;
                    case 5:
                        Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.READ_CODELINE_SW_E13B_X_OCRB;
                        break;
                }
            }
            else if (fCoordinateFor == CoordinateFor.COORDINATE_BARCODE)
            {
                Form1.stParAppl.Barcode_Sw_x = (float)Convert.ToDouble(tbX.Text);
                Form1.stParAppl.Barcode_Sw_x = (float)Convert.ToDouble(tbY.Text);
                Form1.stParAppl.Barcode_Sw_w = (float)Convert.ToDouble(tbWidth.Text);
                Form1.stParAppl.Barcode_Sw_h = (float)Convert.ToDouble(tbHeight.Text);

                switch (cbOCRfont.SelectedIndex)
                {
                    case 0:
                        Form1.stParAppl.BarcodeType = CtsLs.CodeLineType.READ_BARCODE_2_OF_5;
                        break;
                    case 1:
                        Form1.stParAppl.BarcodeType = CtsLs.CodeLineType.READ_BARCODE_CODE39;
                        break;
                    case 2:
                        Form1.stParAppl.BarcodeType = CtsLs.CodeLineType.READ_BARCODE_CODE128;
                        break;
                }
            }
        }

        private void cbLinear_CheckedChanged(object sender, EventArgs e)
        {
            if (Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS40") || Marshal.PtrToStringAnsi(Form1.LsModel).Contains("LS150"))
            {
                if (cbLinear.Checked)
                {
                    rbBW200.Enabled = false;
                    rb16gray100.Enabled = false;
                    rb16gray200.Enabled = false;
                    rb256gray100.Enabled = false;
                    rb256gray200.Enabled = false;
                    rbColor100.Enabled = false;
                    rbColor200.Enabled = false;
                    rbColor300.Enabled = false;
                    rbUV100.Enabled = false;
                    rbUV200.Enabled = false;
                    rbUV300.Enabled = false;

                    rb256gray300.Checked = true;
                }
                else
                {
                    rbBW200.Enabled = true;
                    rb16gray100.Enabled = true;
                    rb16gray200.Enabled = true;
                    rb256gray100.Enabled = true;
                    rb256gray200.Enabled = true;
                    rbColor100.Enabled = true;
                    rbColor200.Enabled = true;
                    rbColor300.Enabled = true;
                    rbUV100.Enabled = true;
                    rbUV200.Enabled = true;
                    rbUV300.Enabled = true;
                }
            }
        }

        private void btOk_Click(object sender, EventArgs e)
        {
            // ScanMode
            if( rbBW200.Checked == true )
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_BW;
            else if( rb16gray100.Checked == true )
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_16_GRAY_100;
            else if (rb16gray200.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_16_GRAY_200;
            else if (rb16gray300.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_16_GRAY_300;
            else if (rb256gray100.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_100;
            else if (rb256gray200.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_200;
            else if (rb256gray300.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256_GRAY_300;
            else if (rbColor100.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_COLOR_100;
            else if (rbColor200.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_COLOR_200;
            else if (rbColor300.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_COLOR_300;
            else if (rbUV100.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256GR100_AND_UV;
            else if (rbUV200.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256GR200_AND_UV;
            else if (rbUV300.Checked == true)
                Form1.stParAppl.ScanMode = (short)CtsLs.ScanMode.SCAN_MODE_256GR300_AND_UV;

            // Side
            switch( cbSide.SelectedIndex )
            {
                case 0:
                    Form1.stParAppl.Side = (char)CtsLs.Side.SIDE_ALL_IMAGE;
                    break;
                case 1:
                    Form1.stParAppl.Side = (char)CtsLs.Side.SIDE_FRONT_IMAGE;
                    break;
                case 2:
                    Form1.stParAppl.Side = (char)CtsLs.Side.SIDE_NONE_IMAGE;
                    break;
            }

            // Codeline
            if (cbMICR.Checked)
                Form1.stParAppl.CodelineMICR = CtsLs.CodeLineType.READ_CODELINE_HW_MICR;
            else if (cbMOCR.Checked )
                Form1.stParAppl.CodelineMICR = CtsLs.CodeLineType.READ_CODELINE_E13B_MICR_WITH_OCR;
            if( ! cbOCR.Checked)
                Form1.stParAppl.CodelineOCR = CtsLs.CodeLineType.NO_READ_CODELINE;
            if( ! cbBarcode.Checked)
                Form1.stParAppl.BarcodeType = CtsLs.CodeLineType.NO_READ_CODELINE;

            // Num Doc.
            if (rbNum.Checked)
                Form1.stParAppl.NumDoc = Convert.ToInt16(tbNumDoc.Text);
            else
                Form1.stParAppl.NumDoc = 0;

            // Wait Timeout
            if (cbWaitTimeout.Checked)
                Form1.stParAppl.WaitTimeout = true;

            // Linear Entrance
            if (cbLinear.Checked)
                Form1.stParAppl.ScanCard = true;

            // Low Speed
            if (cbLowSpeed.Checked)
                Form1.stParAppl.LowSpeed = (short)CtsLs.LsSpeed.SPEED_STAMP;
            else
                Form1.stParAppl.LowSpeed = (short)CtsLs.LsSpeed.SPEED_DEFAULT;

            // Printer Setting
            switch( cbFontPrint.SelectedIndex )
            {
                case 0:
                    Form1.stParAppl.PrintValidate = CtsLs.PrintFont.PRINT_NO_STRING;
                    break;
                case 1:
                    Form1.stParAppl.PrintValidate = CtsLs.PrintFont.PRINT_FONT_NORMAL;
                    break;
                case 2:
                    Form1.stParAppl.PrintValidate = CtsLs.PrintFont.PRINT_FONT_BOLD;
                    break;
                case 3:
                    Form1.stParAppl.PrintValidate = CtsLs.PrintFont.PRINT_FONT_NORMAL_15;
                    break;
            }
            Form1.stParAppl.Endorse_str = tbPrintString.Text;

            // Double Leafing
            Form1.stParAppl.DL_Value = Convert.ToInt16(tbSensibility.Text);
            Form1.stParAppl.DL_MinDoc = Convert.ToInt32(tbMin.Text);
            Form1.stParAppl.DL_MaxDoc = Convert.ToInt32(tbMax.Text);
            if( cbWarning.Checked )
                Form1.stParAppl.DL_Type = (int)CtsLs.DoubleLeafing.DOUBLE_LEAFING_WARNING;
            else if (cbDisabled.Checked )
                Form1.stParAppl.DL_Type = (int)CtsLs.DoubleLeafing.DOUBLE_LEAFING_DISABLE;
            else
                Form1.stParAppl.DL_Type = (int)CtsLs.DoubleLeafing.DOUBLE_LEAFING_ERROR;

            this.Close();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
