﻿namespace Ls_Test
{
    partial class FormHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbHistory = new System.Windows.Forms.GroupBox();
            this.lbDocProcessed = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btExit = new System.Windows.Forms.Button();
            this.gbHistory.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbHistory
            // 
            this.gbHistory.Controls.Add(this.lbDocProcessed);
            this.gbHistory.Controls.Add(this.label1);
            this.gbHistory.Location = new System.Drawing.Point(12, 12);
            this.gbHistory.Name = "gbHistory";
            this.gbHistory.Size = new System.Drawing.Size(428, 109);
            this.gbHistory.TabIndex = 1;
            this.gbHistory.TabStop = false;
            // 
            // lbDocProcessed
            // 
            this.lbDocProcessed.AutoSize = true;
            this.lbDocProcessed.Location = new System.Drawing.Point(330, 46);
            this.lbDocProcessed.Name = "lbDocProcessed";
            this.lbDocProcessed.Size = new System.Drawing.Size(72, 17);
            this.lbDocProcessed.TabIndex = 1;
            this.lbDocProcessed.Text = "00000000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(255, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nr. Documents Processed Successfully";
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(189, 157);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 23);
            this.btExit.TabIndex = 2;
            this.btExit.Text = "E&xit";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // FormHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 205);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.gbHistory);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "History";
            this.Load += new System.EventHandler(this.FormHistory_Load);
            this.gbHistory.ResumeLayout(false);
            this.gbHistory.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbHistory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbDocProcessed;
        private System.Windows.Forms.Button btExit;
    }
}